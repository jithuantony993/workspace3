﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Insert Into the EC_UserDetails Table.
				  2)Change SessionID Column Into ReferenceID.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserCreditCardValidationLog]
@CIAMID INT,
@CardNumber VARCHAR(30),
@ValidationStatus SMALLINT,		
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@UserAgent VARCHAR(200),
@BrowserName VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_EC_Insert_UserCreditCardValidationLog'
	
	INSERT INTO dbo.EC_UserCreditCardValidationLog
	(CIAMID,CardNumber,ValidationStatus,RemoteIPAddress,BrowserVersion,ReferenceID,CreatedOn,CreatedBy,UserAgent,BrowserName)
	VALUES
	(@CIAMID,@CardNumber,@ValidationStatus
	,@RemoteIPAddress,@BrowserVersion,@ReferenceID,@CreatedOn,@CreatedBy,@UserAgent,@BrowserName)
END