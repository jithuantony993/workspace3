﻿/*
Created Date : 08/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the VAOL IDProofeduser.

Modified Date : 16/03/2023
Modified By : Kalirajan
Summary : Some Changes in that Proc. Create New Table UserDetails.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Modify_VAOLIDProofedUser]
@CIAMID INT,
@SSNDOB VARCHAR(64),
@VAOLWorkspaceID UNIQUEIDENTIFIER,
@UCID VARCHAR(256),	
@IDPChannel VARCHAR(10) = '11',
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_IDP_Modify_VAOLIDProofedUser',
		@MDMFeedStatus SMALLINT = 0,
		@Activation_Status TINYINT = 100 , 		
		@ContextInfo VARBINARY(128),
		@a_VAOLWorkspaceID VARCHAR(600),
		@a_EIN VARCHAR(150),
		@a_VAOLTaxYear VARCHAR(100),
		@EINVerified INT = 0,
		@i_VAOLWorkspaceID VARCHAR(600),
		@i_EIN VARCHAR(150),
		@i_VAOLTaxYear VARCHAR(100),
		@v_VAOLWorkspaceID VARCHAR(600),
		@v_EIN VARCHAR(150),
		@v_VAOLTaxYear VARCHAR(100)

	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)
	SET IdHash = @SSNDOB,
		AccountStatusInd = @Activation_Status,
		IDVerified=0,
		ModifiedTS = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE CIAMID = @CIAMID

	IF NOT EXISTS(SELECT IDPChannel FROM [IDP_User] WITH(NOLOCK)	WHERE CIAMID = @CIAMID)
	BEGIN
		INSERT INTO [dbo].[IDP_User](CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)  
		VALUES (@CIAMID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@IDPChannel)  
	END
	ELSE
	BEGIN
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy,
			IDPChannel = CASE WHEN (CHARINDEX (@idpchannel, [IDPChannel]) = 0 )
							     THEN CONCAT([IDPChannel], ',' , @IDPChannel)
			                     ELSE [IDPChannel] END 
		WHERE CIAMID=@CIAMID
	END

	--Fetch values from idp_user
	SELECT @i_VAOLWorkspaceID = VAOL_WOrkspaceID,
			@i_EIN = EIN,
			@i_VAOLTaxYear = [VAOLTaxYear]
	FROM [dbo].[IDP_User] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID 


	DECLARE @VAOL_UserDetails TABLE(SSNDOB VARCHAR(64),VAOLWorkspaceID UNIQUEIDENTIFIER,EIN INT,VAOLTaxYear INT)

	INSERT INTO @VAOL_UserDetails(SSNDOB,VAOLWorkspaceID,EIN,VAOLTaxYear)
	SELECT SSNDOB,VAOLWorkspaceID,EIN,VAOLTaxYear
	FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK)
	WHERE SSNDOB = @SSNDOB

	
	SELECT @a_VAOLWorkspaceID = COALESCE(@a_VAOLWorkspaceID + ',','') + cast(VAOLWorkspaceID as varchar(36)) FROM @VAOL_UserDetails
	SELECT @a_EIN = COALESCE(@a_EIN + ',','') + ISNULL(cast(EIN as varchar(9)),'NULL') FROM @VAOL_UserDetails
	SELECT @a_VAOLTaxYear = COALESCE(@a_VAOLTaxYear + ',', '') + ISNULL(cast(VAOLTaxYear as varchar(4)),'NULL') FROM @VAOL_UserDetails
	SELECT TOP 1 @EINVerified = EIN FROM @VAOL_UserDetails WHERE EIN IS NOT NULL

	IF(ISNULL(@a_VAOLWorkspaceID,'') <> '')
	BEGIN

		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET VAOL_WOrkspaceID =  @a_VAOLWorkspaceID,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
			
		INSERT INTO [dbo].[VAOL_WorkSpaceIDLog](CIAMID,SSNDOB,VAOLWorkSpaceID,CreatedOn,CreatedBy, OldVAOLWorkspaceID)
		SELECT @CIAMID,@SSNDOB,@a_VAOLWorkspaceID,@CreatedOn,@CreatedBy,@i_VAOLWorkspaceID 
	END

	IF(ISNULL(@a_EIN,'') <> '')	
	BEGIN
		
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET EIN = @a_EIN,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID

		INSERT INTO [dbo].[VAOL_EINLog](CIAMID,SSNDOB,EIN,CreatedOn,CreatedBy)
		SELECT @CIAMID,@SSNDOB,@a_EIN,@CreatedOn,@CreatedBy 
	END

	IF(ISNULL(@a_VAOLTaxYear,'') <> '')	
	BEGIN
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET [VAOLTaxYear] = @a_VAOLTaxYear,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
			
		INSERT INTO [dbo].[VAOL_TaxYearLog](CIAMID,SSNDOB,VAOLTaxYear,CreatedOn,CreatedBy)						
		SELECT @CIAMID,@SSNDOB,@a_VAOLTaxYear,@CreatedOn,@CreatedBy 
	END
	
	UPDATE [dbo].[VAOL_UserDetails] WITH(ROWLOCK)
	SET IsActive = 0,
		ModifiedOn = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE SSNDOB = @SSNDOB AND VAOLWorkspaceID = @VAOLWorkspaceID	
END