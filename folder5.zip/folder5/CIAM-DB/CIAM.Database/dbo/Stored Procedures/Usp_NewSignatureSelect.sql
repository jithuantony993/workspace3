﻿Create PROCEDURE [dbo].[Usp_NewSignatureSelect] 

AS
BEGIN	
   SELECT
          idp.UCID,
		  idp.UserID,
		  idp.Signature,
		  idp.DoB,
		  idp.SSN
    FROM   [dbo].[IDP_User]  idp WITH (NOLOCK)

END