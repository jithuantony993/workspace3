﻿/*
Created Date : 31/01/2023
Created By : Kalirajan
Changes Summary : To Insert the Wave UserDetails
*/
CREATE PROCEDURE [dbo].[Usp_Wave_Insert_UserDetails]
@CIAMID INT = NULL,
@WaveID varchar(150), 
@Login varchar(255) = NULL,
@WaveAccessToken varchar(255) ,
@WaveRefreshToken varchar(255) = NULL,
@PageLocation varchar(50) = NULL,
@CreatedOn DATETIME= NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Wave_Insert_UserDetails'
	
	IF EXISTS(SELECT 1 FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) 
	WHERE WaveID = @WaveID AND ISNULL(CIAMID,0) = 0 AND ISNULL(@CIAMID,0) > 0)
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) WHERE WaveID = @WaveID AND CIAMID=@CIAMID AND CIAMID>0)
		BEGIN
			UPDATE [dbo].[Wave_UserDetails] WITH(ROWLOCK)
			SET CIAMID=@CIAMID,
				ModifiedOn = @CreatedOn,
				ModifiedBy = @CreatedBy
			WHERE WaveID = @WaveID AND ISNULL(CIAMID,0) = 0 
		END 
	END
	ELSE IF NOT EXISTS(SELECT 1 FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) 
	WHERE WaveID = @WaveID AND (ISNULL(CIAMID,0)=0 OR CIAMID=@CIAMID))
	BEGIN		
		INSERT INTO [dbo].[Wave_UserDetails](CIAMID,WaveID,[Login],WaveAccessToken,WaveRefreshToken,PageLocation,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy)
		VALUES (@CIAMID,@WaveID,@Login,@WaveAccessToken,@WaveRefreshToken,@PageLocation,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy)
	END
END