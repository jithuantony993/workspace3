﻿/*
Created Date : 17/02/2023
Created By: Kalirajan
Summary : To Get the DeviceVerifyStatus in that Proc.
*/
CREATE PROC [dbo].[Usp_Get_DeviceVerifyStatus] @CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @DeviceVerifyStatus BIT

	SELECT @DeviceVerifyStatus=DeviceVerifyStatus FROM [dbo].[DeviceVerify] WHERE CIAMID=@CIAMID

	SELECT @DeviceVerifyStatus 'DeviceVerifyStatus'

	SELECT CASE WHEN @DeviceVerifyStatus IS NULL THEN '0' ELSE @DeviceVerifyStatus END 'DeviceVerifyStatus'
END