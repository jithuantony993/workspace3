﻿/*
Created Date : 07/14/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Verify the User Signature.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Verify_UserSignatureExists]
@CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	IF(SELECT ISNULL(IDProofedHashValue,'') FROM IDP_User WITH(NOLOCK)	WHERE CIAMID = @CIAMID) <> ''
	BEGIN
		SELECT 1 AS ValidationStatus
	END
	ELSE
	BEGIN
		SELECT 0 AS ValidationStatus
	END
END