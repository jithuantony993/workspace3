﻿/*
Created Date : 07/15/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Insert Into the UserSignInCodeLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_Insert_UserSignInCodeLog]
@CIAMID INT,
@SignInCode INT,
@SignInCodeModifiedOn DATETIME2,
@ReferenceID VARCHAR(50),
@IsActive SMALLINT,
@ModifiedOn DATETIME2,
@ModifiedBy VARCHAR(50),
@MachineIdentifier VARCHAR(40)= NULL,				
@BrowserAgentIdentifier INT= NULL,						
@RemoteIPAddress VARCHAR(20)= NULL,						
@BrowserVersion VARCHAR(200)= NULL,				
@SignInChannel TINYINT= NULL,
@MessageChannel TINYINT,
@CreatedOn DATETIME2,
@CreatedBy VARCHAR(50),
@PageLocation VARCHAR(50) = NULL,		
@OOBChannel VARCHAR(100) = NULL	
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO UserSignInCodeLog(CIAMID,SignInCode,SignInCodeModifiedOn,ReferenceID,IsActive,ModifiedOn,ModifiedBy,
	MachineIdentifier,BrowserAgentIdentifier,RemoteIPAddress,BrowserVersion,CreatedOn,CreatedBy,SignInChannel,MessageChannel,PageLocation,OOBChannel)	
	VALUES(@CIAMID,@SignInCode,@SignInCodeModifiedOn,@ReferenceID,@IsActive,@ModifiedOn,@ModifiedBy,
	@MachineIdentifier,@BrowserAgentIdentifier,@RemoteIPAddress,@BrowserVersion,@CreatedOn,@CreatedBy,@SignInChannel,@MessageChannel,@PageLocation,@OOBChannel)
END
GO
