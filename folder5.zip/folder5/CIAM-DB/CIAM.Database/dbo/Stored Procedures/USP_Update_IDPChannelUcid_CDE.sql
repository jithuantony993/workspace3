﻿/*
Created Date : 02/13/2023
Created By : Jonathan Carpenter
Changes Summary : Created new procedure to update IDPChannel and Ucid for CDE/KBA EEP events
*/

CREATE PROCEDURE [dbo].[USP_Update_IDPChannelUcid_CDE]
 @CIAMID INT
,@UCID VARCHAR(256)
,@ENTRYUUID VARCHAR(256)
,@IDPChannel VARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedOn DATETIME2 = [dbo].[udf_Get_CST](SYSDATETIME()),
		    @CreatedBy VARCHAR(50) = 'USP_Update_IDPChannelUcid_CDE'

	-- Update/Create IDP channel in IDP_User
	IF NOT EXISTS(SELECT 1 FROM IDP_User WHERE CIAMID=@CIAMID )
	BEGIN
	INSERT INTO IDP_User(CIAMID,IDPChannel,CreatedOn,CreatedBy, ModifiedOn, ModifiedBy)
		VALUES(@CIAMID,@IDPChannel,@CreatedOn,@CreatedBy, @CreatedOn, @CreatedBy)
		EXEC [dbo].[Usp_Insert_CDEEventLog] @CIAMID,'2',@CreatedBy

	END
	ELSE IF EXISTS (SELECT IDPChannel FROM IDP_User WHERE CIAMID=@CIAMID AND (IDPSignature IS NULL OR IDPSignature = ''))
	BEGIN
		UPDATE IDP_User SET IDPChannel=CONCAT([IDPChannel], ',' , @IDPChannel),ModifiedOn = @CreatedOn,ModifiedBy = @CreatedBy 
		WHERE CIAMID=@CIAMID
		EXEC [dbo].[Usp_Insert_CDEEventLog] @CIAMID,'1',@CreatedBy
	END

	-- Update/Create Ucid in CIAMUserDetail
	IF NOT EXISTS(SELECT 1 FROM CIAMUserDetail WHERE CIAMID=@CIAMID)
	BEGIN
		INSERT INTO CIAMUserDetail(CIAMID,EntryUUID,CreatedTS, ModifiedTS, ModifiedBy,UCID)
		VALUES(@CIAMID, @ENTRYUUID, @CreatedOn, @CreatedOn, @CreatedBy, @UCID)
	END
	ELSE IF EXISTS (SELECT 1 FROM CIAMUserDetail WHERE @CIAMID=@CIAMID)
	BEGIN
		UPDATE CIAMUserDetail SET ModifiedTS=@CreatedOn, ModifiedBy=@CreatedBy, UCID=@UCID
		WHERE CIAMID=@CIAMID
	END
END
GO