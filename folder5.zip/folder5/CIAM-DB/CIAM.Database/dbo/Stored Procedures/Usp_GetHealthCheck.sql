﻿/*
Created Date : 04-025-20323
Created By : A.Stevens
Changes Summary : 1) Create sp for healthCheck in API's
*/
CREATE PROCEDURE [dbo].[Usp_GetHealthCheck]			
AS
BEGIN
SELECT TOP(1) * FROM CIAMUserDetail (NOLOCK) 
END