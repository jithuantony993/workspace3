﻿/*
Created Date : 07/14/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Get the User Details.
                  2)Instead Of Signature Column Changed into IDProofedHashValue.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Get_UserDetails]
@CIAMID INT = NULL,
@EntryUUID VARCHAR(255) = NULL
AS
BEGIN 
	IF ISNULL(@CIAMID,0) > 0
	BEGIN
		SELECT CIAMID,IDPSignature
		FROM IDP_User WITH(NOLOCK)
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		SELECT I.CIAMID,I.IDPSignature
		FROM CIAMUserDetail C WITH(NOLOCK)
		INNER JOIN IDP_User I WITH(NOLOCK) ON C.CIAMID = i.CIAMID
		WHERE EntryUUID = @EntryUUID	
	END
END
