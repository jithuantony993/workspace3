﻿/*
Created Date : 01/11/2022
Created by : Kalirajn
Changes Summary : to Update the UCID Value in CIAMUserDetail Table.
*/
CREATE PROCEDURE [dbo].[Usp_Update_UCID] @EntryUUID UNIQUEIDENTIFIER
,@UCID VARCHAR(256)
,@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Update_UCID'

	IF EXISTS(SELECT 1 FROM [dbo].[CIAMUserDetail] WHERE EntryUUID=@EntryUUID)
	BEGIN
		UPDATE [dbo].[CIAMUserDetail]
		SET UCID=@UCID,
		ModifiedTS = @CreatedOn,  
		ModifiedBy = @CreatedBy 
		WHERE EntryUUID=@EntryUUID
	END
	select @UCID, @EntryUUID, @CreatedOn
END