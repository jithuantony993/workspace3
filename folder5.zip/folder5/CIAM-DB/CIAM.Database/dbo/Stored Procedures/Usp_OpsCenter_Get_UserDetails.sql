﻿/*
	Created Date: 10/16/2023
	Created By: Teegan Swanson
	Summary: Gets certain user details to be displayed on the OpsCenter UI
	Modified Date: 10/27/2023
	Changes: Updated to include GUA Username for Potential Debug Cases and IDProofedStatus for additional cases
*/

CREATE PROCEDURE [dbo].[Usp_OpsCenter_Get_UserDetails]
	@Email VARCHAR(100),
	@UCID VARCHAR(256)
AS

BEGIN
	SET NOCOUNT ON;

	SELECT 
		CUD.CIAMID,
		CUD.Mobile,
		CUD.CreatedTS,
		CUD.[Login],
		CASE
			WHEN IDP.IDPSignature IS NOT NULL THEN 1
			ELSE 0
		END AS IDProofedStatus,
		CUD.LoginTS,
		IDP.IDPChannel,
		IDP.CreatedOn
	FROM [dbo].[CIAMUserDetail] CUD (NOLOCK)
		LEFT JOIN [dbo].[IDP_User] IDP (NOLOCK) ON CUD.CIAMID = IDP.CIAMID
	WHERE Email = @Email AND UCID = @UCID
END
