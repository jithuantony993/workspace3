﻿/*
Created Date : 31/01/2023
Created By : Kalirajan
Changes Summary : To Get the Tokens in That Sp.
*/
CREATE PROCEDURE [dbo].[Usp_Wave_Get_Token]
@CIAMID INT,
@WaveID VARCHAR(150)
AS
BEGIN
	SET NOCOUNT ON;
	
	SELECT WaveRefreshToken As 'WaveRefreshToken',WaveID As 'WaveID',CIAMID AS 'CIAMID'
	FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) 
	WHERE ((CIAMID = @CIAMID AND @CIAMID > 0) OR WaveID=@WaveID)
END