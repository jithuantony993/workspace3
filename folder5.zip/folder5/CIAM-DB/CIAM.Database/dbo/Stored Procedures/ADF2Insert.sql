﻿CREATE PROCEDURE [dbo].[ADF2Insert]
(
	@UDT_ADF2 [dbo].[UDT_ADF2] READONLY
)
AS
BEGIN
    SET NOCOUNT ON
		
	BEGIN TRY
	IF EXISTS (SELECT 1 FROM @UDT_ADF2 UDT WHERE UDT.IDPSignature IS NOT NULL)
	BEGIN
 		IF EXISTS (SELECT 1 FROM [dbo].[IDP_User] I INNER JOIN @UDT_ADF2 UDT ON I.CIAMID=UDT.IDPUserID)
			BEGIN
				UPDATE I
				SET  CIAMID = UDT_ADF2IDPUser.IDPUserID
					,CreatedOn = UDT_ADF2IDPUser.IDPCreatedOn
					,CreatedBy = UDT_ADF2IDPUser.IDPCreatedBy
					,ModifiedOn = UDT_ADF2IDPUser.IDPModifiedOn
					,ModifiedBy = UDT_ADF2IDPUser.IDPModifiedBy
					,IDPChannel = UDT_ADF2IDPUser.IDPChannel
					,IDPSignature = UDT_ADF2IDPUser.Signature_NewUserSignature
					,UserGUID = UDT_ADF2IDPUser.UserGUID_UserDetails
					,PaperlessWorkSpaceID = UDT_ADF2IDPUser.TaxWorkspaceID_UserDetails	
					,TaxReturnGUID = UDT_ADF2IDPUser.TaxReturnGUID_UserDetails
					,VAOL_WorkspaceID = UDT_ADF2IDPUser.VAOLWorkspaceID_UserDetails
					,VAOLTaxYear = UDT_ADF2IDPUser.VAOLTaxYear_UserDetails
					,EIN = UDT_ADF2IDPUser.EIN
				FROM [dbo].[IDP_User] I 
				INNER JOIN @UDT_ADF2 UDT_ADF2IDPUser 
				ON I.CIAMID=UDT_ADF2IDPUser.IDPUserID
			END
		ELSE
			BEGIN     
	       		INSERT INTO [dbo].[IDP_User](CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel,TaxReturnGUID,VAOL_WorkspaceID, VAOLTaxYear, EIN)        
	       		SELECT  UDT_ADF2IDPUser.IDPUserID,
	           			UDT_ADF2IDPUser.IDPSignature,
	           			UDT_ADF2IDPUser.IDPCreatedOn,
	           			UDT_ADF2IDPUser.IDPCreatedBy,
	           			UDT_ADF2IDPUser.IDPModifiedOn,
	           			UDT_ADF2IDPUser.IDPModifiedBy,
	           			UDT_ADF2IDPUser.IDPChannel,
						UDT_ADF2IDPUser.TaxReturnGUID_UserDetails,
						UDT_ADF2IDPUser.VAOLWorkspaceID_UserDetails,
						UDT_ADF2IDPUser.VAOLTaxYear_UserDetails,
						UDT_ADF2IDPUser.EIN
						FROM @UDT_ADF2 UDT_ADF2IDPUser
				LEFT JOIN [dbo].[IDP_User] I ON UDT_ADF2IDPUser.IDPUserID=I.CIAMID 
				WHERE I.CIAMID IS NULL 
				AND UDT_ADF2IDPUser.IDPUserID IS NOT NULL
	    	END 	
	END
	IF EXISTS (SELECT 1 FROM [dbo].[GA_UserKey] G INNER JOIN @UDT_ADF2 UDT_ADF2GA_UserKey ON G.CIAMID=UDT_ADF2GA_UserKey.UserID)
		BEGIN
			UPDATE G
			SET  CIAMID = UDT_ADF2GA_UserKey.UserID
				,GoogleKey = UDT_ADF2GA_UserKey.GoogleKey
				,RegistrationStatus=UDT_ADF2GA_UserKey.RegistrationStatus
				,ActivationStatus=UDT_ADF2GA_UserKey.ActivationStatus
				,CreatedOn = UDT_ADF2GA_UserKey.CreatedOn
				,CreatedBy = UDT_ADF2GA_UserKey.CreatedBy
				,ModifiedOn = UDT_ADF2GA_UserKey.ModifiedOn
				,ModifiedBy = UDT_ADF2GA_UserKey.ModifiedBy
			FROM [dbo].[GA_UserKey] G
			INNER JOIN @UDT_ADF2 UDT_ADF2GA_UserKey 
			ON G.CIAMID=UDT_ADF2GA_UserKey.UserID
		END
		
		BEGIN
       		INSERT INTO [dbo].[GA_UserKey](CIAMID,GoogleKey,RegistrationStatus,ActivationStatus,CreatedOn,CreatedBy,
           	ModifiedOn,ModifiedBy)        
       		SELECT  UDT_ADF2GA_UserKey.UserID,
           			UDT_ADF2GA_UserKey.GoogleKey,
					UDT_ADF2GA_UserKey.RegistrationStatus,
           			UDT_ADF2GA_UserKey.ActivationStatus,
           			UDT_ADF2GA_UserKey.CreatedOn,
           			UDT_ADF2GA_UserKey.CreatedBy,
           			UDT_ADF2GA_UserKey.ModifiedOn,
           			UDT_ADF2GA_UserKey.ModifiedBy
           	FROM @UDT_ADF2 UDT_ADF2GA_UserKey
			LEFT JOIN [dbo].[GA_UserKey] G ON UDT_ADF2GA_UserKey.UserID=G.CIAMID 
			WHERE G.CIAMID IS NULL AND UDT_ADF2GA_UserKey.UserID IS NOT NULL
		END
		
		-- UserIRSDetails
		IF EXISTS (SELECT 1 FROM [dbo].[UserIRSDetail] G INNER JOIN @UDT_ADF2 UDT_ADF2_UserIRSDetails ON G.CIAMID= UDT_ADF2_UserIRSDetails.UserID)
		BEGIN
			UPDATE G
			SET  
				CIAMID = UDT_ADF2_UserIRSDetails.UserID,
				MachineAuthentication = UDT_ADF2_UserIRSDetails.MachineAuthentication,
				PasswordResetCurrent = UDT_ADF2_UserIRSDetails.PasswordResetCurrent,
				PasswordResetLast = UDT_ADF2_UserIRSDetails.PasswordResetLast,
				EmailIDResetCurrent = UDT_ADF2_UserIRSDetails.EmailIDResetCurrent,
				EmailIDResetLast = UDT_ADF2_UserIRSDetails.EmailIDResetLast,
				MobilePhoneResetCurrent = UDT_ADF2_UserIRSDetails.MobilePhoneResetCurrent,
				MobilePhoneResetLast = UDT_ADF2_UserIRSDetails.MobilePhoneResetLast,
				IdentityProofingLevel = UDT_ADF2_UserIRSDetails.IdentityProofingLevel,
				TokenAuthenticationLevel = UDT_ADF2_UserIRSDetails.TokenAuthenticationLevel,
				EmailIDOOB = UDT_ADF2_UserIRSDetails.EmailIDOOB,
				MobilePhoneOOB = UDT_ADF2_UserIRSDetails.MobilePhoneOOB,
				AuthenticationReviewCode = UDT_ADF2_UserIRSDetails.AuthenticationReviewCode,
				IdentityAssuranceLevel = UDT_ADF2_UserIRSDetails.IdentityAssuranceLevel,
				CreatedTS = UDT_ADF2_UserIRSDetails.CreatedTS_UserIRSDetails,
				CreatedBy = UDT_ADF2_UserIRSDetails.CreatedBy_UserIRSDetails,
				ModifiedTS = UDT_ADF2_UserIRSDetails.ModifiedTS_UserIRSDetails,
				ModifiedBy = UDT_ADF2_UserIRSDetails.ModifiedBy_UserIRSDetails
					
			FROM [dbo].[UserIRSDetail] G
			INNER JOIN @UDT_ADF2 UDT_ADF2_UserIRSDetails 
			ON G.CIAMID = UDT_ADF2_UserIRSDetails.UserID
		END
		ELSE
		BEGIN
       		INSERT INTO [dbo].[UserIRSDetail]
			(
				CIAMID, 
				MachineAuthentication,
				PasswordResetCurrent,
				PasswordResetLast,
				EmailIDResetCurrent,
				EmailIDResetLast,
				MobilePhoneResetCurrent,
				MobilePhoneResetLast,
				IdentityProofingLevel,
				TokenAuthenticationLevel,
				EmailIDOOB,
				MobilePhoneOOB,
				AuthenticationReviewCode,
				IdentityAssuranceLevel,
				CreatedTS,
				CreatedBy,
				ModifiedTS,
				ModifiedBy 			
			)        
       		SELECT 
				UDT_ADF2_UserIRSDetails.UserID,
				UDT_ADF2_UserIRSDetails.MachineAuthentication,
				UDT_ADF2_UserIRSDetails.PasswordResetCurrent,
				UDT_ADF2_UserIRSDetails.PasswordResetLast,
				UDT_ADF2_UserIRSDetails.EmailIDResetCurrent,
				UDT_ADF2_UserIRSDetails.EmailIDResetLast,
				UDT_ADF2_UserIRSDetails.MobilePhoneResetCurrent,
				UDT_ADF2_UserIRSDetails.MobilePhoneResetLast,
				UDT_ADF2_UserIRSDetails.IdentityProofingLevel,
				UDT_ADF2_UserIRSDetails.TokenAuthenticationLevel,
				UDT_ADF2_UserIRSDetails.EmailIDOOB,
				UDT_ADF2_UserIRSDetails.MobilePhoneOOB,
				UDT_ADF2_UserIRSDetails.AuthenticationReviewCode,
				UDT_ADF2_UserIRSDetails.IdentityAssuranceLevel,
				UDT_ADF2_UserIRSDetails.CreatedTS_UserIRSDetails,
				UDT_ADF2_UserIRSDetails.CreatedBy_UserIRSDetails,
				UDT_ADF2_UserIRSDetails.ModifiedTS_UserIRSDetails,
				UDT_ADF2_UserIRSDetails.ModifiedBy_UserIRSDetails

           	FROM @UDT_ADF2 UDT_ADF2_UserIRSDetails
			LEFT JOIN [dbo].[UserIRSDetail] G ON UDT_ADF2_UserIRSDetails.UserID = G.CIAMID 
			WHERE G.CIAMID IS NULL AND UDT_ADF2_UserIRSDetails.UserID IS NOT NULL
		END


    END TRY
    BEGIN CATCH 
        INSERT INTO [dbo].[DataSyncFailedRecordsLog](CIAMID,BatchId,CreatedBy,CreatedOn)
        SELECT UDT_ADF2IDPUser.UserID,
               UDT_ADF2IDPUser.BatchId,
               'ADF2Insert',
               GETDATE()
           	   FROM @UDT_ADF2 UDT_ADF2IDPUser
			   WHERE UDT_ADF2IDPUser.UserID IS NULL
    END CATCH
END