﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : New procedure to Update the UserIRS Details.
*/
CREATE PROCEDURE [dbo].[Usp_Modify_UserIRSDetails]
@CIAMID INT,
@Attribute VARCHAR(50),
@Value VARCHAR(50),
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Modify_UserIRSDetails'
	
	IF @Attribute = 'PasswordResetCurrent'
	BEGIN	
		UPDATE [dbo].[UserIRSDetail] WITH(ROWLOCK)
		SET PasswordResetCurrent = @Value,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID	
	END	

	IF @Attribute = 'EmailIDResetCurrent'
	BEGIN	
		UPDATE [dbo].[UserIRSDetail] WITH(ROWLOCK)
		SET EmailIDResetCurrent = @Value,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID		
	END

	IF @Attribute = 'MobilePhoneResetCurrent'
	BEGIN	
		UPDATE [dbo].[UserIRSDetail] WITH(ROWLOCK)
		SET MobilePhoneResetCurrent = @Value,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END

	IF @Attribute = 'IdentityProofingLevel'
	BEGIN	
		UPDATE [dbo].[UserIRSDetail] WITH(ROWLOCK)
		SET IdentityProofingLevel = @Value,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END

	IF @Attribute = 'AuthenticationReviewCode'
	BEGIN	
		UPDATE [dbo].[UserIRSDetail] WITH(ROWLOCK)
		SET AuthenticationReviewCode = @Value,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END
END