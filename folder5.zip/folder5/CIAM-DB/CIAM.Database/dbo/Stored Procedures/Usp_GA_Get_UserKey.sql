﻿/*
Created Date : 08/30/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in GA_UserKey Table.
*/
CREATE PROCEDURE [dbo].[Usp_GA_Get_UserKey]
@CIAMID	INT,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_GA_Get_UserKey'

	SELECT CIAMID,
		GoogleKey,
		ActivationStatus
	FROM [dbo].[GA_UserKey] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID
		AND ISNULL(RegistrationStatus,0) = 1
END
GO