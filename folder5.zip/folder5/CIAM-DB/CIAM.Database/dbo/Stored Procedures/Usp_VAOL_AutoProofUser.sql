﻿/*
Created Date : 07/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the VAOL AutoProofUser.
*/
CREATE PROCEDURE [dbo].[Usp_VAOL_AutoProofUser]
@CIAMID INT,
@SSNDoB CHAR(64),
@CreatedOn DATETIME
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_VAOL_AutoProofUser',
		@VAOLEmailInvitationValidDays INT,
		@a_VAOLWorkspaceID VARCHAR(600),
		@a_EIN VARCHAR(150),														
		@a_VAOLTaxYear VARCHAR(100),
		@i_VAOLWorkspaceID VARCHAR(600),
		@i_EIN VARCHAR(150),
		@i_VAOLTaxYear VARCHAR(100),
		@ValidationStatus SMALLINT,@FirstName VARCHAR(50),
		@LastName VARCHAR(50),@i_EmailSentOn DATETIME
	
	SELECT @VAOLEmailInvitationValidDays = ControlValue FROM [dbo].[SysControl] WITH(NOLOCK) WHERE ControlName = 'VirtualAOLEmailInvitationValidDays'

	IF NOT EXISTS(SELECT 1 FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK) WHERE SSNDOB = @SSNDoB AND IsActive = 1 AND EmailSentOn >= DATEADD(DD,-@VAOLEmailInvitationValidDays,@CreatedOn))
    BEGIN
        RETURN;
    END

	DECLARE @VAOL_UserDetails TABLE(SSNDOB CHAR(64),VAOLWorkspaceID UNIQUEIDENTIFIER,EIN INT,VAOLTaxYear INT)
	
	INSERT INTO @VAOL_UserDetails(SSNDOB,VAOLWorkspaceID,EIN,VAOLTaxYear)
	SELECT SSNDOB,VAOLWorkspaceID,EIN,VAOLTaxYear
	FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK)
	WHERE SSNDOB = @SSNDoB and IsActive = 1 AND EmailSentOn >= DATEADD(DD,-@VAOLEmailInvitationValidDays,@CreatedOn)
	ORDER BY CreatedOn DESC

		-- get all the associated WSIDs, EINs and TaxYears comma separated.			
	SELECT @a_VAOLWorkspaceID = COALESCE(@a_VAOLWorkspaceID + ',','') + CAST(VAOLWorkspaceID AS VARCHAR(36)) FROM @VAOL_UserDetails
	SELECT @a_EIN = COALESCE(@a_EIN + ',','') + ISNULL(CAST(EIN AS VARCHAR(9)),'NULL') FROM @VAOL_UserDetails
	SELECT @a_VAOLTaxYear = COALESCE(@a_VAOLTaxYear + ',', '') + ISNULL(CAST(VAOLTaxYear AS VARCHAR(4)),'NULL') FROM @VAOL_UserDetails
		
	IF(ISNULL(@a_VAOLWorkspaceID,'') <> '')	
	BEGIN
			UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET VAOL_WOrkspaceID =  @a_VAOLWorkspaceID,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
			
		INSERT INTO [dbo].[VAOL_WorkSpaceIDLog](CIAMID,SSNDOB,VAOLWorkSpaceID,CreatedOn,CreatedBy, OldVAOLWorkspaceID)
		SELECT @CIAMID,@SSNDOB,@a_VAOLWorkspaceID,@CreatedOn,@CreatedBy,@i_VAOLWorkspaceID 
	END

	IF(ISNULL(@a_EIN,'') <> '')
	BEGIN
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET EIN = @a_EIN,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID

		INSERT INTO [dbo].[VAOL_EINLog](CIAMID,SSNDOB,EIN,CreatedOn,CreatedBy)
		SELECT @CIAMID,@SSNDOB,@a_EIN,@CreatedOn,@CreatedBy 
	END

	IF(ISNULL(@a_VAOLTaxYear,'') <> '')
	BEGIN
	UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET [VAOLTaxYear] = @a_VAOLTaxYear,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
			
		INSERT INTO [dbo].[VAOL_TaxYearLog](CIAMID,SSNDOB,VAOLTaxYear,CreatedOn,CreatedBy)						
		SELECT @CIAMID,@SSNDOB,@a_VAOLTaxYear,@CreatedOn,@CreatedBy 
	END
	
	-- Inactivating the VAOL Data for any further IDProofing
	UPDATE [dbo].[VAOL_UserDetails] WITH(ROWLOCK)
	SET IsActive = 0,
		ModifiedOn = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE SSNDOB = @SSNDoB 

	SET @ValidationStatus = '1'	
	EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
		@CIAMID = @CIAMID,
		@SSNDoB = @SSNDoB,
		@VAOLWorkspaceID = @a_VAOLWorkspaceID,
		@FirstName = @FirstName,
		@LastName = @LastName,
		@EmailSentOn = @i_EmailSentOn,
		@ValidationStatus = @ValidationStatus,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy
END