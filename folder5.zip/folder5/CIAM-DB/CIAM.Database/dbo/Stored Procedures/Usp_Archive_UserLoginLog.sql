﻿CREATE PROCEDURE [dbo].[Usp_Archive_UserLoginLog]
	@batchSize int,
	@archival_window int
AS
BEGIN
SET NOCOUNT ON;


DECLARE @maxID INT, 
        @minID INT,
		@CutOffDate DATE = GETDATE() - @archival_window,
		@iteration INT = 1
      
SELECT @minID = ISNULL (MAX(id), -1) + 1 FROM UserLoginLog_Archive
Select @maxID = @minID + @batchSize

IF ((SELECT CreatedOn FROM UserLoginLog WITH (NOLOCK) WHERE ID = @maxID) < @CutOffDate)
BEGIN
	WHILE @iteration <= 500
	BEGIN
		INSERT INTO UserLoginLog_Archive
							(ID, CIAMID, Status, RemoteIPAddress, CreatedOn, SignInChannel, ReferenceID, User2FAMethod, User2FAStatus, UserAgent, BrowserName, BrowserVersion, OS, OSVersion, 
							Device, DeviceType, DeviceOrientation, SourceURL, Location, BiometricType, TrackId)
	    SELECT ID, CIAMID, Status, RemoteIPAddress, CreatedOn, SignInChannel, ReferenceID, User2FAMethod, User2FAStatus, UserAgent, BrowserName, BrowserVersion, OS, OSVersion, 
							Device, DeviceType, DeviceOrientation, SourceURL, Location, BiometricType, TrackId
							FROM UserLoginLog WITH (NOLOCK)
        WHERE ID BETWEEN @minID and @maxID
		AND CreatedOn < @CutOffDate

		IF @@ERROR = 0
		BEGIN
			DELETE FROM UserLoginLog WITH (ROWLOCK) WHERE ID BETWEEN @minID and @maxID AND CreatedOn < @CutOffDate
		END

		SELECT @minID = ISNULL(MAX (ID), -1) + 1 FROM UserLoginLog_Archive (NOLOCK)
		SELECT @maxID = @minID + @batchSize

		IF ((SELECT ISNULL(CreatedOn,'2022-12-31') FROM UserLoginLog WITH(NOLOCK) WHERE ID = @maxID) >= @CutOffDate)-- put a veru high value to come out of the oop if its a gap/NULL
        BEGIN
			BREAK         
        END

		SET @iteration = @iteration + 1
	END

END

END