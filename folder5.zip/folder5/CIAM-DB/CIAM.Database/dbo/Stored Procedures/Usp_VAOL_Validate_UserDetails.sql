﻿/*
Created Date : 07/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the AOL UserDetails.
*/
CREATE PROCEDURE [dbo].[Usp_VAOL_Validate_UserDetails]
@CIAMID INT,
@FirstName VARCHAR(50),
@LastName VARCHAR(50),
@SSNDoB VARCHAR(64),
@VAOLWorkspaceID UNIQUEIDENTIFIER,
@CreatedOn DATETIME
AS
BEGIN		
	SET NOCOUNT ON;
		
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_VAOL_Validate_UserDetails',
		@ValidationStatus SMALLINT

	DECLARE @i_SSNDoB CHAR(64),@i_VAOLWorkspaceID UNIQUEIDENTIFIER,@i_FirstName VARCHAR(50),@i_LastName	VARCHAR(50),
	@i_EmailSentOn DATETIME,@i_IsActive BIT,@FailedValidationAttempts SMALLINT

	SELECT @FailedValidationAttempts = COUNT(1)
	FROM (
		SELECT TOP (3) ValidationStatus,CreatedOn
		FROM [dbo].[VAOL_UserDetailsValidationLog] WITH(NOLOCK)
		WHERE CIAMID = @CIAMID
			AND CreatedOn > DATEADD( MINUTE,-20,[dbo].[udf_Get_CST](GETDATE()))
		ORDER BY CreatedOn DESC
	)x
	WHERE x.ValidationStatus < 0

	IF @FailedValidationAttempts = '3'
	BEGIN
		SET @ValidationStatus = '-6'

		EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
			@CIAMID = @CIAMID,
			@SSNDoB = @SSNDoB,
			@VAOLWorkspaceID = @VAOLWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@EmailSentOn = @i_EmailSentOn,
			@ValidationStatus = @ValidationStatus,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy
	
		SELECT @ValidationStatus AS ValidationStatus
		RETURN				
	END
	
	SELECT @FailedValidationAttempts = COUNT(1)
	FROM (
		SELECT TOP (3) ValidationStatus,CreatedOn
		FROM [dbo].[VAOL_UserDetailsValidationLog] WITH(NOLOCK)
		WHERE SSNDoB = @SSNDoB AND VAOLWorkspaceID = @VAOLWorkspaceID
			AND CreatedOn > DATEADD( MINUTE,-20,dbo.udf_Get_CST(GETDATE()))
		ORDER BY CreatedOn DESC
	)x
	WHERE x.ValidationStatus < 0

	IF @FailedValidationAttempts = '3'
	BEGIN
		SET @ValidationStatus = '-5'

		EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
			@CIAMID = @CIAMID,
			@SSNDoB = @SSNDoB,
			@VAOLWorkspaceID = @VAOLWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@EmailSentOn = @i_EmailSentOn,
			@ValidationStatus = @ValidationStatus,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus
		RETURN				
	END

	SELECT @i_SSNDoB = SSNDOB,
		@i_VAOLWorkspaceID = VAOLWorkspaceID,
		@i_FirstName = FirstName,
		@i_LastName = LastName,
		@i_EmailSentOn = EmailSentOn,
		@i_IsActive = IsActive
	FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK)
	WHERE SSNDOB = @SSNDoB AND VAOLWorkspaceID = @VAOLWorkspaceID
	
	IF @i_SSNDoB IS NULL OR	@i_VAOLWorkspaceID	IS NULL	
	BEGIN
		SET @ValidationStatus = '-1'
		
		EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
			@CIAMID = @CIAMID,
			@SSNDoB = @SSNDoB,
			@VAOLWorkspaceID = @VAOLWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@EmailSentOn = @i_EmailSentOn,
			@ValidationStatus = @ValidationStatus,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus
		RETURN
	END
	
	IF ISNULL(@i_IsActive,0)  <> '1'
	BEGIN
		SET @ValidationStatus = '-7'

		EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
			@CIAMID = @CIAMID,
			@SSNDoB = @SSNDoB,
			@VAOLWorkspaceID = @VAOLWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@EmailSentOn = @i_EmailSentOn,
			@ValidationStatus = @ValidationStatus,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus
		RETURN				
	END

	SET @ValidationStatus = '1'	
	
	EXEC [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
		@CIAMID = @CIAMID,
		@SSNDoB = @SSNDoB,
		@VAOLWorkspaceID = @VAOLWorkspaceID,
		@FirstName = @FirstName,
		@LastName = @LastName,
		@EmailSentOn = @i_EmailSentOn,
		@ValidationStatus = @ValidationStatus,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy

	SELECT @ValidationStatus AS ValidationStatus	
END