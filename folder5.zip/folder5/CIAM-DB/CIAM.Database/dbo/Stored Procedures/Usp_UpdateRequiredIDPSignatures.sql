﻿-------------------------------------------------------------------
-- Created: 1/12/2024 - Teegan Swanson
-------------------------------------------------------------------

CREATE PROCEDURE [dbo].[Usp_UpdateRequiredIDPSignatures]
		@UDT_RequiredSignatureUpdates [dbo].[UDT_RequiredIDPSignatureUpdate] READONLY
AS
BEGIN TRY
	SET NOCOUNT ON

	IF EXISTS (SELECT 1 FROM [dbo].[IDPUser_RequiredSignatureUpdate] RIDP INNER JOIN @UDT_RequiredSignatureUpdates UDT ON RIDP.CIAMID = UDT.CIAMID)
	BEGIN

		UPDATE RIDP
		SET
			RIDP.UpdatedIDPSignature = UDT.UpdatedSignature,
			RIDP.Processed = 1,
            RIDP.UpdatedTS = GETDATE()
		FROM [dbo].[IDPUser_RequiredSignatureUpdate] RIDP
			INNER JOIN @UDT_RequiredSignatureUpdates UDT ON UDT.CIAMID = RIDP.CIAMID
	END
END TRY

BEGIN CATCH
    INSERT INTO [dbo].[IDPUser_RequiredUserFailures]
    (
        CIAMID,
        ErrorMessage,
        CreatedOn
    )
    SELECT
        UDT.CIAMID,
        ERROR_MESSAGE(),
        GETDATE()
    FROM
        @UDT_RequiredSignatureUpdates UDT
END CATCH