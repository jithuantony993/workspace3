﻿/*
Created Date : 02/12/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Remove the UCID.
*/
CREATE PROCEDURE [dbo].[Usp_Remove_IdHash] @CIAMID INT=NULL
,@IdHash VARCHAR(64)=NULL
,@CreatedBy DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @ModifiedBy VARCHAR(50)
	SELECT @ModifiedBy='Usp_Remove_IdHash'

	IF @CIAMID IS NOT NULL 
	BEGIN
		UPDATE [dbo].[CIAMUserDetail] SET IdHash=NULL,ModifiedBy=@ModifiedBy,ModifiedTS=@CreatedBy WHERE CIAMID=@CIAMID
	END
	ELSE IF @IdHash IS NOT NULL
	BEGIN
		UPDATE [dbo].[CIAMUserDetail] SET IdHash=NULL,ModifiedBy=@ModifiedBy,ModifiedTS=@CreatedBy WHERE IdHash=@IdHash
	END
END