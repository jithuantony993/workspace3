﻿/*
Created Date : 03/01/2023
Created By : Kalirajan
Changes Summary : To Get the UserIDProofStatus in that Proc
*/
CREATE PROCEDURE [dbo].[Usp_OLAT_Get_UserIDProofStatus]
@CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CardIDProofStatus BIT = 0,
		@AOLProofStatus BIT = 0,
		@VAOLProofStatus BIT = 0
	
	-- CARD Proof Status
	IF EXISTS(SELECT 1 FROM [dbo].[EC_UserDetails] WITH(NOLOCK) WHERE CIAMID = @CIAMID)	
	BEGIN
		SET @CardIDProofStatus = 1
	END
	
		-- AOL Proof Status
	IF EXISTS(SELECT 1 FROM [dbo].[AOL_UserDetailsValidationLog] WITH(NOLOCK) WHERE CIAMID = @CIAMID AND ValidationStatus = 1)
	BEGIN
		SET @AOLProofStatus = 1
	END

		-- VAOL Proof Status
	IF EXISTS(SELECT 1 FROM VAOL_UserDetailsValidationLog WITH(NOLOCK) WHERE CIAMID = @CIAMID AND ValidationStatus = 1)
	BEGIN
		SET @VAOLProofStatus = 1
	END

	SELECT @CardIDProofStatus AS CardIDProofStatus,
		@AOLProofStatus AS AOLProofStatus,
		@VAOLProofStatus AS VAOLProofStatus	
END