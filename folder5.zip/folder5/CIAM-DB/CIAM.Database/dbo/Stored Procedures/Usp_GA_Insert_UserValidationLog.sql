﻿/*
Created Date : 08/30/2022
Created By : Kalirajan
Changes Summary :  New procedure to Insert the Recs in GA_UserValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_GA_Insert_UserValidationLog]
@CAMID INT,
@ActivationStatus SMALLINT,
@ValidationStatus SMALLINT,
@CreatedOn DATETIME = NULL,
@CreatedBy VARCHAR(50) = NULL,
@Location VARCHAR(100) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	IF @CreatedBy IS NULL
	BEGIN
		SET @CreatedBy = SUSER_NAME()
	END	

	INSERT INTO [dbo].[GA_UserValidationLog](CIAMID,ActivationStatus,ValidationStatus,CreatedOn,CreatedBy,Location)
	VALUES (@CAMID,@ActivationStatus,@ValidationStatus,@CreatedOn,@CreatedBy,@Location)
END
GO