﻿/*
Created Date : 09/05/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs into IDP_UserSharedSecretsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Insert_UserSharedSecretsValidationLog]
@CIAMID INT,
@idHash CHAR(64),
@ValidationStatus SMALLINT,
@MachineIdentifier VARCHAR(40),
@BrowserAgentIdentifier INT,
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@SessionID VARCHAR(50),
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50),
@SignInChannel	TINYINT,
@IDP_Source TINYINT,
@UserChannel TINYINT = NULL,
@ZipCode VARCHAR(5) = NULL,
@GIID VARCHAR(255) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [dbo].[IDP_UserSharedSecretsValidationLog]
		(CIAMID,idHash,ValidationStatus,MachineIdentifier,BrowserAgentIdentifier,
			RemoteIPAddress,BrowserVersion,SessionID,CreatedOn,CreatedBy,SignInChannel,IDP_Source,UserChannel,ZipCode,GIID) 
	VALUES
		(@CIAMID,@idHash,@ValidationStatus,NULL,NULL,
			NULL,NULL,NULL,@CreatedOn,@CreatedBy,@SignInChannel,@IDP_Source,@UserChannel,@ZipCode,@GIID) 
	
END