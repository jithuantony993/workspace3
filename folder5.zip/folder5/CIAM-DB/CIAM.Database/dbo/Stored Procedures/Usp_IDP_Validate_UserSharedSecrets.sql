﻿/*
Created Date : 09/02/2022
Created By : Kalirajan
Changes Summary : New procedure to Valdate the UserSharedSecrets.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Validate_UserSharedSecrets]
@CIAMID INT,
@idHash CHAR(64),
@IDPClientMatchingLockTime INT = 5,
@MachineIdentifier VARCHAR(40),
@BrowserAgentIdentifier INT,
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@SessionID VARCHAR(50),
@SignInChannel	TINYINT,
@IDP_Source		TINYINT,
@UserChannel TINYINT = NULL,
@ZipCode VARCHAR(5) = NULL,
@GIID VARCHAR(255) = NULL,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @i_GIID VARCHAR(255),
		@CreatedBy VARCHAR(50) = 'Usp_IDP_Validate_UserSharedSecrets',
		@ValidationStatus SMALLINT,
		@i_ZipCode VARCHAR(5)
	
	IF(SELECT COUNT(1) FROM [dbo].[IDP_UserSharedSecretsValidationLog] WITH(NOLOCK)	WHERE CIAMID = @CIAMID
		AND CreatedOn > DATEADD(MI,(-1 * @IDPClientMatchingLockTime),@CreatedOn) AND ValidationStatus <> 1)>= 3
	BEGIN
		SET @ValidationStatus = -7
		SELECT @ValidationStatus AS ValidationStatus

		EXEC [dbo].[Usp_IDP_Insert_UserSharedSecretsValidationLog]
			@CIAMID = @CIAMID,
			@idHash = @idHash, 
			@ValidationStatus = @ValidationStatus,
			@MachineIdentifier = @MachineIdentifier,
			@BrowserAgentIdentifier = @BrowserAgentIdentifier,
			@RemoteIPAddress = @RemoteIPAddress,
			@BrowserVersion = @BrowserVersion,
			@SessionID = @SessionID,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy,
			@SignInChannel = @SignInChannel,
			@IDP_Source = @IDP_Source,	
			@UserChannel = @UserChannel,
			@ZipCode =@ZipCode,
			@GIID = @GIID	
		RETURN
	END
	
	IF(SELECT COUNT(1) FROM [dbo].[IDP_UserSharedSecretsValidationLog] WITH(NOLOCK)	WHERE idHash = @idHash
			AND CreatedOn > DATEADD(MI,(-1 * @IDPClientMatchingLockTime),@CreatedOn) AND ValidationStatus <> 1)>= 3
	BEGIN
		SET @ValidationStatus = -8
		SELECT @ValidationStatus AS ValidationStatus

		EXEC [dbo].[Usp_IDP_Insert_UserSharedSecretsValidationLog]
			@CIAMID = @CIAMID,
			@idHash = @idHash,  
			@ValidationStatus = @ValidationStatus,
			@MachineIdentifier = @MachineIdentifier,
			@BrowserAgentIdentifier = @BrowserAgentIdentifier,
			@RemoteIPAddress = @RemoteIPAddress,
			@BrowserVersion = @BrowserVersion,
			@SessionID = @SessionID,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy,
			@SignInChannel = @SignInChannel,
			@IDP_Source = @IDP_Source,
			@UserChannel = @UserChannel,
			@ZipCode =@ZipCode,
			@GIID = @GIID
		RETURN
	END

	IF NOT EXISTS(SELECT IdHash	FROM CIAMUserDetail WITH(NOLOCK) WHERE IdHash=@idHash)
	BEGIN
		SET @ValidationStatus = -1
		SELECT @ValidationStatus AS ValidationStatus		

		EXEC [dbo].[Usp_IDP_Insert_UserSharedSecretsValidationLog]
			@CIAMID = @CIAMID,
			@idHash = @idHash,   
			@ValidationStatus = @ValidationStatus,
			@MachineIdentifier = @MachineIdentifier,
			@BrowserAgentIdentifier = @BrowserAgentIdentifier,
			@RemoteIPAddress = @RemoteIPAddress,
			@BrowserVersion = @BrowserVersion,
			@SessionID = @SessionID,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy,
			@SignInChannel = @SignInChannel,
			@IDP_Source = @IDP_Source,
			@UserChannel = @UserChannel,
			@ZipCode =@ZipCode,
			@GIID = @GIID
		RETURN
	END	
	
	SET @ValidationStatus = 1		-- Succesfully Validated
	SELECT @ValidationStatus AS ValidationStatus

	EXEC [dbo].[Usp_IDP_Insert_UserSharedSecretsValidationLog]
		@CIAMID = @CIAMID,
		@idHash = @idHash, 
		@ValidationStatus = @ValidationStatus,
		@MachineIdentifier = @MachineIdentifier,
		@BrowserAgentIdentifier = @BrowserAgentIdentifier,
		@RemoteIPAddress = @RemoteIPAddress,
		@BrowserVersion = @BrowserVersion,
		@SessionID = @SessionID,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy,
		@SignInChannel = @SignInChannel,
		@IDP_Source = @IDP_Source,	
		@UserChannel = @UserChannel	,
		@ZipCode =@ZipCode,
		@GIID = @GIID	
END