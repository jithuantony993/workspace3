﻿
CREATE PROCEDURE [dbo].[Usp_UpdateSignaturesBatch]
		@UDT_RequiredSignatureUpdates [dbo].[UDT_SignatureStatusUpdate] READONLY
AS
	SET NOCOUNT ON

	BEGIN

		UPDATE Temp_Signature_Verification
		SET
			SigValidationStatus = UDT.SigValidationStatus,
			Processed = 1
		FROM [dbo].[Temp_Signature_Verification] TSV
			INNER JOIN @UDT_RequiredSignatureUpdates UDT ON UDT.CIAMID = TSV.CIAMID
	END