﻿/*
-- =============================================
-- Author:		<Stevens,Alex>
-- Create date: <05/05/2023>
-- Description:	<Modify on Demand accounts>
-- =============================================
*/
CREATE PROCEDURE [dbo].[Usp_Modify_OnDemand]
	@entryuuid VARCHAR(255) NULL,
	@ciamId int NULL
AS
BEGIN

UPDATE [dbo].[CIAMUserDetail] WITH (ROWLOCK) 
	SET MigratedToPing = 1,
	EntryUUID= @entryuuid
WHERE
	CIAMID =@ciamId
END
		
GO