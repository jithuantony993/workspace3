﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : 1) New procedure to Modify the UserEULAStatus Update into EC_UserDetails Table. 
                  2) Then Call Usp_EC_Insert_UserEULAStatusLog Sp to Log the Eula status.

Modified Date : 09/03/2023
Modified By : Kalirajan
Changes Summary : To Add One New Parameter And handle in that Sp.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Modify_UserEULAStatus]
@CIAMID INT,
@EC_EULAStatus BIT,
@EC_EULAVersion SMALLINT,
@BrowserVersion VARCHAR(200),
@RemoteIPAddress VARCHAR(20),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@UserAgent VARCHAR(200),
@BrowserName VARCHAR(100),
@OmbaEulaVersion INT,
@IDVerified BIT,
@CardProofedStatus BIT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_EC_Modify_UserEULAStatus'	
	
	IF EXISTS(SELECT 1 FROM EC_UserDetails WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE [dbo].[EC_UserDetails] WITH (ROWLOCK)
		SET EC_EULAStatus =  @EC_EULAStatus,
			EC_EULAVersion = @EC_EULAVersion,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy,
			CardProofedStatus=@CardProofedStatus
		WHERE CIAMID = @CIAMID

		UPDATE [dbo].[CIAMUserDetail]
		SET OmbaEulaVersion=@OmbaEulaVersion,
		OmbaEulaModifiedOn=@CreatedOn,
		IDVerified= CASE WHEN IDVerified = 1 THEN IDVerified ELSE @IDVerified END 
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[EC_UserDetails](CIAMID,CreatedOn,CreatedBy,EC_EULAStatus,EC_EULAVersion,CardProofedStatus)
		VALUES(@CIAMID,@CreatedOn,@CreatedBy,@EC_EULAStatus,@EC_EULAVersion,@CardProofedStatus)

		UPDATE [dbo].[CIAMUserDetail]
		SET OmbaEulaVersion=@OmbaEulaVersion,
		OmbaEulaModifiedOn=@CreatedOn,
		IDVerified= CASE WHEN IDVerified = 1 THEN IDVerified ELSE @IDVerified END
		WHERE CIAMID = @CIAMID
	END

	EXEC [dbo].[Usp_EC_Insert_UserEULAStatusLog]
		@CIAMID = @CIAMID,
		@EC_EULAStatus = @EC_EULAStatus,
		@EC_EULAVersion = @EC_EULAVersion,
		@BrowserVersion = @BrowserVersion,
		@RemoteIPAddress = @RemoteIPAddress,
		@ReferenceID = @ReferenceID,
		@CreatedOn = @CreatedOn,
		@UserAgent=@UserAgent,
		@BrowserName=@BrowserName
END