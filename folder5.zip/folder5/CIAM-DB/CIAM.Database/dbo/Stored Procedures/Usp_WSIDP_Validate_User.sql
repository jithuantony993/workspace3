﻿/*
Created Date : 07/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the User.
*/
CREATE PROCEDURE [dbo].[Usp_WSIDP_Validate_User]
@CIAMID INT,
@SSNDOB VARCHAR(64),
@TaxWorkspaceID UNIQUEIDENTIFIER,
@FirstName VARCHAR(50),
@LastName VARCHAR(50),
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_WSIDP_Validate_User'

	DECLARE @ValidationStatus SMALLINT = 0
		,@WSIDPValidationLockTime INT
		,@FailedPINAttempts INT
		,@i_IsActive BIT
		,@i_SSNDOB VARCHAR(64)
		,@i_TaxReturnGUID UNIQUEIDENTIFIER
		,@i_TaxWorkspaceID UNIQUEIDENTIFIER
		,@i_FirstName VARCHAR(50)
		,@i_LastName VARCHAR(50)
		,@i_InvitedOn DATETIME2

	SELECT @i_SSNDOB = SSNDOB,
		@i_TaxReturnGUID = TaxReturnGUID,
		@i_TaxWorkspaceID = TaxWorkspaceID,
		@i_FirstName = FirstName,
		@i_LastName = LastName,
		@i_InvitedOn = InvitedOn,
		@i_IsActive = ISNULL(IsActive,0)
	FROM [dbo].[WSIDP_UserDetails] WITH(NOLOCK)
	WHERE TaxWorkspaceID = @TaxWorkspaceID
	   
	IF @i_TaxWorkspaceID IS NULL
	BEGIN
		SET @ValidationStatus = '-16'
		
		EXEC [dbo].[Usp_WSIDP_Insert_UserValidationLog]
			@CIAMID = @CIAMID,
			@ValidationStatus = @ValidationStatus,
			@SSNDOB = @SSNDOB,
			@PIN = NULL,
			@TaxWorkspaceID = @TaxWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@InvitedOn = @i_InvitedOn,
			@InvitationValidHours = NULL,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus

		RETURN
	END

	IF ISNULL(@i_SSNDOB,'') <> @SSNDOB
	BEGIN
		SET @ValidationStatus = '-13'
		
		EXEC [dbo].[Usp_WSIDP_Insert_UserValidationLog]
			@CIAMID = @CIAMID,
			@ValidationStatus = @ValidationStatus,
			@SSNDOB = @SSNDOB,
			@PIN = NULL,
			@TaxWorkspaceID = @TaxWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@InvitedOn = @i_InvitedOn,
			@InvitationValidHours = NULL,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus

		RETURN
	END

	IF ISNULL(@i_IsActive,0) = 0
	BEGIN
		SET @ValidationStatus = '-20'
		
		EXEC [dbo].[Usp_WSIDP_Insert_UserValidationLog]
			@CIAMID = @CIAMID,
			@ValidationStatus = @ValidationStatus,
			@SSNDOB = @SSNDOB,
			@PIN = NULL,
			@TaxWorkspaceID = @TaxWorkspaceID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@InvitedOn = @i_InvitedOn,
			@InvitationValidHours = NULL,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy

		SELECT @ValidationStatus AS ValidationStatus

		RETURN
	END

	SET @ValidationStatus = '10'

	EXEC [dbo].[Usp_WSIDP_Insert_UserValidationLog]
		@CIAMID = @CIAMID,
		@ValidationStatus = @ValidationStatus,
		@SSNDOB = @SSNDOB,
		@PIN = NULL,
		@TaxWorkspaceID = @TaxWorkspaceID,
		@FirstName = @FirstName,
		@LastName = @LastName,
		@InvitedOn = @i_InvitedOn,
		@InvitationValidHours = NULL,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy

	SELECT @CIAMID AS CIAMID,@ValidationStatus AS ValidationStatus
END