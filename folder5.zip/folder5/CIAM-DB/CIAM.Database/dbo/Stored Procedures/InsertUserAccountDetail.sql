﻿CREATE PROCEDURE [dbo].[InsertUserAccountDetail] 
@Email VARCHAR(150), 
@EntryUUID		uniqueidentifier,		   
@Accountstatus	tinyint ,        
@LastLogin DATETIMEOFFSET NULL,
@PingOneId uniqueidentifier = NULL,
@RefID uniqueidentifier=NULL

AS
BEGIN

		DECLARE
		@ModifiedTS datetimeoffset	= [dbo].[UdfGetCST](sysdatetimeoffset()), 
		@CreatedBy VARCHAR(50)		= 'InsertUserAccountDetail',  
		@CiamId INT = 0,
		@MFAStatus INT=0

	SET NOCOUNT ON;	

	EXEC UspModifyUserDetail @EntryUUID,@Accountstatus,@LastLogin, @PingOneId;
	SET @CiamId = (SELECT TOP 1 CIAMID from CIAMUserDetail WHERE EntryUUID =@EntryUUID);
	SET @MFAStatus = (SELECT TOP 1 Value FROM CAMFAStatusLookup WHERE [Key]='EMAIL_PASSWORD')
	INSERT INTO UserAccountDetail(CIAMID,Email,CreatedTS,CreatedBy,RefID,MFAStatus)
	VALUES(@CiamId,@Email,@ModifiedTS,@CreatedBy,@RefID,@MFAStatus)	
	
	SELECT @CiamId AS CIAMId;
END
GO
