﻿/*
Created Date : 08/26/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in UserMobilePhoneSkippedLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_Get_UserMobilePhoneStatus]
@CIAMID INT,
@INITIATEDATE DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	--Business Logic to filter the yearly data
  DECLARE  @initiate_month int, @initiate_day int, @initiate_date varchar(20), 
  @end_day int, @start_date varchar(20), @end_date varchar(20),
  @year_value int, @date_value int, @month_value int,
  @StartYear VARCHAR(20), @EndYear VARCHAR(20), @Today_Date datetime
 
  SET @Today_Date = [dbo].[udf_Get_CST](GETDATE())
  SET @year_value = YEAR(@Today_Date)
  SET @month_value = MONTH(@Today_Date)
  SET @date_value = DAY(@Today_Date)

  SET @initiate_month = MONTH(@INITIATEDATE)
  SET @initiate_day = DAY(@INITIATEDATE)	  

  
  SET @StartYear = (CASE WHEN @month_value < @initiate_month OR
  (@month_value = @initiate_month and @date_value < @initiate_day)
  THEN convert(varchar(4), @year_value - 1)
  ELSE convert(varchar(4), @year_value)
  END)
  
  SET @start_date = concat(@StartYear,'/',FORMAT(@initiate_month,'0#'),'/',FORMAT(@initiate_day,'0#'))  
   
   
   DECLARE @STATUSFLAG INT
   DECLARE @USERFLOWNAME VARCHAR(50)
   DECLARE @CIAMCREATEDDATE DateTime
   DECLARE @ISLOWQUALITY BIT
   --CONDITION ADDED FOR ADD MOBILE SCREEN APPEARING ISSUE WORK AROUND
   --FOR CREATE ACCOUNT. LATER NEED TO CHANGE - REQUESTED BY PRABHASH
   SELECT top 1 @USERFLOWNAME = User2FAMethod from [dbo].[UserLoginLog] WITH(NOLOCK)
	WHERE CIAMID=@CIAMID ORDER BY CreatedOn DESC

	SELECT @ISLOWQUALITY = 1 from LowQualityAuthStatus where LowQualAccountStatus = 1 and MobileUpdateStatus =0

	SELECT @CIAMCREATEDDATE = CAST(CreatedTS AS date) from CIAMUserDetail where CIAMID=@CIAMID
	 
   IF (@USERFLOWNAME = 'ACCOUNT_CREATION') --Condition to skip the add mobile in create account
	BEGIN	
		SET @STATUSFLAG = 1
	END
	ELSE IF (@start_date <= @CIAMCREATEDDATE  AND @ISLOWQUALITY <> 1) --Condition to skip the add mobile prompt for new user created before prompt date in same year
	BEGIN	
		SET @STATUSFLAG = 1
	END
	ELSE
	BEGIN		
		SELECT TOP 1 @STATUSFLAG = StatusFlag
			FROM [dbo].[UserMobilePhoneSkippedLog] WITH(NOLOCK)
			WHERE CIAMID=@CIAMID 
			and CONVERT(VARCHAR(10), CreatedOn, 111) >= @start_date 
			and CreatedOn <= @Today_Date
	END	

	

	IF (@STATUSFLAG IS NOT NULL)
	BEGIN
		SELECT @CIAMID AS 'CIAMID', @STATUSFLAG AS 'StatusFlag'
	END
END