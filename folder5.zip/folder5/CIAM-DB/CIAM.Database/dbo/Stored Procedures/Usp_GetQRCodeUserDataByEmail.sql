﻿CREATE PROCEDURE [dbo].[Usp_GetQRCodeUserDataByEmail] 
@Email VARCHAR(100)
AS
SELECT * FROM QRCodeUser (NOLOCK) 
WHERE Email = @Email
	AND PingOneID IS NOT NULL