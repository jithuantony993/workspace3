﻿-- Change History
   -- RIYAS_07/06/2023 - Insert User Biometric Login History
   -- AJ_10/09/2023 - Refactored to add LastLoginTS

CREATE PROCEDURE [dbo].[InsertUserBiometricLoginLog]
@CIAMID INT,
@Status INT,
@RemoteIPAddress VARCHAR(20) NULL,
@CreatedOn DATETIME,
@SignInChannel TINYINT = 0,				
@ReferenceID VARCHAR(50) NULL,		
@UserAgent VARCHAR(200) NULL,
@BrowserName VARCHAR(100) NULL,
@BrowserVersion VARCHAR(200) NULL,
@OS VARCHAR(30) NULL,
@OSVersion VARCHAR(50) NULL,
@Device VARCHAR(50) NULL,
@DeviceType TINYINT = 0,
@DeviceOrientation VARCHAR(100) NULL,
@SourceURL VARCHAR(30) NULL,
@Location VARCHAR(100),
@BiometricType  VARCHAR(100),
@LastLogin DATETIMEOFFSET NULL,
@User2FAMethod  VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;	

	INSERT INTO UserLoginLog(
	CIAMID,
	[Status],
	RemoteIPAddress,
	CreatedOn,
	SignInChannel,
	ReferenceID,
	UserAgent,
	BrowserName,
	BrowserVersion,
	OS,
	OSVersion,
	Device,
	DeviceType,
	DeviceOrientation,
	SourceURL,
	Location,
	BiometricType,
	User2FAMethod
	)
	VALUES
	(
	@CIAMID,
	@Status,
	@RemoteIPAddress,
	@CreatedOn,
	@SignInChannel,
	@ReferenceID,
	@UserAgent,
	@BrowserName,
	@BrowserVersion,
	@OS,
	@OSVersion,
	@Device,
	@DeviceType,
	@DeviceOrientation,
	@SourceURL,
	@Location,
	@BiometricType,
	@User2FAMethod
	)	
	
	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)	
	SET [LastLoginTS] = [LoginTS],	  
		[LoginTS] = ISNULL(@LastLogin,[LoginTS])
	WHERE CIAMID=@CIAMID

	return @@ROWCOUNT  
END
GO