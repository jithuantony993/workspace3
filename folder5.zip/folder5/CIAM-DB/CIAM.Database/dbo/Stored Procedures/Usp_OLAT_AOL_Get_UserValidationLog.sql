﻿CREATE PROCEDURE [dbo].[Usp_OLAT_AOL_Get_UserValidationLog]
@CiamId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT UserGUID,ValidationStatus,CreatedOn 
	FROM AOL_UserDetailsValidationLog WITH(NOLOCK)
    WHERE CIAMID = @CiamId
END