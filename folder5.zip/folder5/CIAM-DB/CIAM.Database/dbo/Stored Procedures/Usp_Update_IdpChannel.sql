﻿
/*
Created Date : 15/09/2023
Created by : Jithu Antony
Changes Summary : to Update the IdpChannel Value in Idp_User Table.
*/
CREATE PROCEDURE [dbo].[Usp_Update_IdpChannel]
 @CiamId VARCHAR(256),
 @IdpChannel VARCHAR(10),
 @ModifiedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @ModifiedBy VARCHAR(50) = 'Usp_Update_IdpChannel'
	IF EXISTS(SELECT IDPChannel FROM [dbo].[IDP_User] WHERE CIAMID = @CiamId)
	BEGIN
		UPDATE [dbo].[IDP_User]
		SET IDPChannel= CONCAT([IDPChannel], ',' , @IdpChannel),  
		ModifiedBy = @ModifiedBy ,
		ModifiedOn = @ModifiedOn
		WHERE CIAMID=@CiamId
		AND NOT EXISTS (SELECT 1 FROM [dbo].[IDP_User] WHERE CIAMID = @CiamId AND IDPChannel LIKE CONCAT('%', @IdpChannel, '%'))
	END
END