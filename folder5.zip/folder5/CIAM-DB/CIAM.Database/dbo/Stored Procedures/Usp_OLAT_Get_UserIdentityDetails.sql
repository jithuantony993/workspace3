﻿/*
Created Date : 03/01/2023
Created By : Kalirajan
Changes Summary : To Get the UserIdentityDetails in that Proc
*/
CREATE PROCEDURE [dbo].[Usp_OLAT_Get_UserIdentityDetails]
@CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @UserGUID UNIQUEIDENTIFIER

	SELECT @UserGUID = UserGUID FROM [dbo].[AOL_UserDetailsValidationLog] WITH(NOLOCK) 
	WHERE CIAMID = @CIAMID AND ValidationStatus = 1
	
	SELECT	@UserGUID AS UserGUID
END