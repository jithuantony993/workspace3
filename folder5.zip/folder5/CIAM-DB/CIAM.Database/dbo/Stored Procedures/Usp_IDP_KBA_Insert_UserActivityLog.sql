﻿/*
Created Date : 09/02/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs into IDP_KBA_UserActivityLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_KBA_Insert_UserActivityLog]    
@CIAMID INT, 
@SSNDoB CHAR(40) ,
@Action SMALLINT ,
@Status SMALLINT ,
@UserChannel TINYINT = NULL,
@CreatedOn DATETIME,
@UserAgent VARCHAR(200),
@BrowserName VARCHAR(100),
@BrowserVersion VARCHAR(200)
AS    
BEGIN    
	SET NOCOUNT ON;    
 
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_IDP_KBA_Insert_UserActivityLog'  
  
	INSERT INTO [dbo].[IDP_KBA_UserActivityLog](CIAMID,SSNDoB,[Action],[Status],UserChannel,ResetLockStatus,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,UserAgent,BrowserName,BrowserVersion)    
	VALUES(@CIAMID,@SSNDoB,@Action,@Status,@UserChannel,0,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@UserAgent,@BrowserName,@BrowserVersion)    
END