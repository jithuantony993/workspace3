﻿/*
Created Date : 04/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Insert Into BankIDP_KBA_UserActivityLog.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_KBA_Insert_UserActivityLog]    
@CIAMID INT, 
@Action SMALLINT ,
@Status SMALLINT ,
@CreatedOn DATETIME
AS    
BEGIN   
	SET NOCOUNT ON;    
 
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_BankIDP_KBA_Insert_UserActivityLog'  
  
	INSERT INTO BankIDP_KBA_UserActivityLog (CIAMID,[Action],[Status],CreatedOn,CreatedBy)    
	VALUES(@CIAMID,@Action,@Status,@CreatedOn,@CreatedBy)     
END