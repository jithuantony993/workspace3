﻿/*
Created Date : 07/15/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Insert Into the EC_UserSharedSecretsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserSharedSecretsValidationLog]
@CIAMID INT,
@idHash VARCHAR(64),
@ValidationStatus SMALLINT,
@RemoteIPAddress VARCHAR(20),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@UserAgent VARCHAR(200), 
@BrowserName VARCHAR(100), 
@BrowserVersion VARCHAR(200)
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE	@CreatedBy VARCHAR(50) = 'Usp_EC_Insert_UserSharedSecretsValidationLog'

	INSERT INTO [dbo].[EC_UserSharedSecretsValidationLog]
	(CIAMID,idHash,ValidationStatus,RemoteIPAddress,ReferenceID,CreatedOn,CreatedBy,UserAgent,BrowserName,BrowserVersion)
	VALUES
	(@CIAMID,@idHash,@ValidationStatus,@RemoteIPAddress,@ReferenceID,@CreatedOn,@CreatedBy,@UserAgent,@BrowserName,@BrowserVersion)	
END