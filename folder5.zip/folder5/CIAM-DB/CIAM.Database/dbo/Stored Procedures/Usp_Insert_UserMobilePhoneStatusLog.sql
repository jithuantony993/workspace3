﻿/*
Created Date : 08/26/2022
Created By : Kalirajan
Changes Summary : New procedure to insert the Recs in UserMobilePhoneSkippedLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_Insert_UserMobilePhoneStatusLog]
@CIAMID int,
@CreatedOn DATETIME,
@StatusFlag INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Insert_UserMobilePhoneStatusLog'
																
	INSERT INTO [dbo].[UserMobilePhoneSkippedLog](CIAMID,CreatedOn,CreatedBy,StatusFlag)
	VALUES(@CIAMID,@CreatedOn,@CreatedBy,@StatusFlag)	
END