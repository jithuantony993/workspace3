﻿/*
Created Date : 09/05/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs into UserSharedSecretsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_Insert_UserSharedSecretsValidationLog]
@CIAMID INT,
@UserChannel TINYINT ,
@IdHash CHAR(64),
@ValidationStatus SMALLINT = 0,
@PageLocation VARCHAR(50),
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50) = 'Usp_Insert_UserSharedSecretsValidationLog'
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [dbo].[UserSharedSecretsValidationLog]
     ([CIAMID],[UserChannel],[IdHash],[ValidationStatus],[PageLocation],[CreatedOn],[CreatedBy])
     VALUES(@CIAMID,@UserChannel,@IdHash,@ValidationStatus,@PageLocation,@CreatedOn,@CreatedBy)	
END
GO