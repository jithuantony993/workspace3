﻿/*
Created Date : 12/14/2022
Created By : Parminder
*/
CREATE PROCEDURE [dbo].[Usp_PostAuth_Upsert_UserDetails]
@CIAMID INT,
@IsPasswordLock BIT,
@IsPasswordUsed BIT,
@IsMobileUsed BIT,
@ModifiedOn Datetime = NULL
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE	@ModifiedBy VARCHAR(50) = 'Usp_PostAuth_Upsert_UserDetails'
	
	IF EXISTS(SELECT 1 FROM PostAuth_UserDetails WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE PostAuth_UserDetails WITH(ROWLOCK)
		SET IsPasswordLock = @IsPasswordLock,
		IsPasswordUsed= @IsPasswordUsed,
		IsMobileUsed = @IsMobileUsed,
		ModifiedOn =@ModifiedOn,
		ModifiedBy = @ModifiedBy
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[PostAuth_UserDetails]
			(CIAMID, IsPasswordLock,IsPasswordUsed,IsMobileUsed,ModifiedOn,ModifiedBy)
		 VALUES(@CIAMID,@IsPasswordLock,@IsPasswordUsed,@IsMobileUsed,@ModifiedOn,@ModifiedBy)
	END

	
END