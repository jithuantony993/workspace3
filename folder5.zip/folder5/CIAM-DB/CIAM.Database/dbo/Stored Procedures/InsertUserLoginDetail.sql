﻿
/*
 Created By : Vitheesh
 Created Date : 26/12/2023
 Description : Insert user login report details
*/
CREATE PROCEDURE [dbo].[InsertUserLoginDetail] 

    @Identifier		    VARCHAR(150)=NULL,	
	@IdentifierType	VARCHAR(10)=NULL,
	@AccountType		INT=NULL	,
	@FlowID			VARCHAR(10)	= NULL,
	@ReferenceID		UNIQUEIDENTIFIER = NULL,
	@EntryUUID	UNIQUEIDENTIFIER	,
	@UserLogId		INT=NULL	,
	@CreatedTS			DATETIME 	
AS
BEGIN

			DECLARE 
		@CreatedBy VARCHAR(50)		= 'InsertUserLoginDetail',
		@CiamId INT
	SET NOCOUNT ON;	
	IF @UserLogId is null
		BEGIN
			INSERT INTO UserLoginDetail(Identifier,IdentifierType,FlowID,ReferenceID,CreatedTS,CreatedBy)
			VALUES(@Identifier,@IdentifierType,@FlowID,@ReferenceID,@CreatedTS,@CreatedBy)	
		END
	ELSE
		BEGIN
			SET @CiamId = (SELECT TOP 1 CIAMID from CIAMUserDetail WHERE EntryUUID =@EntryUUID)
			update UserLoginDetail set ciamid=ISNULL(@CiamId,ciamid),AccountType=ISNULL(@AccountType,AccountType),ModifiedTS=@CreatedTS,ModifiedBy=@CreatedBy
			 where UserLogID=@UserLogId
		END
	
	SELECT scope_identity() AS UserLogId;
END
GO
