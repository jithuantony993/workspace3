﻿/*
Created Date : 08/08/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Verify the User IDPSignature Exists
*/
CREATE PROCEDURE [dbo].[Usp_EC_Verify_UserIDPSignatureExists]
@CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;
	
	IF(SELECT ISNULL(IDPSignature,'') FROM IDP_User WITH(NOLOCK) WHERE CIAMID = @CIAMID) <> ''
	BEGIN
		SELECT 1 AS ValidationStatus
	END
	ELSE
	BEGIN
		SELECT 0 AS ValidationStatus
	END
END
GO