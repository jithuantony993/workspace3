﻿/*
Created Date : 08/30/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs in GA_UserKey Table.

Modified Date : 19/12/2022
Modified By : Kalirajan
Summary : Delete Some Code For DB CleanUp Activities.
*/
CREATE PROCEDURE [dbo].[Usp_GA_Insert_UserKey]
@CIAMID	INT,
@GoogleKey VARCHAR(512),
@Location VARCHAR(100) = NULL,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(100) = 'Usp_GA_Insert_UserKey' + ISNULL('|' + @Location,'')

	DECLARE @GOOGLE_AUTHENTICATION_REGISTERED SMALLINT = 5

	DECLARE @ContextInfo VARBINARY(128)
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
	SET CONTEXT_INFO @ContextInfo

	IF EXISTS(SELECT 1 FROM [dbo].[GA_UserKey] WITH(NOLOCK)	WHERE CIAMID = @CIAMID)
	BEGIN		
		UPDATE [dbo].[GA_UserKey] WITH(ROWLOCK)
		SET GoogleKey = @GoogleKey,
			RegistrationStatus = 1,
			ActivationStatus = 0,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[GA_UserKey](CIAMID,GoogleKey,RegistrationStatus,ActivationStatus,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy)
		VALUES(@CIAMID,@GoogleKey,1,0,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy)
	END
END