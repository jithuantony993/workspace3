﻿/*
Created Date : 09/02/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs into IDP_UserActivityLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Insert_UserActivityLog]
@CIAMID	INT,
@SSNDoB	CHAR(128),
@Action	SMALLINT,
@BrowserVersion VARCHAR(200),
@RemoteIPAddress VARCHAR(20),
@MachineIdentifier VARCHAR(40),
@BrowserAgentIdentifier INT,
@SessionID VARCHAR(50),
@CreatedOn DATETIME = NULL,
@CreatedBy VARCHAR(50) = 'Usp_IDP_Insert_UserActivityLog',
@SignInChannel	TINYINT,
@IDP_Source		TINYINT,
@UserChannel	TINYINT = NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[IDP_UserActivityLog](CIAMID,SSNDoB,[Action],CreatedOn,CreatedBy,SignInChannel,IDP_Source,UserChannel)
	VALUES(@CIAMID,@SSNDoB,@Action,@CreatedOn,@CreatedBy,@SignInChannel,@IDP_Source,@UserChannel)
END