﻿/* 
Created Date: 11/8/2023
Created By: Teegan Swanson
Changes Summary: Created this SP to get information for OpsCenter usage
Modified On: 11/9/23
Changes: Added aggregate value to show if the user has multiple ucids associated with an email in CIAMUserDetail
*/

CREATE PROCEDURE [dbo].[Usp_EAL_Get_LookupStatusForOpsCenter]
	@Email VARCHAR(100),
	@UCID VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP(15)
		Email,
		UCID,
		EALookupStatus,
		CreatedOn AS LookupTime,
		CASE
			WHEN EALookupStatus = 'EmailUcidMismatch' THEN (
				SELECT STRING_AGG(UCID, ', ')
				FROM CIAMUserDetail CUD (NOLOCK)
					INNER JOIN IDP_User IDP (NOLOCK) ON IDP.CIAMID = CUD.CIAMID
				WHERE Email = @Email AND IDPSignature IS NOT NULL
			)
			ELSE NULL
		END AS IDProofedUCID
	FROM [dbo].[EA_LookupLog] (NOLOCK)
	WHERE Email = @Email OR UCID = @UCID
	ORDER BY CreatedOn DESC
END
