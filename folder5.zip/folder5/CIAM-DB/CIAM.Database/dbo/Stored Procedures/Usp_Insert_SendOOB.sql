﻿
-- =============================================
-- Author:		<Alex Stevens>
-- Create date: <07/01/22>
-- Description:	<Insert Send OOB>
-- =============================================

CREATE PROCEDURE [dbo].[Usp_Insert_SendOOB]
@UserID						INT,
@MessageChannel				TINYINT,
@OOBChannel					VARCHAR(100)        NULL,
@SecurityCode				INT,
@UserGUID                   UNIQUEIDENTIFIER

AS
BEGIN
SET NOCOUNT ON;
	IF EXISTS
	(
		SELECT 1
		FROM dbo.OOBServiceSecurityCode WITH(NOLOCK)
		WHERE UserID = @UserID
	)
	BEGIN
		
		UPDATE OOBServiceSecurityCode WITH(ROWLOCK)
		SET 
			MessageChannel = @MessageChannel,
			UserGUID   = @UserGUID,
			OOBChannel = @OOBChannel,
			SecurityCode = @SecurityCode,
			IsActive = 1,
			ModifiedOn = SYSDATETIME(),
			ModifiedBy = 'UP_Insert_SendOOBCode'
		WHERE UserID = @UserID
	
	END
	ELSE

	BEGIN		

		INSERT OOBServiceSecurityCode(
			UserID,
			UserGUID,
			MessageChannel,
			OOBChannel,
			SecurityCode,
			SecurityCodeModifiedOn,
			IsActive,
			CreatedOn,
			CreatedBy,
			ModifiedOn,
			ModifiedBy	
		)
		VALUES(
			@UserID,
			@UserGUID,
			@MessageChannel,
			@OOBChannel,
			@SecurityCode,
			SYSDATETIME(),
			'1',
			SYSDATETIME(),
			'UP_Insert_SendOOBCode',
			SYSDATETIME(),
			'UP_Insert_SendOOBCode'
		)
	END

	INSERT INTO OOBServiceSecurityCodeLog(
		UserID,
		[Action],
		CreatedOn,
		CreatedBy,
		ModifiedOn,
		ModifiedBy
	)
	VALUES(
		@UserID,
		'Requested OOB Code',
		SYSDATETIME(),
		'UP_Insert_SendOOBCode',
		SYSDATETIME(),
		'UP_Insert_SendOOBCode'
	)
	
	SELECT UserGUID FROM OOBServiceSecurityCode 
		WHERE UserID = @UserID

END

