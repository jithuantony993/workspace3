﻿/*
Created Date : 07/15/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Insert the UserCardValidationLog.
				  2)Instead Of SessionID Change Into ReferenceID.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserCardValidationLog]
@CIAMID INT,
@TokenIndex SMALLINT,
@ValidationStatus SMALLINT,
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50)=NULL,
@BrowserName VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT @CreatedBy='Usp_EC_Insert_UserCardValidationLog'

	INSERT INTO EC_UserCardValidationLog(CIAMID,TokenIndex,ValidationStatus,
	RemoteIPAddress,BrowserVersion,ReferenceID,CreatedOn,CreatedBy,BrowserName) VALUES
	(@CIAMID,@TokenIndex,@ValidationStatus,
	@RemoteIPAddress,@BrowserVersion,@ReferenceID,@CreatedOn,@CreatedBy,@BrowserName)
END

