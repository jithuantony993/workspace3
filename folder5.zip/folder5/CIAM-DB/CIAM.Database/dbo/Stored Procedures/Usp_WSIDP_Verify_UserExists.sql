﻿/*
Created Date : 09/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Verify UserExists.
*/
CREATE PROCEDURE [dbo].[Usp_WSIDP_Verify_UserExists]
@TaxWorkspaceID UNIQUEIDENTIFIER
AS
BEGIN 
	SET NOCOUNT ON;
       
	DECLARE @MobilePhone VARCHAR(20)
		,@EmailID VARCHAR(100)

	SELECT @MobilePhone = ISNULL(MobilePhone,'')
		 ,@EmailID = ISNULL(EmailID,'')
	FROM [dbo].[WSIDP_UserDetails] WITH(NOLOCK)
	WHERE TaxWorkspaceID = @TaxWorkspaceID

	IF EXISTS(SELECT 1 FROM [dbo].[WSIDP_UserDetails] WITH(NOLOCK) WHERE EmailID = @EmailID)
	 OR EXISTS(SELECT 1 FROM [dbo].[WSIDP_UserDetails] WITH(NOLOCK) WHERE MobilePhone = @MobilePhone AND ISNULL(@MobilePhone,'') <> '')
	BEGIN
		SELECT UserExists = 1
	END
	ELSE
	BEGIN
		SELECT UserExists = 0
	END
END