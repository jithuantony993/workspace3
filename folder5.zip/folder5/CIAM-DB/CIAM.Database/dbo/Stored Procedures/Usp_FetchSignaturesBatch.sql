﻿
CREATE PROCEDURE [dbo].[Usp_FetchSignaturesBatch]
	@BatchSize INT
AS
BEGIN
	SET NOCOUNT ON
	BEGIN
		SELECT TOP(@BatchSize) CIAMID, UCID,Signature FROM [dbo].[Temp_Signature_Verification] WHERE Processed = 0
	END
END