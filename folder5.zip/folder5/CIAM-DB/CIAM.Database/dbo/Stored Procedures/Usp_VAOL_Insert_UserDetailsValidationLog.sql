﻿/*
Created Date : 06/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Insert Recs into VAOL_UserDetailsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_VAOL_Insert_UserDetailsValidationLog]
@CIAMID INT NULL,
@SSNDoB CHAR(64) NULL,
@VAOLWorkspaceID UNIQUEIDENTIFIER NULL,
@FirstName VARCHAR(50) NULL,
@LastName VARCHAR(50) NULL,
@EmailSentOn DATETIME NULL,
@ValidationStatus SMALLINT NULL,
@CreatedOn DATETIME NULL,
@CreatedBy VARCHAR(50) NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[VAOL_UserDetailsValidationLog]
	(CIAMID,SSNDoB,VAOLWorkspaceID,FirstName,LastName,EmailSentOn,ValidationStatus,CreatedOn,CreatedBy)
	VALUES
	(@CIAMID,@SSNDoB,@VAOLWorkspaceID,@FirstName,@LastName,@EmailSentOn,@ValidationStatus,@CreatedOn,@CreatedBy)		
	
END