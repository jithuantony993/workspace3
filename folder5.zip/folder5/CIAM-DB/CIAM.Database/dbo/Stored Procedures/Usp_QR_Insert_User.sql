﻿CREATE PROCEDURE [dbo].[Usp_QR_Insert_User]	
	@UCID VARCHAR(50) = NULL,
	@EntryUUID UNIQUEIDENTIFIER = NULL,
	@PingOneID UNIQUEIDENTIFIER = NULL,
	@FirstName VARCHAR(50) = NULL,
	@LastName VARCHAR(50) = NULL,
	@Email VARCHAR(100) = NULL,
	@Phone VARCHAR(50) = NULL,
	@TaxProID VARCHAR(50) = NULL,
	@OfficeID VARCHAR(50) = NULL,
	@ServiceTransactionID VARCHAR(50) = NULL,
	@MessageChannel TINYINT = NULL,	
	@EmailVerified BIT = NULL,
	@PhoneVerified BIT = NULL,
	@UUID UNIQUEIDENTIFIER = NULL,
	@VerifiedMessageChannel TINYINT = NULL, 
	@Active BIT = NULL,
	@IsSpruceSuccess BIT = NULL,
	@IsOTPSuccess BIT = NULL,
	@SpruceLookupStatus BIT = NULL,
	@IsBWO BIT = NULL
AS

BEGIN
	SET NOCOUNT ON;	
	DECLARE @EmptyGUID	 UNIQUEIDENTIFIER	= '00000000-0000-0000-0000-000000000000'	
	
	IF (ISNULL(@UUID, @EmptyGUID) != @EmptyGUID)	
		BEGIN		

		INSERT INTO QRCodeUserLog (UUID, EntryUUID, PingOneID,MessageChannel, VerifiedMessageChannel, Active, IsSpruceSuccess, IsOTPSuccess, CreatedOn)
		SELECT qr.UUID, qr.EntryUUID, qr.PingOneID, qr.MessageChannel, qr.VerifiedMessageChannel, qr.Active, qr.IsSpruceSuccess, qr.IsOTPSuccess, GETDATE()
		FROM QRCodeUser qr (NOLOCK)
		WHERE qr.UUID = @UUID;


			DECLARE @ModifiedOn DATETIMEOFFSET = [dbo].[udf_Get_CST_Offset](sysdatetimeoffset());
			
			UPDATE [dbo].[QRCodeUser]
			SET 
				[EntryUUID] = Isnull(@EntryUUID,EntryUUID),
				[PingOneID] = ISNULL(@PingOneID, PingOneID),
				[VerifiedMessageChannel] =ISNULL(@VerifiedMessageChannel, VerifiedMessageChannel),
				[Active] = ISNULL(@Active,Active),
				[ModifiedOn] = ISNULL(@ModifiedOn,ModifiedOn),
				[IsSpruceSuccess] = ISNULL(@IsSpruceSuccess,IsSpruceSuccess),
				[IsOTPSuccess] =ISNULL( @IsOTPSuccess,@IsOTPSuccess),
				[SpruceLookupStatus] = ISNULL(@SpruceLookupStatus,SpruceLookupStatus)
			WHERE [UUID] = @UUID
		END
	ELSE
		BEGIN
			SET @UUID = NEWID();	
		
			INSERT INTO [dbo].[QRCodeUser]
				(
					[UUID],
					[UCID],			
					[EntryUUID],
					[PingOneID],
					[FirstName],
					[LastName],
					[Email],
					[Phone],
					[TaxProID],
					[OfficeID],
					[ServiceTransactionID],
					[MessageChannel],
					[EmailVerified],
					[PhoneVerified],
					[IsBWO]
				)
			VALUES
				(
					@UUID,
					@UCID,
					@EntryUUID,
					@PingOneID,
					@FirstName,
					@LastName,
					@Email,
					@Phone,
					@TaxProID,
					@OfficeID,
					@ServiceTransactionID,
					@MessageChannel,
					@EmailVerified,
					@PhoneVerified,
					@IsBWO
				)
			
			SELECT @UUID AS UUID
		END
	
	
END