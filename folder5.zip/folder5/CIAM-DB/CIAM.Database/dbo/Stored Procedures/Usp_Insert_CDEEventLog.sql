﻿/*
Created By: Jonathan Carpenter
Created Date: 02/13/2023
Summary : To Inser the Log Details into CDEEventLog Table
*/
CREATE PROCEDURE [dbo].[Usp_Insert_CDEEventLog]
@UserID INT,
@CDEEventID INT,
@CreatedBy VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedOn DATETIME = [dbo].[udf_Get_CST](SYSDATETIME())

	INSERT INTO [dbo].[CDEEventLog](UserID,CDEEventID,CreatedOn,CreatedBy)
	VALUES(@UserID,@CDEEventID,@CreatedOn,@CreatedBy)
END
