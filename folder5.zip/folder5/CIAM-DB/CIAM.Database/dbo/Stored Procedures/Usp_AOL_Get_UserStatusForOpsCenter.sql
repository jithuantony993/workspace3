﻿/* 
Created Date: 10/12/2023
Modified On: 11/8/2023
Created By: Teegan Swanson
Changes Summary: Updated to only hold less information in larger quantities, groomed unnecessary columns for growing OpsCenter Scope (all IDP information, CIAMUserDetails, etc.)
*/

CREATE PROCEDURE [dbo].[Usp_AOL_Get_UserStatusForOpsCenter]
	@Email VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		AUD.EmailSentOn,
		AD.ValidationStatus,
		AD.CreatedOn AS ValidationDate
	FROM [dbo].[AOL_UserDetails] AUD (NOLOCK)
		LEFT JOIN [dbo].[AOL_UserDetailsValidationLog] AD (NOLOCK) ON AUD.EmailSentOn = AD.EmailSentOn AND AUD.SSNDOB = AD.SSNDOB
	WHERE AUD.EmailID = @Email 
	ORDER BY AUD.EmailSentOn DESC

END
