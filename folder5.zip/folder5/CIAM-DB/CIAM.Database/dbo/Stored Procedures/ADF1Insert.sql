﻿

CREATE PROCEDURE [dbo].[ADF1Insert] (
@udt_adf1 [dbo].[UDT_ADF1] READONLY
)
AS


BEGIN TRY 

BEGIN
    SET IDENTITY_INSERT CIAMUserDetail ON
	IF EXISTS (SELECT 1 FROM [dbo].[CIAMUserDetail] cud INNER JOIN  @udt_adf1 UDT ON cud.CIAMID = UDT.CIAMID)
	BEGIN
		UPDATE c
		SET EntryUUID = UDT_CiamUserDetail.EntryUUID,
			IdHash = UDT_CiamUserDetail.IdHash,
			CreatedTS = UDT_CiamUserDetail.CreatedTS,
			CreatedBy = UDT_CiamUserDetail.CreatedBy,
			ModifiedTS = UDT_CiamUserDetail.ModifiedTS,
			ModifiedBy = UDT_CiamUserDetail.ModifiedBy,
			LoginTS = UDT_CiamUserDetail.LoginTS,
			AccountStatusInd = UDT_CiamUserDetail.AccountStatusInd,
			DeleteStatusInd = UDT_CiamUserDetail.DeleteStatusInd,
			EccEulaVersion = UDT_CiamUserDetail.ECCEulaVersion,
			EccEulaModifiedOn = UDT_CiamUserDetail.ECCEulaModifiedOn,
			OsaEulaVersion = UDT_CiamUserDetail.OSAEulaVersion,
			OsaEulaModifiedOn = UDT_CiamUserDetail.OSAEulaModifiedOn,
			OmbaEulaVersion = UDT_CiamUserDetail.OmbaEulaVersion,
			OmbaEulaModifiedOn = UDT_CiamUserDetail.OmbaEulaModifiedOn,
			IDVerified = UDT_CiamUserDetail.IDVerified,
			UCID = UDT_CiamUserDetail.UCID,
			Email = UDT_CiamUserDetail.Email,
			Mobile = UDT_CiamUserDetail.Mobile,
			CountryCode = UDT_CiamUserDetail.CountryCode,
			MigratedToPing = UDT_CiamUserDetail.MigratedToPing,
			[Login] = UDT_CiamUserDetail.Login,
			GuaPassword = UDT_CiamUserDetail.GuaPassword
		FROM CIAMUserDetail c
		INNER JOIN @udt_adf1 UDT_CiamUserDetail
		ON c.CIAMID = UDT_CiamUserDetail.CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO CIAMUserDetail
		(
			CIAMID,
			EntryUUID,
			IdHash,
			CreatedTS,
			CreatedBy,
			ModifiedTS,
			ModifiedBy,
			LoginTS,
			AccountStatusInd,
			DeleteStatusInd,
			EccEulaVersion,
			EccEulaModifiedOn,
			OsaEulaVersion,
			OsaEulaModifiedOn,
			OmbaEulaVersion,
			OmbaEulaModifiedOn,
			IDVerified,
			UCID,
			Email,
			Mobile,
			CountryCode,
			MigratedToPing,
			[Login],
			GuaPassword

		)
		SELECT

			udt_adfvar.CIAMID,
			udt_adfvar.EntryUUID,
			udt_adfvar.IdHash,
			udt_adfvar.CreatedTS,
			udt_adfvar.CreatedBy,
			udt_adfvar.ModifiedTS,	
			udt_adfvar.ModifiedBy,
			udt_adfvar.LoginTS ,
			udt_adfvar.AccountStatusInd ,
			udt_adfvar.DeleteStatusInd ,
			udt_adfvar.ECCEulaVersion ,
			udt_adfvar.ECCEulaModifiedOn ,
			udt_adfvar.OSAEulaVersion ,
			udt_adfvar.OSAEulaModifiedOn ,
			udt_adfvar.OmbaEulaVersion,
			udt_adfvar.OmbaEulaModifiedOn,
			udt_adfvar.IDVerified ,
			udt_adfvar.UCID,
			udt_adfvar.Email,
			udt_adfvar.Mobile,
			udt_adfvar.CountryCode,
			udt_adfvar.MigratedToPing,
			udt_adfvar.[Login],
			udt_adfvar.GuaPassword
			FROM @udt_adf1 udt_adfvar
		END
	END
END TRY

BEGIN CATCH
INSERT INTO [dbo].[DataSyncFailedRecordsLog]
        (
            CIAMID,
            BatchId,
            CreatedBy,
            CreatedOn,
			ErrorMessage
        )
          SELECT 
                udt_adfvar. UserID_EC_UserDetails,
                udt_adfvar.BatchId,
                'ADF1Insert_CIAMUserDetails',
                GETDATE(),
				ERROR_MESSAGE()
            FROM @udt_adf1 udt_adfvar
END CATCH

--Inserting into EC_UserDetails only if entry exists.
BEGIN TRY 
BEGIN
	IF EXISTS (SELECT 1 FROM [dbo].[EC_UserDetails] G INNER JOIN @udt_adf1 UDT_ECUserDetails ON G.CIAMID = UDT_ECUserDetails.UserID_EC_UserDetails)
	BEGIN
	UPDATE G
	SET
		CreatedOn = UDT_ECUserDetails.EC_EULAStatus_EC_UserDetails,
		CreatedBy = UDT_ECUserDetails. CreatedBy_EC_UserDetails,
		ModifiedOn = UDT_ECUserDetails.ModifiedOn_EC_UserDetails,
		ModifiedBy = UDT_ECUserDetails.ModifiedBy_EC_UserDetails,
		EC_EULAStatus = UDT_ECUserDetails.EC_EULAStatus_EC_UserDetails,
		EC_EULAVersion = UDT_ECUserDetails.EC_EULAVersion_EC_UserDetails
	FROM [dbo].[EC_UserDetails] g
	INNER JOIN @udt_adf1 UDT_ECUserDetails
	ON g.CIAMID = UDT_ECUserDetails.UserID_EC_UserDetails
	END
	ELSE
	BEGIN
	INSERT INTO dbo.EC_UserDetails 
	(
		CIAMID,
		CreatedOn,
		CreatedBy,
		ModifiedOn,
		ModifiedBy,
		EC_EULAStatus,
		EC_EULAVersion
	)
	SELECT
		udt_adfvar.UserID_EC_UserDetails,
		udt_adfvar.CreatedOn_EC_UserDetails,
		udt_adfvar.CreatedBy_EC_UserDetails,
		udt_adfvar.ModifiedOn_EC_UserDetails,
		udt_adfvar.ModifiedBy_EC_UserDetails,
		udt_adfvar.EC_EULAStatus_EC_UserDetails,
		udt_adfvar.EC_EULAVersion_EC_UserDetails

	FROM @udt_adf1 udt_adfvar
	where udt_adfvar.UserID_EC_UserDetails is not null
	END
END
END TRY

BEGIN CATCH
INSERT INTO [dbo].[DataSyncFailedRecordsLog]
        (
            CIAMID,
            BatchId,
            CreatedBy,
            CreatedOn,
			ErrorMessage
        )
          SELECT 
                udt_adfvar. UserID_EC_UserDetails,
                udt_adfvar.BatchId,
                'ADF1Insert_EC_UserDetails',
                GETDATE(),
				ERROR_MESSAGE()
            FROM @udt_adf1 udt_adfvar
END CATCH

--Inserting into BankIDP_UserDetails only if entry exists.
BEGIN TRY 
	BEGIN
	IF EXISTS (SELECT 1 FROM [dbo].[BankIDP_UserDetails] G INNER JOIN @udt_adf1 udt ON G.CIAMID = udt.CIAMID_BIDP)
	BEGIN
	UPDATE b
	SET
		 idHash = udt_BankIDP.IDHASH_BIDP,
		 IDProofed = udt_BankIDP.IDPROOFED_BIDP,
		 PIIValidationStatus = udt_BankIDP.PIIValidationStatus,
		 BankIDPLockStatus = udt_BankIDP.BankIDPLockStatus,
		 UserType = udt_BankIDP.UserType,
		 CreatedOn = udt_BankIDP.CreatedOn,
		 CreatedBy = udt_BankIDP.CreatedBy_BIDP,
		 ModifiedOn = udt_BankIDP.ModifiedOn,
		 ModifiedBy = udt_BankIDP.ModifiedBy_BIDP,
		 BankIDPSoftFail = udt_BankIDP.BankIDPSoftFail,
		 BankIDPHardFail = udt_BankIDP.AccountStatusInd,
		 EmailID = udt_BankIDP.EmailID_BIDP,
		 MobilePhone = udt_BankIDP.MobilePhone_BIDP,
		 KBALockStatus = udt_BankIDP.KBALockStatus,
		 MFJlinkEnabled = udt_BankIDP.MFJlinkEnabled,
		 SpouseEmailID = udt_BankIDP.SpouseEmailID,
		 BankIDPProcessed = udt_BankIDP.BankIDPProcessed
	FROM [dbo].BankIDP_UserDetails b
	INNER JOIN @udt_adf1 udt_BankIDP 
	ON b.CIAMID = udt_BankIDP.CIAMID_BIDP
	END
	ELSE
	BEGIN
	INSERT INTO BankIDP_UserDetails
	(
		 CIAMID,
		 idHash,
		 IDProofed,
		 PIIValidationStatus,
		 BankIDPLockStatus,
		 UserType,
		 CreatedOn,
		 CreatedBy,
		 ModifiedOn,
		 ModifiedBy,
		 BankIDPSoftFail,
		 BankIDPHardFail,
		 EmailID,
		 MobilePhone,
		 KBALockStatus,
		 MFJlinkEnabled,
		 SpouseEmailID,
		 BankIDPProcessed
	)
	SELECT 
		udt_adfvar.CIAMID_BIDP,
		udt_adfvar.IDHASH_BIDP ,
		udt_adfvar.IDPROOFED_BIDP ,
		udt_adfvar.PIIValidationStatus ,
		udt_adfvar.BankIDPLockStatus ,
		udt_adfvar.UserType ,
		udt_adfvar.CreatedOn ,
		udt_adfvar.CreatedBy_BIDP ,
		udt_adfvar.ModifiedOn ,
		udt_adfvar.ModifiedBy_BIDP ,
		udt_adfvar.BankIDPSoftFail ,
		udt_adfvar.BankIDPHardFail ,
		udt_adfvar.EmailID_BIDP ,
		udt_adfvar.MobilePhone_BIDP ,
		udt_adfvar.KBALockStatus ,
		udt_adfvar.MFJlinkEnabled,
		udt_adfvar.SpouseEmailID ,
		udt_adfvar.BankIDPProcessed
	FROM @udt_adf1 udt_adfvar
	WHERE udt_adfvar.CIAMID_BIDP is not null
	END
	END
END TRY

BEGIN CATCH
	INSERT INTO [dbo].[DataSyncFailedRecordsLog]
       		(
           		CIAMID,
           		BatchId,
           		CreatedBy,
           		CreatedOn,
				ErrorMessage
       		)
         	  SELECT 
               		udt_adfvar. UserID_EC_UserDetails,
               		udt_adfvar.BatchId,
               		'ADF1Insert_Bank',
               		GETDATE(),
					ERROR_MESSAGE()
           		FROM @udt_adf1 udt_adfvar
END CATCH

