﻿/*
Created Date : 01/06/2023
Created By : Muthukumar
*/
CREATE PROCEDURE [dbo].[Usp_Get_PasswordLockStatus]
@CIAMID INT
AS
BEGIN 
	SET NOCOUNT ON;

	SELECT IsPasswordLock
	FROM [dbo].[PasswordLockStatus] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID	
END