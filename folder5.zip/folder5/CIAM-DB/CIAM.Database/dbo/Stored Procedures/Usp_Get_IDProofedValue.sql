﻿-- Change History
   -- Kalirajan_07/02/2023 - To Get the user info for IdProofedUser
   -- AJ_10/09/2023        - Fetch LoginTS from CIAMUserDetail

CREATE PROCEDURE [dbo].[Usp_Get_IDProofedValue] @CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Idhash VARCHAR(64),
	        @IsActive int,
			@signature VARCHAR(512),
			@idpChannel VARCHAR(10),
			@CardProofCount INT,
			@BankIDPStatus BIT,
			@bankIDPSoftFail BIT,
			@bankIDPHardFail BIT,
			@EIN VARCHAR(255),
			@VAOLWorkspaceID VARCHAR(255),
			@VAOLTaxYear VARCHAR(255),
			@UserGUID UNIQUEIDENTIFIER,
			@PIN VARCHAr(64),
			@TaxReturnGuid UNIQUEIDENTIFIER,
			@TaxWorkspaceID UNIQUEIDENTIFIER,
			@WaveAccessToken VARCHAR(255),
			@LastLoginDate datetimeoffset
	
	SELECT @Idhash=IdHash,@isActive= AccountStatusInd,@LastLoginDate=LoginTS FROM CIAMUserDetail WHERE CIAMID=@CIAMID
		
    SELECT @CardProofCount=COUNT(1) FROM [dbo].[EC_UserDetails] ec INNER JOIN [dbo].[IDP_User] idp on ec.CIAMID = idp.CIAMID
				WHERE ec.CIAMID=@CIAMID and (idp.IDPChannel = '3' or ec.CardProofedStatus = 1)

	

	SELECT @Signature=IDPSignature,@idpChannel=IDPChannel, @UserGUID=UserGUID FROM [dbo].[IDP_User] WHERE CIAMID=@CIAMID
	SELECT @BankIDPStatus=BankIDPProcessed,@bankIDPSoftFail=BankIDPSoftFail,@bankIDPHardFail=BankIDPHardFail FROM [dbo].[BankIDP_UserDetails] WHERE CIAMID=@CIAMID
	SELECT @EIN=EIN,@VAOLWorkspaceID=VAOL_WorkspaceID,@VAOLTaxYear= VAOLTaxYear FROM [dbo].[IDP_User] WHERE CIAMID =@CIAMID
	SELECT @PIN=PIN,@TaxReturnGuid=TaxReturnGUID,@TaxWorkspaceID=TaxWorkspaceID FROM [dbo].[WSIDP_UserDetails] WHERE SSNDOB=@Idhash
	SELECT @WaveAccessToken = WaveAccessToken FROM [dbo].[Wave_UserDetails] WHERE CIAMID = @CIAMID	
	
	SELECT @Signature 'signature',@idpChannel 'idpChannel',CASE WHEN @CardProofCount>0 THEN @Signature ELSE NULL END 'cardProofingSignature'
	,@BankIDPStatus 'bankIDPStatus',@bankIDPSoftFail 'bankIDPSoftFail',@bankIDPHardFail 'bankIDPHardFail'
	,@EIN 'ein',@VAOLWorkspaceID 'vaolWorkspaceID',@VAOLTaxYear 'vaolTaxYear',@UserGUID 'userGuid'
	,@PIN 'pin',@TaxReturnGuid 'taxReturnGuid',@TaxWorkspaceID 'taxWorkSpaceID',@WaveAccessToken 'WaveAccessToken'
	,@Idhash 'Idhash',@isActive 'IsActive', @lastLoginDate 'LastLoginDate'
END