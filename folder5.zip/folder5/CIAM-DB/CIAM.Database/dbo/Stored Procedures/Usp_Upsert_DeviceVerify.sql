﻿/*
Created Date : 16/02/2023
Created By: Kalirajan
Summary : To Insert & Update An the Get the Email Verification Status.
*/
CREATE PROC [dbo].[Usp_Upsert_DeviceVerify] 
 @EntryUuid VARCHAR(256)
,@DeviceVerifyStatus BIT
,@DeviceType BIT
,@CreatedDate DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50)='Usp_Upsert_DeviceVerify'
	DECLARE @CIAMID INT =0
	SELECT @CIAMID= CIAMID FROM [dbo].[CIAMUserDetail] where EntryUUID=@EntryUuid

	IF NOT EXISTS(SELECT 1 FROM [dbo].[DeviceVerify] WHERE CIAMID=@CIAMID)
	BEGIN
		INSERT INTO [dbo].[DeviceVerify](CIAMID,DeviceVerifyStatus,DeviceType,CreatedOn,CreatedBy)
		VALUES(@CIAMID,@DeviceVerifyStatus,@DeviceType,@CreatedDate,@CreatedBy)
	END
	ELSE
	BEGIN
		UPDATE [dbo].[DeviceVerify] SET DeviceVerifyStatus=@DeviceVerifyStatus,CreatedOn=@CreatedDate,CreatedBy=@CreatedBy
		WHERE CIAMID=@CIAMID
	END
END
