﻿CREATE PROCEDURE [dbo].[Usp_Upsert_LowQualityAuthStatus]
    @CiamID					INT				,
	@LowQualAccountStatus	BIT				,
	@PasswordResetStatus	BIT				,
	@MobileUpdateStatus		BIT				,
	@CreatedTS				DATETIMEOFFSET	
AS
BEGIN
	SET NOCOUNT ON
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Upsert_LowQualityAuthStatus'

	IF NOT EXISTS(SELECT 1 FROM LowQualityAuthStatus WITH (NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		INSERT INTO [LowQualityAuthStatus](CiamID,LowQualAccountStatus,PasswordResetStatus,MobileUpdateStatus,CreatedTS,CreatedBy,ModifiedTS,ModifiedBy)
		VALUES(@CiamID,@LowQualAccountStatus,@PasswordResetStatus,@MobileUpdateStatus,@CreatedTS,@CreatedBy,@CreatedTS,@CreatedBy)
	END
	ELSE
	BEGIN
		UPDATE [LowQualityAuthStatus] WITH (ROWLOCK) SET
		LowQualAccountStatus = @LowQualAccountStatus,
		PasswordResetStatus = CASE WHEN PasswordResetStatus <> 1 AND @PasswordResetStatus IS NOT NULL THEN @PasswordResetStatus ELSE PasswordResetStatus END,
		MobileUpdateStatus = CASE WHEN MobileUpdateStatus <> 1  AND @MobileUpdateStatus IS NOT NULL THEN @MobileUpdateStatus ELSE MobileUpdateStatus END,
		ModifiedTS =  @CreatedTS ,
		ModifiedBy =  @CreatedBy 
		WHERE CIAMID = @CIAMID 
	END

END