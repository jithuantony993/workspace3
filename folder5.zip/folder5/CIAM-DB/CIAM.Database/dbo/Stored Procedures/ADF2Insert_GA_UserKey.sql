﻿
/*
Created By : Kalirajan
Created Date : 09/01/2023
Summary : For Datsync ADF2 GA_UserKey Table.
*/
CREATE PROCEDURE [dbo].[ADF2Insert_GA_UserKey] 
(
    @udt_adf_GA_UserKey [dbo].[UDT_GA_UserKey] READONLY
)
AS
BEGIN
    SET NOCOUNT ON

    BEGIN TRY

	IF EXISTS (SELECT 1 FROM [dbo].[GA_UserKey] I INNER JOIN @udt_adf_GA_UserKey udt_adf_GA_UserKey ON I.CIAMID=udt_adf_GA_UserKey.UserID WHERE CIAMID = udt_adf_GA_UserKey.UserID)
	BEGIN
		UPDATE I
		SET CIAMID = udt_adf_GA_UserKey.UserID
		,GoogleKey = udt_adf_GA_UserKey.GoogleKey
		,RegistrationStatus=udt_adf_GA_UserKey.RegistrationStatus
		,ActivationStatus=udt_adf_GA_UserKey.ActivationStatus
		,CreatedOn = udt_adf_GA_UserKey.CreatedOn
		,CreatedBy = udt_adf_GA_UserKey.CreatedBy
		,ModifiedOn = udt_adf_GA_UserKey.ModifiedOn
		,ModifiedBy = udt_adf_GA_UserKey.ModifiedBy
		FROM [dbo].[GA_UserKey] I INNER JOIN @udt_adf_GA_UserKey udt_adf_GA_UserKey 
		ON I.CIAMID=udt_adf_GA_UserKey.UserID

	END
	ELSE
	BEGIN
        INSERT INTO 
        [dbo].[GA_UserKey]
        (
            CIAMID,
            GoogleKey,
			RegistrationStatus,
			ActivationStatus,
            CreatedOn,
            CreatedBy,
            ModifiedOn,
            ModifiedBy
        )
        
        SELECT 
            udt_adf_GA_UserKey.UserID,
            udt_adf_GA_UserKey.GoogleKey,
			udt_adf_GA_UserKey.RegistrationStatus,
            udt_adf_GA_UserKey.ActivationStatus,
            udt_adf_GA_UserKey.CreatedOn,
            udt_adf_GA_UserKey.CreatedBy,
            udt_adf_GA_UserKey.ModifiedOn,
            udt_adf_GA_UserKey.ModifiedBy
            from @udt_adf_GA_UserKey udt_adf_GA_UserKey
	END
	
    END TRY
    BEGIN CATCH
 
        INSERT INTO [dbo].[DataSyncFailedRecordsLog]
        (
            CIAMID,
            BatchId,
            CreatedBy,
            CreatedOn
        )
        
            SELECT 
                udt_adf_GA_UserKey. UserID,
                udt_adf_GA_UserKey.BatchId,
                'ADF2Insert_GA_UserKey',
                GETDATE()
            FROM @udt_adf_GA_UserKey udt_adf_GA_UserKey

    END CATCH
END

