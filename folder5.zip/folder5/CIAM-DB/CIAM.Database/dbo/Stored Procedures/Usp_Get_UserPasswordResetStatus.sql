﻿/*
Created Date : 08/26/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in UserPasswordResetSkippedLog Table.

Modified Date : 13/03/2023
Modified By : Kalirajan
Changes Summary : To Add ORDER BY Condition in that Proc
*/
CREATE PROCEDURE [dbo].[Usp_Get_UserPasswordResetStatus]
@CIAMID INT,
@INITIATEDATE DATETIME
AS
BEGIN
	SET NOCOUNT ON;

  	--Business Logic to filter the yearly data
	DECLARE  @initiate_month int, @initiate_day int, @initiate_date varchar(20), 
	@end_day int, @start_date varchar(20), @end_date varchar(20),
	@year_value int, @date_value int, @month_value int,
	@StartYear VARCHAR(20), @EndYear VARCHAR(20), @Today_Date datetime, @start_data_dt datetime
 
	SET @Today_Date = [dbo].[udf_Get_CST](GETDATE())
	SET @year_value = YEAR(@Today_Date)
	SET @month_value = MONTH(@Today_Date)
	SET @date_value = DAY(@Today_Date)

	SET @initiate_month = MONTH(@INITIATEDATE)
	SET @initiate_day = DAY(@INITIATEDATE)	  

  
	SET @StartYear = (CASE WHEN @month_value < @initiate_month OR
	(@month_value = @initiate_month and @date_value < @initiate_day)
	THEN convert(varchar(4), @year_value - 1)
	ELSE convert(varchar(4), @year_value)
	END)
  
	SET @start_date = concat(@StartYear,'/',FORMAT(@initiate_month,'0#'),'/',FORMAT(@initiate_day,'0#'))  
	
	Select @start_data_dt = CAST(@start_date AS datetime)

	SELECT TOP 1 CIAMID,StatusFlag
	FROM [dbo].[UserPasswordResetSkippedLog] WITH(NOLOCK)
	WHERE CIAMID=@CIAMID 
	AND CreatedOn >= @start_data_dt 
	AND CreatedOn <= @Today_Date
	ORDER BY ID DESC
END