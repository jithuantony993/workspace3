﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Records into EC_UserEULAStatusLog Table. 
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserEULAStatusLog]
@CIAMID INT,
@EC_EULAStatus BIT,
@EC_EULAVersion SMALLINT,
@BrowserVersion VARCHAR(200),
@RemoteIPAddress VARCHAR(20),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@UserAgent VARCHAR(200),
@BrowserName VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50)='Usp_EC_Insert_UserEULAStatusLog'

	INSERT INTO EC_UserEULAStatusLog
	(CIAMID,EC_EULAStatus,EC_EULAVersion,BrowserVersion,RemoteIPAddress,ReferenceID,CreatedOn,CreatedBy,UserAgent,BrowserName)
	VALUES
	(@CIAMID,@EC_EULAStatus,@EC_EULAVersion,@BrowserVersion,@RemoteIPAddress,@ReferenceID,@CreatedOn,@CreatedBy,@UserAgent,@BrowserName)
END