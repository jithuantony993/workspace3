﻿CREATE PROCEDURE [dbo].[Usp_ADHOC_ADF_IDP_Archive_IDP_User]
@CIAMID int,
@ModifiedBy VARCHAR(50)
AS
BEGIN
-- Change History
   -- AJ_1/19/24 - Add ad hoc SP for unidproof.

SET NOCOUNT ON;
	
	DECLARE @CreatedOn DATETIME = dbo.Udf_Get_CST(GETDATE()),
	@CreatedOnOffset DATETIMEOFFSET = dbo.udf_Get_CST_Offset(GETDATE())
	
   INSERT INTO IDP_User_Archive(CIAMID,UCID,IdHash, IDPSignature, CreatedOn, CreatedBy, ModifiedOn, ModifiedBy, DeletedOn, DeletedBy, IDPChannel, UserGUID, TaxReturnGUID, TaxWorkspaceID, PaperlessWorkSpaceID, VAOLTaxYear, EIN, VAOL_WorkspaceID)
	SELECT C.CIAMID, C.UCID, C.IdHash, I.IDPSignature, I.CreatedOn, I.CreatedBy, I.ModifiedOn, I.ModifiedBy, @CreatedOn, @ModifiedBy, I.IDPChannel, I.UserGUID, I.TaxReturnGUID, I.TaxWorkspaceID, I.PaperlessWorkSpaceID, I.VAOLTaxYear, I.EIN, I.VAOL_WorkspaceID
	FROM CIAMUserDetail C WITH(NOLOCK) 
	INNER JOIN IDP_User I  WITH(NOLOCK)  ON C.CiamID = I.CIAMID
	WHERE C.CIAMID = @CIAMID

		IF @@error = 0
		BEGIN
			WAITFOR DELAY '00:00:01'

			DELETE FROM IDP_User WITH(ROWLOCK) WHERE CIAMID = @CIAMID
			
			WAITFOR DELAY '00:00:01'
			
			Update C WITH(ROWLOCK)
			SET IdHash = NULL,
			    UCID = NULL,
				ModifiedBy = @ModifiedBy,
				ModifiedTS = @CreatedOnOffset
			FROM CIAMUserDetail C
			WHERE C.CIAMID = @CIAMID

			UPDATE IRS WITH (ROWLOCK)
			SET IDENTITYPROOFINGLEVEL = 0,
			    ModifiedBy = @ModifiedBy
			FROM UserIRSDetail IRS
			WHERE IRS.CIAMID = @CIAMID
			AND IdentityProofingLevel = 1
        END
   	    
		INSERT INTO EC_UserDetails_Archive(CIAMID, CreatedOn, CreatedBy, ModifiedOn, ModifiedBy, DeletedOn, DeletedBy, EC_EULAStatus, EC_EULAVersion, CardProofedStatus)
			SELECT CIAMID, CreatedOn, CreatedBy, ModifiedOn, ModifiedBy, @CreatedOn, @ModifiedBy , EC_EULAStatus, EC_EULAVersion, CardProofedStatus
			FROM EC_UserDetails WITH(NOLOCK)
			WHERE CIAMID = @CIAMID			

		IF @@error = 0 
		BEGIN
			WAITFOR DELAY '00:00:01'
			DELETE FROM EC_UserDetails WITH(ROWLOCK) WHERE CIAMID = @CIAMID
        END
END