﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Insert Into the EC_UserTokensLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserTokensLog]
@CIAMID INT,
@MachineIdentifier VARCHAR(40),
@BrowserAgentIdentifier INT,
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@ReferenceID VARCHAR(50),
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO EC_UserTokensLog(CIAMID,MachineIdentifier,BrowserAgentIdentifier,RemoteIPAddress,BrowserVersion,ReferenceID,CreatedOn,CreatedBy)
	VALUES(@CIAMID,@MachineIdentifier,@BrowserAgentIdentifier,@RemoteIPAddress,@BrowserVersion,@ReferenceID,@CreatedOn,@CreatedBy)
END


