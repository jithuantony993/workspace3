﻿/*
Modified By : Kalirajan
Modified Date : 10/03/2023
Changes Summary : To Update the BankIDPProcessed Column in that Sp.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Modify_ProcessDetails]
@CIAMID INT,
@IsProcessed BIT = 0,
@CreatedOn DATETIME
AS
BEGIN
    SET NOCOUNT ON;
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_BankIDP_Modify_ProcessDetails'     
	
	UPDATE [dbo].[BankIDP_UserDetails] WITH(ROWLOCK)
    SET BankIDPProcessed = @IsProcessed,
    ModifiedOn = @CreatedOn,
    ModifiedBy = @CreatedBy
    WHERE CIAMID = @CIAMID

	EXEC [dbo].[Usp_BankIDP_Insert_UserDetailsLog]
        @CIAMID = @CIAMID,
        @BankIDPProcessed = @IsProcessed,
        @CreatedOn = @CreatedOn,
        @CreatedBy = @CreatedBy
END