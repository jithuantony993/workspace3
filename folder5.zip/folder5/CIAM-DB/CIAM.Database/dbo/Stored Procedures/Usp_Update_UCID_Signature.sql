﻿/*
Created Date : 02/12/2022
Created by : Kalirajn
Changes Summary : To Update the UCID & Signature Column in Table.
*/
CREATE PROCEDURE [dbo].[Usp_Update_UCID_Signature] @EntryUUID UNIQUEIDENTIFIER
,@UCID VARCHAR(256)
,@Signature VARCHAR(512)
,@CreatedOn DATETIME
,@isIdproofed BIT = 1
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Update_UCID_Signature'
	DECLARE @CIAMID INT	

	IF EXISTS(SELECT 1 FROM [dbo].[CIAMUserDetail] WHERE EntryUUID=@EntryUUID)
	BEGIN
		UPDATE [dbo].[CIAMUserDetail]
		SET UCID=@UCID,
		ModifiedTS = @CreatedOn,  
		ModifiedBy = @CreatedBy 
		WHERE EntryUUID=@EntryUUID

		SELECT @CIAMID=CIAMID FROM [dbo].[CIAMUserDetail] WHERE EntryUUID=@EntryUUID

		IF ( @isIdproofed = 1)
		BEGIN
			UPDATE [dbo].[IDP_User] SET IDPSignature=@Signature,ModifiedBy=@CreatedBy,ModifiedOn=@CreatedOn
			WHERE CIAMID=@CIAMID
		END
	END
END