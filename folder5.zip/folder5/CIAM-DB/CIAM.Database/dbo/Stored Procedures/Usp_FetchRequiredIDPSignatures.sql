﻿-------------------------------------------------------------------
-- Created: 1/12/2024 - Teegan Swanson
-------------------------------------------------------------------

CREATE PROCEDURE [dbo].[Usp_FetchRequiredIDPSignatures]
	@BatchSize INT
AS
BEGIN
	SET NOCOUNT ON

	IF EXISTS(SELECT TOP(@BatchSize) CIAMID, UCID FROM [dbo].[IDPUser_RequiredSignatureUpdate] WHERE Processed = 0)
	BEGIN
		SELECT TOP(@BatchSize) CIAMID, UCID FROM [dbo].[IDPUser_RequiredSignatureUpdate] WHERE Processed = 0
	END
END