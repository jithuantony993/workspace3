﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : New procedure to modify CIAMuserdetails following for EmeraldCard IDProofing 

Modified Date : 31/10/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Column In IDP_User Table. And Add into CIAMUserDetail & Update the UCID Value.

Modified Date : 28/11/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Input Prameter in that Sp.

Modified Date : 05/12/2022
Modified By : Kalirajan
Changes Summary : To Remove IDPSignature Input Prameter in that Sp.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Modify_EmeraldCardIDProofedUser]
@CIAMID INT,
@idHash CHAR(256),
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @ActivationStatus TINYINT = 100,
		@CreatedBy VARCHAR(50) = 'Usp_IDP_Modify_EmeraldCardIDProofedUser'	
	
	DECLARE @ContextInfo VARBINARY(128)
	    
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
    SET CONTEXT_INFO @ContextInfo

	DECLARE @IDPChannel VARCHAR(10) = '3'

	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)
	SET IdHash=@idHash
	,ModifiedBy=@CreatedBy
	,ModifiedTS=@CreatedOn
	WHERE CIAMID=@CIAMID

	IF EXISTS(SELECT IDPChannel FROM [dbo].[IDP_User] WITH(NOLOCK) WHERE CIAMID = @CIAMID)  
	BEGIN
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)  
		SET ModifiedOn = @CreatedOn,  
		ModifiedBy = @CreatedBy,
		IDPChannel = CASE WHEN (CHARINDEX (@idpchannel, [IDPChannel]) = 0 )
							     THEN CONCAT([IDPChannel], ',' , @IDPChannel)
			                     ELSE [IDPChannel] END
		WHERE CIAMID = @CIAMID 
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[IDP_User](CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)
		VALUES (@CIAMID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@IDPChannel)	
	END
END