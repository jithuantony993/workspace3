﻿-- Change History
   -- MM                         - Create new SP for EAL Lookup
   -- Amal_10/25/2023            - Refactored to add partial account result.

CREATE PROCEDURE [dbo].[Usp_EAL_Get_Lookup_Status]
	@UCID VARCHAR(256),
	@EMAIL VARCHAR(150)
AS
BEGIN
DECLARE @EALookupStatus VARCHAR(50);

DROP TABLE IF EXISTS #EAL_Match
SELECT Email, UCID, IDPSignature into #EAL_Match 
FROM [CIAMUserDetail] (NOLOCK) C
LEFT JOIN IDP_User (NOLOCK) IDP ON C.CIAMID = IDP.CIAMID
WHERE Email = @EMAIL
AND DeleteStatusInd <> 1
AND (AccountStatusInd in (1, 100))

IF EXISTS -- Return PartialMatch to EA team (NO QR Code Generated)
(
	Select 1 from 
	(   SELECT Email FROM #EAL_Match
		WHERE UCID = @UCID AND ISNULL (IDPSignature, '') != ''
		INTERSECT 
		SELECT Email FROM #EAL_Match
		WHERE UCID != @UCID AND ISNULL (IDPSignature, '') != '' ) as X
	)
	BEGIN 
		SET @EALookupStatus = 'PartialMatch'
	END
ELSE IF EXISTS -- Return Error to EA team (NO QR Code Generated)
(	
	SELECT 1 FROm #EAL_Match 
	WHERE UCID <> @UCID
	AND ISNULL (IDPSignature, '') != ''
) 
	BEGIN
		SET @EALookupStatus = 'EmailUcidMismatch'
	END
ELSE IF EXISTS -- Return to ea team that account alread exists (NO QR Code Generated)
(
	SELECT 1 FROm #EAL_Match WHERE  UCID = @UCID AND ISNULL (IDPSignature, '') != ''
)
	BEGIN 
		SET @EALookupStatus = 'EmailUcidMatch'
	END
ELSE IF EXISTS -- Only Email exists (Generate QR Code with landing page as sign-in)
(
	SELECT 1 FROM #EAL_Match
)
	BEGIN
		SET @EALookupStatus = 'EmailMatch'
	END
ELSE		-- No Account info exists (Generate QR Code with landing page as create-account
	BEGIN
		SET @EALookupStatus = 'NoMatch'
	END

INSERT INTO EA_LookupLog
(
	UCID,
	EMAIL,
	EALookupStatus
)
VALUES
(
	@UCID,
	@EMAIL,
	@EALookupStatus
)

SELECT @EALookupStatus
END