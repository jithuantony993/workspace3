﻿/*
Created Date : 03/01/2023
Created By : Kalirajan
Changes Summary : To Get the UserAOLProofStatus in that Proc
*/
CREATE PROCEDURE [dbo].[Usp_AOL_Get_UserAOLProofStatus]
@EmailID VARCHAR(100),
@CreatedOn DATETIME,
@CIAMID INT

AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @AOLProofPending BIT = 0,
		@AOLEmailInvitationValidDays INT,
		@VAOLEmailInvitationValidDays INT,
		@VAOLProofPending BIT = 0,
		@VAOL_WorkspaceID VARCHAR(600) = NULL,
		@UserGUID UniqueIdentifier = NULL

	SELECT @AOLEmailInvitationValidDays = ControlValue FROM SysControl WITH(NOLOCK) WHERE ControlName = 'AOLEmailInvitationValidDays'
	SELECT @VAOLEmailInvitationValidDays = ControlValue FROM SysControl WITH(NOLOCK) WHERE ControlName = 'VirtualAOLEmailInvitationValidDays'  

	IF EXISTS(SELECT 1 FROM [dbo].[AOL_UserDetails] WITH(NOLOCK) WHERE EmailID = @EmailID 
			  AND IsActive = 1 AND EmailSentOn >= DATEADD(DD,-@AOLEmailInvitationValidDays,@CreatedOn))
	BEGIN
	    SELECT @UserGUID = UserGuid from [AOL_UserDetails] (NOLOCK) WHERE EmailID = @EmailID AND IsActive = 1

	    
		IF (SELECT 1 FROM [IDP_User] where CIAMID = @CIAMID AND IDPSignature IS NOT NULL AND UserGUID = @UserGUID) = 1
		BEGIN
			UPDATE AOL_UserDetails WITH (ROWLOCK)
			SET IsActive = 0,
			    ModifiedBy = 'Usp_AOL_Get_UserAOLProofStatus',
				ModifiedOn = @CreatedOn
			WHERE EmailID = @EmailID
		END
		ELSE
		BEGIN

		SELECT @AOLProofPending = 1

		END
		
	END
	
	IF EXISTS(SELECT 1 FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK) WHERE EmailID = @EmailID 
			 AND IsActive = 1	AND EmailSentOn >= DATEADD(DD,-@VAOLEmailInvitationValidDays,@CreatedOn))
	BEGIN
		
		SELECT @VAOL_WorkspaceID = VAOLWorkspaceID FROM VAOL_UserDetails (NOLOCK) WHERE EmailID = @EmailID AND IsActive = 1

		IF (SELECT 1 FROM [IDP_User] where CIAMID = @CIAMID AND IDPSignature IS NOT NULL AND VAOL_WorkspaceID LIKE '%' + @VAOL_WorkspaceID + '%' ) = 1
		BEGIN
			UPDATE VAOL_UserDetails WITH (ROWLOCK)
			SET IsActive = 0,
			    ModifiedBy = 'Usp_AOL_Get_UserAOLProofStatus',
			    ModifiedOn = @CreatedOn
			WHERE EmailID = @EmailID
		END
		ELSE
		BEGIN

		SET @VAOLProofPending = 1

		END
		
	END
	
	SELECT @AOLProofPending AS 'AOLProofPending', @VAOLProofPending AS 'VAOLProofPending'
END