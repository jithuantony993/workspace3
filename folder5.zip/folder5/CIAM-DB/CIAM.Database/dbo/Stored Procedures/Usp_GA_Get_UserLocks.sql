﻿/*
Created Date : 08/30/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in GA_UserValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_GA_Get_UserLocks]
@CIAMID INT,
@PageLocation VARCHAR(50) = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Lock_FailedValidation BIT = -1,
		@Lock_FailedValidation_Mts INT = 20,
		@Lock_FailedValidation_Count TINYINT = 3,
		@FailedValidationAttempts SMALLINT

	SELECT @FailedValidationAttempts = COUNT(1)
	FROM(
		SELECT TOP (@Lock_FailedValidation_Count) ActivationStatus,ValidationStatus,CreatedOn,[Location]
		FROM [dbo].[GA_UserValidationLog] WITH (NOLOCK)
		WHERE CIAMID = @CIAMID
			AND CreatedOn > DATEADD(MINUTE,(-20),[dbo].[udf_Get_CST](GETDATE()))	
		ORDER BY CreatedOn DESC
		)x
		WHERE ActivationStatus = 1 and ValidationStatus = -1
		AND  ISNULL([Location],'NA') = ISNULL(@PageLocation,'')

	IF @FailedValidationAttempts = @Lock_FailedValidation_Count
	BEGIN
		SET @Lock_FailedValidation = 1 			
	END
	ELSE IF @FailedValidationAttempts < @Lock_FailedValidation_Count
	BEGIN
		SET @Lock_FailedValidation = 0
	END

	SELECT Lock_FailedValidation = @Lock_FailedValidation
END