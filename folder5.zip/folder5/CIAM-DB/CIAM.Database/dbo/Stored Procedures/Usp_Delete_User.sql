﻿/*
Created Date : 16/03/2023
Created By : Kalirajan
Changes Summary : To Create New Proc For Delete the User.
*/
CREATE PROCEDURE [dbo].[Usp_Delete_User]
@CIAMID INT,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE  @CreatedBy VARCHAR(50) = 'Usp_Delete_User'
	
	INSERT INTO [dbo].[User_Deleted](CIAMID,EntryUUID,IdHash,CreatedTS,CreatedBy,ModifiedTS,ModifiedBy,LoginTS,AccountStatusInd
	,DeleteStatusInd,EccEulaVersion,EccEulaModifiedOn,OsaEulaVersion,OsaEulaModifiedOn,OmbaEulaVersion,OmbaEulaModifiedOn
	,IDVerified,UCID,Email,Mobile,CountryCode)
	SELECT CIAMID,EntryUUID,IdHash,CreatedTS,CreatedBy,ModifiedTS,ModifiedBy,LoginTS,AccountStatusInd
	,DeleteStatusInd,EccEulaVersion,EccEulaModifiedOn,OsaEulaVersion,OsaEulaModifiedOn,OmbaEulaVersion,OmbaEulaModifiedOn
	,IDVerified,UCID,Email,Mobile,CountryCode
	FROM [dbo].[CIAMUserDetail] WITH(NOLOCK) 
	WHERE CIAMID = @CIAMID

	INSERT INTO [dbo].[IDP_User_Deleted](CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)
	SELECT CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel
	FROM [dbo].[IDP_User] WITH(NOLOCK)
	WHERE  CIAMID = @CIAMID
	
	INSERT INTO [dbo].[EC_UserDetails_Deleted]
	(CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,DeletedOn,DeletedBy,EC_EULAStatus,EC_EULAVersion,CardProofedStatus)
	SELECT CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,@CreatedOn,@CreatedBy,EC_EULAStatus,EC_EULAVersion,CardProofedStatus
	FROM [dbo].[EC_UserDetails] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID
	
	
	INSERT INTO [dbo].[Wave_UserDetails_Deleted](CIAMID,WaveID,Login,WaveAccessToken,WaveRefreshToken,PageLocation,CreatedOn
	,CreatedBy,ModifiedOn,ModifiedBy)
	SELECT CIAMID,WaveID,Login,WaveAccessToken,WaveRefreshToken,PageLocation,CreatedOn
	,CreatedBy,ModifiedOn,ModifiedBy
	FROM [dbo].[Wave_UserDetails] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID		
	
	UPDATE [dbo].[CIAMUserDetail] WITH (ROWLOCK)
	SET IdHash = NULL
	,ModifiedTS = @CreatedOn
	,ModifiedBy = @CreatedBy
	,LoginTS = NULL
	,AccountStatusInd = 0
	,DeleteStatusInd = 1
	,EccEulaVersion = NULL
	,EccEulaModifiedOn = NULL
	,OsaEulaVersion = NULL
	,OsaEulaModifiedOn = NULL
	,OmbaEulaVersion = NULL
	,OmbaEulaModifiedOn = NULL
	,IDVerified = NULL
	,UCID = NULL
	,Email = NULL
	,Mobile = NULL
	,CountryCode = NULL
	WHERE CIAMID = @CIAMID
	
	UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
	SET IDPSignature = NULL
		,ModifiedOn = @CreatedOn
		,ModifiedBy = @CreatedBy
		,IDPChannel = NULL		
	WHERE CIAMID = @CIAMID

	UPDATE [dbo].[EC_UserDetails] WITH(ROWLOCK)
	SET ModifiedOn = @CreatedOn
		,ModifiedBy = @CreatedBy
		,EC_EULAStatus = NULL
		,EC_EULAVersion = NULL
		,CardProofedStatus = NULL
	WHERE CIAMID = @CIAMID

	
	UPDATE [dbo].[Wave_UserDetails] WITH(ROWLOCK)
	SET WaveID = SUBSTRING('*__deleted_' + SUBSTRING(REPLACE(CONVERT(VARCHAR(36),NEWID()),'-',''),1,4) + '_' + WaveID,1,150)
	,[Login] = NULL
	,[WaveAccessToken] = NULL
	,[WaveRefreshToken] = NULL
	,PageLocation = NULL
	,ModifiedOn = @CreatedOn
	,ModifiedBy = @CreatedBy
	WHERE CIAMID = @CIAMID	

	SELECT @CIAMID AS CIAMID
END