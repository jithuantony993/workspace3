﻿/*
Created Date : 09/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the UserPIN.
*/
CREATE PROCEDURE [dbo].[Usp_WSIDP_Validate_UserPIN]
@CIAMID INT,
@SSNDOB VARCHAR(64),
@PIN VARCHAR(64),
@TaxWorkspaceID UNIQUEIDENTIFIER,
@CreatedOn DATETIME2
AS
BEGIN		
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_WSIDP_Validate_UserPIN'

	DECLARE @ContextInfo VARBINARY(128)
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
	SET CONTEXT_INFO @ContextInfo

	DECLARE @ValidationStatus SMALLINT = 0
			,@i_PIN VARCHAR(64)

	SELECT @i_PIN = PIN
	FROM [dbo].[WSIDP_UserDetails] WITH(NOLOCK)
	WHERE SSNDOB = @SSNDOB AND TaxWorkspaceID = @TaxWorkspaceID

	IF ISNULL(@i_PIN,'i_PIN') <> ISNULL(@PIN,'PIN')
	BEGIN
		SET @ValidationStatus = '-105'
		
		SELECT @CIAMID AS CIAMID,@ValidationStatus AS ValidationStatus

		INSERT INTO [dbo].[WSIDP_UserPINValidationLog](CIAMID,ValidationStatus,SSNDOB,CreatedOn,CreatedBy)
		VALUES (@CIAMID,@ValidationStatus,@SSNDOB,@CreatedOn,@CreatedBy)

		RETURN
	END

	SET @ValidationStatus = '100'

	INSERT INTO [dbo].[WSIDP_UserPINValidationLog](CIAMID,ValidationStatus,SSNDOB,CreatedOn,CreatedBy)
	VALUES (@CIAMID,@ValidationStatus,@SSNDOB,@CreatedOn,@CreatedBy)

	SELECT @CIAMID AS CIAMID,@ValidationStatus AS ValidationStatus
END