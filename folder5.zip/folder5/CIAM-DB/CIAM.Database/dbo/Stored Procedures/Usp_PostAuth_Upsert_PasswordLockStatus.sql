﻿/*
Created Date : 01/06/2023
Created By : Muthukumar
*/
CREATE PROCEDURE [dbo].[Usp_PostAuth_Upsert_PasswordLockStatus]
@CIAMID INT,
@IsPasswordLock BIT,
@CreatedOn Datetime = NULL,
@ModifiedOn Datetime = NULL,
@LowQualAccountStatus BIT,
@IsLowQuality BIT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE	@ModifiedBy VARCHAR(50) = 'Usp_PostAuth_Upsert_PasswordLockStatus'
	DECLARE	@CreatedBy VARCHAR(50) = 'Usp_PostAuth_Upsert_PasswordLockStatus'

	
	IF EXISTS(SELECT 1 FROM [dbo].[PasswordLockStatus] WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE [dbo].[PasswordLockStatus] WITH(ROWLOCK)
		SET IsPasswordLock = @IsPasswordLock,
		ModifiedOn = @ModifiedOn,
		ModifiedBy = @ModifiedBy
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[PasswordLockStatus]
			(CIAMID, IsPasswordLock, CreatedOn, CreatedBy)
		 VALUES(@CIAMID,@IsPasswordLock,@CreatedOn,@CreatedBy)
	END	
	IF @IsLowQuality = 1 AND @LowQualAccountStatus = 1
	BEGIN
    EXEC Usp_Upsert_LowQualityAuthStatus  @CiamID, @LowQualAccountStatus, 0, 0, @CreatedOn
    END
	
END
