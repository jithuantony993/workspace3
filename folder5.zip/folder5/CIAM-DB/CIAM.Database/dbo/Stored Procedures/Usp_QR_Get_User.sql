﻿CREATE PROCEDURE [dbo].[Usp_QR_Get_User]
	@UUID UNIQUEIDENTIFIER,
	@LandingPageHits INT
AS
BEGIN
	
	UPDATE [dbo].[QRCodeUser]
		SET LandingPageHits += @LandingPageHits
	WHERE [UUID] = @UUID
			
	SELECT 
		[UUID],
		[UCID],
		[EntryUUID],
		[PingOneID],
		[Email],		
		[FirstName],
		[LastName],
		[Phone],
		[TaxProID],
		[OfficeID],
		[ServiceTransactionID],
		[MessageChannel],
		[VerifiedMessageChannel],
		[EmailVerified],
		[PhoneVerified],
		[Active],
		[LandingPageHits],
		[CreatedOn],
		[ModifiedOn]
	FROM 
		[dbo].[QRCodeUser]
	WHERE 
		[UUID] = @UUID

END