﻿/*
Created Date : 02/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Get the Location.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Get_GeoLocation]
@ZipCode VARCHAR(10)
AS
BEGIN
	SET NOCOUNT ON;

	IF ISNULL(@ZipCode,'') <> ''
	BEGIN
		SELECT [State],City,Latitude ,Longitude
		FROM BankIDP_ZipCodeLookup WITH(NOLOCK)
		WHERE ZipCode = @ZipCode	
	END
END