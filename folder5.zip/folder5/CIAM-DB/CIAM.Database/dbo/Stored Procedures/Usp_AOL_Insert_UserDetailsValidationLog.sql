﻿/*
Created Date : 06/12/2022
Created By : Kalirajan
Changes Summary : To Insert records into AOL_UserDetailsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_AOL_Insert_UserDetailsValidationLog]
@CIAMID INT,
@SSNDOB CHAR(64),
@UserGUID UNIQUEIDENTIFIER,
@FirstName VARCHAR(50),
@LastName VARCHAR(50),
@EmailSentOn DATETIME,
@ValidationStatus SMALLINT,
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[AOL_UserDetailsValidationLog]
	(CIAMID,SSNDOB,UserGUID,FirstName,LastName,EmailSentOn,ValidationStatus,CreatedOn,CreatedBy)
	VALUES
	(@CIAMID,@SSNDOB,@UserGUID,@FirstName,@LastName,@EmailSentOn,@ValidationStatus,@CreatedOn,@CreatedBy)		
	
END