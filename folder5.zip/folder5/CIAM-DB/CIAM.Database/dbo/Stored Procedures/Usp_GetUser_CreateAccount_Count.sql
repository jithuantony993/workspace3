﻿CREATE PROCEDURE [dbo].[Usp_GetUser_CreateAccount_Count]
@TimetoFilter DATETIME,
@CurrentDateTime DATETIME 
AS
BEGIN
-- Change History
   -- JA_12/28/12 - Surge protection - Created new procedure to fetch Create account counts. 
   -- AJ_12/28/23 - Refactored to remove the constraint.

  SET NOCOUNT ON;

  DECLARE
  @CreateAccountCount INT = 0

 SELECT @CreateAccountCount = COUNT(1)  FROM [dbo].[CIAMUserDetail] WHERE CreatedTS  BETWEEN  @TimetoFilter  AND  @CurrentDateTime

 SELECT @CreateAccountCount AS CreateAccountCount

END
