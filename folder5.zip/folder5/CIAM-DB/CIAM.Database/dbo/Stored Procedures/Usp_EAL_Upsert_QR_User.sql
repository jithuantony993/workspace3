﻿CREATE PROCEDURE [dbo].[Usp_EAL_Upsert_QR_User]
	@UCID varchar(50)= NULL,
	@UUID uniqueidentifier = NULL,
    @Email varchar(100) = NULL,
    @Phone varchar(50) = NULL,
    @CreatedOn datetimeoffset(7) = NULL,
    @MessageChannel tinyint= NULL,
    @Active bit = NULL,
    @VerifiedMessageChannel tinyint= NULL
AS

BEGIN
    DECLARE @NEWUUID UNIQUEIDENTIFIER = NEWID();
    SET NOCOUNT ON;
    DECLARE	@ModifiedBy VARCHAR(100) = 'Usp_EAL_Upsert_QR_User' 
    
    IF @UUID is null
            --Create a new entry if UUID is null
            BEGIN                 
                INSERT INTO [dbo].[EAL_QR_User]
                (
                    [UCID],
                    [UUID],
                    [Email],
                    [Phone],
                    [MessageChannel],
                    [CreatedOn]
                )
                VALUES 
                (
                    @UCID,
                    @NEWUUID,
                    @Email,
                    @Phone,
                    @MessageChannel,
                    @CreatedOn
                )

            END
        ELSE
        --Update an existing UCID if it exists
        BEGIN
           UPDATE [dbo].[EAL_QR_User]
        SET
            [Email] = ISNULL(@Email, Email),
            [Phone] = ISNULL(@Phone, Phone),
            [MessageChannel] = ISNULL(@MessageChannel, MessageChannel),
            [VerifiedMessageChannel] = ISNULL(@VerifiedMessageChannel, VerifiedMessageChannel),
            [Active] = ISNULL(@Active, Active),
            [ModifiedOn] = @CreatedOn,
            [ModifiedBy] = @ModifiedBy
        WHERE [UUID] = @UUID
        END
    SELECT ISNULL(@NEWUUID,@UUID) AS UUID

END
