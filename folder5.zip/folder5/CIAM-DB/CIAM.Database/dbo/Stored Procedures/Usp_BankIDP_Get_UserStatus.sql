﻿/*
Created Date : 04/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Get the UserStatus.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Get_UserStatus]
@CIAMID INT 
AS
BEGIN
	SET NOCOUNT ON;					
	DECLARE	 @KBALockStatus BIT = 0,								
			 @KBAFailed TINYINT = 0,
			 @QuestionaireAttempts TINYINT = 0

	IF ISNULL(@CIAMID,0) > 0
	BEGIN
		SELECT  @KBAFailed =  COUNT(1) 	FROM 
			(SELECT TOP 1 [Status] FROM [dbo].[BankIDP_KBA_UserActivityLog] WITH (NOLOCK)
				WHERE CIAMID = @CIAMID 
				order by ID desc)x
				WHERE  [Status] = -2

		SELECT @QuestionaireAttempts = COUNT(1)
				FROM [dbo].[BankIDP_KBA_UserActivityLog] WITH (NOLOCK)
				WHERE CIAMID = @CIAMID 
				AND [Action] IN (2) AND [Status] IN (1)

		IF @KBAFailed = 1
		BEGIN
			SET @KBALockStatus = 1
		END
		ELSE IF @QuestionaireAttempts > 1
		BEGIN
			SET @KBALockStatus = 1
		END

		SELECT BankIDPStatus =  CASE WHEN b.BankIDPProcessed IS NULL THEN 0 ELSE b.BankIDPProcessed END,
			BankIDPFailedStatus = CASE WHEN b.BankIDPLockStatus IS NULL THEN 0 ELSE b.BankIDPLockStatus END,
			KBALockStatus=@KBALockStatus
		FROM [dbo].[BankIDP_UserDetails] b WITH(NOLOCK)
		WHERE b.CIAMID = @CIAMID	
	END	
END