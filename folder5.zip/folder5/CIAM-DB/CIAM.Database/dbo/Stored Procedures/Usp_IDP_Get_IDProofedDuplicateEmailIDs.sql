﻿/*
Created Date : 26/05/2023
Created By : Riyas
Changes Summary : 1)Create New procedure to Get the IDProofedDuplicateEmailID. 
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Get_IDProofedDuplicateEmailIDs]
@IdHash VARCHAR(64),
@Limit SMALLINT,
@UserEmail VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;	
	SELECT  DISTINCT TOP (@Limit) U.Email 'EmailID',U.LoginTS,U.EntryUUID,U.CIAMID
	FROM CIAMUserDetail U WITH(NOLOCK)
	INNER JOIN IDP_User i WITH(NOLOCK) 
	ON U.CIAMID = i.CIAMID
	WHERE U.IdHash = @IdHash
	AND ISNULL(i.IDPSignature,'') <> '' 
	AND ISNULL(@UserEmail,'') <> U.Email 
	ORDER BY U.LoginTS DESC
END