﻿/*
Created Date : 08/25/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in EC_UserSharedSecretsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_OLAT_EC_Get_UserSharedSecretsValidationLog]
@CIAMID INT
AS
BEGIN
	SELECT ValidationStatus,
		CreatedOn		
	FROM [dbo].[EC_UserSharedSecretsValidationLog] WITH(NOLOCK)
	WHERE CIAMID = @CIAMID	
END