﻿/*
Created Date : 08/31/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in KBA_UserActivityLog & UserSharedSecretsValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_KBA_Get_UserLocks]
@CIAMID INT,
@PageLocation VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @Lock_FailedValidation BIT = 0,
		@Lock_FailedValidation_Mts INT = 20,
		@Lock_FailedValidation_Count TINYINT = 1,
		@FailedValidationAttempts SMALLINT,
		@Lock_FailedInternalValidation_Count TINYINT = 3,
		@FailedInternalValidationAttempts TINYINT = 0

	SELECT @FailedValidationAttempts = COUNT(1)
	FROM 
		(
			SELECT TOP (@Lock_FailedValidation_Count) [Action],[Status],CreatedOn,PageLocation
			FROM [dbo].[KBA_UserActivityLog] WITH (NOLOCK)
			WHERE CIAMID = @CIAMID
				AND CreatedOn > DATEADD(MINUTE,(-20),[dbo].[udf_Get_CST](GETDATE()))	
			ORDER BY CreatedOn DESC
		)x
		WHERE [Action] IN (1,2,3) AND [Status] IN (-2)
		AND  PageLocation = @PageLocation
		
	SELECT @FailedInternalValidationAttempts = COUNT(1)
		FROM (
		SELECT TOP (@Lock_FailedInternalValidation_Count) ValidationStatus,CreatedOn,PageLocation
			FROM [dbo].[UserSharedSecretsValidationLog] WITH (NOLOCK)
		WHERE CIAMID = @CIAMID 
			AND CreatedOn > DATEADD(MINUTE,(-20),[dbo].[udf_Get_CST](GETDATE()))	
		ORDER BY CreatedOn DESC
		)x
		WHERE ValidationStatus < 0
		AND PageLocation = @PageLocation


	IF (@FailedValidationAttempts = @Lock_FailedValidation_Count OR @FailedInternalValidationAttempts = @Lock_FailedInternalValidation_Count)
	BEGIN
		SET @Lock_FailedValidation = 1
	END
	ELSE IF (@FailedValidationAttempts < @Lock_FailedValidation_Count AND @FailedInternalValidationAttempts < @Lock_FailedInternalValidation_Count)
	BEGIN
		SET @Lock_FailedValidation = 0 
	END

	SELECT Lock_FailedValidation = @Lock_FailedValidation
END
GO