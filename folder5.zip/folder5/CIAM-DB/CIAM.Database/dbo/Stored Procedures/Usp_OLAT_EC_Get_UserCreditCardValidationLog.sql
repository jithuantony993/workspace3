﻿/*
Created Date : 07/19/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in EC_UserCreditCardValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_OLAT_EC_Get_UserCreditCardValidationLog]
@CIAMID INT
AS
BEGIN
	SET NOCOUNT ON;

	SELECT ValidationStatus,
		CreatedOn		
	FROM EC_UserCreditCardValidationLog WITH(NOLOCK)
	WHERE CIAMID = @CIAMID
		AND ValidationStatus NOT IN(100)	
END