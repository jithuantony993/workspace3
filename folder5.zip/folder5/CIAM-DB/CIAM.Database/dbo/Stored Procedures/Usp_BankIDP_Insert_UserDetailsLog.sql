﻿/*
Created Date : 04/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Insert the BankIDP_UserDetailsLog.

Created Date : 03/01/2023
Created By : Kalirajan
Changes Summary : Add 2 New Columns MFJlinkEnabled,SpouseEmailID & Parameter And Insert into that Table.

Modified Date : 03/01/2023
Modified By : Kalirajan
Summary : Add one New Input Parameter in that Proc @BankIDPProcessed.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Insert_UserDetailsLog]
@CIAMID INT  ,
@idHash VARCHAR (64) = NULL,
@IDProofed BIT = 0,							
@PIIValidationStatus SMALLINT = 0,			
@BankIDPLockStatus BIT = 0 ,					
@UserType VARCHAR (25) = NULL,		
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50),
@BankIDPSoftFail BIT = 0,			
@BankIDPHardFail BIT = 0,			
@EmailID VARCHAR(100) = NULL,				
@MobilePhone VARCHAR(20) = NULL,	
@KBALockStatus BIT = NULL,
@MFJlinkEnabled BIT  = 0,
@SpouseEmailID VARCHAR(100) = NULL,
@BankIDPProcessed BIT = 0
AS
BEGIN
	SET NOCOUNT ON;
	
	INSERT INTO [dbo].[BankIDP_UserDetailsLog]
			(CIAMID,idHash,IDProofed,PIIValidationStatus
			,BankIDPLockStatus,UserType,CreatedOn,CreatedBy,BankIDPSoftFail,BankIDPHardFail,EmailID,MobilePhone,KBALockStatus,MFJlinkEnabled,SpouseEmailID,BankIDPProcessed)
	VALUES(@CIAMID,@idHash,@IDProofed,@PIIValidationStatus,
			@BankIDPLockStatus,@UserType,@CreatedOn,@CreatedBy,@BankIDPSoftFail,@BankIDPHardFail,@EmailID,@MobilePhone,@KBALockStatus,@MFJlinkEnabled,@SpouseEmailID,@BankIDPProcessed)
END