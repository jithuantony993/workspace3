﻿/*
Created Date : 17/04/2023
Created By : Vitheesh
Changes Summary : 1) Created SP for insert app security details.
*/
CREATE PROCEDURE [dbo].[Usp_Insert_AppSecurityDetails]
@ReferenceId VARCHAR(150) = NULL,
@Origin VARCHAR(150) = NULL,
@Host VARCHAR(250) = NULL,
@ModuleName VARCHAR(250) = NULL,
@UserAgent VARCHAR(MAX) = NULL,
@BrowserName VARCHAR(250) = NULL,
@BrowserVersion VARCHAR(250) = NULL,
@OS VARCHAR(150) = NULL,
@OSVersion VARCHAR(50) = NULL,
@Device VARCHAR(50) = NULL,
@DeviceType VARCHAR(50) = NULL,
@DeviceOrientation VARCHAR(150) = NULL,
@Ip VARCHAR(50) = NULL,
@DeviceCIAMBaseUrl VARCHAR(450) = NULL,
@FingerprintJS VARCHAR(MAX) = NULL,
@CratedBy VARCHAR(50) = NULL,
@CreatedOn Datetime,
@QueryParams VARCHAR(MAX) = NULL,
@ElementParams VARCHAR(MAX) = NULL,
@CiamId INT NULL,
@EntryUuid VARCHAR(150) = NULL

AS
BEGIN
	SET NOCOUNT ON;
	IF EXISTS(SELECT 1 FROM [dbo].[AppSecurityDetail] WHERE ReferenceId = @ReferenceId)
	BEGIN
	UPDATE [dbo].[AppSecurityDetail] SET CiamId= ISNULL(@CiamId,CiamId), EntryUuid = ISNULL(@EntryUuid,EntryUuid)
			WHERE ReferenceId = @ReferenceId
	END
	ELSE
	BEGIN
	INSERT INTO [dbo].[AppSecurityDetail]
			([ReferenceId],[Origin],[Host],[ModuleName],[UserAgent],[BrowserName],[BrowserVersion], 
			[OS],[OSVersion],[Device],[DeviceType],[DeviceOrientation],[Ip],[DeviceCIAMBaseUrl], 
			[FingerprintJS], [CreatedBy],[CreatedOn], [QueryParams], [ElementParams],[CiamId], [EntryUuid])
			VALUES(@ReferenceId,@Origin,@Host,@ModuleName,@UserAgent,@BrowserName,@BrowserVersion,
			@OS,@OSVersion,@Device,@DeviceType,@DeviceOrientation,@Ip,@DeviceCIAMBaseUrl,@FingerprintJS,
			@CratedBy,@CreatedOn, @QueryParams, @ElementParams, @CiamId, @EntryUuid)
	END
END