﻿/*
Created By : Kalirajan
Created Date : 05/01/2023
Summary : To insert the Recs in TIS_UserActivityLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_TIS_Insert_UserActivityLog]
@SSNDOB VARCHAR(64) = NULL,
@CIAMID INT = NULL,
@EmailID VARCHAR(100) = NULL,
@Action VARCHAR(50),
@Status SMALLINT,
@ErrorCode	VARCHAR(50) = NULL,
@ErrorMessage VARCHAR(MAX) = NULL,
@CreatedOn DATETIME2 = NULL
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50)='Usp_TIS_Insert_UserActivityLog'

	INSERT INTO [dbo].[TIS_UserActivityLog]
	(SSNDOB,CIAMID,EmailID,[Action],[Status],ErrorCode,ErrorMessage,CreatedOn,CreatedBy)
	VALUES(@SSNDOB,@CIAMID,@EmailID,@Action,@Status,@ErrorCode,@ErrorMessage,@CreatedOn,@CreatedBy)
END