﻿/*
Created Date : 03/01/2022
Created By : Kalirajan
Changes Summary : 1) To Insert & Update the MFJ Details in BankIDP_UserDetails & Usp_BankIDP_Insert_UserDetailsLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Modify_MFJDetails]
@CIAMID INT,
@SpouseEmailID VARCHAR(100),
@MFJlinkEnabled BIT = 1,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(50) = 'Usp_BankIDP_Modify_MFJDetails'

	UPDATE [dbo].[BankIDP_UserDetails] WITH(ROWLOCK)
	SET MFJlinkEnabled = @MFJlinkEnabled,
	SpouseEmailID = @SpouseEmailID,
	ModifiedOn = @CreatedOn,
	ModifiedBy = @CreatedBy
	WHERE CIAMID = @CIAMID

	EXEC [dbo].[Usp_BankIDP_Insert_UserDetailsLog]
		@CIAMID = @CIAMID,
		@MFJlinkEnabled = @MFJlinkEnabled,
		@SpouseEmailID = @SpouseEmailID,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy
END