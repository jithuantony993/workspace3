﻿CREATE PROCEDURE [dbo].[Usp_Update_User_Reporting_details]
	@EntryUUID UNIQUEIDENTIFIER ,
	@Email VARCHAR(150) = NULL,
	@ModifiedTS DATETIME = NULL,
	@Phone VARCHAR(20) = NULL,
	@MFAStatus VARCHAR(20) = NULL

AS 
BEGIN

	SET NOCOUNT ON;

	DECLARE	@ModifiedBy	VARCHAR(50)	= 'Usp_Update_User_Reporting_details',  @MfaStatusValue	INT, @CiamID INT

	SELECT @MfaStatusValue = [Value] FROM CAMFAStatusLookup  WITH(NOLOCK) WHERE [Key] = @MFAStatus

	SELECT @CiamID = CIAMID FROM [dbo].[CIAMUserDetail] WITH(NOLOCK) WHERE EntryUUID = @EntryUUID

	UPDATE [dbo].[UserAccountDetail]  WITH(ROWLOCK)
            SET 
                [Phone] = ISNULL(@Phone,Phone),
                [MFAStatus] = ISNULL(@MfaStatusValue, MFAStatus),				
                [Email] = ISNULL(@Email,Email),
                [ModifiedTS] =ISNULL(@ModifiedTS, ModifiedTS),
                [ModifiedBy] = @ModifiedBy
    WHERE [CIAMID] = @CiamID

END



