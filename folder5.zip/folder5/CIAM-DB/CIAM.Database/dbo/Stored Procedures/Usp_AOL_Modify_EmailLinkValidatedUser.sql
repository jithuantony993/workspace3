﻿/*
Created Date : 06/12/2022
Created By : Kalirajan
Changes Summary :Created PROC to modify the user details following to AOL Client Matching idproofing
*/
CREATE PROCEDURE [dbo].[Usp_AOL_Modify_EmailLinkValidatedUser]
@CIAMID INT,
@UserGUID UNIQUEIDENTIFIER,
@SSNDoB CHAR(64),
@CreatedOn DATETIME
AS
BEGIN		
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_AOL_Modify_EmailLinkValidatedUser'
		
	DECLARE @ContextInfo VARBINARY(128)
	    
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
    SET CONTEXT_INFO @ContextInfo

	DECLARE @IDPChannel VARCHAR(10) ='5'

	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)
	SET IdHash = @SSNDoB,
		AccountStatusInd = 100,
		IDVerified=0,
		ModifiedTS = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE CIAMID = @CIAMID

	IF NOT EXISTS(SELECT IDPChannel FROM [IDP_User] WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		INSERT INTO IDP_User (CIAMID,UserGUID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy, IDPChannel)
		VALUES (@CIAMID,@UserGUID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@IDPChannel)
	END
	ELSE
	BEGIN
	   UPDATE IDP_User WITH (ROWLOCK) 
	   SET UserGUID = @UserGUID,
           ModifiedOn = @CreatedOn,
		   ModifiedBy = @CreatedBy,
		   IDPChannel = CASE WHEN (CHARINDEX (@idpchannel, [IDPChannel]) = 0 )
							     THEN CONCAT([IDPChannel], ',' , @IDPChannel)
			                     ELSE [IDPChannel] END 
	  WHERE CIAMID = @CIAMID
	END

	UPDATE [dbo].[AOL_UserDetails] WITH(ROWLOCK)
	SET IsActive = 0,
		UserGUID=@UserGUID,
		ModifiedOn = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE SSNDOB = @SSNDoB	
END