﻿
-- =============================================
-- Author:		Alex Stevens
-- Create date: 6/29/22
-- Description:	SP for SendOOb GET
-- =============================================
CREATE PROCEDURE [dbo].[SendOOBGet] 
	@UserGUID UNIQUEIDENTIFIER,
	@SecurityCode INT
AS
BEGIN	
    SELECT
            oob.UserGUID,
		    oob.SecurityCode
    FROM   [dbo].[OOBServiceSecurityCode]  oob with (nolock)
    WHERE  [UserGUID] = @UserGUID AND [SecurityCode] = @SecurityCode;
END
GO