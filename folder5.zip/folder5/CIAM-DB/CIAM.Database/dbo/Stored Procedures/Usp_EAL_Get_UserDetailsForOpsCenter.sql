﻿/* 
Created Date: 11/8/2023
Created By: Teegan Swanson
Changes Summary: Created this SP to get information for OpsCenter usage
*/

CREATE PROCEDURE [dbo].[Usp_EAL_Get_UserDetailsForOpsCenter]
	@Email VARCHAR(100),
	@UCID VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT TOP(15)
		Email,
		UCID,
		LandingPageHits,
		Phone,
		MessageChannel,
		VerifiedMessageChannel,
		Active,
		CreatedOn
	FROM [dbo].[EAL_QR_User] (NOLOCK)
	WHERE Email = @Email OR UCID = @UCID
	ORDER BY CreatedOn DESC

END
