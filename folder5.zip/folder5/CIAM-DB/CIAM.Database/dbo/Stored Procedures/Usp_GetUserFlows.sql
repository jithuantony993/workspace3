﻿CREATE PROCEDURE [dbo].[Usp_GetUserFlows]
		@CiamID INT ,
		@InitiatedDate DATETIME,
		@EmailID VARCHAR(100),
		@CreatedOn DATETIME 
AS
BEGIN
     SET NOCOUNT ON;

	 DROP TABLE IF EXISTS  #Temp_Result
	 CREATE TABLE #Temp_Result 
     (   
     AOLProofPending INT,  
     VAOLProofPending INT ,
	 IsPasswordLock BIT  ,
	 MobilePhoneStatus	INT,
	 MobilePhoneResetSkipped BIT,
	 PasswordResetStatus INT,
	 PasswordResetSkipped BIT
     ) 

     DECLARE @AolProofPending INT = 0, @VaolProofPending INT = 0, @IsPasswordLock BIT,
	 @MobileResetStatusFlag INT, @MobileResetSkipped BIT, @PasswordResetStatusFlag INT, @PasswordResetSkipped BIT ,
	 @AOLEmailInvitationValidDays INT,	@VAOLEmailInvitationValidDays INT

	 SELECT @AOLEmailInvitationValidDays = ControlValue FROM SysControl WITH(NOLOCK) WHERE ControlName = 'AOLEmailInvitationValidDays'
	 SELECT @VAOLEmailInvitationValidDays = ControlValue FROM SysControl WITH(NOLOCK) WHERE ControlName = 'VirtualAOLEmailInvitationValidDays'  

	 IF EXISTS(SELECT 1 FROM [dbo].[AOL_UserDetails] WITH(NOLOCK) WHERE EmailID = @EmailID 
	 		  AND IsActive = 1 AND EmailSentOn >= DATEADD(DD,-@AOLEmailInvitationValidDays,@CreatedOn))
	 BEGIN
	 	SET @AOLProofPending = 1
	 END
	 
	 IF EXISTS(SELECT 1 FROM [dbo].[VAOL_UserDetails] WITH(NOLOCK) WHERE EmailID = @EmailID 
	 		 AND IsActive = 1	AND EmailSentOn >= DATEADD(DD,-@VAOLEmailInvitationValidDays,@CreatedOn))
	 BEGIN
	 	SET @VAOLProofPending = 1
	 END	 

	 SELECT @IsPasswordLock = IsPasswordLock
	 FROM [dbo].[PasswordLockStatus] WITH(NOLOCK)
	 WHERE CIAMID = @CiamID	

	 DROP TABLE IF EXISTS  #Temp_MobilePasswordResetStatus
	 CREATE TABLE #Temp_MobilePasswordResetStatus
     (   
	  CIAMID INT,
      StatusFlag BIT   
     )
	 INSERT INTO #Temp_MobilePasswordResetStatus EXEC [dbo].[Usp_Get_UserPasswordResetStatus] @CiamID, @InitiatedDate
	 SELECT @PasswordResetStatusFlag = StatusFlag, @PasswordResetSkipped = CASE WHEN CIAMID != 0 THEN 1 ELSE 0 END FROM #Temp_MobilePasswordResetStatus

	 TRUNCATE TABLE #Temp_MobilePasswordResetStatus
	 
	 INSERT INTO #Temp_MobilePasswordResetStatus EXEC [dbo].[Usp_Get_UserMobilePhoneStatus] @CiamID, @InitiatedDate
	 SELECT @MobileResetStatusFlag = StatusFlag, @MobileResetSkipped = CASE WHEN CIAMID != 0 THEN 1 ELSE 0 END FROM #Temp_MobilePasswordResetStatus

	 INSERT INTO #Temp_Result( AOLProofPending, VAOLProofPending, IsPasswordLock , MobilePhoneStatus, MobilePhoneResetSkipped, PasswordResetStatus, PasswordResetSkipped) 
	 VALUES (@AolProofPending, @VaolProofPending, @IsPasswordLock, @MobileResetStatusFlag, @MobileResetSkipped, @PasswordResetStatusFlag, @PasswordResetSkipped)

	 SELECT AOLProofPending, VAOLProofPending, IsPasswordLock , MobilePhoneStatus, MobilePhoneResetSkipped, PasswordResetStatus, PasswordResetSkipped FROM #Temp_Result

	 DROP TABLE IF EXISTS  #Temp_Result
	 DROP TABLE IF EXISTS  #Temp_MobilePasswordResetStatus

	END
