﻿/*
Created Date : 02/01/2024
Created By : Jonathan Carpenter
Changes Summary : Creating A New SP To Delete IDP_User Record
*/

CREATE PROCEDURE [dbo].[Usp_Delete_IdpUser]
	@CIAMID INT,
	@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE  @CreatedBy VARCHAR(50) = 'Usp_Delete_IdpUser'

	INSERT INTO [dbo].[IDP_User_Deleted](CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)
	SELECT CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel
	FROM [dbo].[IDP_User] WITH(NOLOCK)
	WHERE  CIAMID = @CIAMID

	DELETE FROM IDP_User
	WHERE CIAMID = @CIAMID
END
