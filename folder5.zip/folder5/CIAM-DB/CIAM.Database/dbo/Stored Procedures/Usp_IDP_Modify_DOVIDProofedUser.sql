﻿/*
Created Date : 09/08/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Modify the DOVIDProofedUser

Modified Date : 31/10/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Column In IDP_User Table. And Add into CIAMUserDetail & Update the UCID Value.

Modified Date : 28/11/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Input Prameter in that Sp.

Modified Date : 05/12/2022
Modified By : Kalirajan
Changes Summary : To Remove IDPSignature Input Prameter in that Sp.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Modify_DOVIDProofedUser]
@CIAMID INT,
@idHash CHAR(40),
@TransactedUser BIT,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_IDP_Modify_DOVIDProofedUser'
	
	DECLARE @ContextInfo VARBINARY(128)
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
	SET CONTEXT_INFO @ContextInfo

	DECLARE @IDP_CHANNEL VARCHAR(10) = '7',
		@ACTIVATION_STATUS TINYINT = 100

	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)
	SET IdHash = @idHash,
		AccountStatusInd = @ACTIVATION_STATUS,
		ModifiedTS = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE CIAMID = @CIAMID
		
	IF (ISNULL(@TransactedUser,-1) = 0)
	BEGIN
		UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)
		SET IDVerified =  1,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END

	IF NOT EXISTS(SELECT 1 FROM [dbo].[IDP_User] WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		INSERT INTO [dbo].[IDP_User]
		(CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)
		VALUES
		(@CIAMID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@IDP_CHANNEL)
	END		
END