﻿/*
Created Date : 19/07/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Insert Into the EC_UserDetails Table.

Modified Date : 19/12/2022
Modified By : Kalirajan
Summary : Delete Some Code For DB CleanUp Activities.
*/
CREATE PROCEDURE [dbo].[Usp_EC_Insert_UserTokens]
@CIAMID INT,
@MachineIdentifier VARCHAR(40),
@BrowserAgentIdentifier INT,
@RemoteIPAddress VARCHAR(20),
@BrowserVersion VARCHAR(200),
@ReferenceID VARCHAR(50),
@Location VARCHAR(100) = 'CARD_PROOFING',
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(100) = 'Usp_EC_Insert_UserTokens' + ISNULL('|' + @Location,'')
	DECLARE @USER2FA_EMERALDCARD_ACTIVATION SMALLINT = 10

	IF EXISTS(SELECT 1 FROM [dbo].[EC_UserDetails] WITH(NOLOCK)	WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE EC_UserDetails WITH(ROWLOCK)
		SET ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[EC_UserDetails](CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy)
		VALUES(@CIAMID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy)
	END

	EXEC [dbo].[Usp_EC_Insert_UserTokensLog]
		@CIAMID = @CIAMID,
		@MachineIdentifier = @MachineIdentifier,
		@BrowserAgentIdentifier = @BrowserAgentIdentifier,
		@RemoteIPAddress = @RemoteIPAddress,
		@BrowserVersion = @BrowserVersion,
		@ReferenceID = @ReferenceID,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy
END