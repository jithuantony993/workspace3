﻿/*
Created Date : 09/02/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs into IDP_UserSecurityCodeValidationLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Get_UserSecurityCodeLock]
@CIAMID INT				
AS
BEGIN
	SET NOCOUNT ON;

	IF OBJECT_ID('tempdb..#OOBChannel') IS NOT NULL
	BEGIN
		DROP TABLE #OOBChannel
	END

	IF OBJECT_ID('tempdb..#IDPSecurityCodeLocked') IS NOT NULL
	BEGIN
		DROP TABLE #IDPSecurityCodeLocked
	END
	
	CREATE TABLE #OOBChannel(Id INT IDENTITY(1,1),OOBChannel VARCHAR(100))
	CREATE TABLE #IDPSecurityCodeLocked(IsIDPSecurityCodeLocked BIT,InvalidAttempts INT,OOBChannel VARCHAR(100))

	INSERT INTO  #OOBChannel														
	SELECT DISTINCT OOBChannel FROM [dbo].[IDP_UserSecurityCodeValidationLog] WITH (NOLOCK)
			WHERE CIAMID = @CIAMID 
			AND CreatedOn > DATEADD(MINUTE,(-20),[dbo].[udf_Get_CST](GETDATE()))
			AND OOBChannel IS NOT NULL

	DECLARE @Counter INT,@MaxId INT,@OOBChannel VARCHAR(100)
	SELECT @Counter = min(Id) , @MaxId = max(Id) FROM #OOBChannel
	
	WHILE(@Counter IS NOT NULL AND @Counter <= @MaxId)
	BEGIN
		SELECT @OOBChannel = OOBChannel FROM #OOBChannel WHERE Id = @Counter

		DECLARE @IsIDPSecurityCodeLocked BIT = 0	
		,@MaxIDPSecurityCodeAttempts INT = 3 		
		,@FailedIDPSecurityCodeAttempts TINYINT = 0	
    
		SELECT @FailedIDPSecurityCodeAttempts = COUNT(1) FROM 
			(
			SELECT TOP (3) ValidationStatus
			FROM [dbo].[IDP_UserSecurityCodeValidationLog] WITH (NOLOCK)
			WHERE CIAMID = @CIAMID 
			AND CreatedOn > DATEADD( MINUTE,(-20),dbo.udf_Get_CST(GETDATE()))
			AND ValidationStatus <> -4  AND OOBChannel  = @OOBChannel
			ORDER BY CreatedOn DESC
			)x
		WHERE x.ValidationStatus IN(-1,-2,-3) 

		IF @FailedIDPSecurityCodeAttempts = 3				
		BEGIN
			SET @IsIDPSecurityCodeLocked = 1
		END

		INSERT INTO #IDPSecurityCodeLocked(IsIDPSecurityCodeLocked,InvalidAttempts,OOBChannel )
		SELECT @IsIDPSecurityCodeLocked,@FailedIDPSecurityCodeAttempts,@OOBChannel

		SET @Counter  = @Counter  + 1 
	END

	SELECT * FROM #IDPSecurityCodeLocked WHERE IsIDPSecurityCodeLocked = 1	
END