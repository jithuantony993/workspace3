﻿/*
Created Date : 07/29/2022
Created By : Kalirajan
Changes Summary : 1) In UserSigninCodeLock Sp Change Udf_Get_CST Modified As Small case
*/
CREATE PROCEDURE [dbo].[Usp_Get_UserSignInCodeLock]
@CIAMID INT,
@PageLocation VARCHAR(50) = NULL			
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @IsSignInCodeLocked SMALLINT = 0
	DECLARE @FailedSignInCodeAttempts INT

	DECLARE @CurrentCentralDateTime DATETIME = CONVERT(datetime, 
	SWITCHOFFSET(GETUTCDATE(), DATEPART(TZOFFSET,
	GETUTCDATE() AT TIME ZONE 'Central Standard Time')))

	SELECT @FailedSignInCodeAttempts = COUNT(1) FROM 
		(
			SELECT TOP (3) ValidationStatus,CreatedOn, PageLocation
			FROM UserSignInCodeValidationLog WITH (NOLOCK)
			WHERE CIAMID = @CIAMID
			AND CreatedOn > DATEADD( MINUTE,(-20),@CurrentCentralDateTime)
			AND ValidationStatus <> -4
			ORDER BY CreatedOn DESC
		)x
		WHERE x.ValidationStatus IN(-1,-2,-3)
		AND  ISNULL(PageLocation,'NA') = ISNULL(@PageLocation,'') 
	
	IF @FailedSignInCodeAttempts = 3
	BEGIN
		SET @IsSignInCodeLocked = 1
	END
	
	SELECT @IsSignInCodeLocked AS IsSignInCodeLocked,@FailedSignInCodeAttempts AS InvalidAttempts
END