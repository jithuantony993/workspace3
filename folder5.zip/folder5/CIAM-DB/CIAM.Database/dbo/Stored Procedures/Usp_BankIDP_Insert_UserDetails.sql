﻿/*
Created Date : 04/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Insert the BankIDP_UserDetails Table.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Insert_UserDetails]
@CIAMID INT,
@idHash VARCHAR (64)  NULL,
@IDProofed BIT = 0,							
@PIIValidationStatus SMALLINT = 0,			
@BankIDPLockStatus BIT = 0 ,				
@UserType VARCHAR (25)  NULL,				
@BankIDPSoftFail BIT = NULL,					
@BankIDPHardFail BIT = 0,					
@EmailID VARCHAR(100) = NULL,				
@MobilePhone VARCHAR(20) = NULL,			
@CreatedOn DATETIME,
@KBALockStatus BIT
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @SoftFailStatus BIT = CASE WHEN @BankIDPSoftFail IS NOT NULL THEN @BankIDPSoftFail ELSE 0 END
	DECLARE	@CreatedBy VARCHAR(50) = 'Usp_BankIDP_Insert_UserDetails',
		@ACTIVATION_STATUS TINYINT = 100

	DECLARE @ContextInfo VARBINARY(128)
	    SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
		SET CONTEXT_INFO @ContextInfo

	IF EXISTS(SELECT 1 FROM BankIDP_UserDetails WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE [dbo].[BankIDP_UserDetails] WITH(ROWLOCK)
		SET idHash = @idHash,
			IDProofed=@IDProofed,
			PIIValidationStatus=@PIIValidationStatus,
			BankIDPLockStatus=@BankIDPLockStatus,
			UserType=@UserType,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy,
			BankIDPSoftFail = CASE WHEN @BankIDPSoftFail IS NOT NULL THEN @BankIDPSoftFail ELSE BankIDPSoftFail END,
			BankIDPHardFail = @BankIDPHardFail,
			EmailID = @EmailID,
			MobilePhone = @MobilePhone,
			KBALockStatus=@KBALockStatus
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO [dbo].[BankIDP_UserDetails]
			(CIAMID,idHash,IDProofed,PIIValidationStatus
			,BankIDPLockStatus,UserType,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,BankIDPSoftFail,BankIDPHardFail,EmailID,MobilePhone,KBALockStatus)
		 VALUES(@CIAMID,@idHash,@IDProofed,@PIIValidationStatus,
			@BankIDPLockStatus,@UserType,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@SoftFailStatus,@BankIDPHardFail,@EmailID,@MobilePhone,@KBALockStatus)
	END

	EXEC [dbo].[Usp_BankIDP_Insert_UserDetailsLog]
		@CIAMID = @CIAMID,
		@idHash = @idHash ,
		@IDProofed=@IDProofed  ,
		@PIIValidationStatus=@PIIValidationStatus ,
		@BankIDPLockStatus=@BankIDPLockStatus ,
		@UserType=@UserType,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy,
		@BankIDPSoftFail = @SoftFailStatus,
		@BankIDPHardFail = @BankIDPHardFail,
		@EmailID = @EmailID,
		@MobilePhone = @MobilePhone,
		@KBALockStatus=@KBALockStatus

	IF(@IDProofed=0)
	BEGIN
		UPDATE CIAMUserDetail WITH(ROWLOCK)  
		SET IdHash = CASE WHEN @idHash IS NOT NULL THEN @idHash ELSE IdHash END,  
		AccountStatusInd = @ACTIVATION_STATUS,  
		ModifiedTS = @CreatedOn,  
		ModifiedBy = @CreatedBy  
		WHERE CIAMID = @CIAMID  	
	END

	IF (@BankIDPLockStatus=1 AND ISNULL(@idHash,'') <> '')
	BEGIN
		UPDATE CIAMUserDetail WITH(ROWLOCK)
		SET IdHash = @idHash,
			ModifiedTS = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID AND ISNULL(IdHash,'') = ''
	END
END