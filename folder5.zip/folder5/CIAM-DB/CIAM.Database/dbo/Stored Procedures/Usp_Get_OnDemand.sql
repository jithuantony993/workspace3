﻿/*
-- =============================================
-- Author:		<Stevens,Alex>
-- Create date: <05/05/2023>
-- Description:	<get on Demand accounts>
-- =============================================
*/
CREATE PROCEDURE [dbo].[Usp_Get_OnDemand]
@SearchTerm VARCHAR(255) ,-- can be login, email or Mobile
@AccountCount INT ,
@CreateSingleAccount BIT 

AS
BEGIN
	SET NOCOUNT ON;	

	IF(@CreateSingleAccount = 1 OR @AccountCount>0)
		BEGIN
			SELECT TOP (CASE WHEN @CreateSingleAccount = 1 THEN 1 ELSE @AccountCount END)
				cud.CIAMID, 
				cud.[Login] ,
				cud.GuaPassword,
				cud.Email,
				(CASE WHEN idp.IDPSignature IS NOT NULL THEN  cud.UCID  ELSE NUll END) AS  UCID,
				cud.Mobile, 
				cud.CountryCode,
				cud.LoginTS,
				ga.GoogleKey,
				ga.ActivationStatus		
			FROM [CIAMUserDetail] cud (NOLOCK) 
			LEFT OUTER JOIN IDP_User idp (NOLOCK) ON idp.CIAMID = cud.CIAMID
			LEFT OUTER JOIN GA_UserKey ga (NOLOCK) ON ga.CIAMID = cud.CIAMID
			WHERE  
			cud.MigratedToPing = 0 
				AND            
			(	@SearchTerm = cud.Email 
				OR 
				@SearchTerm = cud.Mobile 
				OR 
				@SearchTerm =  cud.[Login] 
			)
			ORDER BY LoginTS DESC
		END
	ELSE
		BEGIN
			 SELECT 
				cud.CIAMID, 
				cud.[Login] ,
				cud.GuaPassword,
				cud.Email,
				(CASE WHEN idp.IDPSignature IS NOT NULL THEN  cud.UCID  ELSE NUll END) AS  UCID,
				cud.Mobile, 
				cud.CountryCode,
				cud.LoginTS,
				ga.GoogleKey,
				ga.ActivationStatus		
			FROM [CIAMUserDetail] cud (NOLOCK) 
			LEFT OUTER JOIN IDP_User idp (NOLOCK) ON idp.CIAMID = cud.CIAMID
			LEFT OUTER JOIN GA_UserKey ga (NOLOCK) ON ga.CIAMID = cud.CIAMID
			WHERE  
			cud.MigratedToPing = 0 
				AND            
			(	@SearchTerm = cud.Email 
				OR 
				@SearchTerm = cud.Mobile 
				OR 
				@SearchTerm =  cud.[Login] 
			)
			ORDER BY LoginTS DESC
		END
END
GO