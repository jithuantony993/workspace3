﻿/*
Created Date : 12/14/2022
Created By : Parminder
*/
CREATE PROCEDURE [dbo].[Usp_PostAuth_Get_UserDetails]
@CIAMID INT

AS
BEGIN 
	
	BEGIN
		SELECT IsPasswordLock,IsPasswordUsed,IsMobileUsed
		FROM PostAuth_UserDetails WITH(NOLOCK)
		WHERE CIAMID = @CIAMID
	END
	
END
