﻿/*
Created Date : 08/26/2022
Created By : Kalirajan
Changes Summary : New procedure to insert the Recs in UserPasswordResetSkippedLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_Insert_UserPasswordResetStatusLog]
@CIAMID int,
@CreatedOn DATETIME,
@StatusFlag INT
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Insert_UserPasswordResetStatusLog'
																
	INSERT INTO [dbo].[UserPasswordResetSkippedLog](CIAMID,CreatedOn,CreatedBy,StatusFlag)
	VALUES(@CIAMID,@CreatedOn,@CreatedBy,@StatusFlag)	
	
	IF EXISTS(SELECT 1 FROM LowQualityAuthStatus WITH (NOLOCK) WHERE CIAMID = @CIAMID AND LowQualAccountStatus = 1 AND PasswordResetStatus  = 0)
	    EXEC Usp_Upsert_LowQualityAuthStatus  @CiamID, 1, 1, NULL, @CreatedOn 
END