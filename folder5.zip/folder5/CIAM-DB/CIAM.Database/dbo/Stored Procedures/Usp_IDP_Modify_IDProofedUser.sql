﻿/*
Created Date : 17/08/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Modify the IDProofedUser

Modified Date : 31/10/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Column In IDP_User Table. And Add into CIAMUserDetail & Update the UCID Value.

Modified Date : 28/11/2022
Modified By : Kalirajan
Changes Summary : To Remove UCID Input Prameter in that Sp.

Modified Date : 05/12/2022
Modified By : Kalirajan
Changes Summary : To Remove IDPSignature Input Prameter in that Sp.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Modify_IDProofedUser]  
@CIAMID INT,
@IdHash CHAR(256),  
@IDP_CHANNEL VARCHAR(10),						
@IDVerifiedChannel TINYINT = NULL,			
@TransactedUser BIT,
@CreatedOn DATETIME
AS  
BEGIN  
	SET NOCOUNT ON;  
   
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_IDP_Modify_IDProofedUser'  
   
	DECLARE @ContextInfo VARBINARY(128)  
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))  
	SET CONTEXT_INFO @ContextInfo  
  
	DECLARE	@ACTIVATION_STATUS TINYINT = 100    
  
	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)  
	SET IdHash = @IdHash,  
	IDVerified =   CASE WHEN IDVerified = 1 THEN IDVerified ELSE 0 END,
	AccountStatusInd = @ACTIVATION_STATUS,  
	ModifiedTS = @CreatedOn,  
	ModifiedBy = @CreatedBy  
	WHERE CIAMID = @CIAMID 
  
	IF (ISNULL(@TransactedUser,-1) = 0 )
	BEGIN
		UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)           
		SET IDVerified =  1,  
		ModifiedTS = @CreatedOn,  
		ModifiedBy = @CreatedBy  
		WHERE CIAMID = @CIAMID  
	END

	IF EXISTS(SELECT IDPChannel FROM [dbo].[IDP_User] WITH(NOLOCK) WHERE CIAMID = @CIAMID)  
	BEGIN  
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)  
		SET ModifiedOn = @CreatedOn,  
		ModifiedBy = @CreatedBy,
		IDPChannel = CASE WHEN (CHARINDEX (@IDP_CHANNEL, [IDPChannel]) = 0 )
							     THEN CONCAT([IDPChannel], ',' , @IDP_CHANNEL)
			                     ELSE [IDPChannel] END
		WHERE CIAMID = @CIAMID  
	END  
	ELSE     
	BEGIN  
		INSERT INTO [dbo].[IDP_User](CIAMID,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)  
		VALUES (@CIAMID,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@IDP_CHANNEL)  
	END   
END