﻿/*
Created Date : 07/15/2022
Created By : Kalirajan
Changes Summary : 1)Create New procedure to Get the IDProofedEmailID.
				  2)Instead Of Signature Column Changes into IDProofedHashValue.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Get_IDProofedEmailIDs]
@IdHash VARCHAR(64)
AS
BEGIN
	SET NOCOUNT ON;	
	
	SELECT EntryUUID,U.CIAMID
	FROM CIAMUserDetail U WITH(NOLOCK)
	INNER JOIN IDP_User i WITH(NOLOCK) 
	ON U.CIAMID = i.CIAMID
	WHERE U.IdHash = @IdHash
	AND ISNULL(i.IDPSignature,'') <> '' 
	ORDER BY U.LoginTS DESC
END