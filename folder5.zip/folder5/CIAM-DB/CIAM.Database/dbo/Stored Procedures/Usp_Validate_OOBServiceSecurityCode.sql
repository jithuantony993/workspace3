﻿-- =============================================
-- Author:		Alex Stevens
-- Create date: 3/15/23
-- Description:	This SP validates the OTP code created by SendOOB and make sure that the code is not expired and has not exceeded maxiumn retry attempt
-- =============================================
CREATE PROCEDURE [dbo].[Usp_Validate_OOBServiceSecurityCode]
@UserGUID UniqueIdentifier  ,
@SecurityCode INT
AS
BEGIN
	
SET NOCOUNT ON;

DECLARE @i_UserID INT,
		@i_MessageChannel TINYINT,
		@i_OOBChannel VARCHAR(100),
		@i_SecurityCode INT,
		@i_ModifiedOn DATETIME,
		@i_IsActive BIT,
		@InvalidAttempts INT = 0,														
		@CreatedOn DATETIME = GETDATE(),
		@ValidationStatus SMALLINT = 0,
		@MaxInvalidAttempts INT = 3,													
		@l_InvalidAttempts INT = 0,
		@l_IsActive BIT = 0,
		@CreatedBy VARCHAR(50) = 'Usp_Validate_OOBServiceSecurityCode'

-- Select only active record with correct GUID
SELECT 
	@i_UserID = UserID,							
	@i_MessageChannel = MessageChannel ,
	@i_OOBChannel = OOBChannel ,
	@i_SecurityCode = SecurityCode,
	@i_ModifiedOn = ModifiedOn,
	@i_IsActive = IsActive
FROM OOBServiceSecurityCode WITH(NOLOCK)
WHERE UserGUID = @UserGUID AND IsActive = 1

-- Select the number of invaild Attempts 
SET @InvalidAttempts = 
(
	SELECT COUNT(ValidationStatus) 							
	FROM OOBServiceSecurityCodeValidationLog WITH (NOLOCK)
	WHERE UserID = @i_UserID 
		AND  OOBChannel = @i_OOBChannel				
		AND CreatedOn > DATEADD( MINUTE,(-20),(GETDATE()))
		AND (ValidationStatus = -1 OR ValidationStatus = -4)
)

-- If locked out
IF @InvalidAttempts >=  @MaxInvalidAttempts 
BEGIN
	SET @ValidationStatus = -4
	SELECT @ValidationStatus AS ValidationStatus
	RETURN
END

--ExpiredCode 24hr
IF DATEDIFF(HH,@i_ModifiedOn,(GETDATE()))>= 24			-- Expired SignInCode
BEGIN
	SET @ValidationStatus = -2	

	SELECT @i_UserID = UserID,							
		@i_MessageChannel = MessageChannel ,
		@i_OOBChannel = OOBChannel 
	FROM OOBServiceSecurityCode WITH(NOLOCK)
	WHERE UserGUID = @UserGUID

	INSERT INTO [dbo].[OOBServiceSecurityCodeValidationLog]
	(
		[UserID],
		[UserGUID],
		[MessageChannel],
		[OOBChannel],
		[SecurityCodeInput],
		[ValidationStatus],
		[CreatedOn],
		[CreatedBy]
	)
	VALUES
	(
		@i_UserID,
		@UserGUID,
		@i_MessageChannel,
		@i_OOBChannel,
		@SecurityCode,
		@ValidationStatus,
		@CreatedOn,
		@CreatedBy
	)
	SELECT @ValidationStatus AS ValidationStatus
	RETURN	
END
-- Invalid Security Code
IF @i_SecurityCode <> @SecurityCode
BEGIN
	SET @InvalidAttempts += 1
	IF @InvalidAttempts > @MaxInvalidAttempts - 1
	BEGIN
		SET @ValidationStatus = -4	
	END
	ELSE
	BEGIN 
		SET @ValidationStatus = -1
	END
	SELECT @i_UserID = UserID,							
		   @i_MessageChannel = MessageChannel ,
		   @i_OOBChannel = OOBChannel 
	FROM OOBServiceSecurityCode WITH(NOLOCK)
	WHERE UserGUID = @UserGUID

	INSERT INTO [dbo].[OOBServiceSecurityCodeValidationLog]
		(
			[UserID],
			[UserGUID],
			[MessageChannel],
			[OOBChannel],
			[SecurityCodeInput],
			[ValidationStatus],
			[CreatedOn],
			[CreatedBy]
		)
	VALUES
		(
			@i_UserID,
			@UserGUID,
			@i_MessageChannel,
			@i_OOBChannel,
			@SecurityCode,
			@ValidationStatus,
			@CreatedOn,
			@CreatedBy
		)
	SELECT @ValidationStatus AS ValidationStatus
	RETURN
END 
--Success validiation 
IF @InvalidAttempts < @MaxInvalidAttempts AND @i_SecurityCode = @SecurityCode 
BEGIN 
	SET @ValidationStatus = 1
	
	UPDATE OOBServiceSecurityCode WITH(ROWLOCK)
	SET IsActive = @l_IsActive,
		ModifiedOn = @CreatedOn,
		ModifiedBy = @CreatedBy
	WHERE UserID = @i_UserID

	SELECT 
		@i_UserID = UserID,							
		@i_MessageChannel = MessageChannel ,
		@i_OOBChannel = OOBChannel 
	FROM OOBServiceSecurityCode WITH(NOLOCK)
	WHERE UserGUID = @UserGUID

	INSERT INTO [dbo].[OOBServiceSecurityCodeValidationLog]
	(
		[UserID],
		[UserGUID],
		[MessageChannel],
		[OOBChannel],
		[SecurityCodeInput],
		[ValidationStatus],
		[CreatedOn],
		[CreatedBy]
	)
	VALUES
	(
		@i_UserID,
		@UserGUID,
		@i_MessageChannel,
		@i_OOBChannel,
		@SecurityCode,
		@ValidationStatus,
		@CreatedOn,
		@CreatedBy
	)

	SELECT @ValidationStatus AS ValidationStatus
	RETURN
END

END
