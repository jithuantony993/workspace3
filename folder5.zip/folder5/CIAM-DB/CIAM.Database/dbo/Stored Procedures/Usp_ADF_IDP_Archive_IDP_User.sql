﻿CREATE PROCEDURE [dbo].[Usp_ADF_IDP_Archive_IDP_User]
@BatchSize int
AS
BEGIN
-- Change History
   -- AJ_11/27/23 - Remove / Delete idproofed accounts that have not logged in the past 2 years
   -- AJ_12/28/23 - Defect Fix # 3770659 Reset IDP Level

SET NOCOUNT ON;

	CREATE TABLE #t_IDP_User (ID INT IDENTITY(1,1), CiamID INT)
	CREATE INDEX IDX1 ON #t_IDP_User(ID)
	CREATE INDEX IDX2 ON #t_IDP_User(CiamID)

	DECLARE @CutOffDate DATETIME = DATEADD(YEAR,(-2),dbo.Udf_Get_CST(GETDATE())),
	@CutOffDateOffset DATETIMEOFFSET = DATEADD(YEAR,(-2),dbo.Udf_Get_CST_Offset(GETDATE())),
	@CreatedOn DATETIME = dbo.Udf_Get_CST(GETDATE()),
	@CreatedOnOffset DATETIMEOFFSET = dbo.udf_Get_CST_Offset(GETDATE()),
	@CreatedBy VARCHAR(50) = 'Usp_ADF_IDP_Archive_IDP_User',
	@RecordsDeleted INT = 0

	INSERT INTO #t_IDP_User
		SELECT TOP(@BatchSize) i.CiamID
		FROM IDP_User i WITH(NOLOCK)
		INNER JOIN [CIAMUserDetail] u (NOLOCK) ON i.CiamID = u.CiamID	
		WHERE ISNULL(u.LoginTS,u.LastLoginTS) < @CutOffDateOffset
		AND U.UCID IS NOT NULL
   
   INSERT INTO IDP_User_Archive(CIAMID,UCID,IdHash, IDPSignature, CreatedOn, CreatedBy, ModifiedOn, ModifiedBy, DeletedOn, DeletedBy, IDPChannel, UserGUID, TaxReturnGUID, TaxWorkspaceID, PaperlessWorkSpaceID, VAOLTaxYear, EIN, VAOL_WorkspaceID)
			SELECT C.CIAMID, C.UCID, C.IdHash, I.IDPSignature, I.CreatedOn, I.CreatedBy, I.ModifiedOn, I.ModifiedBy, @CreatedOn, @CreatedBy, I.IDPChannel, I.UserGUID, I.TaxReturnGUID, I.TaxWorkspaceID, I.PaperlessWorkSpaceID, I.VAOLTaxYear, I.EIN, I.VAOL_WorkspaceID
			FROM #t_IDP_User T WITH(NOLOCK) 
			INNER JOIN CIAMUserDetail C WITH(NOLOCK) ON T.CiamID = C.CIAMID
			INNER JOIN IDP_User I  WITH(NOLOCK)  ON T.CiamID = I.CIAMID
			ORDER BY T.CiamID

		IF @@error = 0
		BEGIN
			WAITFOR DELAY '00:00:01'

			DELETE FROM IDP_User WITH(ROWLOCK) WHERE CIAMID IN (SELECT CiamID FROM #t_IDP_User T WITH(NOLOCK))
			
			WAITFOR DELAY '00:00:01'
			
			Update C WITH(ROWLOCK)
			SET IdHash = NULL,
			    UCID = NULL,
				ModifiedBy = @CreatedBy,
				ModifiedTS = @CreatedOnOffset
			FROM CIAMUserDetail C
			INNER JOIN #t_IDP_User t on C.CIAMID = T.CIAMID

			UPDATE IRS WITH (ROWLOCK)
			SET IDENTITYPROOFINGLEVEL = 0
			FROM UserIRSDetail IRS
			INNER JOIN #t_IDP_User t on IRS.CIAMID = T.CIAMID
			WHERE IdentityProofingLevel = 1
        END
   	    
		INSERT INTO EC_UserDetails_Archive(CIAMID, CreatedOn, CreatedBy, ModifiedOn, ModifiedBy, DeletedOn, DeletedBy, EC_EULAStatus, EC_EULAVersion, CardProofedStatus)
			SELECT E.CIAMID, E.CreatedOn, E.CreatedBy, E.ModifiedOn, E.ModifiedBy, @CreatedOn, @CreatedBy, E.EC_EULAStatus, E.EC_EULAVersion, E.CardProofedStatus
			FROM #t_IDP_User T WITH(NOLOCK) 			
			INNER JOIN EC_UserDetails E  WITH(NOLOCK)  ON T.CIAMID = E.CIAMID	
			ORDER BY T.CiamID

		IF @@error = 0 
		BEGIN
			WAITFOR DELAY '00:00:01'
			DELETE FROM EC_UserDetails WITH(ROWLOCK) WHERE CIAMID IN (SELECT CiamID FROM #t_IDP_User T WITH(NOLOCK))			
        END
END