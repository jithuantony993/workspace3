﻿/*
Created Date : 12/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to Validate the AOL AutoProofUser.
*/
CREATE PROCEDURE [dbo].[Usp_AOL_AutoProofUser]
@CIAMID INT,
@SSNDoB CHAR(64),
@CreatedOn DATETIME
AS
BEGIN	
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_AOL_AutoProofUser',
		@ContextInfo VARBINARY(128),
		@AOLChannel TINYINT = 5,
		@UserGUID UNIQUEIDENTIFIER,
		@AOLEmailInvitationValidDays INT,
		@ValidationStatus SMALLINT,@FirstName VARCHAR(50),
		@LastName VARCHAR(50),@i_EmailSentOn DATETIME

	SELECT @AOLEmailInvitationValidDays = ControlValue FROM [dbo].[SysControl] WITH(NOLOCK) WHERE ControlName = 'AOLEmailInvitationValidDays'
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
    SET CONTEXT_INFO @ContextInfo

	-- Retrive the GUID for the given account
	SELECT @UserGUID = UserGUID
		FROM [dbo].[AOL_UserDetails] WITH(NOLOCK)
		WHERE SSNDOB = @SSNDoB
		AND IsActive = 1
		AND EmailSentOn >= DATEADD(DD,-@AOLEmailInvitationValidDays,@CreatedOn)

	IF(@UserGUID IS NOT NULL)
	BEGIN
		IF NOT EXISTS(SELECT 1 FROM [dbo].[AOL_UserDetails] WITH(NOLOCK) WHERE SSNDOB = @SSNDOB)
		BEGIN
			INSERT INTO [dbo].[AOL_UserDetails](SSNDOB,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,UserGUID)
			VALUES (@SSNDOB,@CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@UserGUID)
		END
		ELSE
		BEGIN
			UPDATE [dbo].[AOL_UserDetails] WITH(ROWLOCK)
			SET UserGUID = @UserGUID,
				ModifiedOn = @CreatedOn,
				ModifiedBy = @CreatedBy
			WHERE SSNDOB = @SSNDOB
		END
		BEGIN
		UPDATE [dbo].[IDP_User] WITH(ROWLOCK)
		SET UserGUID = @UserGUID,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID

	
		END
		SET @ValidationStatus = '1'
	
		EXEC [dbo].[Usp_AOL_Insert_UserDetailsValidationLog]
			@CIAMID = @CIAMID,
			@SSNDOB = @SSNDOB,
			@UserGUID = @UserGUID,
			@FirstName = @FirstName,
			@LastName = @LastName,
			@EmailSentOn = @i_EmailSentOn,
			@ValidationStatus = @ValidationStatus,
			@CreatedOn = @CreatedOn,
			@CreatedBy = @CreatedBy
	
		UPDATE [dbo].[AOL_UserDetails] WITH(ROWLOCK)
		SET IsActive = 0,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE SSNDOB = @SSNDoB
	END
END