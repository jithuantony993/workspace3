﻿-- AJ 05/30/23 - Created new SP to consolidate calls for userinfo API.

CREATE PROCEDURE [dbo].[Usp_Get_UserInfo_Details] 
		@EntryUUID			UNIQUEIDENTIFIER	
AS  
BEGIN
    SET NOCOUNT ON;

    
    BEGIN
        SELECT C.[CIAMID],
                [EntryUUID],
                [AccountStatusInd],
                C.[CreatedTS],
				LoginTS,
				LastLoginTS,
                C.IdHash,
				[OsaEulaVersion],
		        [OsaEulaModifiedOn],
		        [EccEulaVersion],
		        [EccEulaModifiedOn],
		        [OmbaEulaVersion],
		        [OmbaEulaModifiedOn],
				[IDPSignature],
				IDVerified,
				UCID,
				IDPChannel,
				CASE
				WHEN I.PaperlessWorkSpaceID IS NOT NULL AND I.IDPSignature IS NOT NULL THEN 1
				ELSE 0
				END AS WSIDProofed,
				WaveAccessToken,				
				UserType,
				BankIDPHardFail,
				BankIDPSoftFail,
				CASE 
					WHEN BIDP.IDProofed = 1 THEN 'bankproofsuccess'
					WHEN BIDP.BankIDPLockStatus = 1 THEN 'bankprooffailed'
					WHEN BIDP.PIIValidationStatus NOT IN (0,1) THEN 'idcheckfailed'
					ELSE NULL
				END AS BankProofed,
				BankIDPProcessed as bankIDPStatus,
				BankIDPSoftFail as bankIDPSoftFail,
				BankIDPHardFail as bankIDPHardFail,
				CASE
				    WHEN ( EC.CIAMID = I.CIAMID AND (I.IDPChannel = '3' or ec.CardProofedStatus = 1) ) THEN 1
					ELSE 0					
				END AS CardProofed,
				I.VAOL_WorkspaceID AS WorkspaceId,
				I.VAOLTaxYear AS vaolTaxYear,
				I.EIN,
				I.UserGUID,
				I.PaperlessWorkSpaceID as TaxWorkspaceID,
				I.TaxReturnGUID,

				CASE
					WHEN DV.DeviceType = 1 THEN DV.DeviceVerifyStatus
					ELSE 0
				END AS EmailVerified,
				C.Email,
				C.Mobile,
				C.CountryCode,
				ISNULL(C.Login, C.Email) HrbUserName,				
				LQ.MobileUpdateStatus,
				LQ.PasswordResetStatus,
				LQ.LowQualAccountStatus
        FROM   [dbo].[CIAMUserDetail] C WITH(NOLOCK)
		LEFT JOIN [dbo].[IDP_User] I WITH(NOLOCK)
		ON C.CIAMID=I.CIAMID		
		LEFT JOIN [dbo].[BankIDP_UserDetails] BIDP WITH(NOLOCK)
		ON C.CIAMID = BIDP.CIAMID
		LEFT JOIN [dbo].[EC_UserDetails] EC WITH(NOLOCK)
		ON C.CIAMID = EC.CIAMID
		LEFT JOIN [dbo].Wave_UserDetails W WITH (NOLOCK)
		ON C.CIAMID = W.CIAMID
		LEFT JOIN [dbo].[DeviceVerify] DV WITH(NOLOCK)
		ON C.CIAMID = DV.CIAMID
		LEFT JOIN [dbo].[LowQualityAuthStatus] LQ WITH(NOLOCK)
		ON C.CIAMID = LQ.CiamID
	    WHERE  C.[EntryUUID] = @EntryUUID
        AND DeleteStatusInd <> 1
        AND (AccountStatusInd in (1, 100))
    END
END