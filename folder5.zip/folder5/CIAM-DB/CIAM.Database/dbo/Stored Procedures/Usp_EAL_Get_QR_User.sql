﻿CREATE PROCEDURE [dbo].[Usp_EAL_Get_QR_User]
	@UUID UNIQUEIDENTIFIER,
	@LandingPageHits INT
AS
IF EXISTS(SELECT 1 FROM [dbo].[EAL_QR_User] WHERE UUID = @UUID)
BEGIN
	DECLARE @NoHitChange INT
	SET @NoHitChange = 0
	
	-- Conditional to prevent trigger from adding change to log if passing 0 for landingpagehits (no value will change in this case)
	IF ISNULL(@LandingPageHits, @NoHitChange) != 0
		BEGIN
			UPDATE [dbo].[EAL_QR_User]
				SET LandingPageHits += @LandingPageHits
				WHERE [UUID] = @UUID
		END

	SELECT
	    [UCID],
        [UUID],
        [Email],
        [LandingPageHits],
        [Phone],
        [MessageChannel],
        [VerifiedMessageChannel],
        [Active],
        [CreatedOn],
        [ModifiedOn]
    FROM
        [dbo].[EAL_QR_User] (NOLOCK)
    WHERE
        [UUID] = @UUID

END
