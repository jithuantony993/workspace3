﻿/*
-- =============================================
-- Author:		<Amrutha, Surendran>
-- Create date: <14/09/2023>
-- Description:	<Insert User Device Registration/Resend Log>
				Action: 1 - Registration
				Action: 2 - Edit mobile
				Action: 3 - Resend
				Action: 4 - Verification
				Status: 1 - Initiated
				Status: 2 - Success
				Status: -1 - Failure/Exception
				Location: CREATE_ACCOUNT, MANAGE_ACCOUNT, POST_AUTH
			
-- =============================================

*/
CREATE PROCEDURE [dbo].[Usp_InsertUserDeviceActivityLog]
    @CIAMID int,
	@DeviceId uniqueidentifier,
	@Email varchar(150),
	@Mobile varchar(20),
	@Action smallint,
	@Status int,
	@Location varchar(150),
	@CreatedOn datetime,
	@ReferenceId uniqueidentifier
AS
BEGIN
	SET NOCOUNT ON;	

	DECLARE
	@CreatedBy VARCHAR(50)		= 'Usp_InsertUserDeviceActivityLog'

	INSERT INTO UserDeviceActivityLog(
	CIAMID,
	DeviceId,
	Email ,
	Mobile ,
	Action ,
	Status ,
	Location ,
	CreatedOn ,
	CreatedBy ,
	ReferenceId
	)
	VALUES
	(
	@CIAMID ,
	@DeviceId ,
	@Email ,
	@Mobile ,
	@Action ,
	@Status ,
	@Location ,
	@CreatedOn ,
	@CreatedBy ,
	@ReferenceId 
	)		

	return @@ROWCOUNT  
END
GO