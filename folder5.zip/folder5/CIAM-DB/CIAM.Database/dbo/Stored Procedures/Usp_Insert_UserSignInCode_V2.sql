﻿/*
Created Date : 07/15/2022
Created By : Kalirajan
Changes Summary : Created new procedure to Insert Into the UserSignInCode & UserSignInCodeLog Table.
*/

CREATE PROCEDURE [dbo].[Usp_Insert_UserSignInCode_V2]
@CIAMID INT,
@SignInCode INT,
@ReferenceID VARCHAR(50),								
@MessageChannel TINYINT ,
@PageLocation VARCHAR(50),
@OOBChannel VARCHAR(100),
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_Insert_UserSignInCode_V2'	
		
	IF EXISTS(SELECT 1 FROM UserSignInCode WITH(NOLOCK) WHERE CIAMID = @CIAMID)
	BEGIN
		UPDATE UserSignInCode WITH(ROWLOCK)
		SET SignInCode = @SignInCode,
			SignInCodeModifiedOn = @CreatedOn,
			ReferenceID = @ReferenceID,
			IsActive = 1,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy,
			PageLocation = @PageLocation,
			OOBChannel = @OOBChannel
		WHERE CIAMID = @CIAMID
	END
	ELSE
	BEGIN
		INSERT INTO UserSignInCode(CIAMID,SignInCode,SignInCodeModifiedOn,ReferenceID,IsActive,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,PageLocation,OOBChannel)
		VALUES(@CIAMID,@SignInCode,@CreatedOn,@ReferenceID,1, @CreatedOn,@CreatedBy,@CreatedOn,@CreatedBy,@PageLocation,@OOBChannel)
	END
	
	EXEC Usp_Insert_UserSignInCodeLog
		@CIAMID = @CIAMID,
		@SignInCode = @SignInCode,
		@SignInCodeModifiedOn = @CreatedOn,
		@ReferenceID = @ReferenceID,
		@IsActive = 1,
		@ModifiedOn = @CreatedOn,
		@ModifiedBy = @CreatedBy,
		@MessageChannel = @MessageChannel,
		@CreatedOn = @CreatedOn,
		@CreatedBy = @CreatedBy,
		@PageLocation = @PageLocation,
		@OOBChannel = @OOBChannel
END
GO