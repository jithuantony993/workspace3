﻿/*
Created Date : 31/01/2023
Created By : Kalirajan
Changes Summary : To Verify the User Exists in That Sp.
*/
CREATE PROCEDURE [dbo].[Usp_Wave_Verify_UserExists]
@WaveID VARCHAR(150)
AS
BEGIN
	SET NOCOUNT ON;
     
	DECLARE @CIAMID INT,
	@UserExists TINYINT = 0
	
	IF EXISTS(SELECT 1 FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) WHERE WaveID = @WaveID)
	BEGIN
		SET @UserExists = 1								--Wave ID exists

		SELECT @CIAMID = CIAMID	FROM [dbo].[Wave_UserDetails] WITH(NOLOCK) WHERE WaveID = @WaveID

		SELECT @UserExists AS 'UserExists',@CIAMID AS 'CIAMID'
		RETURN
	END
	ELSE
	BEGIN
		SET @UserExists = 2

		SELECT @UserExists AS 'UserExists'
	END	
END