﻿/*
 Created By : Vitheesh
 Created Date : 26/12/2023
 Description : Insert user login mfa report details
*/
CREATE PROCEDURE [dbo].[InsertUserLoginMFADetail]
	@UserLogId INT ,
	@Action VARCHAR(50) = NULL,
	@Status VARCHAR(50) = NULL,
	@CreatedTS			DATETIME
AS 
BEGIN
	DECLARE 
		@CreatedBy VARCHAR(50)		= 'InsertUserLoginMFADetail',
		@ActionId int,
		@StatusId int	
		set @ActionId 		= (ISNULL((select Value from UserLoginMFAActionLookup where [Key]=@Action),0))
		set @StatusId 		= (ISNULL((select Value from UserLoginMFAStatusLookup where [Key]=@Status),0))
	SET NOCOUNT ON;
	INSERT INTO UserLoginMFADetail(UserLogID,Action,Status,CreatedTS,CreatedBy)
			VALUES(@UserLogId,@ActionId,@StatusId,@CreatedTS,@CreatedBy)
END