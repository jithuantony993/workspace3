﻿CREATE PROCEDURE [dbo].[Usp_GetUserLogin_Count]
@TimetoFilter DATETIME,
@CurrentDateTime DATETIME 
AS
BEGIN
-- Change History
   -- JA_12/28/12 - Surge protection - Created new procedure to fetch Login counts. 
   -- AJ_12/28/23 - Refactored to remove the constraint.

  SET NOCOUNT ON;

  DECLARE
  @LoginCount INT = 0

 SELECT @LoginCount = COUNT(1)  FROM [dbo].[UserLoginLog] WHERE CreatedOn BETWEEN  @TimetoFilter AND  @CurrentDateTime

 SELECT  @LoginCount AS LoginCount

END
