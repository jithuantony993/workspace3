﻿-- Change History
   -- Gayatri,Palla_07/06/2023 - Insert User Login History
   -- Kalirajan                - To Change SessionID Into ReferenceID.
   -- AJ_10/09/2023 - Refactored to add LastLoginTS

CREATE PROCEDURE [dbo].[InsertUserLoginLog]
@CIAMID INT,
@Status INT,
@RemoteIPAddress VARCHAR(20) NULL,
@CreatedOn DATETIME,
@SignInChannel TINYINT = 0,				
@ReferenceID VARCHAR(50) NULL,					
@User2FAMethod VARCHAR(500) NULL,
@User2FAStatus SMALLINT = 0,
@UserAgent VARCHAR(200) NULL,
@BrowserName VARCHAR(100) NULL,
@BrowserVersion VARCHAR(200) NULL,
@OS VARCHAR(30) NULL,
@OSVersion VARCHAR(50) NULL,
@Device VARCHAR(50) NULL,
@DeviceType TINYINT = 0,
@DeviceOrientation VARCHAR(100) NULL,
@SourceURL VARCHAR(30) NULL,
@Location VARCHAR(100),
@LastLogin DATETIMEOFFSET NULL
AS
BEGIN
	SET NOCOUNT ON;	

	INSERT INTO UserLoginLog(
	CIAMID,
	[Status],
	RemoteIPAddress,
	CreatedOn,
	SignInChannel,
	ReferenceID,
	User2FAMethod,
	User2FAStatus,
	UserAgent,
	BrowserName,
	BrowserVersion,
	OS,
	OSVersion,
	Device,
	DeviceType,
	DeviceOrientation,
	SourceURL,
	Location
	)
	VALUES
	(
	@CIAMID,
	@Status,
	@RemoteIPAddress,
	@CreatedOn,
	@SignInChannel,
	@ReferenceID,
	@User2FAMethod,
	@User2FAStatus,
	@UserAgent,
	@BrowserName,
	@BrowserVersion,
	@OS,
	@OSVersion,
	@Device,
	@DeviceType,
	@DeviceOrientation,
	@SourceURL,
	@Location
	)	
	
	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)	
	SET [LastLoginTS] = [LoginTS],	  
		[LoginTS] = ISNULL(@LastLogin,[LoginTS])
	WHERE CIAMID=@CIAMID

	return @@ROWCOUNT  
END
GO