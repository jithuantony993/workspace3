﻿
CREATE PROCEDURE [dbo].[Usp_Insert_Post_Login_Information]
@CIAMID INT,
@Status INT,
@RemoteIPAddress VARCHAR(20) NULL,
@CreatedOn DATETIME,
@SignInChannel TINYINT = 0,				
@SessionID VARCHAR(50) NULL,					
@User2FAMethod VARCHAR(500) NULL,
@User2FAStatus SMALLINT = 0,
@UserAgent VARCHAR(200) NULL,
@BrowserName VARCHAR(100) NULL,
@BrowserVersion VARCHAR(200) NULL,
@OS VARCHAR(30) NULL,
@OSVersion VARCHAR(50) NULL,
@Device VARCHAR(50) NULL,
@DeviceType TINYINT = 0,
@DeviceOrientation VARCHAR(100) NULL,
@SourceURL VARCHAR(30) NULL,
@Location VARCHAR(100),
@LastLogin DATETIMEOFFSET NULL,
@DeviceCIAMBaseUrl VARCHAR(450) = NULL,
@FingerprintJS VARCHAR(MAX) = NULL,
@Host VARCHAR(250) = NULL,
@ModuleName VARCHAR(250) = NULL,
@Origin VARCHAR(150) = NULL,
@ReferenceId VARCHAR(150) = NULL,
@CreatedBy VARCHAR(50) = NULL,
@EntryUuid VARCHAR(150) = NULL,
@TrackId VARCHAR(100) = NULL
AS
BEGIN
	SET NOCOUNT ON;	

	INSERT INTO UserLoginLog(
	CIAMID,
	[Status],
	RemoteIPAddress,
	CreatedOn,
	SignInChannel,
	ReferenceID,
	User2FAMethod,
	User2FAStatus,
	UserAgent,
	BrowserName,
	BrowserVersion,
	OS,
	OSVersion,
	Device,
	DeviceType,
	DeviceOrientation,
	SourceURL,
	[Location],
	TrackId
	)
	VALUES
	(
	@CIAMID,
	@Status,
	@RemoteIPAddress,
	@CreatedOn,
	@SignInChannel,
	@ReferenceId,
	@User2FAMethod,
	@User2FAStatus,
	@UserAgent,
	@BrowserName,
	@BrowserVersion,
	@OS,
	@OSVersion,
	@Device,
	@DeviceType,
	@DeviceOrientation,
	@SourceURL,
	@Location,
	@TrackId
	)	
	
	exec [dbo].[Usp_Insert_AppSecurityDetails]
	@ReferenceId = @ReferenceId,
	@Origin = @Origin,
	@Host = @Host,
	@ModuleName = @ModuleName,
	@UserAgent = @UserAgent,
	@BrowserName = @BrowserName,
	@BrowserVersion = @BrowserVersion, 
    @OS = @OS,
	@OSVersion = @OSVersion,
	@Device = @Device,
	@DeviceType = @DeviceType,
	@DeviceOrientation = @DeviceOrientation,
	@Ip = @RemoteIPAddress,
	@DeviceCIAMBaseUrl = @DeviceCIAMBaseUrl, 
    @FingerprintJS = @FingerprintJS,
	@CratedBy = @CreatedBy,
	@CreatedOn = @CreatedOn,
	@CiamId = @CIAMID, 
	@EntryUuid = @EntryUuid	

	UPDATE [dbo].[CIAMUserDetail] WITH(ROWLOCK)	
	SET [LastLoginTS]	= [LoginTS],
		[LoginTS]		= ISNULL(@LastLogin,[LoginTS])
	WHERE CIAMID=@CIAMID

	return @@ROWCOUNT  
END
GO