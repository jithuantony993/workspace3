﻿/*
Created Date : 02/08/2022
Created By : Kalirajan
Changes Summary : 1)Created new procedure to Get the States.
*/
CREATE PROCEDURE [dbo].[Usp_BankIDP_Get_States]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT DISTINCT State
	FROM [dbo].[BankIDP_ZipCodeLookup] WITH(NOLOCK)
	ORDER BY 1	
END