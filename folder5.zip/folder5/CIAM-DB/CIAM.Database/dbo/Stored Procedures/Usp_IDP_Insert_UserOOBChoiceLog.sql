﻿/*
Created Date : 09/05/2022
Created By : Kalirajan
Changes Summary : New procedure to Insert the Recs into IDP_UserOOBChoiceLog Table.
*/
CREATE PROCEDURE [dbo].[Usp_IDP_Insert_UserOOBChoiceLog]
@CIAMID int ,
@EmailIDExist bit = 0 ,		--EmailID not found (0) or EmailID found (1)
@MobilePhoneExist bit = 0 , --MobilePhone not found (0) or MobilePhone found(1)
@Email bit = 0,				--Chose Email (1)
@SMS bit = 0,				--Chose SMS  (1)
@Skip bit = 0,				--Chose Skip (1)
@EmailIDMatch bit = 0,		--Is the tax feed EmailID same as user account EmailID
@MobilePhoneMatch bit = 0,	--Is the tax feed MobilePhone same as that of the user account MobilePhone
@EmailIDVerified bit = 0,	--Is the tax feed EmailID verified
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @CreatedBy VARCHAR(50) = 'Usp_IDP_Insert_UserOOBChoiceLog'
																
	INSERT INTO [dbo].[IDP_UserOOBChoiceLog](CIAMID,[EmailIDExist],[MobilePhoneExist],[Email],[SMS],[Skip],[CreatedOn],[CreatedBy],[EmailIDMatch],[MobilePhoneMatch],[EmailIDVerified])
	VALUES(@CIAMID,@EmailIDExist,@MobilePhoneExist,@Email,@SMS,@Skip,@CreatedOn,@CreatedBy,@EmailIDMatch,@MobilePhoneMatch,@EmailIDVerified)
	
END


