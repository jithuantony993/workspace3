﻿/*
Created By : Kalirajan
Created Date : 05/01/2023
Summary : For Datsync ADF2 IDP_User Table.
*/
CREATE PROCEDURE [dbo].[ADF2Insert_IDP_User]
(
    @udt_adf_idp_user [dbo].[UDT_IDP_User] READONLY
)
AS
BEGIN
    SET NOCOUNT ON

	BEGIN TRY

    IF EXISTS (SELECT 1 FROM [dbo].[IDP_User] I INNER JOIN @udt_adf_idp_user udt_adf_idpuser ON I.CIAMID=udt_adf_idpuser.UserID WHERE CIAMID = udt_adf_idpuser.UserID)
	BEGIN
		UPDATE I
		SET CIAMID = udt_adf_idpuser.UserID,IDPSignature = udt_adf_idpuser.IDPSignature,CreatedOn = udt_adf_idpuser.CreatedOn,CreatedBy = udt_adf_idpuser.CreatedBy
		,ModifiedOn = udt_adf_idpuser.ModifiedOn,ModifiedBy = udt_adf_idpuser.ModifiedBy
		,IDPChannel = udt_adf_idpuser.IDPChannel
		FROM [dbo].[IDP_User] I INNER JOIN @udt_adf_idp_user udt_adf_idpuser 
		ON I.CIAMID=udt_adf_idpuser.UserID

	END
	ELSE
	BEGIN     
        INSERT INTO [dbo].[IDP_User](CIAMID,IDPSignature,CreatedOn,CreatedBy,ModifiedOn,ModifiedBy,IDPChannel)        
        SELECT 
            udt_adf_idpuser.UserID,
            udt_adf_idpuser.IDPSignature,
            udt_adf_idpuser.CreatedOn,
            udt_adf_idpuser.CreatedBy,
            udt_adf_idpuser.ModifiedOn,
            udt_adf_idpuser.ModifiedBy,
            udt_adf_idpuser.IDPChannel
            from @udt_adf_idp_user udt_adf_idpuser
    END     
    END TRY
    BEGIN CATCH
 
        INSERT INTO [dbo].[DataSyncFailedRecordsLog]
        (
            CIAMID,
            BatchId,
            CreatedBy,
            CreatedOn
        )
        
            SELECT 
                udt_adf_idpuser. UserID,
                udt_adf_idpuser.BatchId,
                'ADF2Insert_IDP_User',
                GETDATE()
            FROM @udt_adf_idp_user udt_adf_idpuser

    END CATCH
END
GO

