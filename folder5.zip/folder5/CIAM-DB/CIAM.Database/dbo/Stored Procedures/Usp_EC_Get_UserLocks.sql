﻿CREATE PROCEDURE [dbo].[Usp_EC_Get_UserLocks]
@CIAMID INT,
@PageLocation VARCHAR(50) = NULL
AS
BEGIN
	SET NOCOUNT ON;
	
	DECLARE @SharedSecretsValidationLock BIT = 0,
		@CreditCardValidationLock BIT = 0

	DECLARE @CurrentCentralDateTime DATETIME = CONVERT(datetime, 
	SWITCHOFFSET(GETUTCDATE(), DATEPART(TZOFFSET,
	GETUTCDATE() AT TIME ZONE 'Central Standard Time')))

	IF(SELECT COUNT(1) FROM 
		(
			SELECT TOP (3) CIAMID,CreatedOn,ValidationStatus
			FROM [dbo].[EC_UserSharedSecretsValidationLog] WITH (NOLOCK)
			WHERE CIAMID = @CIAMID
			AND CreatedOn > DATEADD(MINUTE,(-1 * 20),@CurrentCentralDateTime)
			ORDER BY CreatedOn DESC
		)x
		WHERE ValidationStatus = 0
	) = 3
	BEGIN
		SET @SharedSecretsValidationLock  = 1
	END
	
	IF(SELECT COUNT(1) FROM 
		(
			SELECT TOP (3) CIAMID,CreatedOn,ValidationStatus
			FROM [dbo].[EC_UserCreditCardValidationLog] WITH (NOLOCK)
			WHERE CIAMID = @CIAMID
			AND CreatedOn > DATEADD( MINUTE,(-1 * 20),@CurrentCentralDateTime)
			ORDER BY CreatedOn DESC
		)x
		WHERE ValidationStatus IN (0,-2,-3)
	) = 3
	BEGIN
		SET @CreditCardValidationLock  = 1
	END	
	
	SELECT @SharedSecretsValidationLock AS SharedSecretsValidationLock,
		@CreditCardValidationLock AS CreditCardValidationLock
END