﻿/* 
Created Date: 09/12/2023
Modified On: 11/8/2023
Created By: Teegan Swanson
Changes Summary: Updated to only hold less information in larger quantities, groomed unnecessary columns for growing OpsCenter Scope (all IDP information, CIAMUserDetails, etc.)
*/

CREATE PROCEDURE [dbo].[Usp_VAOL_Get_UserStatusForOpsCenter]
	@Email VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON;

	SELECT
		VUD.EmailSentOn,
		AD.ValidationStatus,
		AD.CreatedOn AS ValidationDate
	FROM [dbo].[VAOL_UserDetails] VUD (NOLOCK)
		LEFT JOIN [dbo].[VAOL_UserDetailsValidationLog] AD (NOLOCK) ON VUD.EmailSentOn = AD.EmailSentOn AND VUD.SSNDOB = AD.SSNDOB
	WHERE VUD.EmailID = @Email 
	ORDER BY VUD.EmailSentOn DESC

END