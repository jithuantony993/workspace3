﻿/*
Created Date : 08/30/2022
Created By : Kalirajan
Changes Summary : New procedure to Get the Recs in GA_UserKey & GA_UserActivationLog Table.

Modified Date : 19/12/2022
Modified By : Kalirajan
Summary : Delete Some Code For DB CleanUp Activities.
*/
CREATE PROCEDURE [dbo].[Usp_GA_Modify_UserActivation]
@CIAMID	INT,
@ActivationStatus SMALLINT,
@Password VARCHAR(255) = NULL,
@Location VARCHAR(100) = NULL,
@CreatedOn DATETIME
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @CreatedBy VARCHAR(100) = 'Usp_GA_Modify_UserActivation' + ISNULL('|' + @Location,'')

	DECLARE @ContextInfo VARBINARY(128)
	SELECT @ContextInfo = CAST(@CreatedBy AS VARBINARY(128))
	SET CONTEXT_INFO @ContextInfo

	DECLARE @ValidationStatus SMALLINT
	
	IF (ISNULL(@Password,'') <> '')
	BEGIN
		SET @ValidationStatus = 101

		UPDATE [dbo].[GA_UserKey] WITH(ROWLOCK)
		SET ActivationStatus = @ActivationStatus,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID

		INSERT INTO [dbo].[GA_UserActivationLog](CIAMID,ActivationStatus,ValidationStatus,CreatedOn,CreatedBy)
		VALUES(@CIAMID,@ActivationStatus,@ValidationStatus,@CreatedOn,@CreatedBy)
			
		SELECT ValidationStatus = @ValidationStatus

		RETURN
	END		
	ELSE
	BEGIN
		SET @ValidationStatus = 1

		UPDATE [dbo].[GA_UserKey] WITH(ROWLOCK)
		SET ActivationStatus = @ActivationStatus,
			ModifiedOn = @CreatedOn,
			ModifiedBy = @CreatedBy
		WHERE CIAMID = @CIAMID

		INSERT INTO [dbo].[GA_UserActivationLog](CIAMID,ActivationStatus,ValidationStatus,CreatedOn,CreatedBy)
		VALUES(@CIAMID,@ActivationStatus,@ValidationStatus,@CreatedOn,@CreatedBy)
		
		SELECT ValidationStatus = @ValidationStatus

		RETURN
	END
END