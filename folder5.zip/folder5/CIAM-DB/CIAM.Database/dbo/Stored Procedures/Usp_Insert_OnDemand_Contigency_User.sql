﻿CREATE PROCEDURE [dbo].[Usp_Insert_OnDemand_Contigency_User]
	@Email				VARCHAR(150),
	@EntryUUID			UNIQUEIDENTIFIER,
	@GuaPassword		VARCHAR(255),
    @CreatedOn			DATETIME,
	@RefID				UNIQUEIDENTIFIER,
	@OsaVersion			INT,
	@EccVersion			INT,
	@OmbaVersion		INT,
	@IsEal				BIT

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE
	@CreatedBy VARCHAR(50) = 'Usp_Insert_OnDemand_Contigency_User',
	@CiamID INT

	INSERT INTO CIAMUserDetail
	(Email,EntryUUID, MigratedToPing, AccountStatusInd, GuaPassword, CreatedTS, CreatedBy, ModifiedTS, ModifiedBy) values
    (@Email, @EntryUUID, 0, 1, @GuaPassword, @CreatedOn, @CreatedBy, @CreatedOn, @CreatedBy)

	SELECT @CiamID = SCOPE_IDENTITY()

	INSERT INTO UserAccountDetail(CIAMID, Email, CreatedTS, CreatedBy, ModifiedTS, ModifiedBy, RefID)
	VALUES(@CiamID, @Email, @CreatedOn, @CreatedBy, @CreatedOn, @CreatedBy,@RefID)

	EXEC UspInsertEulaVersion @CiamID, @OsaVersion, @EccVersion, @CreatedOn, @CreatedOn

	IF @IsEal = 1
		EXEC UspUpsertOmbaVersion @CiamID, @OmbaVersion, @CreatedOn
END
