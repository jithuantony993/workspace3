﻿/*
Created Date : 09/12/2022
Created By : Kalirajan
Changes Summary : Create New Proc to insert log entries.
*/
CREATE PROCEDURE [dbo].[Usp_WSIDP_Insert_UserValidationLog]
@CIAMID INT,
@ValidationStatus SMALLINT,
@SSNDOB VARCHAR(64) = NULL,
@PIN VARCHAR(64) = NULL,
@TaxWorkspaceID UNIQUEIDENTIFIER,
@FirstName VARCHAR(50) = NULL,
@LastName VARCHAR(50) = NULL,
@InvitedOn DATETIME2,
@InvitationValidHours SMALLINT,
@CreatedOn DATETIME,
@CreatedBy VARCHAR(50)=NULL
AS
BEGIN
	SET NOCOUNT ON;

	IF @CreatedBy IS NULL
	BEGIN
		SET @CreatedBy = 'Usp_WSIDP_Insert_UserValidationLog'
	END

	INSERT INTO [dbo].[WSIDP_UserValidationLog]
	(CIAMID,ValidationStatus,SSNDOB,PIN,TaxWorkspaceID,FirstName,LastName,InvitedOn,InvitationValidHours,CreatedOn,CreatedBy)
	VALUES
	(@CIAMID,@ValidationStatus,@SSNDOB,@PIN,@TaxWorkspaceID,@FirstName,@LastName,@InvitedOn,@InvitationValidHours,@CreatedOn,@CreatedBy)

END