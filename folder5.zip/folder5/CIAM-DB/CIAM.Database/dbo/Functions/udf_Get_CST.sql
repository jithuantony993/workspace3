﻿/*
Created Date : 08/19/2022
Created By : Kalirajan
Changes Summary : Function Return the DataTimeCST
*/
CREATE FUNCTION [dbo].[udf_Get_CST](@DateTime_UTC DATETIMEOFFSET)
RETURNS DATETIMEOFFSET
AS
BEGIN

	RETURN CONVERT(datetime, SWITCHOFFSET(@DateTime_UTC, DATEPART(TZOFFSET,
	@DateTime_UTC AT TIME ZONE 'Central Standard Time')))
END