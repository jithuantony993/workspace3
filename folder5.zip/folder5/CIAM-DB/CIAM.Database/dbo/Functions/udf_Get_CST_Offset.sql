﻿CREATE FUNCTION [dbo].[udf_Get_CST_Offset](@DateTime_UTC DATETIMEOFFSET)
RETURNS DATETIMEOFFSET
AS

BEGIN

	DECLARE @DateTime_CST		DATETIMEOFFSET,
			@DateTime_Offset	DATETIMEOFFSET



	IF DATEDIFF(mi,SYSUTCDATETIME(),@DateTime_UTC) BETWEEN -10 AND 10 -- Validating that the Input Timestamp is UTC and not CST
		BEGIN
			SET @DateTime_Offset	= CONVERT(DATETIMEOFFSET, @DateTime_UTC) AT TIME ZONE 'Central Standard Time'

			SET @DateTime_CST		= CONVERT(DATETIMEOFFSET, @DateTime_Offset)
		END
	ELSE
		BEGIN
			SET @DateTime_CST		= @DateTime_UTC -- Returning the same Input back to handle server in CST scenario
		END
	   
	RETURN (@DateTime_CST)

END