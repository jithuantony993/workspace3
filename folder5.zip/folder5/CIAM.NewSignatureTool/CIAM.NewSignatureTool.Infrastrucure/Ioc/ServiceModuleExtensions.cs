﻿
using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Service;
using CIAM.NewSignatureTool.Repository.Providers;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Provider;
using Microsoft.Extensions.DependencyInjection;

namespace CIAM.NewSignatureTool.Infrastrucure.Ioc;

public static class ServiceModuleExtensions
{
    public static void RegisterInfrastructureServices(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddSingleton<IDataProvider, SqlDataProvider>();
        serviceCollection.AddScoped<INewSignatureService, NewSignatureService>();      
        serviceCollection.AddScoped<INewSignatureRepository, NewSignatureRepository>();        
    }
}

