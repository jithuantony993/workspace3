﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using CIAM.NewSignatureTool.Repository.Providers.SQL;
using Dapper;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.DataAccess;
using System.Data.SqlClient;
using Microsoft.Extensions.Logging;

namespace CIAM.NewSignatureTool.Repository.Providers
{
    public class SignatureCorrectionRepository : RepositoryBase<SignatureCorrectionRepository>, ISignatureCorrectionRepository
    {
        #region Fields
        private readonly ILogger<SignatureCorrectionRepository> _logger;
        #endregion

        #region Constructor
        public SignatureCorrectionRepository(ILogger<SignatureCorrectionRepository> logger, IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _logger = logger;
        }
        #endregion

        #region Retrieve UserRecords by batch size
        public async Task<IEnumerable<UserRecordDto>> GetUserRecords(int batchSize)
        {
            var methodLabel = "GetUserRecords";
            _logger.LogInformation($"{methodLabel} in repository start");

            try
            {
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@BatchSize", batchSize);
                var dataInput = new DataModel()
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandText = SPNames.Usp_Get_UserRecords,
                    Parameters = dynamicParameters
                };

                var spResponse = await this.DataProvider.ExecuteSp<UserRecordDto>(dataInput);
                _logger.LogInformation($"{methodLabel} in repository ended successfully");
                return spResponse;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{methodLabel} encountered an exception: {ex.Message}");
                throw;
            }
        }
        #endregion

        #region Update IDP_User Signature column and NEW_TABLE Processed column
        public async Task<bool> UpdateIdpSignature(IdpSignatureUpdate update)
        {
            var methodLabel = "UpdateIdpSignature";
            _logger.LogInformation($"{methodLabel} in repository start");

            try
            {

                DataTable dt = new DataTable();
                dt.Columns.Add("[CIAMID]", typeof(int));
                dt.Columns.Add("[UpdatedSignature]", typeof(string));
                dt.Rows.Add(update.CiamId, update.UpdatedSignature);
                var tvp = dt.AsTableValuedParameter();

                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@UDT_RequiredSignatureUpdates", tvp);


                var dataInput = new DataModel()
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandText = SPNames.Usp_UpdateRequiredIDPSignature,
                    Parameters = dynamicParameters
                };

                var spResponse = await this.DataProvider.ExecuteSp<bool>(dataInput);
                _logger.LogInformation($"{methodLabel} in repository ended successfully");
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"{methodLabel} encountered an exception: {ex.Message}");
                throw;
            }
        }
        #endregion
    }
}
