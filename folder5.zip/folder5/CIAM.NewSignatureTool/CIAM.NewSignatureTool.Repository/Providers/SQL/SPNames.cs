﻿using System.Diagnostics.CodeAnalysis;

namespace CIAM.NewSignatureTool.Repository.Providers.SQL
{
    [ExcludeFromCodeCoverage]
    public static class SPNames
    {
        private static string _owner = "[dbo]";
        public static string IDP_User_Get_Signature => $"{_owner}.[IDP_User_Get_Signature]";
        public static string Usp_New_Signature => $"{_owner}.[Usp_New_Signature]";
        public static string Usp_Get_UserRecords => $"{_owner}.[Usp_FetchRequiredIDPSignatures]";
        public static string Usp_UpdateRequiredIDPSignature => $"{_owner}.[Usp_UpdateRequiredIDPSignatures]";
    }

}
