﻿using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using CIAM.NewSignatureTool.Common.Models;
using CIAM.NewSignatureTool.Repository.Providers.SQL;
using Dapper;
using HRB.CIAM.Core.Common.Enum.SQL;
using HRB.CIAM.Core.Common.Exceptions;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.DataAccess;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CIAM.NewSignatureTool.Repository.Providers
{



    public class NewSignatureRepository : RepositoryBase<NewSignatureRepository>, INewSignatureRepository
    {
        public NewSignatureRepository(IServiceProvider serviceProvider) : base(serviceProvider) { }

        public async Task<GetSignaturesResponse> GetSignaturesFromIDPUser(ConnectionStringModel connectionStringModel)
        {
            var methodLabel = "IDP_User_Get_Signature";
            try
            {
                Log.Information("{Label} in repository start", methodLabel);
                var result = new GetSignaturesResponse()
                {
                    IDPUserDataResults = new List<IDPUserData>()
                };

                var dataInput = new DataModel()
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandText = SPNames.IDP_User_Get_Signature,
                };
                var spResult = await DataProvider.ExecuteSp<IDPUserData>(dataInput, DBConnectionName.Gua).ConfigureAwait(false);
                result.IDPUserDataResults = spResult.ToList();
                result.IsDbResponseSuccess = true;
                Log.Information("{Label} in repository ended", methodLabel);
                return result;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Exception caught while executing {methodLabel} in repository", methodLabel);
                throw;
            }
        }

        public async Task<bool> UpsertNewSignatureRecords(List<NewUserSignatureDto> batch, ConnectionStringModel connectionStringModel)
        {
            var methodLabel = "Usp_New_Signature";

            try
            {
                Log.Information("{Label} in repository start", methodLabel);


                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@udt_newSignatureTool", batch);

                var udtParameter = new DataTable();
                udtParameter.Columns.Add("UserId", typeof(int));
                udtParameter.Columns.Add("Signature", typeof(string));
                udtParameter.Columns.Add("UCID", typeof(string));
                udtParameter.Columns.Add("SsnDobSHA2", typeof(string));
                udtParameter.Columns.Add("CreatedOn", typeof(DateTime));
                udtParameter.Columns.Add("CreatedBy", typeof(string));

                foreach (var b in batch)
                    udtParameter.Rows.Add(b.UserID, b.Signature, b.UCID, b.SsnDobSHA2, null, null);


                dynamicParameters.Add("@udt_newSignatureTool", udtParameter.AsTableValuedParameter());

                var dataInput = new DataModel()
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandText = SPNames.Usp_New_Signature,
                    Parameters = dynamicParameters
                };


                await ExecuteSp<NewUserSignatureDto>(dataInput, connectionStringModel).ConfigureAwait(false);


                Log.Information("{Label} in repository ended", methodLabel);
                return true;
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Exception caught while executing {methodLabel} in repository", methodLabel);
                throw;

            }
        }

        private async Task<IEnumerable<T>> ExecuteSp<T>(DataModel dataModel, ConnectionStringModel connectionStringModel)
        {

            var result = new List<T>() as IEnumerable<T>;
            SqlConnection connection = null;
            try
            {
                using (connection = new SqlConnection(connectionStringModel.GuaConnection))
                {
                    await connection.OpenAsync();
                    result = await connection.QueryAsync<T>(dataModel.CommandText, dataModel.Parameters, commandType: CommandType.StoredProcedure, commandTimeout: connectionStringModel.TimeoutValueInSecsDB);
                    await connection.CloseAsync();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open)
                {
                    await connection.CloseAsync();
                }
            }
            return result;
        }




    }
}