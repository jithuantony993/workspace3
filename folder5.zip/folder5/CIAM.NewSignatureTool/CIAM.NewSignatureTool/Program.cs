﻿using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Contracts.Service;
using CIAM.NewSignatureTool.Common.Models;
using CIAM.NewSignatureTool.Common.Service;
using CIAM.NewSignatureTool.Repository.Providers;
using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Contracts.Services;
using CIAM.Security.Library.Helpers;
using CIAM.Security.Library.Model;
using CIAM.Security.Library.Services;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Helpers;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Provider;
using HRB.CIAM.Database.Library.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Contracts.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Models;
using HRB.CIAM.Logging.Contracts.Service;
using HRB.CIAM.Logging.Helpers;
using HRB.CIAM.Logging.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using Microsoft.Extensions.Logging;

HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);
IServiceCollection services = builder.Services;

LoggerConfigurationExtention.SetupLoggerConfiguration(builder.Configuration, services);
builder.Logging.AddSerilog();

services.Configure<CoreSettings>(builder.Configuration.GetSection("CoreSettings"));
services.Configure<LaunchDarklySettings>(builder.Configuration.GetSection("LaunchDarklySettings"));
services.Configure<CryptoSettings>(builder.Configuration.GetSection("CryptoSettings"));

services.AddApplicationInsightsTelemetryWorkerService();
services.AddScoped<ILaunchDarklyHelper, LaunchDarklyHelper>();
services.AddSingleton<ISqlResiliencePolicyFactory, SqlResiliencePolicyFactory>();
services.AddScoped<ITelemetrySecurityService, TelemetrySecurityService>();
services.AddScoped<ICryptoUtil, CryptoUtil>();
services.AddLogging();
services.ConfigureDatabaseServices();
services.AddScoped<ISignatureCorrectionRepository, SignatureCorrectionRepository>();
services.AddScoped<ISignatureCorrectionService, SignatureCorrectionService>();
services.AddScoped<IDataProvider, SqlDataProvider>();
services.AddScoped<ITelemetryService, TelemetryService>();

var app = builder.Build();

ISignatureCorrectionService signatureCorrectionService = app.Services.GetService<ISignatureCorrectionService>();

int batchSize = builder.Configuration.GetValue<int>("SignatureToolSettings:BatchSize");
int iterationCount = builder.Configuration.GetValue<int>("SignatureToolSettings:IterationCount");
int batchDelay = builder.Configuration.GetValue<int>("SignatureToolSettings:BatchDelay");

ITelemetryService telemetryService = app.Services.GetService<ITelemetryService>();
ILogger<Program> logger = app.Services.GetService<ILogger<Program>>();

int recordsProccessed = 0;

telemetryService.TrackEvent("SIGNATURE-CORRECTION-TOOL-BEGINNING");
logger.LogInformation($"Starting run with batch size {batchSize} - Iteration Count {iterationCount} - Batch Delay {batchDelay}");
for (int i = 0; i < iterationCount; i++)
{
    var userRecords = await signatureCorrectionService.FetchUserRecords(batchSize);
    logger.LogInformation($"Fetched {userRecords.Count()} from DB");
    foreach (var userRecord in userRecords)
    {
        string signature = signatureCorrectionService.CreateSignature(userRecord.CiamId.ToString(), userRecord.Ucid);
        _ = await signatureCorrectionService.UpdateIdpSignature(userRecord.CiamId, signature);
    }
    recordsProccessed += userRecords.Count();
    logger.LogInformation($"Completed update of {recordsProccessed} records");
    telemetryService.TrackEvent($"SIGNATURE-CORRECTION-TOOL-{recordsProccessed}-RECORDS-COMPLETE");

    if (userRecords.Count() == 0)
    {
        break;
    }

    Thread.Sleep(batchDelay);
}

telemetryService.TrackEvent("SIGNATURE-CORRECTION-TOOL-SHUTTING-DOWN");