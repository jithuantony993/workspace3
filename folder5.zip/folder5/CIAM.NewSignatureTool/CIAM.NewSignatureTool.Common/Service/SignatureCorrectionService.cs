﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Contracts.Service;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using CIAM.Security.Library.Contracts.Helpers;

namespace CIAM.NewSignatureTool.Common.Service
{
    public class SignatureCorrectionService : ISignatureCorrectionService
    {
        #region fields
        private readonly ISignatureCorrectionRepository _repository;
        private readonly ICryptoUtil _cryptoUtil;
        #endregion


        #region Constructor
        public SignatureCorrectionService(ISignatureCorrectionRepository repository, ICryptoUtil cryptoUtil)
        {
            _repository = repository;
            _cryptoUtil = cryptoUtil;
        }
        #endregion

        #region Create Signature()
        public string CreateSignature(string ciamId, string ucid)
        {
            return _cryptoUtil.CreateSignedData(ciamId + ucid);
        }
        #endregion

        #region Fetch CiamId, Ucid records by batch size from CiamDB
        public async Task<IEnumerable<UserRecordDto>> FetchUserRecords(int batchSize)
        {
            return await _repository.GetUserRecords(batchSize);
        }
        #endregion

        public async Task<bool> UpdateIdpSignature(int ciamId, string signature)
        {
            var update = new IdpSignatureUpdate { CiamId = ciamId, UpdatedSignature = signature };

            return await _repository.UpdateIdpSignature(update);
        }
    }
}
