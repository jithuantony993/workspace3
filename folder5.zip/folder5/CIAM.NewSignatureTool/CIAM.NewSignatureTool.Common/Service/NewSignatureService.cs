﻿using CIAM.NewSignatureTool.Common.Contracts.DataAccess;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using HRB.CIAM.Core.Common.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.OpenSsl;
using CIAM.NewSignatureTool.Common.Models;
using Serilog;
using System.IO;
using CIAM.NewSignatureTool.Common.Contracts.Service;

namespace CIAM.NewSignatureTool.Common.Service
{
    public class NewSignatureService : AppServiceBase<NewSignatureService>, INewSignatureService
    {
        private readonly INewSignatureRepository _newSignatureRepository;
        private string KeyPrivate;
        private string KeyPublic;
        private string KeyGuaPrivate;

        public NewSignatureService(IServiceProvider provider, INewSignatureRepository newSignatureRepository) : base(provider)
        {
            _newSignatureRepository = newSignatureRepository;
        }

        public async Task<GetSignaturesResponse> GetIDPUserData(KeysModel keys, ConnectionStringModel connectionStringModel)
        {
            try
            {

                KeyPrivate = keys.PrivateKeySiganture;
                KeyPublic = keys.PublicKeySignature;
                KeyGuaPrivate = keys.GuaPrivateKey;
                Log.Information("Get IDP_User Signatures init");
                await Task.Delay(connectionStringModel.TimeoutValueWaitMilSec);
                var sigResponse = await _newSignatureRepository.GetSignaturesFromIDPUser(connectionStringModel);
                Log.Information($"total IDP records returned: {sigResponse?.IDPUserDataResults.Count()}");
                return sigResponse;
            }
            catch (Exception ex)
            {
                Log.Error("Get IDP_User Signatures error:", ex.Message);
                await Task.Delay(connectionStringModel.TimeoutValueWaitMilSec);
                var sigResponse = await _newSignatureRepository.GetSignaturesFromIDPUser(connectionStringModel);
                return sigResponse;
            }
        }

        public async Task GetNewSignatureAndInsert(GetSignaturesResponse records, ConnectionStringModel connectionStringModel)
        {
            List<NewUserSignatureDto> batch = new List<NewUserSignatureDto>();

            try
            {
                int start = 0;
                int end = records.IDPUserDataResults.Count();
                string format = "yyyyMMdd";

                foreach (var r in records.IDPUserDataResults)
                {
                    try
                    {
                        NewUserSignatureDto newUserSignatureDto = new NewUserSignatureDto { UCID = r.UCID, UserID = r.UserID, };



                        IdHashInfo hashInfo = new IdHashInfo();
                        string dobDecrypted = string.Empty;

                        //Decrypt
                        hashInfo.Ssn = DecryptGua(r.Ssn);
                        dobDecrypted = DecryptGua(r.Dob);

                        if (dobDecrypted != null)
                        {
                            DateTime Dob = DateTime.ParseExact(dobDecrypted,
                                format,
                                System.Globalization.CultureInfo.InvariantCulture);

                            //TODO MAKE SURE FORMAT IS MM DD YYYY
                            hashInfo.Dob = new HashingDob()
                            {
                                Month = (Dob.Month).ToString(),
                                Year = (Dob.Year).ToString(),
                                Day = (Dob.Day).ToString()
                            };
                        }


                        if (hashInfo.Ssn != null && hashInfo.Dob != null)
                            newUserSignatureDto.SsnDobSHA2 = GenerateHashValue(hashInfo);

                        if (!string.IsNullOrEmpty(r.UCID) && !string.IsNullOrEmpty(r.Signature))
                            newUserSignatureDto.Signature = CreateSignedData(r.UserID + r.UCID);

                        batch.Add(newUserSignatureDto);
                        start++;
                        Console.WriteLine($"Record: {start} Of {end}");
                    }
                    catch (Exception ex)
                    {
                        Log.Error($"Failed on GetNewSignatureAndInsert userID{r.UserID} Ex: {ex.Message}");
                        continue;

                    }

                }
                await _newSignatureRepository.UpsertNewSignatureRecords(batch, connectionStringModel);

            }
            catch (Exception ex)
            {
                Log.Error("ERROR in Method GetNewSignatureAndInsert: ", ex.Message);
                throw;
            }
        }


        #region CryptoUtil methods


        private string Decrypt(string encryptedText)
        {
            try
            {
                Log.Information("Decryption :Started decryption for the text {encryptedText}", encryptedText);
                RSACryptoServiceProvider privateKey = GetPrivateKey();
                var encryptedString = HexString2B64String(encryptedText);
                var decryptedBytes = privateKey.Decrypt(Convert.FromBase64String(encryptedText), true);
                Log.Information("Decryption :Completed decryption and decryption value {decryptedBytes}", decryptedBytes);
                return Encoding.UTF8.GetString(decryptedBytes, 0, decryptedBytes.Length);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Log.Error("Decryption :Error occured while decrypting bytes {Message}", ex.Message);
                throw;
            }
        }


        private string HexString2B64String(string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return System.Convert.ToBase64String(HexStringToHex(input));
        }

        private static byte[] HexStringToHex(string inputHex)
        {
            if (inputHex == null)
                return null;
            var resultantArray = new byte[inputHex.Length / 2];
            for (var i = 0; i < resultantArray.Length; i++)
            {
                resultantArray[i] = System.Convert.ToByte(inputHex.Substring(i * 2, 2), 16);
            }
            return resultantArray;
        }

        private string CreateSignedData(string data)
        {
            try
            {
                RSACryptoServiceProvider csp = GetPrivateKey();
                byte[] byteData = Encoding.UTF8.GetBytes(data);

                byte[] signBytes = csp.SignData(byteData, CryptoConfig.MapNameToOID("SHA256"));
                string signedData = Convert.ToBase64String(signBytes);
                return signedData;
            }
            catch (Exception ex)
            {

                Log.Error("ERROR in Method CreateSignedData: ", ex.Message);
                throw;
            }
        }

        private bool ValidateSignature(string data, string signature)
        {
            try
            {

                RSACryptoServiceProvider csp = GetPublicKey();
                byte[] byteData = Encoding.UTF8.GetBytes(data);
                var signatureBytes = Convert.FromBase64String(signature);
                var result = csp.VerifyData(byteData, CryptoConfig.MapNameToOID("SHA256"), signatureBytes);
                return result;
            }
            catch (Exception ex)
            {
                Log.Error("ERROR in Method GetNewSignatureAndInsert: ", ex.Message);
                throw;
            }
        }


        private RSACryptoServiceProvider GetPrivateKey()
        {
            string key = KeyPrivate;


            string beginPrivateKey = "-----BEGIN RSA PRIVATE KEY-----";
            string endPrivateKey = "-----END RSA PRIVATE KEY-----";
            string privateKey = beginPrivateKey + key + endPrivateKey;
            using (TextReader privateKeyTextReader = new StringReader(privateKey))
            {
                AsymmetricCipherKeyPair readKeyPair = (AsymmetricCipherKeyPair)new PemReader(privateKeyTextReader).ReadObject();

                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)readKeyPair.Private);
                RSACryptoServiceProvider csp = new RSACryptoServiceProvider(2048);
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }

        private RSACryptoServiceProvider GetPublicKey()
        {
            string key = KeyPublic;
            string beginPublicKey = "-----BEGIN PUBLIC KEY-----";
            string endPublicKey = "-----END PUBLIC KEY-----";
            string publicKey = beginPublicKey + key + endPublicKey;

            using (TextReader publicKeyTextReader = new StringReader(publicKey))
            {
                RsaKeyParameters publicKeyParam = (RsaKeyParameters)new PemReader(publicKeyTextReader).ReadObject();

                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters(publicKeyParam);

                RSACryptoServiceProvider csp = new RSACryptoServiceProvider(2048);
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }
        #endregion


        #region Hashing Service methods
        private string GenerateHashValue(IdHashInfo idHashInfo)
        {
            Log.Information("create CreateHashValue request started");
            string rawDataToHash = idHashInfo?.Ssn + idHashInfo.Dob.Year + idHashInfo.Dob.Month + idHashInfo.Dob.Day;
            var hashResult = ComputeHash(rawDataToHash);
            Log.Information("create CreateHashValue request completed", hashResult);
            return hashResult;
        }

        private string ComputeHash(string data)
        {
            try
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    Log.Information("creation of hash started", data);
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(data));

                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }
                    Log.Information("creation of hash completed", builder.ToString());
                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                var stackTrace = ex.StackTrace.ToString();
                Log.Error("Exception occurred {stackTrace}", stackTrace);
                throw new ArithmeticException();
            }

        }

        #endregion
        ///ssn/dob -


        #region GUA Decrypt


        public string DecryptGua(string encryptedText)
        {
            try
            {
                Log.Information("Decryption :Started GUA decryption for the text {encryptedText}", encryptedText);
                RSACryptoServiceProvider guaPrivateKey = GetGuaPrivateKey();
                var encryptedString = HexString2B64String(encryptedText);
                var decryptedBytes = guaPrivateKey.Decrypt(Convert.FromBase64String(encryptedString), false);
                Log.Information("Decryption :Completed decryption and decryption value {decryptedBytes}", decryptedBytes);
                return Encoding.UTF8.GetString(decryptedBytes, 0, decryptedBytes.Length);
            }
            catch (Exception ex)
            {
                Log.Error("Decryption :Error occured while decrypting bytes {Message}", ex.Message);
                return null;
            }
        }

        private RSACryptoServiceProvider GetGuaPrivateKey()
        {
            string key = KeyGuaPrivate;
            string beginPrivateKey = "-----BEGIN PRIVATE KEY-----";
            string endPrivateKey = "-----END PRIVATE KEY-----";
            string guaPrivateKey = beginPrivateKey + key + endPrivateKey;

            using (TextReader privateKeyTextReader = new StringReader(guaPrivateKey))
            {
                PemReader pr = new PemReader(new StringReader(guaPrivateKey));
                RSAParameters rsaParams = DotNetUtilities.ToRSAParameters((RsaPrivateCrtKeyParameters)pr.ReadObject());

                RSACryptoServiceProvider csp = new RSACryptoServiceProvider(2048);
                csp.ImportParameters(rsaParams);
                return csp;
            }
        }

        #endregion
    }
}
