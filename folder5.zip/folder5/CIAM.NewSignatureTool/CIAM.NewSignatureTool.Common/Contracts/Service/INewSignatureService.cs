﻿using System.Threading.Tasks;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using CIAM.NewSignatureTool.Common.Models;
using HRB.CIAM.Core.Common.Contracts.Provider;

namespace CIAM.NewSignatureTool.Common.Contracts.Service
{
    public interface INewSignatureService : IService
    {
        Task<GetSignaturesResponse> GetIDPUserData(KeysModel keys, ConnectionStringModel connectionStringModel);
        Task GetNewSignatureAndInsert(GetSignaturesResponse records, ConnectionStringModel connectionStringModel);
    }
}
