﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;

namespace CIAM.NewSignatureTool.Common.Contracts.Service
{
    public interface ISignatureCorrectionService
    {
        public Task<IEnumerable<UserRecordDto>> FetchUserRecords(int batchSize);
        public Task<bool> UpdateIdpSignature(int ciamId, string signature);
        public string CreateSignature(string ciamId, string ucid);
    }
}
