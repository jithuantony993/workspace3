﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CIAM.NewSignatureTool.Common.Entities.DataAccess;
using HRB.CIAM.Core.Common.Contracts.Provider;

namespace CIAM.NewSignatureTool.Common.Contracts.DataAccess
{
    public interface ISignatureCorrectionRepository : IService
    {
        public Task<IEnumerable<UserRecordDto>> GetUserRecords(int batchSize);
        public Task<bool> UpdateIdpSignature(IdpSignatureUpdate update);
    }
}
