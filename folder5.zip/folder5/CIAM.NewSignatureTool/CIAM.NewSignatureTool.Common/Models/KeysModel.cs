﻿namespace CIAM.NewSignatureTool.Common.Models
{
    public class KeysModel
    {
        public string PrivateKeySiganture { get; set; }
        public string PublicKeySignature { get; set; }
        public string GuaPrivateKey { get; set; }
    }
}
