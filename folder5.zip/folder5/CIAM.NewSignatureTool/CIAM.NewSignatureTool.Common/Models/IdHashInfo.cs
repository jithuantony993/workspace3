﻿namespace CIAM.NewSignatureTool.Common.Models
{
    public class IdHashInfo
    {
        public string Ssn { get; set; }
        public HashingDob Dob { get; set; }
    }
}

