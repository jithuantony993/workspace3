﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIAM.NewSignatureTool.Common.Models
{
    public class SignatureToolSettings
    {
        public int BatchSize { get; set; }
        public int IterationCount { get; set; }
        public int BatchDelay { get; set; }
    }
}
