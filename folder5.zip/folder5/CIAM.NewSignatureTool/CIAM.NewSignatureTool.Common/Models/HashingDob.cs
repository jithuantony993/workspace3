﻿
namespace CIAM.NewSignatureTool.Common.Models
{
    public class HashingDob
    {
        public string Year { get; set; }
        public string Month { get; set; }
        public string Day { get; set; }
    }
}
