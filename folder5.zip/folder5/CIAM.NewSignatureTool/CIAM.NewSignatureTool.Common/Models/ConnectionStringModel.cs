﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIAM.NewSignatureTool.Common.Models
{
    public class ConnectionStringModel
    {
        public string DefaultConnection { get; set; }
        public string GuaConnection { get; set; }
        public int TimeoutValueInSecsDB { get; set; }
        public int TimeoutValueWaitMilSec { get; set; }
    }
}

