﻿using System;
using System.Collections.Generic;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using HRB.CIAM.Core.Common.Contracts.Provider;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CIAM.NewSignatureTool.Common
{
    public abstract class AppServiceBase<T> where T : IService
    {

        private ILogger<T> _logger;
        private IApiHelper _apiHelper;
        private readonly IServiceProvider _serviceProvider;
        private readonly Dictionary<string, string> _parameters;

        protected AppServiceBase(IServiceProvider provider)
        {
            _serviceProvider = provider;
            _parameters = new Dictionary<string, string>();
        }

        protected ILogger<T> Logger => _logger ??= _serviceProvider.GetService<ILogger<T>>();
        protected IApiHelper ApiHelper => _apiHelper ??= _serviceProvider.GetService<IApiHelper>();
        public Dictionary<string, string> Parameters => _parameters;
    }
}