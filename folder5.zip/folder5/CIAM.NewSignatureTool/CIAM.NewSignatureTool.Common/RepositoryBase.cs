﻿using System;
using System.Collections.Generic;
using HRB.CIAM.Core.Common.Contracts.Provider;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace CIAM.NewSignatureTool.Common
{
    public abstract class RepositoryBase<T> where T : IService
    {
        private ILogger<T> _logger;
        private readonly IServiceProvider _serviceProvider;
        private IDataProvider _dataProvider;
        private readonly Dictionary<string, string> _parameters;

        protected RepositoryBase(IServiceProvider provider)
        {
            _serviceProvider = provider;
            _parameters = new Dictionary<string, string>();
        }

        protected ILogger<T> Logger => _logger ??= _serviceProvider.GetService<ILogger<T>>();
        protected IDataProvider DataProvider => _dataProvider ??= _serviceProvider.GetService<IDataProvider>();
        public Dictionary<string, string> Parameters => _parameters;
    }
}

