﻿namespace CIAM.NewSignatureTool.Common.Entities.DataAccess
{
    public class NewUserSignatureDto
    {
        public string UserID { get; set; }
        public string UCID { get; set; }
        public string Signature { get; set; }
        public string SsnDobSHA2 { get; set; }
    }

}


