﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIAM.NewSignatureTool.Common.Entities.DataAccess
{
    public class IdpSignatureUpdate
    {
        public int CiamId { get; set; }
        public string UpdatedSignature { get; set; }
    }
}
