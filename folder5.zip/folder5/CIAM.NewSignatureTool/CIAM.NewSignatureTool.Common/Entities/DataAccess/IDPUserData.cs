﻿using System.Diagnostics.CodeAnalysis;

namespace CIAM.NewSignatureTool.Common.Entities.DataAccess
{
    [ExcludeFromCodeCoverage]
    public class IDPUserData
    {
        public string UserID { get; set; }
        public string UCID { get; set; }
        public string Signature { get; set; }
        public string Dob { get; set; }
        public string Ssn { get; set; }
        public string SssDobSHA2 { get; set; }

    }
}
