﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIAM.NewSignatureTool.Common.Entities.DataAccess
{
    [ExcludeFromCodeCoverage]
    public class UserRecordDto
    {
        public int CiamId { get; set; }
        public string Ucid { get; set; }
    }
}
