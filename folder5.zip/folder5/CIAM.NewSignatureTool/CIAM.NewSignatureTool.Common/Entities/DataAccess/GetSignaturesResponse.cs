﻿using System.Collections.Generic;

namespace CIAM.NewSignatureTool.Common.Entities.DataAccess
{
    public class GetSignaturesResponse
    {
        public IEnumerable<IDPUserData> IDPUserDataResults { get; set; }
        public bool IsDbResponseSuccess { get; set; }
    }
}

