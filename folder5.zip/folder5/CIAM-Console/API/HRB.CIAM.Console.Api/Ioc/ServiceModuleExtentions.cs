﻿using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Helpers;
using Google.Authenticator;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Helpers;
using HRB.CIAM.Console.Common.Contracts;

using HRB.CIAM.Console.Common.Services;
using HRB.CIAM.Core.Common.Contracts.Apim;
using HRB.CIAM.Core.Common.Contracts.Helpers;

using HRB.CIAM.Core.Common.Contracts.Provider;

using HRB.CIAM.Core.Common.Helpers;

using HRB.CIAM.Core.Common.Provider;


using HRB.CIAM.Database.Library.Helpers;

using HRB.CIAM.EmailNotification.Library.Contracts.Notification;
using HRB.CIAM.EmailNotification.Library.EmailNotification;
using HRB.CIAM.GoogleAuthenticator.Contracts;
using HRB.CIAM.GoogleAuthenticator.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Contracts.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Helpers;
using HRB.CIAM.Logging.Contracts.Service;
using HRB.CIAM.Logging.Services;
using Microsoft.Extensions.DependencyInjection;
using System.Diagnostics.CodeAnalysis;
using HRB.CIAM.Console.Common.Contracts.DataAccess;
using HRB.CIAM.Console.Repository;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Repository.PingDirectory;
using HRB.CIAM.Console.Common.Contracts.Repository;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using HRB.CIAM.Console.Common.Contracts.Providers;
using HRB.CIAM.Console.Common.Provider;

namespace HRB.CIAM.Console.Api.Ioc
{
    [ExcludeFromCodeCoverage]
    public static class ServiceModuleExtentions
    {
        public static void RegisterServices(this IServiceCollection services)
        {           
            services.AddScoped<IPingOneProvider, PingOneProvider>();
            services.AddScoped<IApiHelper, ApiHelper>();
            services.AddScoped<IPingDirectoryProvider, PingDirectoryProvider>();
            services.AddScoped<IPingFederateProvider, PingFederateProvider>();
         
            services.AddScoped<IApimClient, ApimClient>();       
            services.AddScoped<IApimClient, ApimClient>();
            services.AddScoped<ConfigurationHelper>();
           
            services.ConfigureDatabaseServices();
            services.ConfigureServices();                    
            services.AddScoped<ICorePingoneHelper, CorePingoneHelper>();
            services.AddSingleton<IDataProvider, SqlDataProvider>();
            services.AddScoped<ILaunchDarklyHelper, LaunchDarklyHelper>();
            services.AddScoped<IHashingService, HashingService>();  
            
            services.AddScoped<ICorePingDirectoryHelper, CorePingDirectoryHelper>();          
            services.AddScoped<ICorePingoneHelper, CorePingoneHelper>();   
            services.AddScoped<IEmailPublisherUtil, EmailPublisherUtil>(); 
            services.AddScoped<IGoogleAuthenticatorHelper, GoogleAuthenticatorHelper>();  
            services.AddScoped<ITelemetryService, TelemetryService>(); 
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<TwoFactorAuthenticator>();
            services.AddScoped<ICorePingoneHelper, CorePingoneHelper>();
            services.AddScoped<IPingDirectoryService, PingDirectoryService>();
            services.AddScoped<IPingDirectoryHelper, PingDirectoryHelper>();
            services.AddScoped<IPingDirectoryClient, PingDirectoryClient>();
            services.AddScoped<IUserDetailsService, UserDetailsService>();
            services.AddScoped<IUserDetailsRepository, UserDetailsRepository>();
            services.AddScoped<IPingFederateClient, PingFederateClient>();
            services.AddScoped<IPingFederateHelper, PingFederateHelper>();
            services.AddScoped<IConsumerTokenHelper, ConsumerTokenHelper>();
            services.AddScoped<IConsumerTokenService, ConsumerTokenService>();
            services.AddScoped<ISendEmailService, SendEmailService>();
            services.AddScoped<Common.Contracts.Providers.IApiClient, Common.Provider.ApiClient>();
            services.AddScoped<HRB.CIAM.Core.Common.Contracts.Repository.IHealthCheckRepository, HRB.CIAM.Core.Common.Repository.HealthCheckRepository>();
            services.AddScoped<SwaggerToggle>();            
        }
    }
}
