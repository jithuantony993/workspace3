#region Derictives
using CIAM.Security.Library.Helpers;
using HRB.CIAM.Core.Common.Exceptions;
using HRB.CIAM.Core.Common.Helpers;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.Apim;
using HRB.CIAM.Nudata.Library.Helpers;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Text.Json.Serialization;
using HRB.CIAM.Console.Api.Ioc;
using HRB.CIAM.Console.Common.Mappper;
using HRB.CIAM.Console.Common.Swagger;
using HRB.CIAM.Console.Common.Model;
using EndPoints = HRB.CIAM.Console.Common.Model.EndPoints;
using HRB.CIAM.EmailNotification.Library.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Helpers;
using HRB.CIAM.IDM.Library.Helpers;
using HRB.CIAM.Database.Library.Helpers;
using HRB.CIAM.Console.Common.Helpers;
using HRB.CIAM.Console.Common.Model.PingFederate;
using HRB.CIAM.Logging.Helpers;
using HRBlock.AspNetCore.HealthChecks;
using HRBlock.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using HRBlock.HealthChecks.SqlServer;
using HRBlock.Diagnostics.HealthChecks.Log.AppInsights;
using HRBlock.HealthChecks.ApiEndpoint;
using HRBlock.AspNetCore.HealthChecks.UI.Client;
#endregion

#region Intializer
var builder = WebApplication.CreateBuilder(args);
ConfigurationManager configuration = builder.Configuration;
#endregion


#region Runtime methods to add services to container 
var services = builder.Services;
#region logger configurations 
LoggerConfigurationExtention.SetupLoggerConfiguration(configuration, services);
builder.Host.UseSerilog();
#endregion


services.AddApplicationInsightsTelemetry();
services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
});

#region Interfaces and Implementaions
services.RegisterServices();
// Adding core dependencies

services.ConfigureServices();
services.ConfigureLaunchDarklyServices(configuration);
services.ConfigureSecureServices(configuration);
services.ConfigureNudetectProviderServices();
services.ConfigureIdmServices(configuration); 
services.ConfigureEmailServices(configuration);
services.ConfigureDatabaseServices();
FluentMapping.Initialize(); 
#endregion


#region Swagger Configuration
services.AddSwaggerGen(c =>
{

    c.DocumentFilter<CiamDocumentFilter>();


});
#endregion

#region Bindoptions
services.Configure<CoreSettings>(configuration.GetSection("CoreSettings"));
services.Configure<ApiBaseUrls>(configuration.GetSection("ApiBaseUrls"));
services.Configure<ServiceBusSettings>(configuration.GetSection("ServiceBusSettings"));
services.Configure<EndPoints>(configuration.GetSection("EndPoints"));
services.Configure<ApplicationSettings>(configuration.GetSection("ApplicationSettings"));
services.Configure<ApimEnvironment>(configuration.GetSection("ApimEnvironment"));
services.Configure<DropOffEnvironment>(configuration.GetSection("DropOffEnvironment")); 
services.Configure<JwtSettings>(configuration.GetSection("JwtSettings"));
services.Configure<CookiesSettings>(configuration.GetSection("CookiesList"));
services.Configure<LogoutSettings>(configuration.GetSection("LogoutSettings"));
services.Configure<HostNameSettings>(configuration.GetSection("HostNameSettings"));
services.Configure<RedisCacheSettings>(configuration.GetSection("RedisCache"));
services.Configure<MailinatorSettings>(configuration.GetSection("MailinatorSettings")); 
services.Configure<PingDirEnvironment>(configuration.GetSection("PingDirectoryEnvironment"));
services.Configure<PingFedEnvironment>(configuration.GetSection("PingFederateEnvironment"));
services.Configure<PingDirAuthFlowSettings>(configuration.GetSection("PingDirAuthFlowSettings"));
services.Configure<RedisCacheSettings>(configuration.GetSection("RedisCache"));
services.AddScoped<Func<HttpContext, IConfigurationRoot>>(sp => context => {

    return sp.GetRequiredService<ConfigurationHelper>().GetConfiguration();

});
#endregion

#region Registering Azure ServiceBusClient
string serviceBusConnString = configuration.GetValue<string>("ServiceBusSettings:ConnectionString");
if (serviceBusConnString == null)
    throw new CiamException("Service Bus Missing Connection String Config");

services.AddAzureClients(builder =>
{
    builder.AddServiceBusClient(serviceBusConnString).ConfigureOptions(options =>
    {
        options.RetryOptions.MaxRetries = configuration.GetValue<int>("CoreSettings:MaxRetryCount");
    });
});
#endregion

#endregion

#region Health Check
//Adding HRB Health check library
string connectionString = configuration.GetValue<string>("ConnectionStrings:DefaultConnection");
var apiConfigUrls = configuration.GetSection("ApiHealthUrls");
foreach (var child in apiConfigUrls.GetChildren())
{
    builder.Services.AddHttpClient(child.Key, (client) =>
    {
        client.BaseAddress = new Uri(child.Value);

    });
    builder.Services.AddHRBHealthChecks().AddAPICheck(child.Key, name: child.Key + "HealthCheck");
}
builder.Services.AddHRBHealthChecks()
    .AddCheck("Self", () => { return HealthCheckResult.Healthy(); }, tags: new[] { "islive" })
    .AddSqlServer(connectionString, name: "SQLHealthCheck")
    .AddApplicationInsightsPublisher("CIAM", "CIAM_Console_HEALTH_CHECK");

#endregion

#region Runtime method to configure the HTTP request pipeline.
builder.Services.AddHsts(options => {
    options.Preload = true;
    options.IncludeSubDomains = true;
    options.MaxAge = TimeSpan.FromDays(60);
});
var app = builder.Build();
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseHsts();
}
app.UseWhen(context =>
{
    var enableSwaggerByProject = context.RequestServices.GetRequiredService<SwaggerToggle>().EnableSwaggerByProject;
    return enableSwaggerByProject;
}, builder => builder.UseSwagger().UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "CIAM Console API V1");
    c.RoutePrefix = "swagger";
    c.DisplayRequestDuration();
    c.DocumentTitle = "CIAM Console API V1";
    c.InjectStylesheet("/swagger-ui/custom.css");
    c.DefaultModelsExpandDepth(-1);
}));
app.ConfigureSecureServices();
//entire health check end point
app.MapHRBHealthChecks("api/health", new HealthCheckOptions
{
    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
});
//isLive check
app.MapHRBHealthChecks("api/islive", new HealthCheckOptions()
{
    Predicate = healthCheck => healthCheck.Tags.Contains("islive")
});

app.UseHttpsRedirection();
app.UseRouting();
app.UseAuthorization();
app.UseCors("MyAllowedOrigins");
AuthorizationHelper.Configure(app.Services.GetService<IHttpContextAccessor>());

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapFallbackToFile("index.html");
});
app.Run();
#endregion
