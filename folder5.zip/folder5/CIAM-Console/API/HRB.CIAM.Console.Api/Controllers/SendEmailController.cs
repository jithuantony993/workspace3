﻿using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace HRB.CIAM.Console.Api.Controllers
{
    [Route("ciam/console/api/email")]
    [ApiController]
    public class SendEmailController : BaseController<SendEmailController>
    {
        private readonly ISendEmailService _sendEmailService;
        #region Constructor
        public SendEmailController(ISendEmailService sendEmailService, IServiceProvider serviceProvider) : base(serviceProvider)
        {
            _sendEmailService = sendEmailService;
        }
        #endregion Constructor End

       
        [HttpPost("sendemail")]
        public SendEmailResponse SendEmail(EmailRequest request)
        {    
            this.Logger.LogDebug("Send Email Request {@request}", request);
            return _sendEmailService.SendEmail(request);
        }

    }
}
