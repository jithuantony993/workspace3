﻿using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Api.Controllers
{
    [Route("ciam/console/api/ciamconsumer")]
    [ApiController]
    public class CiamConsumerController : BaseController<CiamConsumerController>
    {
        #region Declarations
        private readonly IConsumerTokenService _tokenService;
        #endregion

        #region Constructor
        public CiamConsumerController
            (
          IConsumerTokenService tokenService, IServiceProvider serviceProvider
            ) : base(serviceProvider)
        {
            _tokenService = tokenService;
        }

        #endregion

        [HttpPost("getCIAMTokens")]
        public async Task<ConsumerTokenResponseResult> GetConsumerTokens([FromBody] ConsumerTokenRequestDto consumerTokenRequestDto)
        {
            this.Logger.LogDebug("Get Consumer tokens {@consumerTokenRequest}", consumerTokenRequestDto);
            var response = await _tokenService.GetConsumerTokens(consumerTokenRequestDto);
            this.Logger.LogDebug("GetConsumerTokens Response: {@response}", response);
            return response;
        }

        [HttpPost("getCIAMTokenswithEmail")]
        public async Task<ConsumerTokenResponseResult> GetConsumerTokenswithEmail([FromBody] ConsumerTokenRequestDto consumerTokenRequestDto)
        {
            this.Logger.LogDebug("Get Consumer tokens {@consumerTokenRequest}", consumerTokenRequestDto);
            var response = await _tokenService.GetConsumerTokenswithEmail(consumerTokenRequestDto);
            this.Logger.LogDebug("GetConsumerTokens Response: {@response}", response);
            return response;
        }


    }
}
