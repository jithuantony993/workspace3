﻿#region Using Directives

//System Namespaces
using System;
using CIAM.Security.Library.Filters;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Core.Common.Contracts.Helpers;

//Mirosoft Namespaces
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

#endregion

namespace HRB.CIAM.Console.Api.Controllers
{
    [AuthorizationFilterAttribute]
    public abstract  class BaseController<T> :  ControllerBase
    {
        private readonly IServiceProvider _serviceProvider;
        private  IApiHelper _apiHelper;
        private ILogger<T> _logger;

        #region Constructor

        protected BaseController(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        protected BaseController(
            IApiHelper apiHelper,
            ILogger<T> logger)
        {
            _apiHelper = apiHelper;
     
            _logger = logger;
        }

        #endregion

        #region Properties       
        protected ILogger<T> Logger => _logger ??= _serviceProvider.GetService<ILogger<T>>();

        #endregion

    }
}
        