﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Entities.PingDirectory;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Api.Controllers
{
    [Route("ciam/console/api/pingdirectory")]
    [ApiController]
    public class PingDirectoryController : BaseController<PingDirectoryController>
    {
        private readonly IPingDirectoryService _pingDirectoryService;
        private readonly IConfiguration _config;
        public PingDirectoryController(IPingDirectoryService pingDirectoryService, IServiceProvider serviceProvider, IConfiguration config) :
            base(serviceProvider)
        {
            _pingDirectoryService = pingDirectoryService;
            _config = config;
        }

        [HttpGet("email")]
        public async Task<UserInfoResponseResult> GetUserDetailswithEmail(string email)
        {
            this.Logger.LogDebug("Get UserDetails with Email {email}", email);
            var encodedEmail = System.Web.HttpUtility.UrlEncode(email);
            var response = await _pingDirectoryService.GetUserDetails(encodedEmail, ApiData.Email);
            this.Logger.LogDebug("GetUserDetailswithEmail Response: {@response}", response);
            return response;
        }

        [HttpGet("phone")]
        public async Task<UserInfoResponseResult> GetUserDetailswithPhone(string mobile)
        {
            this.Logger.LogDebug("Get UserDetails with Phone {mobile}", mobile);
            var response = await _pingDirectoryService.GetUserDetails(mobile, ApiData.Mobile);
            this.Logger.LogDebug("GetUserDetailswithPhone Response: {@response}", response);
            return response;
        }

        [HttpGet("ucid")]
        public async Task<UserInfoResponseResult> GetUserDetailswithUcid(string Ucid)
        {
            this.Logger.LogDebug("Get UserDetails with Ucid {Ucid}", Ucid);
            var response = await _pingDirectoryService.GetUserDetails(Ucid, ApiData.Ucid);
            this.Logger.LogDebug("GetUserDetailswithUcid Response: {@response}", response);
            return response;
        }

        [HttpPost("tokenbyrefreshtoken")]
        public async Task<ExchangeCodeResponseResult> GetAccessTokenwithRefreshToken([FromBody] TokenRequestDto tokenRequestDto)
        {
            tokenRequestDto.TokenType = ApiData.Refresh_token;
            this.Logger.LogDebug("Get Refresh token with Auth code {@TokenRequestDto}", tokenRequestDto);
            var response = await _pingDirectoryService.GetAccessToken(tokenRequestDto);
            this.Logger.LogDebug("GetRefreshTokenwithAuthCode Response: {@response}", response);
            return response;
        }

        [HttpPost("tokenbyauthcode")]
        public async Task<ExchangeCodeResponseResult> GetRefreshTokenwithAuthCode([FromBody] TokenRequestDto tokenRequestDto)
        {
            tokenRequestDto.TokenType = ApiData.Authorization_code;
            this.Logger.LogDebug("Get AccessToken with Refresh Token {@TokenRequestDto}", tokenRequestDto);
            var response = await _pingDirectoryService.GetAccessToken(tokenRequestDto);
            this.Logger.LogDebug("GetAccessTokenwithRefreshToken Response: {@response}", response);
            return response;
        }
    }
}
