﻿using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Exceptions;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HtmlAgilityPack;
using mailinator_csharp_client;
using mailinator_csharp_client.Models.Messages.Entities;
using mailinator_csharp_client.Models.Messages.Requests;
using mailinator_csharp_client.Models.Responses;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Api.Controllers
{
    [Route("ciam/console/api/auth")]
    [ApiController]
    public class ConsoleAuthentication : BaseController<ConsoleAuthentication>
    {
        
        private readonly IUserService _userService;
        #region Constructor
        public ConsoleAuthentication(IApiHelper apiHelper, ILogger<ConsoleAuthentication> logger, IUserService userService) : base(apiHelper, logger)
        { 
            _userService=userService;
        }
        #endregion Constructor End

        #region To Authenticate
        [HttpPost("login")]

        public Task<AuthenticationResponseResult> AuthenticateUser([FromBody] AuthDto authDto)
        {
            

            try
            {
                this.Logger.LogInformation("CIAM Console authentication started");
                this.Logger.LogDebug("Credetials from user entry : {authDto}", authDto.Credential);
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    this.Logger.LogInformation("creation of hash started", authDto.Credential);
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(authDto.Credential));

                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }
                    this.Logger.LogInformation("creation of hash completed", builder.ToString());
                    authDto.Credential = builder.ToString();
                }
            }
            catch (Exception ex)
            {
                var stackTrace = ex.StackTrace.ToString();
                this.Logger.LogError("Exception occurred {stackTrace}", stackTrace);
                throw new ArithmeticException();
            }

            //CIAMKansas
            if (authDto.Credential.Equals("b61cd39ec1ff0c9f431dd18ea685ee1a8558cc1de63fdd510776701256cf91aa"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "MasterUser"
                });
            }

            //CIAMQA
            if (authDto.Credential.Equals("a8cb91615171a021c766616d010a019f5f270aa28b793c5514467fb5f96f063f"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "QAUser"
                });
            }

            //CIAMAdmin
            if (authDto.Credential.Equals("39b37c5a30afeadc17083e49904d0ed6f0d0a709a328707e98d37125765196a4"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "NewUser"
                });
            }

            //Prabhash config update...
            if (authDto.Credential.Equals("cb2445c1ec65d5404cc4b49ede1c89dbf1de9d1c94c78b25310efbe0f7575788"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "AdminUser"
                });
            }
            if (authDto.Credential.Equals("81d06beb5cb0b6716e91e0990c7151fe86a92e9020ea4a394f15ca465d237b04"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "AdminUser"
                });
            }

            //SupportUser
            if (authDto.Credential.Equals("bb57466cf88df1b0bbca5d36a00f58053fc6db29417a4245bfd468a83b27c018"))
            {
                return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.OK)
                {
                    AuthStatus = "SupportUser"
                });
            }
            return Task.FromResult(new AuthenticationResponseResult(string.Empty, HttpStatusCode.NotFound));
        }
        #endregion Authentiocate POST method end
         
        [HttpPost("generateHash")]
        public string GenerateSha256(ShaRequest request)
        {
            return _userService.GenerateHashValue(request);
        }

        [HttpPost("GetIdentifierHash")]
        public string GetIdentifierHash(string identifier)
        {
            return _userService.GetIdentifierHash(identifier);
        }

        [HttpPost("generateGuid")]
        public string NewGuid()
        {
           return _userService.GenerateNewGuid();
        }

        [HttpPost("fetchCodeFromMailinator")]
        public async Task<string> FetchCodeFromEmail(string email)
        {
            return await _userService.FetchMailinatorCode(email);
        }
         
    }
}
