﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Entities.PingDirectory
{
    [ExcludeFromCodeCoverage]
    public class UserAccount
    {
        public Links _links { get; set; }
        public List<string> mail { get; set; }
        public List<string> sn { get; set; }
        public List<string> cn { get; set; }
        public List<string> givenName { get; set; }
        public List<string> mobile { get; set; }
        public string entryUUID { get; set; }
        public string _dn { get; set; }
        public string hrbUserName { get; set; }
        public string hrbGuaid { get; set; }
        public bool hrbIsTemp { get; set; }
        public string hrbUcid { get; set; }
        public bool hrbGAEnabled { get; set; }
        public string hrbGASecret { get; set; }

        [ExcludeFromCodeCoverage]
        public class Self
        {
            public string href { get; set; }
        }
        [ExcludeFromCodeCoverage]
        public class Links
        {
            public Self self { get; set; }
        }
    }
}
