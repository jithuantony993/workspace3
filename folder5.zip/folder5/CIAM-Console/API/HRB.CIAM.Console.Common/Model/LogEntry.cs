﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class LogEntry
    {
        public DateTime TimeStamp { get; private set; }

        public string EntryId { get; internal set; }

        public int StatusCode { get; private set; }

        public string Message { get; internal set; }

        public string RequestParams { get; private set; }

        public string UserId { get; private set; }

        public string AppId { get; private set; }

        public string AuthToken { get; private set; }

        public string ServiceName { get; private set; }

        internal LogEntry() => TimeStamp = DateTime.Now;


        public LogEntry(string message, string requestParams, string userId, string appId, string authToken, string serviceName, int statuscode, string entryId = null)
        {
            TimeStamp = DateTime.Now;
            EntryId = string.IsNullOrWhiteSpace(entryId) ? Guid.Empty.ToString() : entryId;
            StatusCode = statuscode;
            Message = message;
            RequestParams = requestParams;
            UserId = userId;
            AuthToken = authToken;
            ServiceName = serviceName;
        }

    }
}
