﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class ApplicationSettings
    {
        public string AllowedHeaders { get; set; }
        public string AllowedMethods { get; set; }
        public string CorsPattern { get; set; }
        public string Environment { get; set; }
        public string UserAttributesTokenSalt { get; set; }
    }
}
