﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class PingDirEnvironment
    {
        public string ParentDN { get; set; } = String.Empty;
        public string ObjectClass { get; set; } = String.Empty;
        public int RecordsLimit { get; set; }
}
}
