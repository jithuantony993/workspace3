﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class DropOffEnvironment
    {
        public string DropOffUserIdpAdptrUserName { get; set; } = String.Empty;
        public string DropOffUserIdpAdptrPassPhrase { get; set; } = String.Empty;
        public string LoginUrl { get; set; } = String.Empty;
        public string InstanceId { get; set; } = String.Empty;
        public string ExchangeCodeUserName { get; set; } = String.Empty;
        public string ExchangeCodeSecret { get; set; } = String.Empty;
    }
}