﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class InvalidResponse
    {
        public string id { get; set; }
        public string code { get; set; }
        public string message { get; set; }
        public Detail[] details { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Detail
    {
        public string code { get; set; }
        public string target { get; set; }
        public string message { get; set; }
        public Innererror innerError { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Innererror
    {
        public int attemptsRemaining { get; set; }
    }

}
