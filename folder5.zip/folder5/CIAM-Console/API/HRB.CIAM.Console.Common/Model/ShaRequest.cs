﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class ShaRequest
    {
        public string Ssn { get; set; }
        public string Dob { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Dob
    {
        public string Month { get; set; }
        public string Day { get; set; }
        public string Year { get; set; }
    }
}
