﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class LogoutSettings
    {
        public string LoginRedirectBaseUrl { get; set; } = String.Empty;
    }
}