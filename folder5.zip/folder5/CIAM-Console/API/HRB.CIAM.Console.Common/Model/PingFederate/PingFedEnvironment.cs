﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Model.PingFederate
{
    [ExcludeFromCodeCoverage]
    public class PingFedEnvironment
    {
        public string GrantType { get; set; } = String.Empty;
        public string Scope { get; set; } = String.Empty;
        public string GrantTypeAuthCode { get; set; } = String.Empty;
        public string GrantTypeRefreshToken { get; set; } = String.Empty;
    }
}
