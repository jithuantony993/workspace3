﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Model.PingDirectory
{

    [ExcludeFromCodeCoverage]
    public class PingDirectoryEnvironment
    {
        #region Properties
        public string SearchScope { get; set; } = String.Empty;
        public int Limit { get; set; }
        public string Filter { get; set; } = String.Empty;
        public string ParentDN { get; set; } = String.Empty;
        public string ObjectClass { get; set; } = String.Empty;
        #endregion
    }
}
