﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Model.PingDirectory
{
    [ExcludeFromCodeCoverage]
    public class DirectoryUser
    {
        public Links _links { get; set; }
        public string hrbGuaid { get; set; }
        public List<string> sn { get; set; }
        public List<string> cn { get; set; }
        public List<string> givenName { get; set; }
        public string hrbUcid { get; set; }
        public string hrbUserName { get; set; }
        public bool hrbIsTemp { get; set; }
        public List<string> mail { get; set; }
        public List<string> mobile { get; set; }
        public string entryUUID { get; set; }
        public List<string> isMemberOf { get; set; }
        public List<string> objectClass { get; set; }
        public string _dn { get; set; }
        [JsonPropertyName("hrb-ds-pwp-last-login-time")]
        public string lastlogintime { get; set; }
        public int size { get; set; }
        public Embedded _embedded { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Schema
    {
        public string href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Self
    {
        public string href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class IsMemberOf
    {
        public string href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Links
    {
        public List<Schema> schemas { get; set; }
        public Self self { get; set; }
        public List<IsMemberOf> isMemberOf { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Embedded
    {
        public DirectoryUser[] entries { get; set; }
    }
}
