﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HRB.CIAM.Console.Common.Model
{
    public enum SignInType
    {
        Mobile,
        UserName,
        Mail
    }
}
