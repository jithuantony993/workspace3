﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class PingDirAuthFlowSettings
    {
        public string AuthCodeGrantType { get; set; } = String.Empty;
        public string RefreshTokenGrantType { get; set; } = String.Empty;
        public string RedirectUrl { get; set; } = String.Empty;
        public string ClientId { get; set; } = String.Empty;
        public string ClientSecret { get; set; } = String.Empty;

    }
}
