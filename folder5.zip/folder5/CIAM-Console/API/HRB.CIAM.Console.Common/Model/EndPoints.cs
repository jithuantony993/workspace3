﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class EndPoints
    {
        #region Properties
        public string updatePassword { get; set; } = String.Empty;
        public string DeleteDirectory { get; set; } = String.Empty;
        public string getAccessToken { get; set; } = String.Empty;        
        public string getDeviceDetails { get; set; } = String.Empty;
        public string mfadeviceverification { get; set; } = String.Empty;        
        public string getPingFedToken { get; set; } = String.Empty;
        public string ReadDirectoryUser { get; set; } = String.Empty;
        public string CreateDirectory { get; set; } = string.Empty;
        public string UpdateFedDirectory { get; set; } = string.Empty;
        public string ReadFedDirectory { get; set; } = string.Empty;
        public string EnableMFA { get; set; } = String.Empty;
        public string MFAUserCreate { get; set; } = String.Empty;
        public string getRefId { get; set; } = String.Empty;
        public string IdentityAvailability { get; set; } = String.Empty;
        public string MFADeleteDevice { get; set; } = String.Empty;
        public string SignInPingDirectory { get; set; } = String.Empty;
        public string ProfileDirectory { get; set; } = String.Empty;
        public string DirectoryUser { get; set; } = String.Empty;
        #endregion
    }
}
