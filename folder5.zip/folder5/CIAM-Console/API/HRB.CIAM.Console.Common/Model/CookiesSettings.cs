﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class CookiesSettings
    {
        public string Names { get; set; }
    }
}
