﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using System.Text.Json.Serialization;

namespace HRB.CIAM.Console.Common.Model
{
    [ExcludeFromCodeCoverage]
    public class UsersRootObject
    {
        [JsonPropertyName("_links")]
        public Links Links { get; set; }

        [JsonPropertyName("_embedded")]
        public Embedded Embedded { get; set; }

        [JsonPropertyName("count")]
        public int Count { get; set; }

        [JsonPropertyName("size")]
        public int Size { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class UsersRootObjectSelf
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Links
    {
        [JsonPropertyName("self")]
        public UsersRootObjectSelf Self { get; set; }

        [JsonPropertyName("password")]
        public Password Password { get; set; }

        [JsonPropertyName("password.set")]
        public PasswordSet PasswordSet { get; set; }

        [JsonPropertyName("password.reset")]
        public PasswordReset PasswordReset { get; set; }

        [JsonPropertyName("password.check")]
        public PasswordCheck PasswordCheck { get; set; }

        [JsonPropertyName("password.recover")]
        public PasswordRecover PasswordRecover { get; set; }

        [JsonPropertyName("account.sendVerificationCode")]
        public AccountSendVerificationCode AccountSendVerificationCode { get; set; }

        [JsonPropertyName("linkedAccounts")]
        public LinkedAccounts LinkedAccounts { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Password
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class PasswordSet
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class PasswordReset
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class PasswordCheck
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class PasswordRecover
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class AccountSendVerificationCode
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class LinkedAccounts
    {
        [JsonPropertyName("href")]
        public string Href { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class UsersRootObjectEnvironment
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Account
    {
        [JsonPropertyName("canAuthenticate")]
        public bool CanAuthenticate { get; set; }

        [JsonPropertyName("status")]
        public string Status { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class IdentityProvider
    {
        [JsonPropertyName("type")]
        public string Type { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class LastSignOn
    {
        [JsonPropertyName("at")]
        public DateTime At { get; set; }

        [JsonPropertyName("remoteIp")]
        public string RemoteIp { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Lifecycle
    {
        [JsonPropertyName("status")]
        public string Status { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Population
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class UsersRootObjectUser
    {
        [JsonPropertyName("_links")]
        public Links Links { get; set; }

        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("environment")]
        public UsersRootObjectEnvironment Environment { get; set; }

        [JsonPropertyName("account")]
        public Account Account { get; set; }

        [JsonPropertyName("createdAt")]
        public DateTime CreatedAt { get; set; }

        [JsonPropertyName("enabled")]
        public bool Enabled { get; set; }

        [JsonPropertyName("identityProvider")]
        public IdentityProvider IdentityProvider { get; set; }

        [JsonPropertyName("lastSignOn")]
        public LastSignOn LastSignOn { get; set; }

        [JsonPropertyName("lifecycle")]
        public Lifecycle Lifecycle { get; set; }

        [JsonPropertyName("mfaEnabled")]
        public bool MfaEnabled { get; set; }

        [JsonPropertyName("population")]
        public Population Population { get; set; }

        [JsonPropertyName("updatedAt")]
        public DateTime UpdatedAt { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; }

        [JsonPropertyName("verifyStatus")]
        public string VerifyStatus { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public class Embedded
    {
        [JsonPropertyName("users")]
        public List<UsersRootObjectUser> Users { get; set; }

        [JsonPropertyName("devices")]
        public Device[] devices { get; set; }
    }


    [ExcludeFromCodeCoverage]
    public class Device
    {
        public string id { get; set; }
        public string type { get; set; }
        public string status { get; set; }
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
        public string email { get; set; }
        public string phone { get; set; }
    }
}
