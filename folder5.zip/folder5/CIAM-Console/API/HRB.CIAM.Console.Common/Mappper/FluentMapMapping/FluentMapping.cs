﻿using Dapper.FluentMap;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Mappper
{
    [ExcludeFromCodeCoverage]
    public static class FluentMapping
    {
        public static void Initialize()
        {
            FluentMapper.EntityMaps.Clear();
            FluentMapper.Initialize(config =>
            {
            });
        }
        
    }
}
