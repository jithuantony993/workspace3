﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class UserInfoResponseResult : HttpBaseResponseDto
    {
        public UserAttributes userAttributes { get; set; }
        public IdentityAttributes IdentityAttributes { get; set; }

    }
    [ExcludeFromCodeCoverage]
    public class UserAttributes
    {
        public string uid { get; set; }
        public string uname { get; set; }
        public string lastlogindate { get; set; }
        public bool isactive { get; set; }
        public string currentLoginDate { get; set; }
        public string waveAccessToken { get; set; }
        public string passwordResetMobile { get; set; }
        public string mail { get; set; }
        public string ucid { get; set; }
        public string useridtoken { get; set; }
        public string hashedciamId { get; set; }
        public string hashedUcid { get; set; }
        public string signature { get; set; }
        public string mobile { get; set; }
        public string idHash { get; set; }

    }
    [ExcludeFromCodeCoverage]
    public class IdentityAttributes
    {
        public Idproofing idproofing { get; set; }
        public Cardproofing cardproofing { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public BankProofing bankingProofing { get; set; }
        public VaolProofing vaolProofing { get; set; }
        public AolProofing aolProofing { get; set; }
        public PaperlessProofing paperlessProofing { get; set; }
        public IrsDetails irsDetails { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Idproofing
    {
        public string signature { get; set; }
        public string IDPChannel { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class Cardproofing
    {
        public string cardProofingSignature { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class BankProofing
    {
        public string bankIDPStatus { get; set; }
        public string bankIDPSoftFail { get; set; }
        public string bankIDPHardFail { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class VaolProofing
    {
        public Guid vaolWorkspaceID { get; set; }
        public int vaolTaxYear { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class AolProofing
    {
        public Guid userGuid { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class PaperlessProofing
    {
        public Guid taxWorkSpaceID { get; set; }
        public Guid taxReturnGuid { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public class IrsDetails
    {
        public string emailIDOOB { get; set; }
        public string mobilePhoneOOB { get; set; }
        public int machineAuthentication { get; set; }
        public int passwordResetCurrent { get; set; }
        public int passwordResetLast { get; set; }
        public int emailIDResetCurrent { get; set; }
        public int emailIDResetLast { get; set; }
        public int mobilePhoneResetCurrent { get; set; }
        public int mobilePhoneResetLast { get; set; }
        public int identityProofingLevel { get; set; }
        public string tokenAuthenticationLevel { get; set; }
        public string identityAssuranceLevel { get; set; }
        public int authenticationReviewCode { get; set; }
    }
}


