﻿using CIAM.Security.Library.Model;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models.Provider;
using System.Diagnostics.CodeAnalysis;
using System.Net;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class ExchangeCodeResponseResult :ResponseResult
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public string TokenType { get; set; }
        public int ExpiresIn { get; set; }

        public ExchangeCodeResponseResult(IServiceResult<AccessTokenResponse> result) : base(result)
        {
            AccessToken = result?.Data?.access_token;
            ExpiresIn = result?.Data?.expires_in ?? 0;
            TokenType = result?.Data?.token_type;
            RefreshToken = result?.Data?.Refresh_token;
        }

        public ExchangeCodeResponseResult(string errorMessage, HttpStatusCode statusCode) : base(errorMessage, statusCode) { }
    }
}
