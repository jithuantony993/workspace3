﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class FlowResponse
    {
        public string id { get; set; }
        public string status { get; set; }
    }
}
