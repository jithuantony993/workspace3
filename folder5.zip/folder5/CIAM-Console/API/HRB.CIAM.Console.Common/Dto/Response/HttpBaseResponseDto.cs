﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class HttpBaseResponseDto
    {
        public string statusMessage { get; set; }
        public string referenceId { get; set; }
        public string errorMessage { get; set; }
    }
}
