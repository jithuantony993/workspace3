﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class UserDetailsResponseDto
    {
        public IEnumerable<UserDetailsDto> UserDetailsItems { get; set; }

        public bool IsDbResponseSuccess { get; set; }
    }
}
