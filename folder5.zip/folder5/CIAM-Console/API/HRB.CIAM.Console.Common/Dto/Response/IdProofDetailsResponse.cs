﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class IdProofDetailsResponse
    {
        public string Signature { get; set; }
        public string IdpChannel { get; set; }
        public string CardProofingSignature { get; set; }
        public string BankIDPStatus { get; set; }
        public string BankIDPSoftFail { get; set; }
        public string BankIDPHardFail { get; set; }
        public string Ein { get; set; }
        public Guid VaolWorkspaceID { get; set; }
        public int VaolTaxYear { get; set; }
        public Guid UserGuid { get; set; }
        public Guid TaxReturnGuid { get; set; }
        public Guid TaxWorkSpaceID { get; set; }
        public string WaveAccessToken { get; set; }
        public string EmailIDOOB { get; set; }
        public string MobilePhoneOOB { get; set; }
        public int MachineAuthentication { get; set; }
        public int PasswordResetCurrent { get; set; }
        public int PasswordResetLast { get; set; }
        public int EmailIDResetCurrent { get; set; }
        public int EmailIDResetLast { get; set; }
        public int MobilePhoneResetCurrent { get; set; }
        public int MobilePhoneResetLast { get; set; }
        public int IdentityProofingLevel { get; set; }
        public string TokenAuthenticationLevel { get; set; }
        public string IdentityAssuranceLevel { get; set; }
        public int AuthenticationReviewCode { get; set; }
        public string IsActive { get; set; }
        public string idHash { get; set; }
    }
}
