﻿using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class AuthResponse
    {
        [JsonProperty("id")]
        public string Id { get; set; }

        [JsonProperty("pluginTypeId")]
        public string PluginTypeId { get; set; }

        [JsonProperty("status")]
        public string Status { get; set; }

        [JsonProperty("authorizeResponse")]
        public AuthorizeResponse AuthorizeResponse { get; set; }

        [JsonProperty("_links")]
        public Links Links { get; set; }
    }

    [ExcludeFromCodeCoverage]
    public partial class AuthorizeResponse
    {
        [JsonProperty("code")]
        public string Code { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public partial class Links
    {
        [JsonProperty("self")]
        public Self Self { get; set; }
    }
    [ExcludeFromCodeCoverage]
    public partial class Self
    {
        [JsonProperty("href")]
        public Uri Href { get; set; }
    }
}
