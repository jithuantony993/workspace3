﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class DropOffResponse
    {
        public string REF { get; set; }
    }
}
