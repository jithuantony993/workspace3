﻿using CIAM.Security.Library.Model;
using HRB.CIAM.Core.Common.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Response
{
    [ExcludeFromCodeCoverage]
    public class AuthenticationResponseResult : ResponseResult
    {

        public string Id { get; set; }
        public string Type { get; set; }
        public string Status { get; set; }
        public string AuthStatus { get; set; }

        public AuthenticationResponseResult(IServiceResult result) : base(result){ }

        public AuthenticationResponseResult(string errorMessage, HttpStatusCode statusCode) : base(errorMessage, statusCode ){ }

        public AuthenticationResponseResult(string errorMessage) : base(errorMessage) { }

    }
}
