﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto
{
    public enum OlatSearchType
    {
        Login,
        Email,
        EntryUUID,
        Name,
        Ucid,
        Mobile
    }
}
