﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.DataAccess
{
    [ExcludeFromCodeCoverage]
    public class UserDetailsRequestDto
    {
        public int CIAMId { get; set; }
        public string EntryUUID { get; set; }
        public string PingoneID { get; set; }
        public byte EULAStatus { get; set; }
        public byte EULAVersion { get; set; }
        public byte AccountStatus { get; set; }
        public bool PasswordVerified { get; set; }
        public DateTime LastLoginDate { get; set; }
        public DateTime CurrentLoginDate { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime ModifiedOn { get; set; }
        public string ModifiedBy { get; set; }

        public byte UserChannel { get; set; }
    }
}
