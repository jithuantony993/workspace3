﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class ConsumerTokenRequestDto
    {
        public string Email { get; set; }
        public string EntryUUID { get; set; }
    }
}
