﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class UserDetailsDto
    {
        public int CIAMId { get; set; }
        public Guid EntryUUID { get; set; }
        public string EULAStatus { get; set; }
        public string EULAVersion { get; set; }
        public byte ActivationStatus { get; set; }
        public bool HasPasswordPrompt { get; set; }
    }
}
