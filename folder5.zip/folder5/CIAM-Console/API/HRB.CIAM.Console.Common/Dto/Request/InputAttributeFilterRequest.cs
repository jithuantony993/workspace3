﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class InputAttributeFilterRequest
    {
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Ucid { get; set; }
    }
}
