﻿using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class TokenRequestDto
    {
        public string Data { get; set; }
        [JsonIgnore]
        public string TokenType { get; set; }
    }
}
