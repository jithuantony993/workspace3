﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    public class EmailRequest
    {
        public string EmailTemplate { get; set; }
        public string EmailId { get; set; }
        public List<Parameter> Parameters { get; set; }
    }
    public class Parameter
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
