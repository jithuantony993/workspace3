﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Dto.Request
{
    [ExcludeFromCodeCoverage]
    public class UserInfoRequestDto
    {
        public string EntryUUID { get; set; }
        public string AccessToken { get; set; }
        public string Client { get; set; }
    }
}
