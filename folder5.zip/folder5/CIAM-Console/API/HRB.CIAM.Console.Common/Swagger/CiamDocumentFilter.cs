﻿using Microsoft.OpenApi.Models;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace HRB.CIAM.Console.Common.Swagger
{
    [ExcludeFromCodeCoverage]
    public class CiamDocumentFilter : IDocumentFilter
    {
        public void Apply(OpenApiDocument swaggerDoc, DocumentFilterContext context)
        {
            swaggerDoc.Info = new OpenApiInfo
            {
                Title = "CIAM Console API Application",
                Version = "v1",
                Description = "CIAM Console Application api(s)",
                TermsOfService = new Uri("https://hrblock.com"),
                Contact = new OpenApiContact
                {
                    Name = "Prabhash Viswanathan",
                    Email = "prabhash.viswanathan@hrblock.com"
                },
                License = new OpenApiLicense
                {
                    Name = "CIAM.Console",
                    Url = new Uri("https://hrblock.com")
                }
            };
        }
    }
}

