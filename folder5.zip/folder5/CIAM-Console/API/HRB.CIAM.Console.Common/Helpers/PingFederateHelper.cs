﻿using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Core.Common.Constants;
using HRB.CIAM.Core.Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Helpers
{
    public class PingFederateHelper: IPingFederateHelper
    {    

        #region Declarations
        private readonly ILogger<PingFederateHelper> _logger;
        private readonly PingDirAuthFlowSettings _pingDirAuthFlowSettings = new();
        #endregion

        #region Constructor
        public PingFederateHelper(ILogger<PingFederateHelper> logger,
                 IHttpContextAccessor accessor,
            Func<HttpContext, IConfigurationRoot> configurationHelper)
        {
            _logger = logger;
            var configurationRoot = configurationHelper(accessor.HttpContext);
            configurationRoot.GetSection("PingDirAuthFlowSettings").Bind(_pingDirAuthFlowSettings);
        }
        #endregion

        public AuthenticationHeaderValue GetAuthenticationHeader()
        {
          _logger.LogInformation("Getting PingFederate Auth Header");
            var credentials = _pingDirAuthFlowSettings.ClientId + ApiConstants.COLON + _pingDirAuthFlowSettings.ClientSecret;
            var byteArray = Encoding.ASCII.GetBytes(credentials);
            return new AuthenticationHeaderValue(ApiConstants.BASIC, Convert.ToBase64String(byteArray));
        }
    }
}
