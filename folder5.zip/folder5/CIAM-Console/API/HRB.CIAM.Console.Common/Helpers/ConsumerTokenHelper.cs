﻿using HRB.CIAM.Console.Common.Contracts.Helpers;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Helpers
{
    public class ConsumerTokenHelper : IConsumerTokenHelper
    {
        private readonly ILogger<ConsumerTokenHelper> _logger;

        public ConsumerTokenHelper(ILogger<ConsumerTokenHelper> logger)
        {
            _logger = logger;
        }
        public Dictionary<string, string> MapCookies(HttpResponseHeaders incomingHeaders)
        {
            _logger.LogDebug("IncomingHeaders : {@incomingHeaders}", incomingHeaders);
            var outgoingCookies = new Dictionary<string, string>();

            List<string> cookies = incomingHeaders?.SingleOrDefault(header => header.Key == "Set-Cookie").Value?.ToList();
            if (cookies?.Any() ?? false)
            {
                foreach (string cookie in cookies)
                {
                    int startIndex = cookie.IndexOf('=');
                    int endIndex = cookie.IndexOf(';');

                    var cookieName = cookie.Substring(0, startIndex);
                    var cookieValue = cookie.Substring(startIndex + 1, (endIndex - 1) - startIndex);

                    outgoingCookies.Add(cookieName, cookieValue);
                }
            }
            _logger.LogDebug("outgoingCookies : {@outgoingCookies}", outgoingCookies);
            return outgoingCookies;
        }
    }
}
