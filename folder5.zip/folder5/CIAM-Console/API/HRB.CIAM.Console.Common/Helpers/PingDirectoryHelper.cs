﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Exceptions;
using HRB.CIAM.Core.Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Helpers
{
    public class PingDirectoryHelper : IPingDirectoryHelper
    {
        private readonly EndPoints _endpoints;
        private readonly PingDirEnvironment _pingDirEnvironment = new();
        private readonly ILogger<PingDirectoryHelper> _logger;

        public PingDirectoryHelper(IOptions<EndPoints> endPointsoptions, IOptions<PingDirEnvironment> pingDirEnvironment,
            ILogger<PingDirectoryHelper> logger,
                IHttpContextAccessor accessor,
            Func<HttpContext, IConfigurationRoot> configurationHelper)
        {
            _endpoints = endPointsoptions.Value;
            _logger = logger;
            var configurationRoot = configurationHelper(accessor.HttpContext);
            configurationRoot.GetSection("PingDirectoryEnvironment").Bind(_pingDirEnvironment);
        }

        public string GetUrl(string query, string type)
        {
            var endpointUrl = _endpoints.IdentityAvailability;
            endpointUrl = endpointUrl.Replace("[TYPE]", type).Replace("[PARENTDN]", _pingDirEnvironment.ParentDN).Replace("[QUERY]", "\"" + query.ToLower() + "\"");

            if (!string.IsNullOrEmpty(endpointUrl))
            {
                _logger.LogDebug("Endpoint Url: {endpointUrl}", endpointUrl);
                return endpointUrl;
            }
            throw new CiamException("End Point Url is Null");

        }

        public HttpRequestModel CreateHttpRequestModel
         (
             string requestUrl,
             IDictionary<string, string> requestParams,
             IDictionary<string, IEnumerable<string>> requestHeaders,
             string body,
             string contentType
         )
        {

            return new HttpRequestModel()
            {
                RequestUrl = requestUrl,
                Body = body,
                ContentType = contentType,
                RequestHeaders = requestHeaders,
                RequestParams = requestParams,
            };
        }
        public string GetDirectoryUrl(string uuid)
        {
            return _endpoints.ReadFedDirectory.Replace("[PARENTDN]", _pingDirEnvironment.ParentDN).Replace("[UUID]", uuid);

        }
    }
}
