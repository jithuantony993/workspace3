﻿using CIAM.Security.Library.Constants;
using HRB.CIAM.LaunchDarkly.Library.Constants;
using HRB.CIAM.LaunchDarkly.Library.Contracts.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Helpers
{
    public class SwaggerToggle
    {
        private readonly ILaunchDarklyHelper _launchDarklyProvider;

        public bool DisableSwagger { get; set; }
        public bool EnableSwaggerByProject { get; set; }

        public SwaggerToggle(ILaunchDarklyHelper launchDarklyProvider)
        {
            _launchDarklyProvider = launchDarklyProvider;
            DisableSwagger = _launchDarklyProvider.GetFeatureFlag(LaunchDarklyFeatureFlags.DISABLE_SWAGGER);
            string skipList = _launchDarklyProvider.GetStringFeatureFlag(LaunchDarklyFeatureFlags.SWAGGER_DISABLED_PROJECTS);
            var skipProj = JsonConvert.DeserializeObject<string[]>(string.IsNullOrEmpty(skipList) ? "[]" : skipList);
            if (!DisableSwagger && !skipProj.Contains(AuthorizationData.AUTH_CIAM_CONSOLE_WORKFLOWID))
            {
                EnableSwaggerByProject = true;
            }
        }
    }
}
