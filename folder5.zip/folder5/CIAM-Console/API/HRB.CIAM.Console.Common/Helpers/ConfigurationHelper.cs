﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Helpers
{
    public class ConfigurationHelper
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ConfigurationHelper(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public IConfigurationRoot GetConfiguration()
        {
            var env = _httpContextAccessor.HttpContext.Request.Headers["env"].ToString();

            if (string.IsNullOrEmpty(env))
            {
                env = "Qa";
            }

            var builder = new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: true)
              .AddJsonFile($"appsettings.{env}.json", optional: true);
  
            return builder.Build();
        }
    }
}
