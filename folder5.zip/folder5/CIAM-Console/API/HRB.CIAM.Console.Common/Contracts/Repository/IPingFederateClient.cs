﻿using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Helpers
{
    public interface IPingFederateClient
    {
        Task<IServiceResult<AccessTokenResponse>> GetAccessToken(TokenRequestDto tokenRequestDto);
    }
}
