﻿using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Core.Common.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Repository
{
    public interface IPingDirectoryClient
    {
        Task<string> GetEntryUuid(string query, string type);
        Task<IServiceResult<DirectoryUser>> ReadDirectoryUser(string uuid);
    }
}
