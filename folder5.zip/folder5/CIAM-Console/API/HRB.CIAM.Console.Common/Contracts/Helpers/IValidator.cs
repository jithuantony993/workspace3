﻿namespace HRB.CIAM.Console.Common.Contracts.Helpers
{
    public interface IValidator
    {
        bool ValidateOTP(string Otp);
    }
}
