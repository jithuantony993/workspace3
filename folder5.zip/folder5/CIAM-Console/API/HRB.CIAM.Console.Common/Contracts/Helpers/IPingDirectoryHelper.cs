﻿using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Core.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Helpers
{
    public interface IPingDirectoryHelper
    {
        string GetUrl(string query, string type);
        HttpRequestModel CreateHttpRequestModel(
             string requestUrl,
             IDictionary<string, string> requestParams,
             IDictionary<string, IEnumerable<string>> requestHeaders,
             string body,
             string contentType
         );
        string GetDirectoryUrl(string uuid);

    }
}
