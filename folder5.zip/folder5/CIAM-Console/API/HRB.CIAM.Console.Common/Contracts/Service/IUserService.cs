﻿using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Service
{
    public interface IUserService
    {
        Task<string> FetchMailinatorCode(string inbox);
        string GenerateHashValue(ShaRequest request);
        string GenerateNewGuid();
        string GetIdentifierHash(string identifier);

    }
}
