﻿using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Service
{
    public interface ISendEmailService
    {
        SendEmailResponse SendEmail(EmailRequest emailRequest);
    }
}
