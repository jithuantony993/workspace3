﻿using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts.Providers
{
    public interface IApiClient
    {
        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult> GetAsync(HttpRequestModel requestModel);

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult<T>> GetAsync<T>(HttpRequestModel requestModel);

        /// <summary>
        /// Puts the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult<T>> PutAsync<T>(HttpRequestModel requestModel);

        /// <summary>
        /// Puts the data asynchronous.
        /// </summary>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult> PutAsync(HttpRequestModel requestModel);

        /// <summary>
        /// Posts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        Task<IServiceResult<T>> PostAsync<T>(HttpRequestModel requestModel);

        /// <summary>
        /// Posts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        Task<IServiceResult> PostAsync(HttpRequestModel requestModel);


        /// <summary>
        /// Update the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        Task<IServiceResult<T>> PatchAsync<T>(HttpRequestModel requestModel);

        /// <summary>
        /// Update the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        Task<IServiceResult> PatchAsync(HttpRequestModel requestModel);

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult> DeleteAsync(HttpRequestModel requestModel);

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        Task<IServiceResult<T>> DeleteAsync<T>(HttpRequestModel requestModel);

}
}
