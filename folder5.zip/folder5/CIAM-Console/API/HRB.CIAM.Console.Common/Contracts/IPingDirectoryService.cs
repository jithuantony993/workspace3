﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Entities.PingDirectory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Contracts
{
    public interface IPingDirectoryService
    {
        Task<UserInfoResponseResult> GetUserDetails(string query, string type);
        Task<ExchangeCodeResponseResult> GetAccessToken(TokenRequestDto tokenRequestDto);
    }
}
