﻿using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Core.Common.Contracts.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UserDetailsRequestDto = HRB.CIAM.Console.Common.Dto.DataAccess.UserDetailsRequestDto;

namespace HRB.CIAM.Console.Common.Contracts.DataAccess
{
    public interface IUserDetailsRepository: IService
    {
        Task<UserDetailsResponseDto> GetUserDetails(UserDetailsRequestDto userDetailsRequestDto);
        Task<IdProofDetailsResponse> GetIdProofDetails(int ciamId);
    }
}
