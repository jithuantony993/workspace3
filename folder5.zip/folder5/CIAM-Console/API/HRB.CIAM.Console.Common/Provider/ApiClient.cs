﻿using HRB.CIAM.Console.Common.Contracts.Providers;
using HRB.CIAM.Core.Common.Constants;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Helpers;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Provider;
using HRB.CIAM.LaunchDarkly.Library.Constants;
using HRB.CIAM.LaunchDarkly.Library.Contracts.Helpers;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly.CircuitBreaker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using IApiClient = HRB.CIAM.Console.Common.Contracts.Providers.IApiClient;

namespace HRB.CIAM.Console.Common.Provider
{
    public class ApiClient : IApiClient
    {
        #region Public Fields
        public HttpClient HttpClient { get; set; }
        #endregion

        #region Private Fields

        private readonly CoreSettings _coreSettings;
        private readonly IList<string> _defaultHeaders = new List<string> { "Accept", "Accept-Encoding", "Accept-Language", "Connection", "Content-Length", "Content-Type", "Cookie", "Host", "Referer", "User-Agent", "sec-fetch-site", "sec-fetch-mode", "sec-fetch-dest" };
        private static ILogger<ApiClient> _logger;
        private readonly ILaunchDarklyHelper _launchDarklyProvider;
        private static int timeOut;
        private static int maxInstanceCount;
        private static bool isNamedHttpInstance;
        private static bool isAdvancedCircuitBreaker;
        #endregion Private Fields

        #region Public Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiClient"/> class.
        /// </summary>
        /// <param name="coreSettings">The application settings.</param>
        /// <param name="httpClient">The HTTP client.</param>
        /// <exception cref="ArgumentNullException">applicationSettings or httpClient</exception>
        public ApiClient(IOptions<CoreSettings> coreSettings, ILogger<ApiClient> logger, ILaunchDarklyHelper launchDarklyHelper)
        {
            _coreSettings = coreSettings?.Value ?? throw new ArgumentNullException(nameof(coreSettings));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _launchDarklyProvider = launchDarklyHelper ?? throw new ArgumentNullException(nameof(launchDarklyHelper));
            SetLDFlags();
            ApiClientHelper.SetParams(_logger, isNamedHttpInstance, maxInstanceCount, timeOut);
            if (!isNamedHttpInstance)
            {
                ApiClientHelper.ClearInstanceList();
                HttpClient = new HttpClient();
            }
        }
        #endregion Public Constructors

        #region Public Methods

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult> GetAsync(HttpRequestModel requestModel)
        {
            return await RequestAsync(requestModel, HttpMethod.Get);
        }

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult<T>> GetAsync<T>(HttpRequestModel requestModel)
        {
            return await RequestAsync<T>(requestModel, HttpMethod.Get);
        }

        /// <summary>
        /// Posts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult<T>> PostAsync<T>(HttpRequestModel requestModel)
        {
            return await RequestAsync<T>(requestModel, HttpMethod.Post);
        }

        /// <summary>
        /// Posts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult> PostAsync(HttpRequestModel requestModel)
        {
            return await RequestAsync(requestModel, HttpMethod.Post);
        }

        /// <summary>
        /// Puts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult<T>> PutAsync<T>(HttpRequestModel requestModel)
        {
            return await RequestAsync<T>(requestModel, HttpMethod.Put);
        }

        /// <summary>
        /// Puts the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult> PutAsync(HttpRequestModel requestModel)
        {
            return await RequestAsync(requestModel, HttpMethod.Put);
        }

        /// <summary>
        /// Update the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult<T>> PatchAsync<T>(HttpRequestModel requestModel)
        {
            return await RequestAsync<T>(requestModel, HttpMethod.Patch);
        }

        /// <summary>
        /// Update the asynchronous.
        /// </summary>
        /// <param name="httpUpdateRequestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult> PatchAsync(HttpRequestModel requestModel)
        {
            return await RequestAsync(requestModel, HttpMethod.Patch);
        }

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult> DeleteAsync(HttpRequestModel requestModel)
        {
            return await RequestAsync(requestModel, HttpMethod.Delete);
        }

        /// <summary>
        /// Gets the data asynchronous.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestModel"></param>
        /// <returns></returns>
        public async Task<IServiceResult<T>> DeleteAsync<T>(HttpRequestModel requestModel)
        {
            return await RequestAsync<T>(requestModel, HttpMethod.Delete);
        }

        /// <summary>
        /// Dispose HttpClient
        /// </summary>
        //public void Dispose()
        //  {
        //     HttpClient.Dispose();
        //}

        #endregion Public Methods

        #region Private methods
        private async Task<IServiceResult> RequestAsync(HttpRequestModel requestModel, HttpMethod method)
        {

            _logger.LogInformation("Request sent to endpoint {RequestUrl}", requestModel.RequestUrl);
            try
            {
                var response = await SendHttpRequest(requestModel, method);
                _logger.LogInformation("Response received from server {StatusCode}", (int)response.StatusCode);
                var content = await (response?.Content?.ReadAsStringAsync()).ConfigureAwait(false);
                _logger.LogDebug("success response - Status Code: {StatusCode}", response.StatusCode);
                return new ServiceResult(response);
            }
            catch (BrokenCircuitException ex)
            {
                _logger.LogError("Broken Circuit Exception {Message}", ex.Message);
                return new ServiceResult(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            }
            catch (Exception ex)
            {
                _logger.LogError("API Client Exception {Message}", ex.Message);
                return new ServiceResult(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            }
        }

        private async Task<IServiceResult<T>> RequestAsync<T>(HttpRequestModel requestModel, HttpMethod method)
        {
            _logger.LogInformation("Request sent to endpoint {RequestUrl}", requestModel.RequestUrl);
            HttpResponseMessage response = new HttpResponseMessage();
            try
            {
                response = await SendHttpRequest(requestModel, method);
            }
            catch (BrokenCircuitException ex)
            {
                _logger.LogError("Broken Circuit Exception - {Message}", ex.Message);
                return new ServiceResult<T>(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            }
            catch (Exception ex)
            {
                _logger.LogError("API Client Exception {Message}", ex.Message);
                return new ServiceResult<T>(new HttpResponseMessage() { StatusCode = HttpStatusCode.InternalServerError });
            }

            _logger.LogInformation("Response received from server {StatusCode}", response.StatusCode);
            var content = await (response?.Content?.ReadAsStringAsync()).ConfigureAwait(false);
            defaultErrorHandler(response.StatusCode, content);
            var serializeOptions = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };
            _logger.LogDebug("success response - Status Code: {StatusCode}", response.StatusCode);
            return new ServiceResult<T>(response)
            {
                Data = response.IsSuccessStatusCode ? System.Text.Json.JsonSerializer.Deserialize<T>(content, serializeOptions) : default(T)
            };
        }

        private async Task<HttpResponseMessage> SendHttpRequest(HttpRequestModel requestModel, HttpMethod method)
        {
            HttpClient = ApiClientHelper.GetHttpClient(requestModel.RequestUrl);
            //Add cookies
            if (requestModel.RequestCookies != null)
            {
                _logger.LogDebug("Request cookies avalable {@RequestCookies}", requestModel.RequestCookies);
                var cookieContainer = new CookieContainer();
                foreach (var cookies in requestModel.RequestCookies)
                {
                    cookieContainer.Add(new Cookie(cookies.Key, cookies.Value, null, ApiConstants.COOKIE_DOMAIN));//Need to change the domain as localhost when debug in local
                }
                var HttpClientHandler = new HttpClientHandler
                {
                    AllowAutoRedirect = true,
                    UseCookies = true,
                    CookieContainer = cookieContainer
                };
                HttpClient = new HttpClient(HttpClientHandler);

                _logger.LogDebug("Request cookies http client {@HttpClient}", HttpClient);
            }
          
            //if (!requestModel.RequestTimeout.Equals(TimeSpan.Zero))
            //{
            //    HttpClient.Timeout = requestModel.RequestTimeout;
            // }
            // else if (_coreSettings?.RequestTimeout.HasValue ?? false)
            // {
            //     HttpClient.Timeout = _coreSettings.RequestTimeout.Value;
            // }

            if (requestModel.RequestParams != null)
            {
                requestModel.RequestUrl = QueryHelpers.AddQueryString(requestModel.RequestUrl, requestModel.RequestParams);
            }

            HttpClient.DefaultRequestHeaders.Clear();
            if (requestModel?.RequestHeaders?.Any() ?? false)
            {
                foreach (var requestHeader in requestModel.RequestHeaders)
                {
                    if (_defaultHeaders.Contains(requestHeader.Key))
                    {
                        continue;
                    }

                    HttpClient.DefaultRequestHeaders.TryAddWithoutValidation(requestHeader.Key, requestHeader.Value);
                }
            }
            var request = new HttpRequestMessage(method, requestModel.RequestUrl);
            if (requestModel.Body != null)
            {
                _logger.LogDebug("success response");
                request.Content = new StringContent(requestModel.Body, Encoding.UTF8, requestModel.ContentType);
            }
            if (requestModel.RequestFormData != null)
            {
                _logger.LogDebug("Request Form Data :  {RequestFormData}", requestModel.RequestFormData);
                request.Content = new FormUrlEncodedContent(requestModel.RequestFormData);
            }

            if (isAdvancedCircuitBreaker)
            {
                var policyFactory = new ResiliencePolicyFactory(HttpClient, _logger, _launchDarklyProvider);
                var pollyInstanceKey = ApiClientHelper.GetDynamicDomainInstanceKey(requestModel.RequestUrl, "Polly");
                var policy = policyFactory.GetRetryAndCircuitBreakerPolicy(pollyInstanceKey);
                _logger.LogInformation("polly instance key {pollyInstanceKey}", pollyInstanceKey);
                return await policy.ExecuteAsync(() =>
                {
                    var request = new HttpRequestMessage(method, requestModel.RequestUrl);
                    if (requestModel.Body != null)
                    {
                        _logger.LogDebug("success response");
                        request.Content = new StringContent(requestModel.Body, Encoding.UTF8, requestModel.ContentType);
                    }
                    if (requestModel.RequestFormData != null)
                    {
                        _logger.LogDebug("Request Form Data :  {RequestFormData}", requestModel.RequestFormData);
                        request.Content = new FormUrlEncodedContent(requestModel.RequestFormData);
                    }
                    try
                    {
                        return HttpClient.SendAsync(request);
                    }
                    catch (BrokenCircuitException brokenException)
                    {
                        _logger.LogError(" BrokenCircuitException : The circuit is open for the domain - {pollyInstanceKey}. Ciricuit does not allow calls to this api.", pollyInstanceKey);
                        throw brokenException;
                    }
                    catch (Exception exception)
                    {
                        _logger.LogError(exception.Message);
                        throw;
                    }

                }).ConfigureAwait(false);
            }
            else
            {
                var _httpRetryPolicy = ResiliencePolicy.GetInstance(_coreSettings, _logger);
                return await _httpRetryPolicy.ExecuteWithCircuitBreakerAsync(() => HttpClient.SendAsync(request));
            }

        }

        private void SetLDFlags()
        {
            timeOut = _launchDarklyProvider.GetIntFeatureFlag(LaunchDarklyFeatureFlags.REQUEST_TIMEOUT);
            isNamedHttpInstance = _launchDarklyProvider.GetFeatureFlag(LaunchDarklyFeatureFlags.ENABLE_NAMED_HTTP_INSTANCE);
            maxInstanceCount = _launchDarklyProvider.GetIntFeatureFlag(LaunchDarklyFeatureFlags.NAMED_HTTP_INSTANCE_COUNT);
            isAdvancedCircuitBreaker = false;// _launchDarklyProvider.GetFeatureFlag(LaunchDarklyFeatureFlags.ENABLE_NEW_CIRCUITBREAKER);
        }

        private readonly Action<HttpStatusCode, string> defaultErrorHandler = (statusCode, body) =>
        {
            if (statusCode < HttpStatusCode.OK || statusCode >= HttpStatusCode.Ambiguous)
            {
                _logger.LogError("Error occured when processing the request");
            }
            _logger.LogDebug("success response");
        };

        #endregion
    }
}
