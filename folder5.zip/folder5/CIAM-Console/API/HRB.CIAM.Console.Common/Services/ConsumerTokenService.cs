﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Contracts.Providers;
using HRB.CIAM.Console.Common.Contracts.Repository;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Exceptions;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Exceptions;
using HRB.CIAM.Core.Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Services
{
    public class ConsumerTokenService : IConsumerTokenService
    {
        private readonly ILogger<ConsumerTokenService> _logger;
        private readonly IApiClient _apiClient;
        private readonly DropOffEnvironment _dropOffEnvironment = new();
        private readonly ApiBaseUrls _apiBaseUrls = new();
        private readonly IConsumerTokenHelper _tokenHelper;
        private readonly IConfigurationRoot _configurationRoot;
        private readonly IPingDirectoryClient _pingDirectoryClient;

        public ConsumerTokenService(ILogger<ConsumerTokenService> logger, IConsumerTokenHelper tokenHelper,
             IApiClient apiClient, IHttpContextAccessor accessor,
            Func<HttpContext, IConfigurationRoot> configurationHelper, IPingDirectoryClient pingDirectoryClient)
        {
            _logger = logger;
            _tokenHelper = tokenHelper;
            _apiClient = apiClient;
            _pingDirectoryClient = pingDirectoryClient;
            _configurationRoot = configurationHelper(accessor.HttpContext);
            _configurationRoot?.GetSection("ApiBaseUrls").Bind(_apiBaseUrls);
            _configurationRoot?.GetSection("DropOffEnvironment").Bind(_dropOffEnvironment);
        }
        public async Task<ConsumerTokenResponseResult> GetConsumerTokens(ConsumerTokenRequestDto consumerTokenRequestDto)
        {
            var step1RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/as/authorization.oauth2?client_id=LoginRouterApp&response_type=code&response_mode=pi.flow&scope=openid%20profile%20ds");

            var flowResponse = await _apiClient.GetAsync<FlowResponse>(step1RequestModel);
            if (flowResponse?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 1 Failed: {StatusCode}", flowResponse?.StatusCode);
                throw new CiamException("API Failure");
            }
            var flowID = flowResponse.Data.id;
            _logger.LogInformation("Request 1 Succeeded - FLow ID: ", flowID);

            //Step 2 Submit Unregistered Identifier
            var step2RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/pf-ws/authn/flows/" + flowID);
            string step2RequestBody = JsonConvert.SerializeObject(new { identifier = "unregisteredEmail4@mailinator.com" });
            var step2RequestHeaders = new Dictionary<string, IEnumerable<string>>();
            step2RequestHeaders.Add("x-xsrf-header", new string[] { "true" });
            step2RequestModel.RequestHeaders = step2RequestHeaders;
            step2RequestModel.Body = step2RequestBody;
            step2RequestModel.ContentType = "application/vnd.pingidentity.submitIdentifier+json";
            step2RequestModel.RequestCookies = _tokenHelper.MapCookies(flowResponse.Raw.Headers);
            var step2Response = await _apiClient.PostAsync(step2RequestModel);

            if (step2Response?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 2 Failed: {StatusCode}", step2Response?.StatusCode);
                throw new CiamException("API Failure");
            }
            _logger.LogInformation($"Request 2 Succeeded");

            //Step 3 RegisterAccount
            var step3RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/pf-ws/authn/flows/" + flowID);
            var step3RequestHeaders = new Dictionary<string, IEnumerable<string>>();
            step3RequestHeaders.Add("x-xsrf-header", new string[] { "true" });
            string step3RequestBody = JsonConvert.SerializeObject(new { authenticationSource = "Register" });
            step3RequestModel.Body = step3RequestBody;
            step3RequestModel.RequestHeaders = step3RequestHeaders;
            step3RequestModel.ContentType = "application/vnd.pingidentity.useAlternativeAuthenticationSource+json";
            step3RequestModel.RequestCookies = _tokenHelper.MapCookies(step2Response.Raw.Headers);
            var step3Response = await _apiClient.PostAsync(step3RequestModel);

            if (step3Response?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 3 Failed: {StatusCode}", step3Response?.StatusCode);
                throw new CiamException("API Failure");
            }
            _logger.LogInformation($"Request 3 Succeeded");

            //Step 4 DropOff Step 3,4
            string step4RequestBody = JsonConvert.SerializeObject(new { subject = consumerTokenRequestDto.Email, entryUUID = consumerTokenRequestDto.EntryUUID });
            var step4RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/ext/ref/dropoff");
            step4RequestModel.ContentType = "application/json";
            step4RequestModel.Body = step4RequestBody;
            var step4RequestHeaders = new Dictionary<string, IEnumerable<string>>();
            step4RequestHeaders.Add("x-xsrf-header", new string[] { "true" });
            step4RequestHeaders.Add("ping.instanceId", new string[] { _dropOffEnvironment.InstanceId });
            var step4AuthString = $"{_dropOffEnvironment.DropOffUserIdpAdptrUserName}:{_dropOffEnvironment.DropOffUserIdpAdptrPassPhrase}";
            var base64Step4Auth = Convert.ToBase64String(Encoding.ASCII.GetBytes(step4AuthString));
            step4RequestHeaders.Add("Authorization", new string[] { $"Basic {base64Step4Auth}" });
            step4RequestModel.RequestHeaders = step4RequestHeaders;
            step4RequestModel.RequestCookies = _tokenHelper.MapCookies(step3Response.Raw.Headers);
            step4RequestModel.ContentType = "application/json";
            var step4Response = await _apiClient.PostAsync<DropOffResponse>(step4RequestModel);
            var dropOffResponse = JsonConvert.DeserializeObject<DropOffResponse>(step4Response.Body);

            if (step4Response?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 4 Failed: {StatusCode}", step4Response?.StatusCode);
                throw new CiamException("API Failure");
            }
            _logger.LogInformation($"Request 4 Succeeded");

            //Step 5 DropOff Step 5
            string refID = dropOffResponse?.REF;
            string step5RequestBody = JsonConvert.SerializeObject(new { dropoffReferenceId = refID });
            var step5RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/pf-ws/authn/flows/" + flowID);
            var step5RequestHeaders = new Dictionary<string, IEnumerable<string>>();
            step5RequestHeaders.Add("x-xsrf-header", new string[] { "true" });
            step5RequestModel.ContentType = "application/vnd.pingidentity.checkReferenceId+json";
            step5RequestModel.Body = step5RequestBody;
            step5RequestModel.RequestHeaders = step5RequestHeaders;
            step5RequestModel.RequestCookies = _tokenHelper.MapCookies(step4Response.Raw.Headers);
            var step5Response = await _apiClient.PostAsync<AuthResponse>(step5RequestModel);

            if (step5Response?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 5 Failed: {StatusCode}", step5Response?.StatusCode);
                throw new CiamException("API Failure");
            }
            _logger.LogInformation($"Request 5 Succeeded");

            //Step 6 Exchange Code For Access Token
            string authCode = step5Response.Data.AuthorizeResponse.Code;
            HttpRequestModel step6RequestModel = GetHttpRequestModel($"{_apiBaseUrls.PingFederateBaseURL}/as/token.oauth2?code=" + authCode + "&grant_type=authorization_code&scope=openid profile");
            var step6RequestHeaders = new Dictionary<string, IEnumerable<string>>();
            var step6AuthString = $"{_dropOffEnvironment.ExchangeCodeUserName}:{_dropOffEnvironment.ExchangeCodeSecret}";
            var base64Step6Auth = Convert.ToBase64String(Encoding.ASCII.GetBytes(step6AuthString));
            step6RequestHeaders.Add("Authorization", new string[] { $"Basic {base64Step6Auth}" });
            step6RequestModel.RequestHeaders = step6RequestHeaders;
            step6RequestModel.RequestCookies = _tokenHelper.MapCookies(step5Response.Raw.Headers);
            var accessTokenResponse = await _apiClient.PostAsync<ConsumerTokenResponseResult>(step6RequestModel);

            if (accessTokenResponse?.Raw?.IsSuccessStatusCode != true)
            {
                _logger.LogError("Request 6 Failed: {StatusCode}", accessTokenResponse?.StatusCode);
                throw new CiamException("API Failure");
            }
            _logger.LogInformation($"Request 6 Succeeded");

            return accessTokenResponse.Data;
        }

        public async Task<ConsumerTokenResponseResult> GetConsumerTokenswithEmail(ConsumerTokenRequestDto consumerTokenRequestDto)
        {
            consumerTokenRequestDto.EntryUUID = await _pingDirectoryClient.GetEntryUuid(consumerTokenRequestDto.Email, ApiData.Email);
            if (string.IsNullOrWhiteSpace(consumerTokenRequestDto.EntryUUID))
            {
                _logger.LogDebug($"Invalid entry uuid");
                throw new CaimValidationException(Messages.INVALID_REQUEST);
            }
            return await GetConsumerTokens(consumerTokenRequestDto);
        }
            HttpRequestModel GetHttpRequestModel(string url)
        {
            HttpRequestModel httpRequestModel = new HttpRequestModel
            {
                RequestUrl = url,
                RequestHeaders = new Dictionary<string, IEnumerable<string>>()
            };
            return httpRequestModel;
        }
    }
}
