﻿using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.EmailNotification.Library.Contracts.Notification;
using HRB.CIAM.EmailNotification.Library.Models.Notification.Email;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Services
{
    public class SendEmailService : ISendEmailService
    {
        private readonly IEmailPublisherUtil _emailPublisherUtil;
        private readonly ILogger<SendEmailService> _logger;
        public SendEmailService(IEmailPublisherUtil emailPublisherUtil, ILogger<SendEmailService> logger)
        {
            _emailPublisherUtil = emailPublisherUtil;
            _logger = logger;
        }
        public SendEmailResponse SendEmail(EmailRequest emailRequest)
        {
            SendEmailResponse response = new SendEmailResponse();
            MailContent mailContent = GetMailContent(emailRequest);
            _emailPublisherUtil.SendEmail(mailContent);
            response.StatusCode = HttpStatusCode.OK;
            response.Response = "Email Sent to User: " + emailRequest.EmailId;
            _logger.LogDebug("Email Sent to User {EmailId}", emailRequest.EmailId);
            return response;
        }
        private MailContent GetMailContent(EmailRequest emailRequest)
        {
            _logger.LogDebug("Creating mail content for the template {Template} and the ToMailId {MailId}", emailRequest?.EmailTemplate, emailRequest?.EmailId);
            MailContent content = new MailContent(emailRequest?.EmailTemplate, emailRequest?.EmailId);
            foreach (var param in emailRequest?.Parameters)
            {
                content.SetParamMapping(param.Key, param.Value);
            }
            return content;
        }
    }
}
