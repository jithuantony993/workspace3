﻿using CIAM.Security.Library.Constants;
using HRB.CIAM.Console.Common.Contracts.DataAccess;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Dto.Response;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Services
{
    public class UserDetailsService: IUserDetailsService
    {
        private readonly IUserDetailsRepository _userDetailsRepository;
        private readonly ILogger<UserDetailsService> _logger;
        public UserDetailsService(IUserDetailsRepository userDetailsRepository, ILogger<UserDetailsService> logger)
        {
            _userDetailsRepository=userDetailsRepository;
            _logger=logger;
        }

        #region user Info Details
        public async Task<UserInfoResponseResult> GetUserInfo(string entryUuid)
        {
            if(entryUuid == null)
            {
                return new UserInfoResponseResult() { };
            }
            var userDetails = await _userDetailsRepository.GetUserDetails(new UserDetailsRequestDto() { EntryUUID = entryUuid });
            _logger.LogDebug("GetUserDetails Response: {@Response}", userDetails);
            IdProofDetailsResponse idProofDetails =new IdProofDetailsResponse();
            if (userDetails?.UserDetailsItems?.FirstOrDefault()?.CIAMId !=null)
            {
                idProofDetails = await _userDetailsRepository.GetIdProofDetails(userDetails?.UserDetailsItems?.FirstOrDefault()?.CIAMId ?? 0);
            }
            
            _logger.LogDebug("GetIdProofDetails Response: {@Response}", idProofDetails);
            return new UserInfoResponseResult
                {
                    userAttributes = new UserAttributes
                    {
                        currentLoginDate = string.Empty,
                        isactive = idProofDetails?.IsActive != "0",
                        lastlogindate = string.Empty,
                        mail = string.Empty,
                        uid = string.Empty,
                        uname = string.Empty,
                        waveAccessToken = string.IsNullOrEmpty(idProofDetails?.WaveAccessToken) ? string.Empty : idProofDetails?.WaveAccessToken,
                        ucid = string.Empty,
                        useridtoken = string.Empty,
                        hashedciamId = string.Empty,
                        hashedUcid = string.Empty,
                        signature = idProofDetails?.Signature,
                        idHash = idProofDetails?.idHash,
                        mobile = string.Empty
                    },
                    IdentityAttributes = new IdentityAttributes
                    {
                        bankingProofing = new BankProofing
                        {
                            bankIDPHardFail = idProofDetails?.BankIDPHardFail,
                            bankIDPSoftFail = idProofDetails?.BankIDPSoftFail,
                            bankIDPStatus = idProofDetails?.BankIDPStatus,
                        },
                        cardproofing = new Cardproofing
                        {
                            cardProofingSignature = idProofDetails?.CardProofingSignature,
                        },
                        vaolProofing = new VaolProofing
                        {
                            vaolTaxYear = idProofDetails?.VaolTaxYear ?? 0,
                            vaolWorkspaceID = idProofDetails?.VaolWorkspaceID ?? Guid.Empty,
                        },
                        aolProofing = new AolProofing
                        {
                            userGuid = idProofDetails?.UserGuid ?? Guid.Empty
                        },
                        paperlessProofing = new PaperlessProofing
                        {
                            taxReturnGuid = idProofDetails?.TaxReturnGuid ?? Guid.Empty,
                            taxWorkSpaceID = idProofDetails?.TaxWorkSpaceID ?? Guid.Empty
                        },

                    }
                };
           
        }
        #endregion
    }
}
