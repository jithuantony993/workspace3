﻿using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Model;
using HtmlAgilityPack;
using mailinator_csharp_client;
using mailinator_csharp_client.Models.Messages.Entities;
using mailinator_csharp_client.Models.Messages.Requests;
using mailinator_csharp_client.Models.Responses;
using Microsoft.Extensions.Options;
using System;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Common.Services
{
    public class UserService : IUserService
    {
        private readonly MailinatorSettings mailinatorSettings;
        private readonly IHashingService hashingService;
        public UserService(IOptions<MailinatorSettings> _mailinatorSettings, IHashingService _hashingService)
        {
            mailinatorSettings = _mailinatorSettings.Value;
            hashingService = _hashingService;
        }

        public async Task<string> FetchMailinatorCode(string inbox)
        {
            inbox = inbox.Replace("@" + mailinatorSettings.DomainName, string.Empty);
            MailinatorClient mailinatorClient = new MailinatorClient(mailinatorSettings.ApiKey);
            FetchInboxRequest fetchInboxRequest = new FetchInboxRequest()
            {
                Domain = mailinatorSettings.DomainName,
                Inbox = inbox,
                Skip = 0,
                Limit = 1,
                Sort = Sort.desc
            };
            FetchInboxResponse fetchInboxResponse = await mailinatorClient.MessagesClient.FetchInboxAsync(fetchInboxRequest);
            FetchMessageRequest fetchMessageRequest = new FetchMessageRequest()
            {
                Domain = mailinatorSettings.DomainName,
                Inbox = inbox,
                MessageId = fetchInboxResponse?.Messages.Count > 0 ? fetchInboxResponse?.Messages[0]?.Id : "0",
            };
            try
            {
                FetchMessageResponse fetchMessageResponse = await mailinatorClient.MessagesClient.FetchMessageAsync(fetchMessageRequest);
                HtmlDocument htmlDocument = new HtmlDocument();
                htmlDocument.LoadHtml(fetchMessageResponse.Parts[1].Body);
                StringBuilder builder = new StringBuilder();
                foreach (var node in htmlDocument.DocumentNode.SelectNodes("//span"))
                {
                    var str = node.InnerText.Replace("&nbsp;", " ");
                    if (!builder.ToString().Contains(str))
                        builder.Append(str);
                }
                return builder.ToString();
            }
            catch (Exception ex) { return "No OTP found"; }
        }

        public string GenerateHashValue(ShaRequest request)
        {
            var dob = request?.Dob;
            var hashValue = hashingService.GenerateHashValue(new IdHashInfo { Ssn = request?.Ssn, Dob = new HashingDob() { Year = dob?.Substring(0, 4), Month = dob?.Substring(4, 2), Day = dob?.Substring(6, 2) } });
            return hashValue;
        }

        public string GenerateNewGuid()
        {
            return Guid.NewGuid().ToString();
        }
        public string GetIdentifierHash(string identifier)
        {
            var hashValue = hashingService.ComputeHash(identifier);
            return hashValue;
        }

    }
}
