﻿using HRB.CIAM.Console.Common.Contracts;
using HRB.CIAM.Console.Common.Contracts.DataAccess;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Entities.PingDirectory;
using HRB.CIAM.Console.Common.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Constants;
using Microsoft.AspNetCore.Http;
using HRB.CIAM.Console.Common.Contracts.Repository;
using HRB.CIAM.Console.Common.Model;
using Microsoft.Extensions.Options;
using HRB.CIAM.Core.Common.Exceptions;
using HRB.CIAM.Core.Common.Contracts.Provider;
using CIAM.Security.Library.Contracts.Helpers;

namespace HRB.CIAM.Console.Common.Services
{
    public class PingDirectoryService : IPingDirectoryService
    {

        private readonly ApplicationSettings _applicationSettings;

        private readonly IUserDetailsService _userDetailsService;
        private readonly IHashingService _hashingService;
        private readonly ILogger<PingDirectoryService> _logger;


        private readonly IPingFederateClient _pingFederateClient;

        private readonly IPingDirectoryClient _pingDirectoryClient;
        public PingDirectoryService(

            IUserDetailsService userDetailsService,
            ILogger<PingDirectoryService> logger,
            IPingFederateClient pingFederateClient,
            IPingDirectoryClient pingDirectoryClient,
            IOptions<ApplicationSettings> applicationSettings,
            IHashingService hashingService
            )
        {

            _userDetailsService = userDetailsService;
            _logger = logger;
            _pingFederateClient = pingFederateClient;
            _pingDirectoryClient = pingDirectoryClient;
            _applicationSettings = applicationSettings.Value;
            _hashingService = hashingService;
        }
        public async Task<UserInfoResponseResult> GetUserDetails(string query, string type)
        {

            _logger.LogDebug("Request to get UserDetails");
            var entryuuid = await _pingDirectoryClient.GetEntryUuid(query, type);
            _logger.LogDebug("EntryUUID with {query} and {type}: {entryuuid}", query, type, entryuuid);
            if(entryuuid == null)
            {
                return new UserInfoResponseResult()
                {
                    statusMessage="NOT_FOUND",
                    errorMessage= "No data found"
                };
            }
            var serviceResponse = await _userDetailsService.GetUserInfo(entryuuid);
            _logger.LogDebug("GetUserInfo Response: {@Response}", serviceResponse);
            return await GetUserDetailsFromPingDirectory(entryuuid, serviceResponse);
        }

        public async Task<ExchangeCodeResponseResult> GetAccessToken(TokenRequestDto tokenRequestDto)
        {
            _logger.LogDebug("Request to get AccessToken");
            var response = await _pingFederateClient.GetAccessToken(tokenRequestDto);
            _logger.LogDebug("GetAccessToken response: {@Response}", response);
            return new ExchangeCodeResponseResult(response);
        }

        #region Retrieve User Details from Ping Directory
        private async Task<UserInfoResponseResult> GetUserDetailsFromPingDirectory(string entryuuid, UserInfoResponseResult serviceResponse)
        {
            _logger.LogDebug("Making Request to Ping Directory for UserDetails");
            var pingDirectoryUserDetails = await _pingDirectoryClient.ReadDirectoryUser(entryuuid);

            if (pingDirectoryUserDetails.HasError)
            {
                _logger.LogDebug("PingDirectory UserDetails Has Error :{@Error}", pingDirectoryUserDetails.Error);
                throw new CiamException(pingDirectoryUserDetails.Error, pingDirectoryUserDetails.StatusCode);
            }
            if (pingDirectoryUserDetails.Data != null)
            {
                _logger.LogDebug("PingDirectory UserDetails  :{@pingDirectoryUserDetails}", pingDirectoryUserDetails);

                serviceResponse.userAttributes.uid = pingDirectoryUserDetails?.Data?.hrbGuaid;
                serviceResponse.userAttributes.mail = pingDirectoryUserDetails?.Data?.mail?.FirstOrDefault();
                serviceResponse.userAttributes.passwordResetMobile = pingDirectoryUserDetails?.Data?.mobile?.FirstOrDefault();
                serviceResponse.userAttributes.uname = pingDirectoryUserDetails?.Data?.hrbUserName;
                serviceResponse.userAttributes.ucid = pingDirectoryUserDetails?.Data?.hrbUcid;
                serviceResponse.userAttributes.lastlogindate = pingDirectoryUserDetails?.Data?.lastlogintime;
                serviceResponse.userAttributes.useridtoken = _hashingService.ComputeHash(pingDirectoryUserDetails?.Data?.hrbGuaid + pingDirectoryUserDetails?.Data?.hrbUserName + _applicationSettings.UserAttributesTokenSalt);              
                serviceResponse.userAttributes.hashedciamId = await _hashingService.GenerateUniversalId(pingDirectoryUserDetails?.Data?.hrbGuaid, pingDirectoryUserDetails?.Data?.entryUUID);
                serviceResponse.userAttributes.hashedUcid = await _hashingService.GenerateHashedUcid(pingDirectoryUserDetails?.Data?.hrbUcid, pingDirectoryUserDetails?.Data?.entryUUID);
                serviceResponse.userAttributes.mobile = pingDirectoryUserDetails?.Data?.mobile?.FirstOrDefault();
                _logger.LogDebug("User Details : {@Response}", serviceResponse);
                //this.TelemetryService.TrackEvent(ServiceEvents.SERVICE_USERINFO_PINGDIR_CALL_SUCCESS);
            }
            else
            {
                _logger.LogError("Ping Directory ReadDirectoryUser response was null");
                //this.TelemetryService.TrackEvent(ServiceEvents.SERVICE_USERINFO_PINGDIR_CALL_FAILURE);
            }

            return serviceResponse;
        }

        #endregion
    }
}
