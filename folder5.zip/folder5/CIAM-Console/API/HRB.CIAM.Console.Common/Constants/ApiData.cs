﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Constants
{
    [ExcludeFromCodeCoverage]
    public static class ApiData
    {
        public const string DEV = "DEV";
        public const string QA = "QA";
        public const string Authorization_code = "authorization_code";
        public const string Refresh_token = "refresh_token";
        public const string Email = "mail";
        public const string Mobile = "mobile";
        public const string Ucid = "hrbUcid";
    }
}
