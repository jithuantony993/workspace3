﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Constants
{
    [ExcludeFromCodeCoverage]
    public static class ApiEvents
    {
    }
}