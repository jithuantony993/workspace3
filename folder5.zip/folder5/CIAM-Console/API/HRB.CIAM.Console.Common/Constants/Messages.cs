﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Common.Constants
{
    [ExcludeFromCodeCoverage]
    public static class Messages
    {
        public const string INVALID_REQUEST = "Invalid Request";
    }
}
