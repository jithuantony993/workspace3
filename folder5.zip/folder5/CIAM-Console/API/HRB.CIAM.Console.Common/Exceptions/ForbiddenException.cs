﻿#region Using Directivies
using HRB.CIAM.Core.Common.Exceptions;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
#endregion

namespace HRB.CIAM.Console.Common.Exceptions
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class ForbiddenException : CiamException
    {
        #region Exception method without arrguments
        public ForbiddenException() : base()
        {
            ExceptionMessage = "Forbidden";
            StatusCode = HttpStatusCode.Forbidden;
        }
        #endregion

        #region Exception method with message
        public ForbiddenException(string message) : base(message)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.Forbidden;
        }
        #endregion

        #region Exception method with message and inner Exception
        public ForbiddenException(string message, Exception innerException) :
            base(message, innerException)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.Forbidden;
        }
        #endregion
    }
}
