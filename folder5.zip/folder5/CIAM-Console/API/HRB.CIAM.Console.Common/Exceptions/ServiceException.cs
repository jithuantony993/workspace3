﻿#region Using Directivies
using HRB.CIAM.Core.Common.Exceptions;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
#endregion

namespace HRB.CIAM.Console.Common.Exceptions
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class ServiceException : CiamException
    {
        #region Exception method without arrguments
        public ServiceException() : base()
        {
            ExceptionMessage = "ServiceUnavailable";
            StatusCode = HttpStatusCode.ServiceUnavailable;
        }
        #endregion

        #region Exception method with message
        public ServiceException(string message) : base(message)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.ServiceUnavailable;
        }
        #endregion

        #region Exception method with message, status code and inner exception
        public ServiceException(string message, HttpStatusCode code, Exception innerException) :
            base(message, innerException)
        {
            ExceptionMessage = message;
            StatusCode = code;
        }
        #endregion

        #region Exception method with message and inner Exception
        public ServiceException(string message, Exception innerException) :
            base(message, innerException)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.ServiceUnavailable;
        }
        #endregion

        #region Exception method with message and status code
        public ServiceException(string message, HttpStatusCode code) :
            base(message)
        {
            ExceptionMessage = message;
            StatusCode = code;
        }
        #endregion
    }
}
