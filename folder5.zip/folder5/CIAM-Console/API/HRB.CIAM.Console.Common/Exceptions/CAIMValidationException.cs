﻿#region Using Directivies
using HRB.CIAM.Core.Common.Constants;
using HRB.CIAM.Core.Common.Exceptions;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
#endregion

namespace HRB.CIAM.Console.Common.Exceptions
{
    [ExcludeFromCodeCoverage]
    [Serializable]
    public class CaimValidationException : CiamException
    {
        #region Constructors
        public CaimValidationException() :
            base()
        {
            ExceptionMessage = ApiConstants.VALIDATION_FAILURE;
            StatusCode = HttpStatusCode.BadRequest;
        }

        public CaimValidationException(string message) : base(message)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.BadRequest;
        }

        public CaimValidationException(string message, Exception innerException) :
            base(message, innerException)
        {
            ExceptionMessage = message;
            StatusCode = HttpStatusCode.BadRequest;
        }
        #endregion
    }
}
