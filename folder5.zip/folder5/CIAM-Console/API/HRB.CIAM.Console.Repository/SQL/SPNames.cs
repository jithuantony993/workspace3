﻿using System.Diagnostics.CodeAnalysis;

namespace HRB.CIAM.Console.Repository.SQL
{
    [ExcludeFromCodeCoverage]
    internal static class SPNames
    {
        private static string _owner = "dbo";
        public static string GetUserDetails => $"[{_owner}].[UspGetUserDetails]";
        public static string Get_IDProofedValue => $"[{_owner}].[Usp_Get_IDProofedValue]";
    }
}
