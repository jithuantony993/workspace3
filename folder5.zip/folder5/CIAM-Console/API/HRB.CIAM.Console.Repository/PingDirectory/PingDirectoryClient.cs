﻿using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Console.Common.Contracts.Repository;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Core.Common.Constants;
using System.Net.Http.Headers;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace HRB.CIAM.Console.Repository.PingDirectory
{
    public class PingDirectoryClient : IPingDirectoryClient
    {
        private readonly ILogger<PingDirectoryClient> _logger;
        private readonly IApiClient _apiClient;
        private readonly IPingDirectoryHelper _pingDirectoryHelper;
        private readonly IPingDirectoryProvider _pingDirectoryProvider;
        private readonly ApiBaseUrls _apiBaseUrls = new();
        private readonly IConfigurationRoot _configurationRoot;

        public PingDirectoryClient(ILogger<PingDirectoryClient> logger, IApiClient apiClient,
            IPingDirectoryHelper pingDirectoryHelper, IPingDirectoryProvider pingDirectoryProvider,
            IOptions<ApiBaseUrls> apiBaseUrls,
             IHttpContextAccessor accessor,
            Func<HttpContext, IConfigurationRoot> configurationHelper
            )
        {
            _logger = logger;
            _apiClient = apiClient;
            _pingDirectoryHelper = pingDirectoryHelper;
            _pingDirectoryProvider = pingDirectoryProvider;
            _configurationRoot = configurationHelper(accessor.HttpContext);
            _configurationRoot.GetSection("ApiBaseUrls").Bind(_apiBaseUrls);
            _pingDirectoryProvider.UseCustomConfigurations(_configurationRoot);
        }

        public async Task<string> GetEntryUuid(string query, string type)
        {
            var pingResponse = await GetPingResponse(query, type);
            _logger.LogDebug("Ping Response: {@PingResponse}", pingResponse);
            if (pingResponse?.HasError ?? false)
            {
                _logger.LogDebug("EntryUUID not found");
                return null;
            }
            var serialisedData = pingResponse?.Data?._embedded?.entries[0];
            _logger.LogDebug("Serialized Embedded entries: {serialisedData}", pingResponse);
            string entryUuid = serialisedData?.entryUUID;
            _logger.LogDebug("EntryUUID : {EntryUuid}", entryUuid);
            return entryUuid;
        }
        private async Task<IServiceResult<DirectoryUser>> GetPingResponse(string query, string type)
        {
            IDictionary<string, IEnumerable<string>> requestHeaders = new Dictionary<string, IEnumerable<string>>();
            requestHeaders.Add(ApiConstants.CONTENT_TYPE, new string[] { ApiConstants.JSON_CONTENT_TYPE });
            requestHeaders.Add(ApiConstants.HEADER_AUTHORIZATION, new string[] { new AuthenticationHeaderValue(ApiConstants.BEARER, await GetAccessToken()).ToString() });
            var endpoint = _pingDirectoryHelper.GetUrl(query, type);
            _logger.LogDebug("Endpoint Url: {endpoint}", endpoint);
            HttpRequestModel httpRequestModel = _pingDirectoryHelper.CreateHttpRequestModel($"{_apiBaseUrls?.PingDirectoryBaseURL}{endpoint}", null, requestHeaders, "", ApiConstants.JSON_CONTENT_TYPE);
            _logger.LogDebug("HttpRequestModel: {@HttpRequestModel}", httpRequestModel);
            return await _apiClient.GetAsync<DirectoryUser>(httpRequestModel);
        }

        public async Task<IServiceResult<DirectoryUser>> ReadDirectoryUser(string uuid)
        {
            var accessToken = await GetAccessToken();
            _logger.LogDebug("AccessToken: {accessToken}", accessToken);
            IDictionary<string, IEnumerable<string>> requestHeaders = new Dictionary<string, IEnumerable<string>>();
            requestHeaders.Add(ApiConstants.CONTENT_TYPE, new string[] { ApiConstants.JSON_CONTENT_TYPE });
            requestHeaders.Add(ApiConstants.HEADER_AUTHORIZATION, new string[] { new AuthenticationHeaderValue(ApiConstants.BEARER, accessToken).ToString() });
            var endpointUrl = _pingDirectoryHelper.GetDirectoryUrl(uuid);
            _logger.LogDebug("Endpoint Url: {endpointUrl}", endpointUrl);
            HttpRequestModel httpRequestModel = _pingDirectoryHelper.CreateHttpRequestModel($"{_apiBaseUrls?.PingDirectoryBaseURL}{endpointUrl}", null, requestHeaders, null, ApiConstants.JSON_CONTENT_TYPE);
            _logger.LogDebug("HttpRequestModel: {@httpRequestModel}", httpRequestModel);
            return await _apiClient.GetAsync<DirectoryUser>(httpRequestModel);

        }

        private async Task<string> GetAccessToken()
        {
            return await _pingDirectoryProvider.GetAccessToken(false);
        }

    }
}
