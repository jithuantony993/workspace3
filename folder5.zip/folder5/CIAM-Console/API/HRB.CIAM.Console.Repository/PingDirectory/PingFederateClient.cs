﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Model.PingFederate;
using HRB.CIAM.Core.Common.Constants;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.Provider;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Repository.PingDirectory
{
    public class PingFederateClient : IPingFederateClient
    {
        private readonly ILogger<PingFederateClient> _logger;
        private readonly IApiClient _apiClient;
        private readonly IPingFederateHelper _pingFedHelper;
        private readonly PingDirAuthFlowSettings _pingDirAuthFlowSettings = new();
        private readonly ApiBaseUrls _apiBaseUrls = new();
        private readonly EndPoints _endPoints = new();
        private readonly IConfigurationRoot _configurationRoot;

        public PingFederateClient(ILogger<PingFederateClient> logger, IApiClient apiClient,
            IOptions<ApiBaseUrls> apiBaseUrls, IOptions<EndPoints> endPoints,
            IPingFederateHelper pingFedHelper, IOptions<PingDirAuthFlowSettings> pingDirAuthFlowSettings,
            IHttpContextAccessor accessor,
            Func<HttpContext, IConfigurationRoot> configurationHelper)
        {
            _logger = logger;
            _apiClient = apiClient;
            _apiBaseUrls = apiBaseUrls.Value;          
            _pingFedHelper = pingFedHelper; 
            _configurationRoot = configurationHelper(accessor.HttpContext);

            _configurationRoot.GetSection("EndPoints").Bind(_endPoints);
            _configurationRoot.GetSection("PingDirAuthFlowSettings").Bind(_pingDirAuthFlowSettings);
            _configurationRoot.GetSection("ApiBaseUrls").Bind(_apiBaseUrls);
        }

        #region Ping Federate Get Access Token with Client Credentials
        public async Task<IServiceResult<AccessTokenResponse>> GetAccessToken(TokenRequestDto tokenRequestDto)
        {
            IDictionary<string, IEnumerable<string>> requestHeaders = new Dictionary<string, IEnumerable<string>>();
            requestHeaders.Add(ApiConstants.HEADER_AUTHORIZATION, new string[] { _pingFedHelper.GetAuthenticationHeader().ToString() });

            var content = new Dictionary<string, string>();
            switch (tokenRequestDto.TokenType)
            {
                case ApiData.Refresh_token:
                    content["grant_type"] = _pingDirAuthFlowSettings.RefreshTokenGrantType;
                    content["refresh_token"] = tokenRequestDto.Data;
                    break;
                case ApiData.Authorization_code:
                    content["grant_type"] = _pingDirAuthFlowSettings.AuthCodeGrantType;
                    content["code"] = tokenRequestDto.Data;
                    break;
            }

            content["redirect_uri"] = _pingDirAuthFlowSettings.RedirectUrl;
            string postData = string.Join("&", content.Select(x => $"{x.Key}={x.Value}"));
            _logger.LogDebug("GrantType {GrantType} URL: {PingFederateBaseURL}{PingFedToken}?{postData}", _pingDirAuthFlowSettings.AuthCodeGrantType, _apiBaseUrls?.PingFederateBaseURL, _endPoints.getPingFedToken, postData);
            _logger.LogDebug("GrantType {GrantType} URL: {PingFederateBaseURL}{PingFedToken}?{postData}", _pingDirAuthFlowSettings.RefreshTokenGrantType, _apiBaseUrls?.PingFederateBaseURL, _endPoints.getPingFedToken, postData);

            HttpRequestModel httpRequestModel = CreateHttpRequestModel($"{_apiBaseUrls?.PingFederateBaseURL}{_endPoints?.getPingFedToken}?{postData}", null, requestHeaders, null, ApiConstants.JSON_CONTENT_TYPE);
            _logger.LogDebug("HttpRequestModel: {@HttpRequestModel}", httpRequestModel);
            var response = await _apiClient.PostAsync<AccessTokenResponse>(httpRequestModel);
            _logger.LogDebug("Access Token returned: {token}", response?.Data?.access_token);
            _logger.LogDebug("Response returned: {@Response}", response);
            return response;
        }
       
        #endregion

        #region Private methods
        private HttpRequestModel CreateHttpRequestModel
          (
              string requestUrl,
              IDictionary<string, string> requestParams,
              IDictionary<string, IEnumerable<string>> requestHeaders,
              string body,
              string contentType
          )
        {
            return new HttpRequestModel()
            {
                RequestUrl = requestUrl,
                Body = body,
                ContentType = contentType,
                RequestHeaders = requestHeaders,
                RequestParams = requestParams,
            };
        }


        #endregion

    }
}
