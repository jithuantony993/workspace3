﻿using Dapper;
using HRB.CIAM.Console.Common.Contracts.DataAccess;
using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Repository.SQL;
using HRB.CIAM.Core.Common.Enum.SQL;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.DataAccess;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using UserDetailsRequestDto = HRB.CIAM.Console.Common.Dto.DataAccess.UserDetailsRequestDto;

namespace HRB.CIAM.Console.Repository
{
    public class UserDetailsRepository : RepositoryBase<UserDetailsRepository>, IUserDetailsRepository
    {

        public UserDetailsRepository(IServiceProvider serviceProvider) : base(serviceProvider)
        {

        }

        public async Task<UserDetailsResponseDto> GetUserDetails(UserDetailsRequestDto userDetailsRequestDto)
        {

            var methodLabel = "GetUserDetails";
            this.Logger.LogInformation($"{methodLabel} in repository start");
            var result = new UserDetailsResponseDto()
            {
                UserDetailsItems = new List<UserDetailsDto>()
            };
            var dynamicParameters = new DynamicParameters();
            dynamicParameters.Add("@EntryUUID", userDetailsRequestDto.EntryUUID);
            dynamicParameters.Add("@CIAMID", userDetailsRequestDto.CIAMId);

            var dataInput = new DataModel()
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = SPNames.GetUserDetails,
                Parameters = dynamicParameters
            };
            var spResult = await this.DataProvider.ExecuteSp<UserDetailsDto>(dataInput, DBConnectionName.Ciam).ConfigureAwait(false);
            result.UserDetailsItems = spResult.ToList();
            this.Logger.LogInformation($"{methodLabel} in repository ended");
            return result;

        }

        public async Task<IdProofDetailsResponse> GetIdProofDetails(int ciamId)
        {
            var methodLabel = SPNames.Get_IDProofedValue;
            try
            {
                this.Logger.LogDebug("{MethodLabel} in repository start", methodLabel);
                var dynamicParameters = new DynamicParameters();
                dynamicParameters.Add("@CIAMID", ciamId);
                var dataInput = new DataModel()
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandText = SPNames.Get_IDProofedValue,
                    Parameters = dynamicParameters
                };

                var spResult = await this.DataProvider.ExecuteSp<IdProofDetailsResponse>(dataInput).ConfigureAwait(false);
                this.Logger.LogDebug("{MethodLabel} in repository ended", methodLabel);
                return spResult?.FirstOrDefault();
            }
            catch (Exception ex)
            {
                this.Logger.LogError("Exception caught while executing GetAolProofStatus in repository, Message : {Message}", ex.Message);
                throw;
            }
        }

    }
}
