﻿namespace HRB.CIAM.Console.Repository.Constants
{
    public static class SpNames
    {
    }
}
