﻿using AutoFixture;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace HRB.CIAM.Test.HRB.CIAM.ApiTest.Controller.Data
{
    public class ConsoleAuthenticationtestData
    {
        private readonly IFixture _fixture;
        public ConsoleAuthenticationtestData()
        {
            _fixture = new Fixture();
        }

        public Console.Common.Dto.Request.AuthDto authDto
        {
            get
            {
                return _fixture.Create<Console.Common.Dto.Request.AuthDto>();
            }
        }

        public ShaRequest ShaRequest
        {
            get
            {
                return _fixture.Create<ShaRequest>();
            }
        }


        public string NewGuid
        {
            get
            {
                var guid = Guid.NewGuid();
                return guid.ToString();
            }
        }
    }
}
