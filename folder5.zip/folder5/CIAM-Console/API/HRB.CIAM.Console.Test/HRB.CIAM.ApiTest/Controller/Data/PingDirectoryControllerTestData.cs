﻿using AutoFixture;
using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.Provider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Test.HRB.CIAM.ApiTest.Controller.Data
{
    public class PingDirectoryControllerTestData
    {
        private readonly IFixture _fixture;
        public PingDirectoryControllerTestData()
        {
            _fixture = new Fixture();
        }

        public UserInfoResponseResult UserInfoResponseResult
        {
            get
            {
                return _fixture.Create<UserInfoResponseResult>();
            }
        }

        public TokenRequestDto RefreshTokenRequest
        {
            get
            {
                var result= _fixture.Create<TokenRequestDto>();
                result.TokenType = ApiData.Refresh_token;
                return result;
            }
        }

        public TokenRequestDto AuthCodeRequest
        {
            get
            {
                var result = _fixture.Create<TokenRequestDto>();
                result.TokenType = ApiData.Authorization_code;
                return result;
            }
        }

        public ExchangeCodeResponseResult ExchangeCodeResponseResult
        {
            get
            {
                var httpResponseMessage = new HttpResponseMessage(System.Net.HttpStatusCode.OK);
                var res = new ServiceResult<AccessTokenResponse>(httpResponseMessage);
                var response = _fixture.Create<AccessTokenResponse>();
                res.Data = response;
                var result = new ExchangeCodeResponseResult(res);
              //  result.AccessToken = "dfsdfs324ffdfs";
                return result;
            }
        }
    }
}
