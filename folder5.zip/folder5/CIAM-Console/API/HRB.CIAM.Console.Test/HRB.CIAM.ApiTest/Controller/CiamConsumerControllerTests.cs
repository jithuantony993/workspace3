﻿using HRB.CIAM.Console.Api.Controllers;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.ApiTest.Controller
{
    public class CiamConsumerControllerTests
    {
        private readonly Mock<IConsumerTokenService> _tokenServiceMock;
        private readonly CiamConsumerController _controller;

        public CiamConsumerControllerTests()
        {
            _tokenServiceMock = new Mock<IConsumerTokenService>();
            var logger = Mock.Of<ILogger<CiamConsumerController>>();
            var serviceProviderMock = new Mock<IServiceProvider>();
            serviceProviderMock.Setup(x => x.GetService(typeof(ILogger<CiamConsumerController>))).Returns(logger);
            _controller = new CiamConsumerController(_tokenServiceMock.Object, serviceProviderMock.Object);
        }

        [Fact]
        public async Task GetConsumerTokens_WhenCalled_ReturnsResponse()
        {
            // Arrange
            var requestDto = new ConsumerTokenRequestDto();

            var expectedResponse = new ConsumerTokenResponseResult();
            _tokenServiceMock.Setup(x => x.GetConsumerTokens(It.IsAny<ConsumerTokenRequestDto>()))
                             .ReturnsAsync(expectedResponse);

            // Act
            var response = await _controller.GetConsumerTokens(requestDto);

            // Assert
            Assert.Same(expectedResponse, response);
        }

        [Fact]
        public async Task GetConsumerTokenswithEmail_WhenCalled_ReturnsResponse()
        {
            // Arrange
            var requestDto = new ConsumerTokenRequestDto();

            var expectedResponse = new ConsumerTokenResponseResult();
            _tokenServiceMock.Setup(x => x.GetConsumerTokenswithEmail(It.IsAny<ConsumerTokenRequestDto>()))
                             .ReturnsAsync(expectedResponse);

            // Act
            var response = await _controller.GetConsumerTokenswithEmail(requestDto);

            // Assert
            Assert.Same(expectedResponse, response);
        }
    }
}
