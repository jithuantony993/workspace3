﻿using HRB.CIAM.Console.Api.Controllers;
using HRB.CIAM.Console.Common.Contracts;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Test.HRB.CIAM.ApiTest.Controller.Data;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.ApiTest.Controller
{
    public class PingDirectoryControllerTest
    {
        #region Declaration
        private PingDirectoryController _pingDirectoryController;
        private readonly ILogger<PingDirectoryController> _logger;
        private readonly Mock<IServiceProvider> _serviceProvider;
        private readonly Mock<IConfiguration> _configuration;
        private readonly Mock<IPingDirectoryService> _pingDirectoryService;
        private readonly PingDirectoryControllerTestData _pingDirectoryControllerTestData;
        #endregion

        #region Constructor
        public PingDirectoryControllerTest()
        {
            _logger = Mock.Of<ILogger<PingDirectoryController>>();
            _serviceProvider = new Mock<IServiceProvider>();
            _configuration = new Mock<IConfiguration>();
            _pingDirectoryService = new Mock<IPingDirectoryService>();
            _pingDirectoryControllerTestData = new PingDirectoryControllerTestData();
            _serviceProvider.Setup(x => x.GetService(typeof(ILogger<PingDirectoryController>))).Returns(_logger);
            _pingDirectoryController = new PingDirectoryController(_pingDirectoryService.Object, _serviceProvider.Object, _configuration.Object);

        }
        #endregion

        [Fact]
        public async Task GetUserDetailswithEmail()
        {
            string email = "evlin01@mailinator.com";
            _pingDirectoryService.Setup(x => x.GetUserDetails(It.IsAny<string>(),It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryControllerTestData.UserInfoResponseResult));

            // Act
            var result = await _pingDirectoryController.GetUserDetailswithEmail(email);

            // Assert
            Assert.Equal(result.statusMessage, result.statusMessage);
        }

        [Fact]
        public async Task GetUserDetailswithPhone()
        {
            string mobile = "79079979989";
            _pingDirectoryService.Setup(x => x.GetUserDetails(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryControllerTestData.UserInfoResponseResult));

            // Act
            var result = await _pingDirectoryController.GetUserDetailswithPhone(mobile);

            // Assert
            Assert.Equal(result.statusMessage, result.statusMessage);
        }

        [Fact]
        public async Task GetUserDetailswithUcid()
        {
            string ucid = "552786782";
            _pingDirectoryService.Setup(x => x.GetUserDetails(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryControllerTestData.UserInfoResponseResult));

            // Act
            var result = await _pingDirectoryController.GetUserDetailswithUcid(ucid);

            // Assert
            Assert.Equal(result.statusMessage, result.statusMessage);
        }

        [Fact]
        public async Task GetAccessTokenwithRefreshToken()
        {
            _pingDirectoryService.Setup(x => x.GetAccessToken(It.IsAny<TokenRequestDto>())).Returns(Task.FromResult(_pingDirectoryControllerTestData.ExchangeCodeResponseResult));

            // Act
            var result = await _pingDirectoryController.GetAccessTokenwithRefreshToken(_pingDirectoryControllerTestData.RefreshTokenRequest);

            // Assert
            Assert.Equal(result.StatusCode, result.StatusCode);
        }

        [Fact]
        public async Task GetRefreshTokenwithAuthCode()
        {
            _pingDirectoryService.Setup(x => x.GetAccessToken(It.IsAny<TokenRequestDto>())).Returns(Task.FromResult(_pingDirectoryControllerTestData.ExchangeCodeResponseResult));

            // Act
            var result = await _pingDirectoryController.GetRefreshTokenwithAuthCode(_pingDirectoryControllerTestData.AuthCodeRequest);

            // Assert
            Assert.Equal(result.StatusCode, result.StatusCode);
        }

    }
}
