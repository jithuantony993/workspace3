﻿using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Api.Controllers;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Exceptions;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Core.Common.Contracts.Helpers;
using HRB.CIAM.Test.HRB.CIAM.ApiTest.Controller.Data;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Test.HRB.CIAM.ApiTest.Controller
{
    public class ConsoleAuthenticationTest
    {
        #region Declarations        
        private ConsoleAuthentication _controller;
        private readonly ILogger<ConsoleAuthentication> _logger;
        private Mock<IApiHelper> _apiHelper;
        private Mock<IUserService> _userService;

        private readonly ConsoleAuthenticationtestData _ConsoleAuthenticationtestData;
        #endregion

        public ConsoleAuthenticationTest()
        {
            _apiHelper = new Mock<IApiHelper>();
            _userService = new Mock<IUserService>();
            _apiHelper.Setup(_ => _.TrackEvent(It.IsAny<string>()));
            _logger = Mock.Of<ILogger<ConsoleAuthentication>>();
            _ConsoleAuthenticationtestData = new ConsoleAuthenticationtestData();

        }


        #region Insert User LoginHistory
        [Fact]
        public void AuthenticateUser()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }


        [Fact]
        public void AuthenticateUserCIAMKansas()
        {
            // Given
            
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = "CIAMKansas";
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }


        [Fact]
        public void AuthenticateUserQAUser()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = "CIAMQA";
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }

        [Fact]
        public void AuthenticateUserCIAMPrabhash()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = "CIAMPrabhash";
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }

        [Fact]
        public void AuthenticateUsermanasa()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = "manasa";
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }

        [Fact]
        public void AuthenticateSupportUser()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = "SupportUser";
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.AuthenticateUser(authDto).Result;
            // Assert
            Assert.Equal(result.AuthStatus, result.AuthStatus);
        }


        #endregion

        #region Insert User LoginHistory throws exception
        [Fact]
        public void AuthenticateUser_ThrowsCIAMException()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act & Assert
            Assert.ThrowsAsync<CaimValidationException>(async () => await _controller.AuthenticateUser(authDto));
        }


        
        [Fact]
        public void AuthenticateUser_ThrowsException()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act & Assert
            Assert.ThrowsAsync<CaimValidationException>(async () => await _controller.AuthenticateUser(authDto));
        }

        [Fact]
        public void AuthenticateUser_ThrowsException1()
        {
            // Given
            AuthDto authDto = null;
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act & Assert
            Assert.ThrowsAsync<CaimValidationException>(async () => await _controller.AuthenticateUser(authDto));
        }

        #endregion


        [Fact]
        public async Task AuthenticateUserQAUser_Exception()
        {
            // Given
            AuthDto authDto = _ConsoleAuthenticationtestData.authDto;
            authDto.Credential = null;
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            await Assert.ThrowsAsync<ArithmeticException>(async () => await _controller.AuthenticateUser(authDto));
        }

        [Fact]
        public void NewGuid()
        {
            string guid = _ConsoleAuthenticationtestData.NewGuid;
            _userService.Setup(_ => _.GenerateNewGuid()).Returns(guid);

            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.NewGuid();
            // Assert
            Assert.Equal(result, guid);
        }

        [Fact]
        public async Task FetchCodeFromEmail()
        {            
            string code = "testresult";
            _userService.Setup(_ => _.FetchMailinatorCode(It.IsAny<string>())).Returns(Task.FromResult(code));
            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = await _controller.FetchCodeFromEmail(code);
            // Assert
            Assert.Equal(result, code);
        }

        [Fact]
        public void GenerateSha256()
        {
            ShaRequest request = _ConsoleAuthenticationtestData.ShaRequest;
            string hashValue="12345";
            _userService.Setup(_ => _.GenerateHashValue(It.IsAny<ShaRequest>())).Returns(hashValue);

            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.GenerateSha256(request);
            // Assert
            Assert.Equal(result, hashValue);
        }
        [Fact]
        public void GetIdentifierHash()
        {           
            string hashValue = "12345";
            _userService.Setup(_ => _.GetIdentifierHash(It.IsAny<string>())).Returns(hashValue);

            _controller = new ConsoleAuthentication(_apiHelper.Object, _logger, _userService.Object);
            // Act
            var result = _controller.GetIdentifierHash(hashValue);
            // Assert
            Assert.Equal(result, hashValue);
        }
    }
}
