﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Testing;
using Moq;
using System.Net;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test
{
    public class ProgramTest
    {
        #region Test Program
        [Fact]
        public async Task TestInitialize()
        {
            using var application = new WebApplicationFactory<Program>();
            var client = application.CreateClient();
            var healthChecksResult = await client.GetAsync("api/health");
            Assert.NotNull(healthChecksResult);
            Assert.Equal(HttpStatusCode.OK, healthChecksResult.StatusCode);
        }
        #endregion
    }
}
