﻿using CIAM.Security.Library.Contracts.Helpers;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Contracts.Repository;
using HRB.CIAM.Console.Common.Contracts.Service;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Services;
using HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.Services
{
    public class PingDirectoryServiceTest
    {
        private MockRepository mockRepository;
        private readonly PingDirectoryServiceTestData _pingDirectoryServiceTestData;
        

        private Mock<IUserDetailsService> mockUserDetailsService;
        private Mock<ILogger<PingDirectoryService>> mockLogger;
        private Mock<IPingFederateClient> mockPingFederateClient;
        private Mock<IPingDirectoryClient> mockPingDirectoryClient;
        private IOptions<ApplicationSettings> mockOptions;
        private Mock<IHashingService> mockHashingService;

        public PingDirectoryServiceTest()
        {
            this.mockRepository = new MockRepository(MockBehavior.Default);
            _pingDirectoryServiceTestData = new();

            this.mockUserDetailsService = this.mockRepository.Create<IUserDetailsService>();
            this.mockLogger = this.mockRepository.Create<ILogger<PingDirectoryService>>();
            this.mockPingFederateClient = this.mockRepository.Create<IPingFederateClient>();
            this.mockPingDirectoryClient = this.mockRepository.Create<IPingDirectoryClient>();
            this.mockOptions = _pingDirectoryServiceTestData.ApplicationSettings;
            this.mockHashingService = this.mockRepository.Create<IHashingService>();

            this.mockPingDirectoryClient.Setup(x => x.GetEntryUuid(It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryServiceTestData.Uuid));
            this.mockUserDetailsService.Setup(x => x.GetUserInfo(It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryServiceTestData.UserInfoResponseResult));
            this.mockPingFederateClient.Setup(x => x.GetAccessToken(It.IsAny<TokenRequestDto>())).Returns(Task.FromResult(_pingDirectoryServiceTestData.AccessTokenResult));

            this.mockPingDirectoryClient.Setup(x => x.ReadDirectoryUser(It.IsAny<string>())).Returns(Task.FromResult(_pingDirectoryServiceTestData.DirectoryUserResult));
            this.mockHashingService.Setup(x => x.ComputeHash(It.IsAny<string>())).Returns(_pingDirectoryServiceTestData.Uuid);
        }

        private PingDirectoryService CreateService()
        {
            return new PingDirectoryService(
                this.mockUserDetailsService.Object,
                this.mockLogger.Object,
                this.mockPingFederateClient.Object,
                this.mockPingDirectoryClient.Object,
                this.mockOptions,
                this.mockHashingService.Object);
        }

        [Fact]
        public async Task GetUserDetails_ValidInput_ReturnsNotNullValue()
        {
            // Arrange
            var service = this.CreateService();
            string query = "query";
            string type = "type";

            // Act
            var result = await service.GetUserDetails(
                query,
                type);

            // Assert
            Assert.NotNull(result);
          
        }

        [Fact]
        public async Task GetAccessToken_ValidInput_ReturnsNotNullValue()
        {
            // Arrange
            var service = this.CreateService();
            TokenRequestDto tokenRequestDto = new TokenRequestDto();

            // Act
            var result = await service.GetAccessToken(
                tokenRequestDto);

            // Assert
            Assert.NotNull(result);
        }
    }
}
