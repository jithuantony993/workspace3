﻿using AutoFixture;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Model;
using Microsoft.Extensions.Options;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data
{
    

    public class UserDetailsServiceTestData
    {
        private readonly IFixture _fixture;

        public UserDetailsServiceTestData()
        {
            _fixture = new Fixture();
        }
       

        public string Uuid
        {
            get
            {
                return _fixture.Create<string>();
            }
        }

        public UserDetailsResponseDto UserDetailsResponseDto
        {
            get
            {
                return _fixture.Create<UserDetailsResponseDto>();
            }
        }

        public IdProofDetailsResponse IdProofDetailsResponse
        {
            get
            {
                return _fixture.Create<IdProofDetailsResponse>();
            }
        }


    }
}
