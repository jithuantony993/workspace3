﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AutoFixture;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.Provider;
using Microsoft.Extensions.Options;
using Embedded = HRB.CIAM.Console.Common.Model.PingDirectory.Embedded;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data
{


    public class PingDirectoryServiceTestData
    {
        private readonly IFixture _fixture;

        public PingDirectoryServiceTestData()
        {
            _fixture = new Fixture();
        }


        public string Uuid
        {
            get
            {
                return _fixture.Create<string>();
            }
        }

        public IOptions<ApplicationSettings> ApplicationSettings
        {
            get
            {
                var settings = Options.Create(_fixture.Create<ApplicationSettings>());
                return settings;
            }
        }

        public UserInfoResponseResult UserInfoResponseResult
        {
            get
            {
                return _fixture.Create<UserInfoResponseResult>();
            }
        }

        public IServiceResult<AccessTokenResponse> AccessTokenResult
        {
            get
            {
                IServiceResult<AccessTokenResponse> serviceResult = new ServiceResult<AccessTokenResponse>(new System.Net.Http.HttpResponseMessage { StatusCode = System.Net.HttpStatusCode.Accepted });
                serviceResult.Data = _fixture.Create<AccessTokenResponse>();

                return serviceResult;
            }
        }

        public IServiceResult<DirectoryUser> DirectoryUserResult
        {
            get
            {
                var data = new ServiceResult<DirectoryUser>(new HttpResponseMessage())
                {

                    Data = new DirectoryUser
                    {
                        entryUUID = Guid.NewGuid().ToString(),
                        _embedded = new Embedded
                        {
                            entries = new List<DirectoryUser>()
                        {
                          new DirectoryUser (){
                                    entryUUID= Guid.NewGuid().ToString()
                                }
                        }.ToArray()
                        }
                    }
                };
                data.Error = "";
                return data;
            }
        }


    }
}
