﻿using AutoFixture;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Model;
using mailinator_csharp_client.Models.Responses;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data
{
    public class UserServiceTestData
    {
        private readonly IFixture _fixture;

        public UserServiceTestData()
        {
            _fixture = new Fixture();
        }
        public IOptions<MailinatorSettings> MailinatorSettings
        {
            get
            {
                var settings =  Options.Create(new MailinatorSettings { ApiKey = "4a8bfb00cc16454f88e1ebe67dad0642", DomainName = "hrblock.testinator.com" });               
                 return settings;
            }
        }

        public FetchInboxResponse FetchInboxResponse
        {
            get
            {
                return _fixture.Create<FetchInboxResponse>();
            }
        }

        public FetchMessageResponse FetchMessageResponse
        {
            get
            {
                return _fixture.Create<FetchMessageResponse>();
            }
        }

        public ShaRequest ShaRequest
        {
            get
            {
                return _fixture.Create<ShaRequest>();
            }
        }

        
    }
}
