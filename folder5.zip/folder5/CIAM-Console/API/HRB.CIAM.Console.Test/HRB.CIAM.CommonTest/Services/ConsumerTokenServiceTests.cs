﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using HRB.CIAM.Console.Common.Services;
using HRB.CIAM.Console.Common.Contracts.Helpers;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using HRB.CIAM.Console.Common.Contracts.Repository;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts.Providers;
using HRB.CIAM.Core.Common.Contracts.Provider;
using IApiClient = HRB.CIAM.Console.Common.Contracts.Providers.IApiClient;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services
{

    public class ConsumerTokenServiceTests
    {
        private readonly ILogger<ConsumerTokenService> _loggerMock;
        private readonly Mock<IConsumerTokenHelper> _tokenHelperMock;
        private readonly Mock<IApiClient> _apiClientMock;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        private readonly Mock<Func<HttpContext, IConfigurationRoot>> _configurationHelperMock;
        private readonly Mock<IPingDirectoryClient> _pingDirectoryClientMock;
        private readonly ConsumerTokenService _consumerTokenService;

        public ConsumerTokenServiceTests()
        {
            _loggerMock = Mock.Of<ILogger<ConsumerTokenService>>();
            _tokenHelperMock = new Mock<IConsumerTokenHelper>();
            _apiClientMock = new Mock<IApiClient>();
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _configurationHelperMock = new Mock<Func<HttpContext, IConfigurationRoot>>();
            _pingDirectoryClientMock = new Mock<IPingDirectoryClient>();

            _consumerTokenService = new ConsumerTokenService(
                _loggerMock,
                _tokenHelperMock.Object,
                _apiClientMock.Object,
                _httpContextAccessorMock.Object,
                _configurationHelperMock.Object,
                _pingDirectoryClientMock.Object
            );
        }

        [Fact]
        public async Task GetConsumerTokens_WithValidRequest_ReturnsConsumerTokenResponseResult()
        {
            // Arrange
            var consumerTokenRequestDto = new ConsumerTokenRequestDto();

            // Mock API responses
            IServiceResult<FlowResponse> flowResponse = new ServiceResult<FlowResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new FlowResponse
                {
                    id = "1",
                    status = "tesSuccess"
                }
            };

            IServiceResult step2Response = new ServiceResult(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
            };

            IServiceResult<DropOffResponse> dropOffResponse = new ServiceResult<DropOffResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new DropOffResponse
                {
                    REF = "test ref"
                }
            };

            IServiceResult<AuthResponse> authResponse = new ServiceResult<AuthResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new AuthResponse
                {
                    AuthorizeResponse = new AuthorizeResponse(),
                    Id = "1",
                    Links = new Links(),
                    PluginTypeId = "1",
                    Status = "Success"
                }
            };

            IServiceResult<ConsumerTokenResponseResult> consumerTokenResponseResult = new ServiceResult<ConsumerTokenResponseResult>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new ConsumerTokenResponseResult
                {
                    AccessToken = "AccessToken"
                }
            };

            var accessTokenResponse = new ConsumerTokenResponseResult();

            _apiClientMock.Setup(mock => mock.GetAsync<FlowResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(flowResponse);
            _apiClientMock.Setup(mock => mock.PostAsync(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(step2Response);
            _apiClientMock.Setup(mock => mock.PostAsync<DropOffResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(dropOffResponse);
            _apiClientMock.Setup(mock => mock.PostAsync<AuthResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(authResponse);
            _apiClientMock.Setup(mock => mock.PostAsync<ConsumerTokenResponseResult>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(consumerTokenResponseResult);

            // Act
            var result = await _consumerTokenService.GetConsumerTokens(consumerTokenRequestDto);

            // Assert
            Assert.Equal(accessTokenResponse.StatusCode, result.StatusCode);
        }

        [Fact]
        public async Task GetConsumerTokenswithEmail_WithValidRequest_ReturnsConsumerTokenResponseResult()
        {
            

            // Mock API responses
            IServiceResult<FlowResponse> flowResponse = new ServiceResult<FlowResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new FlowResponse
                {
                    id = "1",
                    status = "tesSuccess"
                }
            };

            IServiceResult step2Response = new ServiceResult(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
            };

            IServiceResult<DropOffResponse> dropOffResponse = new ServiceResult<DropOffResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new DropOffResponse
                {
                    REF = "test ref"
                }
            };

            IServiceResult<AuthResponse> authResponse = new ServiceResult<AuthResponse>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new AuthResponse
                {
                    AuthorizeResponse = new AuthorizeResponse(),
                    Id = "1",
                    Links = new Links(),
                    PluginTypeId = "1",
                    Status = "Success"
                }
            };

            IServiceResult<ConsumerTokenResponseResult> consumerTokenResponseResult = new ServiceResult<ConsumerTokenResponseResult>(new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.OK))
            {
                Data = new ConsumerTokenResponseResult
                {
                    AccessToken = "AccessToken"
                }
            };

            var accessTokenResponse = new ConsumerTokenResponseResult();

            _apiClientMock.Setup(mock => mock.GetAsync<FlowResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(flowResponse);
            _apiClientMock.Setup(mock => mock.PostAsync(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(step2Response);
            _apiClientMock.Setup(mock => mock.PostAsync<DropOffResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(dropOffResponse);
            _apiClientMock.Setup(mock => mock.PostAsync<AuthResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(authResponse);
            _apiClientMock.Setup(mock => mock.PostAsync<ConsumerTokenResponseResult>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(consumerTokenResponseResult);
            // Arrange
            var consumerTokenRequestDto = new ConsumerTokenRequestDto
            {
                Email = "test@example.com"
            };

            var entryUuid = "12345";
            _pingDirectoryClientMock.Setup(mock => mock.GetEntryUuid(consumerTokenRequestDto.Email, It.IsAny<string>()))
                .ReturnsAsync(entryUuid);

            // Mock the behavior of the GetConsumerTokens method
            var expectedResponse = new ConsumerTokenResponseResult();


            // Act
            var result = await _consumerTokenService.GetConsumerTokenswithEmail(consumerTokenRequestDto);

            // Assert
            Assert.Equal(expectedResponse.StatusCode, result.StatusCode);
        }
    }

}
