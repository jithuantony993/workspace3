﻿using CIAM.Security.Library.Contracts.Helpers;
using CIAM.Security.Library.Model;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Services;
using HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data;
using Microsoft.Extensions.Options;
using Moq;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.Services
{
    public class UserServiceTest
    {
        private MockRepository mockRepository;

        private IOptions<MailinatorSettings> mailinatorOptions;
        private Mock<IHashingService> mockHashingService;
        private readonly UserServiceTestData _userServiceTestData;


        public UserServiceTest()
        {
            this.mockRepository = new MockRepository(MockBehavior.Default);
            _userServiceTestData = new UserServiceTestData();

            this.mailinatorOptions = _userServiceTestData.MailinatorSettings;
            this.mockHashingService = this.mockRepository.Create<IHashingService>();

            this.mockHashingService.Setup(x => x.GenerateHashValue(It.IsAny<IdHashInfo>())).Returns("HashedValue");

        }

        private UserService CreateService()
        {
            return new UserService(
                this.mailinatorOptions,
                this.mockHashingService.Object);
        }

        [Fact]
        public async Task FetchMailinatorCode_InvalidData_ThrowsException()
        {
            // Arrange
            var service = this.CreateService();
            string inbox = "Test@mailinator.com";         

            // Act
             var result = await service.FetchMailinatorCode(inbox);

            // Assert
            Assert.Equal("No OTP found", result);
        }

        [Fact]
        public void GenerateHashValue_ValidInput_ReturnsNotNullValue()
        {
            // Arrange
            var service = this.CreateService();
            ShaRequest request = _userServiceTestData.ShaRequest;

            // Act
            var result = service.GenerateHashValue(
                request);

            // Assert
            Assert.NotNull(result);
         
        }

        [Fact]
        public void GenerateNewGuid_ValidInput_ReturnsNotNullValue()
        {
            // Arrange
            var service = this.CreateService();

            // Act
            var result = service.GenerateNewGuid();

            // Assert
            Assert.NotNull(result);
        }
        [Fact]
        public void GetIdentifierHash()
        {
            // Arrange
            var service = this.CreateService();
            string identifier = "2232323";
            string hashValue = "12345";
            mockHashingService.Setup(_ => _.ComputeHash(It.IsAny<string>())).Returns(hashValue);
            // Act
            var result = service.GetIdentifierHash(identifier);

            // Assert
            Assert.NotNull(result);
        }
    }
}
