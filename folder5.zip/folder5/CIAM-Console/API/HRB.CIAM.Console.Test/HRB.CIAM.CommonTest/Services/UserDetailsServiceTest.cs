﻿using HRB.CIAM.Console.Common.Contracts.DataAccess;
using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Services;
using HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Services.Data;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.Services
{
    public class UserDetailsServiceTest
    {
        private MockRepository mockRepository;

        private Mock<IUserDetailsRepository> mockUserDetailsRepository;
        private Mock<ILogger<UserDetailsService>> mockLogger;
        private readonly UserDetailsServiceTestData _userDetailsServiceTestData;

        public UserDetailsServiceTest()
        {
            this.mockRepository = new MockRepository(MockBehavior.Default);
            _userDetailsServiceTestData = new UserDetailsServiceTestData();
            this.mockUserDetailsRepository = this.mockRepository.Create<IUserDetailsRepository>();
            this.mockLogger = this.mockRepository.Create<ILogger<UserDetailsService>>();

            mockUserDetailsRepository.Setup(x => x.GetUserDetails(It.IsAny<UserDetailsRequestDto>())).Returns(Task.FromResult(_userDetailsServiceTestData.UserDetailsResponseDto));
            mockUserDetailsRepository.Setup(x => x.GetIdProofDetails(It.IsAny<int>())).Returns(Task.FromResult(_userDetailsServiceTestData.IdProofDetailsResponse));
        }

        private UserDetailsService CreateService()
        {
            return new UserDetailsService(
                this.mockUserDetailsRepository.Object,
                this.mockLogger.Object);
        }

        [Fact]
        public async Task GetUserInfo_ValidInput_ReturnsNotNullValue()
        {
            // Arrange
            var service = this.CreateService();
            string entryUuid = _userDetailsServiceTestData.Uuid;

            // Act
            var result = await service.GetUserInfo(
                entryUuid);

            // Assert
            Assert.NotNull(result);
           
        }
    }
}
