﻿using AutoFixture;
using HRB.CIAM.Console.Common.Model;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers.Data
{
    public class PingDirectoryHelperTestData
    {
        private readonly IFixture _fixture;

        public PingDirectoryHelperTestData()
        {
            _fixture = new Fixture();
        }
        public static IOptions<PingDirEnvironment> CreatePingOneEnvironment
        {
            get

            {
                var environment = Options.Create(new PingDirEnvironment
                {
                    ParentDN = "ParentDN",
                    ObjectClass = "ObjectClass"

                });
                return environment;
            }
        }
        public string Uuid
        {
            get
            {
                return _fixture.Create<string>();
            }
        }
        public string Query
        {
            get
            {
                return _fixture.Create<string>();
            }
        }
        public string Type
        {
            get
            {
                return _fixture.Create<string>();
            }
        }
        public static IOptions<EndPoints> CreateEndPoint
        {
            get

            {
                var EndPoints = Options.Create(new EndPoints
                {
                    getRefId = "testId",
                    MFAUserCreate = "testSecret",
                    EnableMFA = "pingoneClientSecret",
                    UpdateFedDirectory = "grant_type",
                    ReadDirectoryUser = "ReadDirectoryUser",
                    getPingFedToken = "getPingFedToken",
                    mfadeviceverification = "mfadeviceverification",
                    getDeviceDetails = "getDeviceDetails",
                    getAccessToken = "getAccessToken",
                    DeleteDirectory = "DeleteDirectory",
                    updatePassword = "updatePassword",
                    MFADeleteDevice = "MFADeleteDevice",
                    IdentityAvailability = "IdentityAvailability"
                });
                return EndPoints;
            }
        }
    }
}
