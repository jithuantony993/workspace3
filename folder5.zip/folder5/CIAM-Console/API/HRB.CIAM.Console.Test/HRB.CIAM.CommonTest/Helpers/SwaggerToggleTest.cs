﻿using HRB.CIAM.Console.Common.Helpers;
using HRB.CIAM.LaunchDarkly.Library.Contracts.Helpers;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers
{
    public class SwaggerToggleTest
    {
        #region Declerations
        private readonly Mock<ILaunchDarklyHelper> _launchDarklyProvider;
        private readonly SwaggerToggle _swaggerToggle;
        #endregion

        #region Constructor        
        public SwaggerToggleTest()
        {
            _launchDarklyProvider = new Mock<ILaunchDarklyHelper>();
            _swaggerToggle = new SwaggerToggle(_launchDarklyProvider.Object);
        }
        #endregion


        #region Swagger enable disable test
        [Fact]
        public void SwaggerToggle_Test()
        {
            //Arrange
            var ProjectName = "Test_Name";
            _launchDarklyProvider.Setup(_ => _.GetStringFeatureFlag(It.IsAny<string>())).Returns(ProjectName);

            //Act & Assert
            var response = _swaggerToggle.DisableSwagger;
            Assert.False(response);
        }
        #endregion
    }
}
