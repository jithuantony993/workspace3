﻿using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Helpers;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers.Data;
using HRB.CIAM.Core.Common.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers
{
    public class PingDirectoryHelperTest
    {
        private readonly PingDirectoryHelperTestData _pingDirectoryHelperTestData;
        private  PingDirectoryHelper _pingDirectoryHelper;
        private readonly Mock<IOptions<EndPoints>> _endpoints;
        private readonly IOptions<PingDirEnvironment> _pingDirEnvironment;
        private readonly ILogger<PingDirectoryHelper> _logger;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessor;
        private readonly Mock<Func<HttpContext, IConfigurationRoot>> configurationHelper;
        private readonly Mock<IConfigurationRoot> MockConfig;

        public PingDirectoryHelperTest()
        {
            _pingDirectoryHelperTestData = new PingDirectoryHelperTestData();
             _endpoints = new Mock<IOptions<EndPoints>>();
            _logger =  Mock.Of<ILogger<PingDirectoryHelper>>();
            _pingDirEnvironment = Options.Create
                (
                    new PingDirEnvironment
                    {
                        ParentDN = "ParentDN"
                    }
                );
            MockConfig = new Mock<IConfigurationRoot>();
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            configurationHelper = new Mock<Func<HttpContext, IConfigurationRoot>>();
            MockConfig.Setup(x => x.GetSection(It.IsAny<string>()));
            configurationHelper.Setup(x => x(It.IsAny<HttpContext>())).Returns(MockConfig.Object);
            MockConfig.Setup(m => m.GetSection("PingDirectoryEnvironment")).Returns(new Mock<IConfigurationSection>().Object);

            _pingDirectoryHelper = new PingDirectoryHelper(_endpoints.Object, _pingDirEnvironment, _logger, _httpContextAccessor.Object,configurationHelper.Object);

        }
        [Fact]
        public void CreateHttpRequestModelTests()
        {
            var serviceResult = _pingDirectoryHelper.CreateHttpRequestModel(It.IsAny<string>(), It.IsAny<IDictionary<string, string>>(), It.IsAny<IDictionary<string, IEnumerable<string>>>(), It.IsAny<string>(), It.IsAny<string>());

            Assert.NotNull(serviceResult);
        }
        [Fact]
        public void GetDirectoryUrlTests()
        {
            IOptions<EndPoints> endPoints = PingDirectoryHelperTestData.CreateEndPoint;
            _pingDirectoryHelper = new PingDirectoryHelper(endPoints, _pingDirEnvironment, _logger, _httpContextAccessor.Object, configurationHelper.Object);
            string uuid = _pingDirectoryHelperTestData.Uuid;
            var serviceResult = _pingDirectoryHelper.GetDirectoryUrl(uuid);

            Assert.NotNull(serviceResult);
        }
        [Fact]
        public void GetUrlTest()
        {
            IOptions<EndPoints> endPoints = PingDirectoryHelperTestData.CreateEndPoint;
            _pingDirectoryHelper = new PingDirectoryHelper(endPoints, _pingDirEnvironment, _logger, _httpContextAccessor.Object, configurationHelper.Object);
            string query = _pingDirectoryHelperTestData.Query;
            string type = _pingDirectoryHelperTestData.Type;

            var serviceResult = _pingDirectoryHelper.GetUrl(query, type);

            Assert.NotNull(serviceResult);
        }
        [Fact]
        public void GetUrlTestFail()
        {
            IOptions<EndPoints> endPoints = PingDirectoryHelperTestData.CreateEndPoint;
            endPoints.Value.IdentityAvailability = String.Empty;
            _pingDirectoryHelper = new PingDirectoryHelper(endPoints, _pingDirEnvironment, _logger, _httpContextAccessor.Object, configurationHelper.Object);
            string query = String.Empty;
            string type = String.Empty;
            Assert.Throws<CiamException>(() => _pingDirectoryHelper.GetUrl(query, type));
        }
        
    }
}
