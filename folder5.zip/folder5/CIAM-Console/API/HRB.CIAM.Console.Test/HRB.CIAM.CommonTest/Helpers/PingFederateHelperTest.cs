﻿using HRB.CIAM.Console.Common.Helpers;
using HRB.CIAM.Console.Common.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers
{
    public class PingFederateHelperTest
    {
        private readonly PingFederateHelper _pingFederateHelper;
        private readonly ILogger<PingFederateHelper> _logger;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessor;
        private readonly Mock<Func<HttpContext, IConfigurationRoot>> configurationHelper;
        private readonly Mock<IConfigurationRoot> MockConfig;
        public PingFederateHelperTest()
        {           
            _logger = Mock.Of<ILogger<PingFederateHelper>>();
            MockConfig = new Mock<IConfigurationRoot>();
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            configurationHelper = new Mock<Func<HttpContext, IConfigurationRoot>>();
            MockConfig.Setup(x => x.GetSection(It.IsAny<string>()));
            configurationHelper.Setup(x => x(It.IsAny<HttpContext>())).Returns(MockConfig.Object);
            MockConfig.Setup(m => m.GetSection("PingDirAuthFlowSettings")).Returns(new Mock<IConfigurationSection>().Object);
            _pingFederateHelper = new PingFederateHelper(_logger, _httpContextAccessor.Object, configurationHelper.Object);
        }

        [Fact]
        public void TestGetAuthenticationHeader()
        {
            var response = _pingFederateHelper.GetAuthenticationHeader();
            Assert.NotNull(response);
        }
    }
}
