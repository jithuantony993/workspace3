﻿using System;
using Xunit;
using Moq;
using Microsoft.Extensions.Logging;
using System.Net.Http.Headers;
using HRB.CIAM.Console.Common.Helpers;
using System.Net.Http;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers
{
    public class ConsumerTokenHelperTests
    {
        private readonly Mock<ILogger<ConsumerTokenHelper>> _loggerMock;
        private readonly ConsumerTokenHelper _consumerTokenHelper;

        public ConsumerTokenHelperTests()
        {
            _loggerMock = new Mock<ILogger<ConsumerTokenHelper>>();
            _consumerTokenHelper = new ConsumerTokenHelper(_loggerMock.Object);
        }

        [Fact]
        public void MapCookies_WithValidHeaders_ReturnsMappedCookies()
        {
            // Arrange
            var response = new HttpResponseMessage();
            response.Headers.Add("Set-Cookie", "cookie1=value1; cookie2=value2;");
            var headers = response.Headers;

            // Act
            var result = _consumerTokenHelper.MapCookies(headers);

            // Assert
            Assert.Equal("value1", result["cookie1"]);
        }

        [Fact]
        public void MapCookies_WithNoHeaders_ReturnsEmptyDictionary()
        {
            // Arrange
            var response = new HttpResponseMessage();
            var headers = response.Headers;

            // Act
            var result = _consumerTokenHelper.MapCookies(headers);

            // Assert
            Assert.Empty(result);
        }
    }

}
