﻿using HRB.CIAM.Console.Common.Helpers;
using Microsoft.AspNetCore.Http;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.CommonTest.Helpers
{
    public class ConfigurationHelperTest
    {
        private readonly Mock<IHttpContextAccessor> _httpContextAccessor;
        private readonly ConfigurationHelper ConfigurationHelper;

        public ConfigurationHelperTest()
        {
            _httpContextAccessor = new Mock<IHttpContextAccessor>();
            ConfigurationHelper = new ConfigurationHelper(_httpContextAccessor.Object);
        }

        [Fact]
        public void GetConfigurationTest()
        {
            var httpContext = new DefaultHttpContext();
            _httpContextAccessor.Setup(x => x.HttpContext).Returns(httpContext);
            var result = ConfigurationHelper.GetConfiguration();
            Assert.NotNull(result);
        }
    }
}
