﻿using AutoFixture;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Core.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.Ping
{
    public class PingDirectoryClientTestData
    {
        public static IFixture _fixture { get; set; }
        static PingDirectoryClientTestData()
        {
            _fixture = new Fixture();
        }
        public static ServiceResult<DirectoryUser> DirectoryUser
        {
            get
            {
                var data = new ServiceResult<DirectoryUser>(new HttpResponseMessage())
                {

                    Data = new DirectoryUser
                    {
                        entryUUID = Guid.NewGuid().ToString(),
                        _embedded = new Embedded
                        {
                            entries = new List<DirectoryUser>()
                        {
                          new DirectoryUser (){
                                    entryUUID= Guid.NewGuid().ToString()
                                }
                        }.ToArray()
                        }
                    }
                };
                data.Error = "";
                return data;
            }
        }
    }
}
