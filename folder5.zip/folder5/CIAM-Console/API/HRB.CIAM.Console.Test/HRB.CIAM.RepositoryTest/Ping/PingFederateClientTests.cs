﻿using HRB.CIAM.Console.Common.Constants;
using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Repository.PingDirectory;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.Provider;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.Ping
{
    public class PingFederateClientTests
    {
        [Theory]
        [InlineData(ApiData.Authorization_code)]
        [InlineData(ApiData.Refresh_token)]
        public async Task GetAccessToken(string tokenType)
        {
            // Arrange
            var tokenRequestDto = new TokenRequestDto { TokenType = tokenType, Data = "code" };

            var loggerMock = new Mock<ILogger<PingFederateClient>>();
            var apiClientMock = new Mock<IApiClient>();
            var apiBaseUrlsOptionsMock = new Mock<IOptions<ApiBaseUrls>>();
            var endPointsOptionsMock = new Mock<IOptions<EndPoints>>();
            var pingFedHelperMock = new Mock<IPingFederateHelper>();
            var pingDirAuthFlowSettingsOptionsMock = new Mock<IOptions<PingDirAuthFlowSettings>>();
            var httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            var configurationHelperMock = new Mock<Func<HttpContext, IConfigurationRoot>>();
            var configuration = new ConfigurationBuilder()
               .AddJsonFile("appsettings.json")
               .Build();

            IConfigurationRoot configurationRoot = configuration;
            configurationHelperMock.Setup(x => x.Invoke(It.IsAny<HttpContext>())).Returns(configurationRoot);
            pingFedHelperMock.Setup(_ => _.GetAuthenticationHeader()).Returns(new AuthenticationHeaderValue("test"));
            var pingFederateClient = new PingFederateClient(loggerMock.Object, apiClientMock.Object, apiBaseUrlsOptionsMock.Object, endPointsOptionsMock.Object, pingFedHelperMock.Object, pingDirAuthFlowSettingsOptionsMock.Object, httpContextAccessorMock.Object, configurationHelperMock.Object);

            apiClientMock.Setup(x => x.PostAsync<AccessTokenResponse>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(new ServiceResult<AccessTokenResponse>(new System.Net.Http.HttpResponseMessage()) { Data = new AccessTokenResponse { access_token = "access_token" } });

            // Act
            var result = await pingFederateClient.GetAccessToken(tokenRequestDto);

            // Assert
            Assert.NotNull(result);
            Assert.NotNull(result.Data);
            Assert.Equal("access_token", result.Data.access_token);
        }

    }
}
