﻿using HRB.CIAM.Console.Common.Contracts.Helpers;
using HRB.CIAM.Console.Common.Model;
using HRB.CIAM.Console.Common.Model.PingDirectory;
using HRB.CIAM.Console.Repository.PingDirectory;
using HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.Ping;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using Embedded = HRB.CIAM.Console.Common.Model.PingDirectory.Embedded;

namespace HRB.CIAM.Console.Repository.Tests.PingDirectory
{
    public class PingDirectoryClientTests
    {
        private readonly Mock<ILogger<PingDirectoryClient>> _loggerMock;
        private readonly Mock<IApiClient> _apiClientMock;
        private readonly Mock<IPingDirectoryHelper> _pingDirectoryHelperMock;
        private readonly Mock<IPingDirectoryProvider> _pingDirectoryProviderMock;
        private readonly Mock<IOptions<ApiBaseUrls>> _apiBaseUrlsMock;
        private readonly Mock<IHttpContextAccessor> _httpContextAccessorMock;
        private readonly Mock<Func<HttpContext, IConfigurationRoot>> _configurationHelperMock;
        private readonly IConfigurationRoot _configurationRoot;
        private readonly PingDirectoryClient _pingDirectoryClient;
        private static ServiceResult<DirectoryUser> directoryUser;
        public PingDirectoryClientTests()
        {
            _loggerMock = new Mock<ILogger<PingDirectoryClient>>();
            _apiClientMock = new Mock<IApiClient>();
            _pingDirectoryHelperMock = new Mock<IPingDirectoryHelper>();
            _pingDirectoryProviderMock = new Mock<IPingDirectoryProvider>();
            _apiBaseUrlsMock = new Mock<IOptions<ApiBaseUrls>>();
            _httpContextAccessorMock = new Mock<IHttpContextAccessor>();
            _configurationHelperMock = new Mock<Func<HttpContext, IConfigurationRoot>>();

            var configuration = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            _configurationRoot = configuration;
            _configurationHelperMock.Setup(x => x.Invoke(It.IsAny<HttpContext>())).Returns(_configurationRoot);
            _apiBaseUrlsMock.Setup(x => x.Value).Returns(new ApiBaseUrls());
            directoryUser = PingDirectoryClientTestData.DirectoryUser;
            _apiClientMock.Setup(x => x.GetAsync<DirectoryUser>(It.IsAny<HttpRequestModel>()))
                .ReturnsAsync(directoryUser);
            _pingDirectoryClient = new PingDirectoryClient(
            _loggerMock.Object,
            _apiClientMock.Object,
            _pingDirectoryHelperMock.Object,
            _pingDirectoryProviderMock.Object,
            _apiBaseUrlsMock.Object,
            _httpContextAccessorMock.Object,
            _configurationHelperMock.Object);
        }

        [Fact]
        public async Task GetEntryUuid_Returns_EntryUuid()
        {
            // Arrange
            _pingDirectoryProviderMock.Setup(x => x.GetAccessToken(false)).ReturnsAsync("token");

            // Act
            var entryUuid = await _pingDirectoryClient.GetEntryUuid("query", "type");

            // Assert
            Assert.Equal(directoryUser?.Data?._embedded?.entries?[0]?.entryUUID, entryUuid);
        }

        [Fact]
        public async Task ReadDirectoryUser()
        {
            // Arrange
            string uuid = "test-uuid";
            string accessToken = "test-access-token";

            _pingDirectoryProviderMock.Setup(x => x.GetAccessToken(false)).ReturnsAsync(accessToken);
            _pingDirectoryHelperMock.Setup(x => x.GetDirectoryUrl(uuid)).Returns("test-endpoint-url");
            _apiBaseUrlsMock.Setup(x => x.Value).Returns(new ApiBaseUrls() { PingDirectoryBaseURL = "test-base-url" });
            _apiClientMock.Setup(x => x.GetAsync<DirectoryUser>(It.IsAny<HttpRequestModel>())).ReturnsAsync(directoryUser);

            // Act
            var result = await _pingDirectoryClient.ReadDirectoryUser(uuid);

            // Assert
            Assert.Equal(directoryUser?.Data?._embedded?.entries?[0]?.entryUUID, result?.Data?._embedded?.entries?[0]?.entryUUID);
        }
    }
}
