﻿using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using HRB.CIAM.Console.Repository;
using HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.UserDetails.Data;
using HRB.CIAM.Core.Common.Contracts.Provider;
using HRB.CIAM.Core.Common.Models;
using HRB.CIAM.Core.Common.Models.DataAccess;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Threading.Tasks;
using Xunit;

namespace HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.UserDetails
{
    public class UserDetailsRepositoryTest
    {
        private UserDetailsRepository _userDetailsRepository;
        private readonly Mock<IServiceProvider> _serviceProvider;
        private readonly UserDetailsRepositoryTestData _userDetailsRepositoryTestTestData;
        private readonly Mock<IDataProvider> _dataProvider;
        private readonly ILogger<UserDetailsRepository> _logger;
        public UserDetailsRepositoryTest()
        {
            _serviceProvider = new Mock<IServiceProvider>();
            _dataProvider = new Mock<IDataProvider>();
            _logger = Mock.Of<ILogger<UserDetailsRepository>>();
            _userDetailsRepositoryTestTestData = new UserDetailsRepositoryTestData();
            _userDetailsRepository = new UserDetailsRepository(_serviceProvider.Object);
        }

        [Fact]
        public async Task<UserDetailsResponseDto> GetUserDetails()
        {
            UserDetailsRequestDto userDetailsRequestDto = _userDetailsRepositoryTestTestData.UserDetailsRequestDto;
            userDetailsRequestDto.EntryUUID = "7e21ab22-6e7d-42ad-beae-3f5278b47e71";

            var data = _userDetailsRepositoryTestTestData.UserDetailsDTOList;
            _dataProvider.Setup(x => x.ExecuteSp<UserDetailsDto>(It.IsAny<DataModel>())).Returns(Task.FromResult(data));

            _serviceProvider.Setup(x => x.GetService(typeof(ILogger<UserDetailsRepository>))).Returns(_logger);
            _serviceProvider.Setup(x => x.GetService(typeof(IDataProvider))).Returns(_dataProvider.Object);

            _userDetailsRepository = new UserDetailsRepository(_serviceProvider.Object);

            var response = await _userDetailsRepository.GetUserDetails(userDetailsRequestDto);

            Assert.NotNull(response);
            return response;
        }
        [Fact]
        public async Task<IdProofDetailsResponse> GetIdProofDetails()
        {
            int ciamId = _userDetailsRepositoryTestTestData.CiamId;

             var data = _userDetailsRepositoryTestTestData.IdProofDetailsResponse;
            _dataProvider.Setup(x => x.ExecuteSp<IdProofDetailsResponse>(It.IsAny<DataModel>())).Returns(Task.FromResult(data));

            _serviceProvider.Setup(x => x.GetService(typeof(ILogger<UserDetailsRepository>))).Returns(_logger);
            _serviceProvider.Setup(x => x.GetService(typeof(IDataProvider))).Returns(_dataProvider.Object);


            var response = await _userDetailsRepository.GetIdProofDetails(ciamId);

            Assert.NotNull(response);
            return response;
        }
        [Fact]
        public async Task GetIdProofDetailsFail()
        {
            int ciamId = _userDetailsRepositoryTestTestData.CiamId;
           
            _dataProvider.Setup(x => x.ExecuteSp<IdProofDetailsResponse>(It.IsAny<DataModel>()));

            _serviceProvider.Setup(x => x.GetService(typeof(ILogger<UserDetailsRepository>)));
            _serviceProvider.Setup(x => x.GetService(typeof(IDataProvider)));
            var exception = await Record.ExceptionAsync(() => _userDetailsRepository.GetIdProofDetails(ciamId));
            Assert.NotNull(exception);

        }
    }
}
