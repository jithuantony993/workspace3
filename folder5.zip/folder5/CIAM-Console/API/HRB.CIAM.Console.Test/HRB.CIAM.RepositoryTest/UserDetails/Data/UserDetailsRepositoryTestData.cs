﻿using AutoFixture;
using HRB.CIAM.Console.Common.Dto.DataAccess;
using HRB.CIAM.Console.Common.Dto.Request;
using HRB.CIAM.Console.Common.Dto.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRB.CIAM.Console.Test.HRB.CIAM.RepositoryTest.UserDetails.Data
{
    public class UserDetailsRepositoryTestData
    {
        private readonly IFixture _fixture;
        public UserDetailsRepositoryTestData()
        {
            _fixture = new Fixture();
        }
        public UserDetailsResponseDto UserDetailsResponseDto
        {
            get
            {
                return _fixture.Create<UserDetailsResponseDto>();
            }
        }
        public UserDetailsRequestDto UserDetailsRequestDto
        {
            get
            {
                return _fixture.Create<UserDetailsRequestDto>();
            }
        }
        public IEnumerable<IdProofDetailsResponse> IdProofDetailsResponse
        {
            get
            {
                return _fixture.CreateMany<IdProofDetailsResponse>(5);
            }
        }
        public IEnumerable<UserDetailsDto> UserDetailsDTOList
        {
            get
            {
                return _fixture.CreateMany<UserDetailsDto>(5);
            }
        }
        public int CiamId
        {
            get
            {
                return _fixture.Create<int>();
            }
        }
    }
}
