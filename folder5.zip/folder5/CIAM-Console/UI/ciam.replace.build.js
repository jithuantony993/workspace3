
/**
 * Package version collected from package.json
 * Set the build version
 * Configured now only in environment.ts/ciam.versioning.build
 * Prebuild is run always
 */
var replaceFile = require('replace-in-file');
var packageJSON = require("./package.json");
var buildVersion = packageJSON.version;
const options = {
	// files: 'src/environments/environment.prod.ts',
	files: 'src/environments/environment.ts',
	from: /version: '(.*)'/g,
	to: "version: '" + buildVersion + "'",
	allowEmptyPaths: false,
};
try {
	let changeFiles = replaceFile.sync(options);
	if (changeFiles == 0) {
		throw "Please make sure file have version";
	}
	console.log('Build version set: ' + buildVersion);
} catch (error) {
	console.error('Error occurred:', error);
	throw error
}
