export const environment = {
  production: true,
  name: 'release',
  configPath: '#{UiBaseUrl}#/assets/config/config',
  endpoint:'http://localhost:5000',
  baseUrl:"#{UiBaseUrl}#",
  ADOBE_TRACKER_URL: 'http://assets.adobedtm.com/f6306126288b/f42544c62b33/launch-e36c4856bda4-staging.min.js',
};
