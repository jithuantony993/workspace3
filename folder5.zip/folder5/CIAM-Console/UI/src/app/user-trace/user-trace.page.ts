import { Component, OnInit } from '@angular/core';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import * as $ from 'jquery';
import 'daterangepicker';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataParserPipe } from '../common/pipe/data-parser.pipe';
import { JsonparserPipe } from '../common/pipe/jsonparser.pipe';

@Component({
  selector: 'app-user-trace',
  templateUrl: './user-trace.page.html',
  styleUrls: ['./user-trace.page.scss'],
})
export class UserTracePage implements OnInit {

   showSection:boolean=false;
  //Date picker
  startDate: any;
  endDate: any;
   from_Date:string;
   to_Date:string;
   sessionID: string;
   data:any;
   dataByGuid:any;
   timestamp :any=[];
   name :any=[];
   timestampByGuid :any=[];
   nameByGuid :any=[];
   guidParam: string='';
   appInsightsApiEndPoints:any;
   isFromLogin:boolean=false;
   guidFromEmail:string='';
   guidListFromEmail:any=[];
   displayStyle = "none";
   modalDispay='none';
   userInfoData:any=[];

  constructor(private http: HttpService, private sharedService: SharedService,private formBuilder: FormBuilder, private route: ActivatedRoute,
   private jsonparserPipe : JsonparserPipe  ) { }
  public traceForm: FormGroup = this.formBuilder.group({
    email: ['', ([Validators.required])]
  }
  );

  ngOnInit() {
    this.openPopup();

    if(this.sharedService.loginUser.authStatus=='PublicUser'){
      this.guidParam=this.sharedService?.guidParam;
      this.sharedService.loginUser.authStatus = "MasterUser";
    }else{
      this.isFromLogin=true;
    }
    this.appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
    this.setSectionVisible();
    if(!this.isFromLogin){
      this.initiate();
    }
  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";  
  }

  setSectionVisible(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      this.showSection = false;
    } else {
      this.showSection = true;
    }
  }


   initiate(){
    let guid=this.guidParam!=undefined?this.guidParam:'9b1fc97c-7dd8-4edd-9f0f-6aec25007581';
    console.log('guid!!', guid)
     this.getSessionIdfromGUID(guid);
     this.getTraceByGUID(guid);
  
  }

  getSessionIdfromGUID(guid: string){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where customDimensions.TrackId=='"+ guid+"' |project session_Id | distinct session_Id ").subscribe((result: any) => {
      this.sessionID =  result?.body?.tables[0]?.rows[0][0]; 
      this.getTraceBySessionID(); 
      console.log("session ID : ", this.sessionID)
    })
   
  }

  getTraceBySessionID(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where session_Id=='"+ encodeURIComponent(this.sessionID)+"' and customDimensions.Data !contains 'cleartoken' | project timestamp, name, customDimensions,operation_Id, session_Id, user_Id, client_Type, client_Model, client_OS, client_City,client_StateOrProvince, client_CountryOrRegion, client_Browser, operation_Name, cloud_RoleName | order by timestamp desc").subscribe((result: any) => {
      this.data =  result?.body;  
      const rows = this.data?.tables[0]?.rows;

      if (rows) {
        for (const row of rows) {
          this.timestamp.push(row[0]);
          this.name.push(row[1]);
         // console.log(`Timestamp: ${this.timestamp}, Name: ${this.name}`);
        }
      }
    })

   
  }

  

  
  getTraceByGUID(guid){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where customDimensions.TrackId=='"+ guid+"' and customDimensions.Data !contains 'cleartoken' | project timestamp, name, customDimensions,operation_Id, session_Id, user_Id, client_Type, client_Model, client_OS, client_City,client_StateOrProvince, client_CountryOrRegion, client_Browser, operation_Name, cloud_RoleName | order by timestamp desc").subscribe((result: any) => {
      this.dataByGuid =  result?.body;  
      const rows = this.dataByGuid?.tables[0]?.rows;
      //console.log(`testets`, rows);
      if (rows) {
      //  console.log(`testets`);
        for (const row of rows) {
          this.timestampByGuid.push(row[0]);
          this.nameByGuid.push(row[1]);
        //  console.log(`Timestamp: ${this.timestampByGuid}, Name: ${this.nameByGuid}`);
        }
      }
    })

  
  }

  getTrace(){
    if (this.traceForm?.valid) {
      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where tolower(customDimensions.Email) ==tolower('"+this.traceForm?.value?.email+"') or tolower(customDimensions.Identifier)==tolower('"+this.traceForm?.value?.email+"') | project tostring(customDimensions.TrackId) , timestamp | distinct customDimensions_TrackId, timestamp| summarize FirstTimestamp = min(timestamp) by customDimensions_TrackId | order by FirstTimestamp desc").subscribe((result: any) => {
       this.guidListFromEmail=result?.body?.tables[0]?.rows.filter(row => row[0] !== "");
         this.guidFromEmail=this.guidListFromEmail[0][0];
       this.getUserTraceByEmail(this.guidFromEmail);
      })
    }
  }

  getUserTraceByEmail(guid){
    this.getSessionIdfromGUID(guid);
    this.getTraceByGUID(guid);
    
  }
  getData(guid){
    console.log('guid from link', guid)
    this.getUserTraceByEmail(guid);
  }

  getUserInfo(row: any){
     this.userInfoData=row;
     this.modalDispay = "block";
  }

  closeModal(){
    this.modalDispay = "none";
  }

  getUserTrace(userInfo){
    window.open('https://a3d0dvcimstr01.z19.web.core.windows.net/ciam-console?guid='+this.jsonparserPipe.transform(userInfo, 'TrackId'),'_blank');
  }

}
