import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of } from 'rxjs';
import { JsonparserPipe } from '../common/pipe/jsonparser.pipe';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';

import { UserTracePage } from './user-trace.page';

describe('UserTracePage', () => {
  let component: UserTracePage;
  let fixture: ComponentFixture<UserTracePage>;  
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }


  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ UserTracePage, JsonparserPipe ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
        providers: [HTTP, FormBuilder,SharedService, JsonparserPipe,
          {  provide: ActivatedRoute, useValue: mockRouter }]
    }).compileComponents();

    fixture = TestBed.createComponent(UserTracePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger ngOnInit as PublichUser', () => {
    component['sharedService'].loginUser.authStatus = 'PublicUser';
    component.ngOnInit();
    expect(component['sharedService'].loginUser.authStatus).toEqual('MasterUser');
  });

  it('should trigger openPopup', () => {
    component.openPopup();
    expect(component.displayStyle).toEqual("block");
  });

  it('should trigger closePopup', () => {
    component.closePopup();
    expect(component.displayStyle).toEqual("none");
  });

  it('should trigger initiate', () => {
    let guid = "TEST";
    component.guidParam = guid;
    spyOn(console,"log");
    component.initiate();
    expect(console.log).toHaveBeenCalledWith('guid!!', guid)
  });

  it('should trigger initiate with undefined guid', () => {
    let guid = undefined;
    component.guidParam = guid;
    spyOn(console,"log");
    component.initiate();
    expect(console.log).toHaveBeenCalledWith('guid!!', '9b1fc97c-7dd8-4edd-9f0f-6aec25007581')
  });

  it('should trigger closeModal', () => {
    component.closeModal();
    expect(component.modalDispay).toEqual('none');
  });

  it('should trigger getSessionIdfromGUID', () => {
    const result = {
      body : {
        tables : [{
          "name": "PrimaryResult",
          "columns": [
              {
                  "name": "session_Id",
                  "type": "string"
              }
          ],
          rows: [
              [
                  "zsLN2THpHc41Uq6r+U02S7"
              ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSessionIdfromGUID('9316932b-e03e-49e1-888a-0bde193b1a3a');
    expect(component.sessionID).toEqual('zsLN2THpHc41Uq6r+U02S7');
  });

  it('should trigger getSessionIdfromGUID branch cover', () => {
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(null));
    component.getSessionIdfromGUID('9316932b-e03e-49e1-888a-0bde193b1a3a');
    expect(component.sessionID).not.toBeNull();
  });

  it('should trigger getTraceBySessionID', () => {
    const result = {
      body : {
        tables : [{
          "name": "PrimaryResult",
          "columns": [
              {
                  "name": "session_Id",
                  "type": "string"
              }
          ],
          rows: [
              [
                
              ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getTraceBySessionID();
    expect(component.data).toEqual(result.body);
  });

  it('should trigger getTraceByGUID', () => {
    const result = {
      body : {
        tables : [{
          "name": "PrimaryResult",
          "columns": [
              {
                
              }
          ],
          rows: [
            [
              
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getTraceByGUID('9316932b-e03e-49e1-888a-0bde193b1a3a');
    expect(component.dataByGuid).toEqual(result.body);
  });

  it('should trigger getTraceByGUID branch cover', () => {
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(null));
    component.getTraceByGUID('9316932b-e03e-49e1-888a-0bde193b1a3a');
    expect(component.dataByGuid).not.toBeNull();
  });

   
  it('should call getTraceByGUID on getTrace', () => {
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of({ body: { tables: [{ rows: [['session-id']] }] } }));

    component.traceForm.setValue({ email: 'test-email' });
    component.getTrace();

    expect(component.guidListFromEmail).toEqual([['session-id']]);
    expect(component.guidFromEmail).toBe('session-id');
  });

  it('should call getTrace with if condition failure', () => {
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of({ body: { tables: [{ rows: [['session-id']] }] } }));

    component.traceForm = null;
    component.getTrace();

    expect(component.guidFromEmail).toBe('');
  });
  
  it('should call getUserTraceByEmail on getData', () => {
    spyOn(component, 'getUserTraceByEmail');

    component.getData('test-guid');

    expect(component.getUserTraceByEmail).toHaveBeenCalledWith('test-guid');
  });

  
  it('should call getUserInfo', () => {
    spyOn(component['jsonparserPipe'],"transform").and.returnValue(of(''));

    component.getUserInfo('test-guid');

    expect(component.userInfoData).toEqual('test-guid')
  });

  it('should trigger setSectionVisible with AdminUser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser";
    component.setSectionVisible();
    expect(component.showSection).toEqual(false);
  });

  it('should open a new window with the correct URL', () => {
    // Mock the window.open method
    const mockWindowOpen = spyOn(window, 'open');

    // Define a userInfo object for testing
    const userInfo = {  };

    // Call the function
    component.getUserTrace(userInfo);

    // Verify that window.open was called with the expected URL
    expect(mockWindowOpen).toHaveBeenCalledWith('https://loginapp-dev.hrblock.com/ciam-console?guid=', '_blank');
  });

});


