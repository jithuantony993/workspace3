import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserTracePage } from './user-trace.page';

const routes: Routes = [
  {
    path: '',
    component: UserTracePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserTracePageRoutingModule {}
