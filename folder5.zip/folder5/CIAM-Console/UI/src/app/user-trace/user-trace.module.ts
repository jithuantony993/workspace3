import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UserTracePageRoutingModule } from './user-trace-routing.module';

import { UserTracePage } from './user-trace.page';
import { ImportsModule } from '../common/imports/imports.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { JsonparserPipe } from '../common/pipe/jsonparser.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    UserTracePageRoutingModule,
    NgxChartsModule
  ],
  declarations: [UserTracePage],
  providers:[JsonparserPipe],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class UserTracePageModule {}
