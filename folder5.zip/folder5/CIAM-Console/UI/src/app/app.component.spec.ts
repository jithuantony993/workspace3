import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SharedService , modalobj} from './shared-services/shared/shared.service';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { AppIncludesComponent } from './common/app-includes/app-includes.component';
import { FormatTimePipe } from './pipes/timer/format-time.pipe';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { Observable, of, Subscription } from 'rxjs';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let component2: AppIncludesComponent;
  let fixture2: ComponentFixture<AppIncludesComponent>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate'),
    initialNavigation(){
      
    },
    events:new Observable()
  }

  beforeEach(async() => {

    TestBed.configureTestingModule({
      declarations: [AppComponent,AppIncludesComponent,FormatTimePipe],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports:[RouterTestingModule,HttpClientTestingModule],
      providers: [HTTP,
        { provide: Router, useValue: mockRouter},
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture2 = TestBed.createComponent(AppIncludesComponent);
    component2 = fixture2.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });


  // it('should subscribe message', () => {
  //   const service = fixture.debugElement.injector.get(SharedService);
  //   (service as any).messageSource.next('test');
  //   expect(component.serviceData.emit).toBeTruthy()
  // });
  // TODO: add more tests!
 xit('should  subscribe modelRef', () => {
    const service = fixture.debugElement.injector.get(SharedService);
    (service as any).refModelSub.next({name:'errorDialog',content:{msg:'Make sure you are checking'}});
    expect(component.modelRefVar).toEqual('errorDialog');
    fixture.detectChanges();
  
    // spyOn(component2.errorDialog, 'nativeElement');
    // component.invokeModels({name:'errorDialog',content:{msg:'Make sure you are checking'}});
    // expect(component.modelRefVar).toEqual('errorDialog');
    // let spy = spyOn(component,'invokeModels');
    // expect(spy).toHaveBeenCalledWith({name:'errorDialog',content:{msg:'Make sure you are checking'}});
  });
  afterEach(() => {
    fixture.destroy();
  });

});
