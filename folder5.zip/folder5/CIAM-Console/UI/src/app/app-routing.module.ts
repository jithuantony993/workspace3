import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UtilitiesPageRoutingModule } from './utilities/utilities-routing.module';
import { UtilitiesPageModule } from './utilities/utilities.module';
import { PdfUserReportComponent } from './user-flows/pdf-user-report/pdf-user-report.component';
const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule),
    //canActivate: [MaGuardGuard]
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then( m => m.DashboardPageModule)
  },  {
    path: 'security-dashboard',
    loadChildren: () => import('./security-dashboard/security-dashboard.module').then( m => m.SecurityDashboardPageModule)
  },{
    path: 'services-dashboard',
    loadChildren: () => import('./services-dashboard/services-dashboard.module').then( m => m.ServicesDashboardPageModule)
  },
  {
    path: 'accesstoken',
    loadChildren: () => import('./accesstoken/accesstoken.module').then( m => m.AccesstokenPageModule)
  },
  {
    path: 'utilities',
    loadChildren: () => import('./utilities/utilities.module').then(m => UtilitiesPageModule)
  },
  {
    path: 'performance-dashboard',
    loadChildren: () => import('./performance-dashboard/performance-dashboard.module').then( m => m.PerformanceDashboardPageModule)
  },
  {
    path: 'get-details-email',
    loadChildren: () => import('./pingDir-details/get-details-email/get-details-email.module').then( m => m.GetDetailsEmailPageModule)
  },
  {
    path: 'get-details-phone',
    loadChildren: () => import('./pingDir-details/get-details-phone/get-details-phone.module').then( m => m.GetDetailsPhonePageModule)
  },
  {
    path: 'get-details-ucid',
    loadChildren: () => import('./pingDir-details/get-details-ucid/get-details-ucid.module').then( m => m.GetDetailsUcidPageModule)
  },{
    path: 'user-trace',
    loadChildren: () => import('./user-trace/user-trace.module').then( m => m.UserTracePageModule)
  },{
    path: 'mobile-number',
    loadChildren: () => import('./mobile-number/mobile-number.module').then( m => m.MobileNumberPageModule)
  },
  {
    path: 'ciam-glance',
    loadChildren: () => import('./ciam-glance/ciam-glance.module').then( m => m.CiamGlancePageModule)
  },
  {
    path: 'ciam-report-one',
    loadChildren: () => import('./ciam-report-one/ciam-report-one.module').then( m => m.CiamReportOnePageModule)
  },
  {
    path: 'ciam-report-two',
    loadChildren: () => import('./ciam-report-two/ciam-report-two.module').then( m => m.CiamReportTwoPageModule)
  },
  {
    path: 'ciam-report-three',
    loadChildren: () => import('./ciam-report-three/ciam-report-three.module').then( m => m.CiamReportThreePageModule)
  },
  {
    path: 'ciam-report-four',
    loadChildren: () => import('./ciam-report-four/ciam-report-four.module').then( m => m.CiamReportFourPageModule)
  },
  {
    path: 'ciam-report-five',
    loadChildren: () => import('./ciam-report-five/ciam-report-five.module').then( m => m.CiamReportFivePageModule)
  },
  {
    path: 'ciam-report-six',
    loadChildren: () => import('./ciam-report-six/ciam-report-six.module').then( m => m.CiamReportSixPageModule)
  },
  {
    path: 'ut',
    loadChildren: () => import('./user-trace/user-trace.module').then( m => m.UserTracePageModule)
  },
  {
    path: 'user-flows',
    loadChildren: () => import('./user-flows/user-flows.module').then( m => m.UserFlowsPageModule)
  },
  {
    path:'pdf-report',
    component:PdfUserReportComponent
  },
  {
    path: '**',
    loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule),
  }


];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {

    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
