import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserFlowsPage } from './user-flows.page';

const routes: Routes = [
  {
    path: '',
    component: UserFlowsPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserFlowsPageRoutingModule {}
