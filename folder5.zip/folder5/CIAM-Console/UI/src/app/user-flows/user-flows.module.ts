import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UserFlowsPageRoutingModule } from './user-flows-routing.module';

import { UserFlowsPage } from './user-flows.page';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { ImportsModule } from '../common/imports/imports.module';
import { JsonparserPipe } from '../common/pipe/jsonparser.pipe';
import { PdfUserReportComponent } from './pdf-user-report/pdf-user-report.component'
import { TimeFormatPipe } from '../common/pipe/time-format.pipe';
import { DataParserPipe } from '../common/pipe/data-parser.pipe';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    NgxChartsModule,
    UserFlowsPageRoutingModule
  ],
  declarations: [UserFlowsPage,PdfUserReportComponent],
  providers:[JsonparserPipe,TimeFormatPipe,DataParserPipe],
 
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class UserFlowsPageModule {}
