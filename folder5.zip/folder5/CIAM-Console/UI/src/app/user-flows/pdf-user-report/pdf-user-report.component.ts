import { Component, ElementRef, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { SharedService } from 'src/app/shared-services/shared/shared.service';
import jsPDF from 'jspdf';
import domtoimage from 'dom-to-image';
import html2canvas from 'html2canvas';
import { JsonparserPipe } from '../../../app/common/pipe/jsonparser.pipe';
import { TimeFormatPipe } from 'src/app/common/pipe/time-format.pipe';
import { DataParserPipe } from 'src/app/common/pipe/data-parser.pipe';

@Component({
  selector: 'app-pdf-user-report',
  templateUrl: './pdf-user-report.component.html',
  styleUrls: ['./pdf-user-report.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PdfUserReportComponent implements OnInit {
  @ViewChild('sampleDiv', { static: false }) sampleDiv: ElementRef;
  update_userDetails: any;
  successCheckList: any = [];
  failureCheckList: any = [];
  trackingData: any = {};
  userFlowDetails:any=[];
  clientData:string=null
  deviceInfo:string=null
  hasEmailLink:boolean=false;
  successCases:boolean=false;
  failureCases:boolean=false;

  constructor(
    private sharedService: SharedService, 
    private renderer: Renderer2, 
    public JsonparserPipe:JsonparserPipe,
    public formatTime:TimeFormatPipe,
    public dataParserPipe:DataParserPipe
  ) {
    this.sharedService.update_userDetails.subscribe((data) => {
      if (data) {
        this.update_userDetails = data;
        console.log(this.update_userDetails, 'dfdjfdfhdhdfjfhdjdfh')
      }
    })
  }

  ngAfterViewInit() {
    // Use Renderer2 to add the testcss class to the body element
    this.renderer.addClass(document.body, 'testcss');
  }


  ngOnInit() {
    this.getTrackingData();
  }


  getTrackingData() {
    this.successCheckList = [ 'UI-SIDP-SUCCESS-EVENT-BACK', 'TIS-PRIMARY-IDPROOF-SUCCESS', 'AOL-SUCCESS-PAGE-INIT', 'VAOL-SUCCESS-PAGE-INIT', 'SI-EVENT-BACK-TO-PARENT','BP-SUCCESS-INIT','UI-SIDP-SUCCESS-ONLOAD','CP-CARD-PIN-MATCHING-SUBMIT-SUCCESS','PAPERLESS-IDPROOF-SUCCESS-ONLOAD',
    'MA-PASSWORD-UPDATE-SUCCESS-ONLOAD','MA-EMAIL-CODE-SUCCESS',
    'UI-POSTAUTH-UPDATE-MOBILE-SUCCESS-ONLOAD','UI-POSTAUTH-ADD-MOBILE-SUCCESS-ONLOAD','UI-POSTAUTH-RESET-PASSWORD-SUCCESS-ONLOAD'];
    this.failureCheckList = [
      'BP-FAILURE-EVENT-BACK', 'UI-SIDP-FAILURE-EVENT-BACK', 'TIS-PRIMARY-IDPROOF-FAILURE', 
    'AOL-ERROR-SCREEN-INIT', 'AOL-ERROR-PAGE-INIT', 'AOL_GENERAL_ERROR_EXIT', 'VAOL-ERROR-PAGE-INIT', 
    'CP_OOB_FAILURE','CP-APP-GENERAL-ERROR-INIT', //CP
    'SIGN_IN_FAILURE-INIT',
    'UI-SIDP-KBA-CHALLENGE-ANSWER-FAILURE','UI-SIDP-KBA-CHALLENGE-ANSWER-ERROR','UI-SIDP-CLIENTMATCH-FAILURE','UI-SIDP-CLIENTMATCH-EXCEPTION','UI-SIDP-KBA-ANSWER-FAILURE', //SIDP
    'BP-FAILURE-INIT','BP-HARD-FAILURE-INIT',// Bank proof
    'ERROR-SCREEN-PAGE-INIT','ERROR-SCREEN-SCENARIO-PAGE-INIT','PAPERLESS-GENERAL-ERROR-INIT', //paperless,
    'MA-EMAIL-CODE-FAILURE', 'MA-EMAIL-CODE-EXCEPTION'
  ];
    this.trackingData = { BP: { success: 0, failure: 0 }, SIDP: { success: 0, failure: 0 }, AOL: { success: 0, failure: 0 }, VAOL: { success: 0, failure: 0 }, TIS: { success: 0, failure: 0 }, CP: { success: 0, failure: 0 }, SI: { success: 0, failure: 0, origin: null, client_id: null,sfaUsed:null },paperless:{success: 0, failure: 0},MA:{UP:{success:0,failure:0},UE:{success:0,failure:0}},POSTAUTH:{AM:{success:0},UM:{success:0},RP:{success:0}} }
    for(let j=0;j<this.update_userDetails?.dataTrakingFullList.length;j++){
      for (let i = 0; i < this.update_userDetails?.dataTrakingFullList[j].length; i++) {  
        //console.log(this.update_userDetails?.dataTrakingFullList[j][i][2], 'llllllttttttt' )
        this.userFlowDetails.push({
          'AppName':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'HostName'), 
          'SFAUsed':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'SFAUsed'),
          'origin':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'Origin'),
          'client_id':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'client_id'),
          'TagName':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'TagName'),
          'AuthStatus':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'AuthStatus'),
          'StatusMessage':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'StatusMessage'),
          'ErrorMessage':this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'ErrorMessage'),
          'time':this.formatTime.transform(this.update_userDetails?.dataTrakingFullList[j][i][0]),
          'event_name':this.dataParserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][1],'screened'),
          'end_point':this.update_userDetails?.dataTrakingFullList[j][i][13]
        }) 
        this.userFlowDetails[i].AuthStatus=(this.userFlowDetails[i].AuthStatus != undefined)?this.userFlowDetails[i].AuthStatus.replace(/_/g, " "):""
        if(!this.clientData){
          const client_data = this.update_userDetails?.dataTrakingFullList[j][i];
          this.clientData = (
            ((client_data && client_data[6]) ? client_data[6] + '|' : '') +
            ((client_data && client_data[7]) ? client_data[7] + '|' : '') +
            ((client_data && client_data[8]) ? client_data[8] + '|' : '') +
            ((client_data && client_data[9]) ? client_data[9] + '|' : '') +
            ((client_data && client_data[10]) ? client_data[10] + '|' : '') +
            ((client_data && client_data[11]) ? client_data[11] + '|' : '') +
            ((client_data && client_data[12]) ? client_data[12] : '')
          );
        }
        if(!this.deviceInfo){
          const data = this.update_userDetails?.dataTrakingFullList[j][i][2];
          const deviceType = this.JsonparserPipe.transform(data, 'DeviceType');
          const browserName = this.JsonparserPipe.transform(data, 'BrowserName');
          const browserVersion = this.JsonparserPipe.transform(data, 'BrowserVersion');
          const os = this.JsonparserPipe.transform(data, 'OS');
          const osVersion = this.JsonparserPipe.transform(data, 'OSVersion');
        
          // Check if any property is undefined or an empty string
          if (deviceType !== undefined && deviceType !== '' &&
              browserName !== undefined && browserName !== '' &&
              browserVersion !== undefined && browserVersion !== '' &&
              os !== undefined && os !== '' &&
              osVersion !== undefined && osVersion !== '') {
            this.deviceInfo = `${deviceType}|${browserName}|${browserVersion}|${os}|${osVersion}`;
          } else {
            this.deviceInfo = '';
          }
        }
        this.hasEmailLink = this.update_userDetails.emailLinks.some(element => element !== 0);
        if (this.successCheckList.includes(this.update_userDetails?.dataTrakingFullList[j][i][1])) {
          switch (this.update_userDetails?.dataTrakingFullList[j][i][1]) {
            case 'BP-SUCCESS-INIT': this.trackingData.BP.success = 1;
              this.successCases = true;
              break;
            case 'UI-SIDP-SUCCESS-ONLOAD': this.trackingData.SIDP.success = 1;
              this.successCases = true;
              break;
            case 'TIS-PRIMARY-IDPROOF-SUCCESS': this.trackingData.TIS.success = 1;
              this.successCases = true;
              break;
            case 'VAOL-SUCCESS-PAGE-INIT': this.trackingData.VAOL.success = 1;
              this.successCases = true;
              break;
            case 'AOL-SUCCESS-PAGE-INIT': this.trackingData.AOL.success = 1;
              this.successCases = true;
              break;
            case 'CP-CARD-PIN-MATCHING-SUBMIT-SUCCESS': this.trackingData.CP.success = 1;
              this.successCases = true;
              break;
            case 'PAPERLESS-IDPROOF-SUCCESS-ONLOAD': this.trackingData.paperless.success = 1;
              this.successCases = true;
              break;
            case 'SI-EVENT-BACK-TO-PARENT':
               this.trackingData.SI.success = 1;
               this.trackingData.SI.sfaUsed = this.JsonparserPipe.transform(this.update_userDetails?.dataTrakingFullList[j][i][2],'SFAUsed');
               this.successCases = true;
              break;
            case 'MA-PASSWORD-UPDATE-SUCCESS-ONLOAD':
              this.trackingData.MA.UP.success=1;
              this.successCases = true;
              break;
            case 'MA-EMAIL-CODE-SUCCESS':
              this.trackingData.MA.UE.success=1;
              this.successCases = true;
              break;
            case 'UI-POSTAUTH-UPDATE-MOBILE-SUCCESS-ONLOAD':
                this.trackingData.POSTAUTH.UM.success=1;
                break;
            case 'UI-POSTAUTH-ADD-MOBILE-SUCCESS-ONLOAD':
              this.trackingData.POSTAUTH.AM.success=1;
              this.successCases = true;
                  break;
            case 'UI-POSTAUTH-RESET-PASSWORD-SUCCESS-ONLOAD':
              this.trackingData.POSTAUTH.RP.success=1;
              this.successCases = true;
                    break;
          }
        }
        if (this.failureCheckList.includes(this.update_userDetails?.dataTrakingFullList[j][i][1])) {
          switch (this.update_userDetails?.dataTrakingFullList[j][i][1]) {
            //BP failure
            case 'BP-HARD-FAILURE-INIT':
            case 'BP-FAILURE-INIT': this.trackingData.BP.failure = 1;
              this.failureCases=true;
              break;
              //sIDP FAILURE
            case 'UI-SIDP-KBA-CHALLENGE-ANSWER-ERROR':
            case 'UI-SIDP-CLIENTMATCH-FAILURE':
            case 'UI-SIDP-CLIENTMATCH-EXCEPTION':
            case 'UI-SIDP-KBA-ANSWER-FAILURE':
            case 'UI-SIDP-KBA-CHALLENGE-ANSWER-FAILURE': this.trackingData.SIDP.failure = 1;
              this.failureCases=true;
              break;
            case 'TIS-PRIMARY-IDPROOF-FAILURE': this.trackingData.TIS.failure = 1;
              this.failureCases=true;
              break;
            case 'AOL_GENERAL_ERROR_EXIT':
            case 'AOL-ERROR-PAGE-INIT':
            case 'AOL-ERROR-SCREEN-INIT': this.trackingData.AOL.failure = 1;
              this.failureCases=true;
              break;
            case 'VAOL_GENERAL_ERROR_EXIT':
            case 'VAOL-ERROR-PAGE-INIT': this.trackingData.VAOL.failure = 1;
              this.failureCases=true;
              break;
            case 'CP-APP-GENERAL-ERROR-INIT':
            case 'CP_OOB_FAILURE': this.trackingData.CP.failure = 1;
              this.failureCases=true;
              break;
            case 'SIGN_IN_FAILURE-INIT': this.trackingData.CP.failure = 1;
              this.failureCases=true;
              break;
            case 'ERROR-SCREEN-SCENARIO-PAGE-INIT':
            case 'PAPERLESS-GENERAL-ERROR-INIT':
            case 'ERROR-SCREEN-PAGE-INIT': this.trackingData.paperless.failure = 1;
              this.failureCases=true;
              break;
            case 'MA-EMAIL-CODE-EXCEPTION':
            case 'MA-EMAIL-CODE-FAILURE': this.trackingData.MA.UE.failure = 1;
              this.failureCases=true;
              break;
          }
        }
      }
    }
  }

  generatePDF() {

    // const pdf = new jsPDF('p', 'mm', 'a4');

    const content = document.getElementById('testData');
    //   const img = new Image();
    //   img.src = dataUrl;
    domtoimage.toPng(content).then((dataUrl) => {
      const pdf = new jsPDF();
      const img = new Image();
      img.src = dataUrl;
      // Add the captured image to the PDF
      img.onload = () => {
        pdf.addImage(dataUrl, 'PNG', 10, 10, 190, 100);
        // pdf.setTextColor(255, 255, 255);
        // pdf.setFillColor(0, 0, 0);
        // pdf.setFont('times', 'normal');
        // Save or open the PDF
        pdf.save('generated-report.pdf');
      };

    });
    // html2canvas(content,{scale:2}).then((canvas)=>{
    //   const pdf = new jsPDF();
    //   pdf.setFillColor(55,2552,200);
    //   pdf.setTextColor(255,0,0);    // Add the captured image to the PDF
    //   canvas.onload = () => {
    //       pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, 0, 0);

    //       pdf.save('generated-report.pdf');
    //   };

    // })
  }

}
