import { AfterViewInit, Component, OnInit, Renderer2, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { JsonparserPipe } from '../common/pipe/jsonparser.pipe';
import { ElementRef, ViewChild } from '@angular/core';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { TimeFormatPipe } from '../common/pipe/time-format.pipe';
@Component({
  selector: 'app-user-flows',
  templateUrl: './user-flows.page.html',
  styleUrls: ['./user-flows.page.scss']
})

export class UserFlowsPage implements OnInit {
  appInsightsApiEndPoints: any;
  sessionIdFromEmail: any = [];
  userFlowList: any = [];
  dataFromTrackingId: any = [];
  modalDispay = 'none';
  userInfoData: any = [];
  displayStyle = "none";
  emailLinks: any[] = [0];
  user: string;
  selectedUF;
  selectedSession;
  selectedImprint;
  selectedSessionDate: null;
  isFormSubmited: boolean = false;
  showUserDetails: boolean = true;
  dataFromTrackingIdFullList: any = []
  entryUUID;
  formatedSessionDate:any;
  startPdf:boolean=false;
  percentageWidth:any;
  depencyList:any=[];
  exceptionList:any=[];
  constructor(
    private http: HttpService,
    private sharedService: SharedService,
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private jsonparserPipe: JsonparserPipe,
    private renderer: Renderer2,
    private el: ElementRef,
    public router: Router,
    public formatTime:TimeFormatPipe
  ) { }

  public userForm: FormGroup = this.formBuilder.group({
    email: [null, ([Validators.required])]
  });

  
  ngOnInit() {
    this.appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser") ? AppConfigService?.settings?.endpoints?.console?.appinsights : AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
    this.user = this.sharedService.loginUser.authStatus;
  }

  generateReport() {
    this.showUserDetails = false;
    let Data = {
      sessionIdFromEmail: this.sessionIdFromEmail,
      userFlowList: this.userFlowList,
      dataFromTrackingId: this.dataFromTrackingId,
      userInfoData: this.userInfoData,
      emailLinks: this.emailLinks,
      selectedUF: this.selectedUF,
      selectedSession: this.selectedSession,
      selectedImprint: this.selectedImprint,
      identifier: this.userForm.controls.email.value,
      selectedDate: this.selectedSessionDate,
      generatedDate: new Date(),
      dataTrakingFullList: this.dataFromTrackingIdFullList,
      exceptionList:this.exceptionList,
      depencyList:this.depencyList
    }
    // this.sharedService.userDetails=Data;
    this.sharedService.updateUserDetails(Data);
    //   const url = this.router.serializeUrl(
    //     this.router.createUrlTree([`pdf-report`])
    //   );
    // setTimeout(()=>{
    //   window.open(url, '_blank');
    // },500)

    // this.router.navigate(['pdf-report'],{skipLocationChange:true})
    // const pdf = new jsPDF('p', 'mm', 'a4');
    // console.log('test', this.sampleDiv)
    // console.log('test', this.sampleDiv.nativeElement)
    // const content = this.sampleDiv.nativeElement;

    // domtoimage.toPng(content).then((dataUrl) => {
    //   const img = new Image();
    //   img.src = dataUrl;
    //   img.onload = () => {
    //     const imgWidth = 210;
    //     const imgHeight = (img.height * imgWidth) / img.width;

    //     pdf.addImage(dataUrl, 'PNG', 0, 0, imgWidth, imgHeight);
    //     pdf.save('generated-pdf.pdf');
    //   };
    // });
    // const content = document.getElementById('testData');
    // content.removeAttribute('hidden')
    // domtoimage.toPng(content).then((dataUrl) => {
    //   const pdf = new jsPDF();
    //   const img = new Image();
    //   img.src = dataUrl;
    //   // Add the captured image to the PDF
    //   img.onload = () => {
    //     pdf.addImage(dataUrl, 'PNG', 10, 10, 190, 100);
    //     pdf.setTextColor(255, 255, 255);
    //     pdf.setFillColor(0, 0, 0);
    //     pdf.setFont('times', 'normal');
    //     // Save or open the PDF
    //     pdf.save('generated-report.pdf');
    //   };

    // });
  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }

  closeModal() {
    this.modalDispay = "none";
  }

  getTrace() {
    if (this.userForm?.valid) {
      this.isFormSubmited = true;
      this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents|  where (name=='API-L0GIN-USER-DETAIL-REPORT-INITITAED' and tolower(customDimensions['USER-DETAIL-REPORTING-IDENTIFIER'])==tolower('" + this.userForm?.value?.email + "')) or tolower(customDimensions.Email)==tolower('" + this.userForm?.value?.email + "')  | where  customDimensions.SessionId!=''| project tostring(customDimensions.SessionId) , timestamp | distinct customDimensions_SessionId, timestamp| summarize FirstTimestamp = min(timestamp) by customDimensions_SessionId | order by FirstTimestamp desc").subscribe((result: any) => {
        this.sessionIdFromEmail = result?.body?.tables[0]?.rows.filter(row => row[0] !== "");

      })

      this.getEmailSendData('API-AOL-MAGIC-LINK-EMAIL-SEND-SUCCESS', 0);
      this.getEmailSendData('API-AOL-MAGIC-LINK-EMAIL-SEND-FAILURE', 1);

      this.getEmailSendData('API-VAOL-MAGIC-LINK-EMAIL-SEND-SUCCESS', 2);
      this.getEmailSendData('API-VAOL-MAGIC-LINK-EMAIL-SEND-FAILURE', 3);

      this.getEmailSendData('API-PAPERLESS-MAGIC-LINK-EMAIL-SEND-SUCCESS', 4);
      this.getEmailSendData('API-PAPERLESS-MAGIC-LINK-EMAIL-SEND-FAILURE', 5);
      this.resetAll()
    }
  }
  resetAll() {
    this.userFlowList = []
    this.dataFromTrackingId = []
    this.userInfoData = []
    this.selectedUF = null;
    this.selectedSession = null;
    this.selectedImprint = null;
    this.selectedSessionDate = null;

    this.dataFromTrackingIdFullList = [];
  }

  getUserFlows(row) {
    this.selectedUF = row[0];
    this.selectedSessionDate = row[1]
    this.formatedSessionDate= this.formatTime.transform(this.selectedSessionDate);
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents| where customDimensions.SessionId==('" + row[0] + "') and name =='WORKFLOW-INITIATE'| order by timestamp asc | project customDimensions.Workflow,customDimensions.TrackingId,customDimensions.PreviousWorkflow,customDimensions.PreviousTrackingId,timestamp").subscribe((result: any) => {
      this.userFlowList = result?.body?.tables[0]?.rows.filter(row => row[0] !== "");
      if(this.userFlowList.length>0){
       const trackingidList = this.userFlowList.map(subArray => subArray[1]);
        let formatedTrackingidList =  trackingidList.map(item => `'${item}'`).join(',')
        this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents| where customDimensions.entryUUID !='' and customDimensions.entryUUID !='undefined' and customDimensions.TrackingId in ("+ formatedTrackingidList+")| project entryUUID = tostring(customDimensions.entryUUID) | distinct entryUUID").subscribe((result: any) => {
          this.entryUUID = result?.body;
        // console.log('entryuuid', this.entryUUID);
        })
      }
    })
   
    this.dataFromTrackingId = []
    this.userInfoData = []
    this.selectedSession = null;
    this.selectedImprint = null;
    this.dataFromTrackingIdFullList = [];
  }

  getDataFromTrackingId(row) {
    this.selectedSession = row[1];
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents| where customDimensions.TrackingId=='" + row[1] + "' | project timestamp, name, customDimensions,operation_Id, session_Id, user_Id, client_Type, client_Model, client_OS, client_City,client_StateOrProvince, client_CountryOrRegion, client_Browser, operation_Name, cloud_RoleName | order by timestamp desc").subscribe((result: any) => {
      this.dataFromTrackingId = result?.body;

    })

    for (let i = 0; i < this.userFlowList.length; i++) {
      this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents| where customDimensions.TrackingId=='" + this.userFlowList[i][1] + "' | project timestamp, name, customDimensions,operation_Id, session_Id, user_Id, client_Type, client_Model, client_OS, client_City,client_StateOrProvince, client_CountryOrRegion, client_Browser, operation_Name, cloud_RoleName | order by timestamp desc").subscribe((result: any) => {
        this.dataFromTrackingIdFullList.push(result?.body?.tables[0]?.rows);

      })
    }
    this.selectedImprint = null;
    this.userInfoData = [];
  }

  getUserInfo(row: any) {
    this.selectedImprint = row;
    this.userInfoData = row;
    this.modalDispay = "block";
    this.generateExceptionDetails(row[3])
  }

  getUserTrace(userInfo) {
    window.open('https://a3d0dvcimstr01.z19.web.core.windows.net/ciam-console?guid=' + this.jsonparserPipe.transform(userInfo, 'TrackId'), '_blank');
  }

  getEmailSendData(tag, pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents| where customDimensions.Email==('" + this.userForm?.value?.email + "') and name =='" + tag + "'| summarize Total = count()").subscribe((result: any) => {
      this.emailLinks[pos] = result?.body?.tables[0]?.rows[0][0]
      console.log(this.emailLinks)
    })
  }

  cancel() {
    this.showUserDetails = true;
    // Check if the testcss class exists on the body
    const bodyHasTestCssClass = document.body.classList.contains('testcss');
    if (bodyHasTestCssClass) {
      // Use Renderer2 to remove the testcss class from the body element
      this.renderer.removeClass(document.body, 'testcss');
    }
  }

  generatePDF() {
    const content = document.getElementById('apptest');
    

    var currentPosition = document.getElementById("apptest").scrollTop;
    var w = document.getElementById("apptest").offsetWidth;
    var h = document.getElementById("apptest").offsetHeight;
    document.getElementById("apptest").style.height="auto";

    html2canvas(content,{scale:2}).then((canvas)=>{
      const pdf = new jsPDF();
      // Add the captured image to the PDF
        var img = canvas.toDataURL("image/jpeg", 1);
        var doc = new jsPDF('p', 'px', [w, h]);
        doc.addImage(img, 'JPEG', 0, 0, w, h);
        doc.addPage();
        doc.save(this.formatedSessionDate+'.pdf');

    })

    document.getElementById("apptest").style.height="100px";
    document.getElementById("apptest").scrollTop = currentPosition;
  }

  // generatePDF() {
  //   const content = document.getElementById('testData');
  
  //   // Set the height to auto to capture the entire content
  //   content.style.height = 'auto';
  
  //   const options = {
  //     margin: 10,
  //     filename: this.formatedSessionDate + '.pdf',
  //     image: { type: 'jpeg', quality: 0.98 },
  //     html2canvas: { scale: 2 },
  //     jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
  //   };
  
  //   html2pdf().from(content).set(options).outputPdf(pdf => {
  //     // Save or open the PDF
  //     pdf.save();
      
  //     // Reset the height to the initial value
  //     content.style.height = '100px';
  //   });
  // }

  async  addA4PageToPDF(pdf, container, pageSize,width) {
    const canvas = await html2canvas(container, { scale: 2 });
    const imgData = canvas.toDataURL("image/jpeg", 1);
  
    pdf.addImage(imgData, 'JPEG', 0, 0, width, pageSize.height);
  
    pdf.addPage();
    // html2canvas(container,{scale:2}).then((canvas)=>{
     
    //   // Add the captured image to the PDF
    //     var img = canvas.toDataURL("image/jpeg", 1);
    //     var doc = new jsPDF('p', 'px', [width, pageSize.height]);
    //     doc.addImage(img, 'JPEG', 0, 0, width, pageSize.height);
    //     doc.addPage();
       

    // })
  }
  
  // Function to split HTML content into A4-sized PDF pages
  async  splitHtmlToA4PDF() {
    const container = document.getElementById("apptest");
    const pageSize = { width: 842, height: 1189 }; // A4 size in pixels
      // Get the total height of the HTML content
    const totalHeight = container.offsetHeight;
    const totalWidth = container.offsetWidth-700;
    const pdf = new jsPDF('p', 'px', [totalWidth, pageSize.height]);
  
  
    // Calculate the number of pages needed
    const pageCount = Math.ceil(totalHeight / pageSize.height);
  
    // Capture and add each A4-sized section to the PDF
    this.startPdf= true;
    for (let i = 0; i < pageCount; i++) {
      const startY = i * pageSize.height;
      this.percentageWidth = (i+1)/pageCount*100
      container.scrollTo(0,startY)
      container.style.height = `${pageSize.height}px`;
  
      await this.addA4PageToPDF(pdf, container, pageSize,totalWidth);
    }
  
    // Reset container styles
    container.style.height = "auto";
    container.scrollTop = 0;
  
    // Save the PDF
    document.getElementById('closeBtn').click();
    this.startPdf=false;
    pdf.save(this.formatedSessionDate+'.pdf');
  }
  
  // Call the function to split HTML content into A4-sized PDF pages
  generateExceptionDetails(operation_Id: string){
    console.log(operation_Id);
    this.http._httpDataGet(this.appInsightsApiEndPoints + "exceptions| where operation_Id =='"+operation_Id+"'").subscribe((result: any) => {
      this.exceptionList= result?.body?.tables[0]?.rows;
    })
    this.http._httpDataGet(this.appInsightsApiEndPoints + "dependencies| where operation_Id =='"+operation_Id+"' and success==false").subscribe((result: any) => {
      this.depencyList= result?.body?.tables[0]?.rows;
    })
  }

}
