import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router, RouterModule } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';

import { NavigationsComponent } from './navigations.component';

describe('NavigationsComponent', () => {
  let component: NavigationsComponent;
  let fixture: ComponentFixture<NavigationsComponent>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ NavigationsComponent ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP,
      { provide: Router, useValue : mockRouter }]
    }).compileComponents();

    fixture = TestBed.createComponent(NavigationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call goTolocation function', () => {
    let url = '/dashboard';
    component.goToLocation(url,false);
    expect(mockRouter.navigate).toHaveBeenCalledWith([url], { skipLocationChange: true });
  });
});
