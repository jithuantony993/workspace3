import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common'
import { SharedService } from 'src/app/shared-services/shared/shared.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-navigations',
  templateUrl: './navigations.component.html',
  styleUrls: ['./navigations.component.scss'],
})
export class NavigationsComponent implements OnInit {
  user:String;
  constructor( private sharedService: SharedService,
    private location: Location,
    private router: Router,) { }

  ngOnInit() {
    this.user = this.sharedService.loginUser.authStatus;
  }

  goToLocation(url: string, status:boolean = true) {
    this.sharedService.landingUrl = url;
    this.location.go(this.location.path());
    this.router.navigate([url], { skipLocationChange: true });
  }
 
}
