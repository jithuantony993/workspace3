import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CIAM_ERROR_BANNER } from '../../resources/messages';

@Component({
  selector: 'app-error-banner',
  templateUrl: './error-banner.component.html',
  styleUrls: ['./error-banner.component.scss'],
})
export class ErrorBannerComponent {
  message: any =  CIAM_ERROR_BANNER;

  change(change: any, arg1: string) {
    throw new Error('Method not implemented.');
  }

  @Input() errMsg: string;
  @Output() close = new EventEmitter();
  
  hideError(){
    this.close.emit();
  }

}
