import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ErrorBannerComponent } from './error-banner.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
describe('ErrorBannerComponent', () => {
  let component: ErrorBannerComponent;
  let fixture: ComponentFixture<ErrorBannerComponent>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ErrorBannerComponent],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger close emittor', () => {
    spyOn(component.close, 'emit');
    component.hideError();
    expect(component.close.emit).toHaveBeenCalled();
  });

  it('should trigger change method and return throw error', ()=> {
    expect(() =>{
      component.change('test','test');
    }).toThrowError("Method not implemented.");
  });

});
