import { Component, ViewChild, ElementRef, Input } from '@angular/core';
import { CIAM_BROWSER_BACK_BUTTON, CIAM_IDLE_TIME_POPUP, CIAM_VALIDATE_OOB } from '../../resources/messages';
import { SharedService } from '../../shared-services/shared/shared.service';
import { Router } from '@angular/router';
import { AppConfigService } from '../../shared-services/ciam-appconfig/app.config.service';
import { Subscription, timer } from 'rxjs';
@Component({
  selector: 'app-app-includes',
  templateUrl: './app-includes.component.html',
  styleUrls: ['./app-includes.component.scss'],
})
export class AppIncludesComponent {
  base_path = this.sharedService.getAppURL()+AppConfigService?.settings?.env?.imgPath ;
  @Input() modalContent: any = {};
  @ViewChild('bkButtonOverlay') model: ElementRef;
  @ViewChild('errorDialog') errorDialog: ElementRef;
  @ViewChild('oobSuccess') oobSuccess: ElementRef;
  @ViewChild('resendOOBPopUp') resendOOBPopUp: ElementRef;
  @ViewChild('error500') error500: ElementRef;
  @ViewChild('osaDialog') osaDialog: Element;
  @ViewChild('eulaModal') eulaModal: Element;
  @ViewChild('ombaModal') ombaModal: Element;
  @ViewChild('idleTimeoutDialog') idleTimeoutDialog: ElementRef;
  labels = CIAM_BROWSER_BACK_BUTTON;
  idleTimeLabel = CIAM_IDLE_TIME_POPUP;
  message = CIAM_VALIDATE_OOB;
  counter: number;
  limit = AppConfigService?.settings?.limit;
  closeModalSub: Subscription;
  disabledStatus:boolean= true;
  timeLeft: number;
  interval;
  subscribeTimer: any;
  public timerSub: Subscription;

  constructor(private sharedService: SharedService, public router: Router) {

    // this subscribtion is used to fetch counter value 
    this.sharedService.counter_value.subscribe((data) => {
      if (data) {
        this.startTimer();
      } else {
        this.stopTimer();
      }
    })

    /**
   * this is for closing the modals that have opened earlier
   * This will subscribe closeModelRef observable
     */
    this.closeModalSub = this.sharedService.closeModelRef.subscribe((data) => {
      if (data) {
        this.closeModal(false, data);
      }
    });
  }

  startTimer() {
    this.timeLeft = this.sharedService.timeLeft;
    const source = timer(0, 1000);
    this.timerSub = source.subscribe(val => {
      this.subscribeTimer = this.timeLeft - val;
      if (this.subscribeTimer >= 0) {
        this.counter = this.subscribeTimer;
        this.disabledStatus = false;
      }
      else {
        this.disabledStatus = true;
        this.stopTimer();
      }
    });
  }
  /**
   * This method is used to trigger resend oob api subscribtion
   */
  resendOtp(dailogue:string) {
    if(this.disabledStatus) {
      this.disabledStatus = false;
      this.sharedService.updateResendApi(true,this.modalContent?.key); 
      this.closeModal(false,dailogue);
    }
  }

  /**
* This method used to close any modal that have been opened on click ok or close button.
*/
  closeModal(flag, dailogue) {
    if (flag) {
      this.router.navigate([''])
    }
    setTimeout(() => {
      this[dailogue].nativeElement.close();
    }, this.limit?.interval);
  }

  /**
   * unsubscribe timer for resend otp 
   */
  stopTimer() {
    this.timerSub?.unsubscribe();
    //this.subscribeTimer = 0;
  }
  /**
   * this is to trigger stay signin button on idle timeout
   */
  stayIn(dailogue:string){
    this.disabledStatus = false;
    this.sharedService.updateIdleRef(true,'stayin'); 
    this.closeModal(false,dailogue)
  }

  /**
   * This function is used to do signout functionality for idle timeout popup
   */
   signOut(dailogue:string){
    this.disabledStatus = false;
    this.sharedService.updateIdleRef(false,'signout'); 
    this.closeModal(false,dailogue)
   }

  ngOnDestroy() {
    this.timerSub?.unsubscribe();
  } 
}
