import { ElementRef } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { RouterTestingModule } from '@angular/router/testing';
import { AppIncludesComponent } from './app-includes.component';
import { Router } from '@angular/router';
import { SharedService } from 'src/app/shared-services/shared/shared.service';
import{ FormatTimePipe} from '../../pipes/timer/format-time.pipe'

import { AppConfigService } from 'src/app/shared-services/ciam-appconfig/app.config.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
class MockElementRef implements ElementRef {
  nativeElement = {};
}
;


describe('AppIncludesComponent', () => {
  let component: AppIncludesComponent;
  let fixture: ComponentFixture<AppIncludesComponent>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }
  let mockAppConfigService = {
    limit:{
      interval:0
    }
  };
  // let mockServiceSpy = jasmine.createSpyObj('SharedService',['counter_value','oberserableTimer','closeModelRef','timeLeft','updateResendApi'])
  beforeEach(async() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AppIncludesComponent,FormatTimePipe],
      imports: [IonicModule.forRoot(), RouterTestingModule],
      providers:[ 
        { provide: ElementRef, useClass: MockElementRef },
        { provide: Router, useValue: mockRouter },
        { provide: AppConfigService ,useValue: mockAppConfigService}
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppIncludesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should start timer if case satisfied', (done) => {
    const service = fixture.debugElement.injector.get(SharedService);
    service.counter.next(true);
    service.timeLeft = 10;
   fixture.detectChanges();
   done();
  //  component.startTimer();
   expect(true).toEqual(true);
  });

  
  it('should start timer else case satisfied', (done)=> {
    const service = fixture.debugElement.injector.get(SharedService);
    service.counter.next(true);
    service.timeLeft = -1;
   fixture.detectChanges();
   done();
  //  component.startTimer();
   expect(true).toEqual(true);
  } );

  
  xit('should closemodel ref  on subscribe called',()=> {
   
    spyOn(component.model, 'nativeElement');
    
    const service = fixture.debugElement.injector.get(SharedService);
    service.invokeModel({name:'bkButtonOverlay',content:{}});
    (component as any).closeModalSub.next('bkButtonOverlay');
   
    fixture.detectChanges();
    // expect(component.model.nativeElement.hide).toHaveBeenCalledTimes
  
  //  expect(true).toEqual(true);
  });

  xit('should closemodel ref  on click ok ', (done) => {
   
  // spyOn(component.error500, 'nativeElement');
   const service = fixture.debugElement.injector.get(SharedService);
   service.invokeModel({name:'error500',content:{}});
   component.closeModal(true,'error500');
  expect(component.error500.nativeElement.hide).toHaveBeenCalledTimes
   fixture.detectChanges();
 done();
   expect(mockRouter.navigate).toHaveBeenCalledWith(['']);
  
  //  expect(true).toEqual(true);
  });

   
  it('should trigger closemodel if true case',()=>{
    component['bkButtonOverlay'] = {
      nativeElement: {
        close: () => {}
      }
    };
     component.closeModal(true,'bkButtonOverlay');
    expect(mockRouter.navigate).toHaveBeenCalledWith(['']);
  })

 


  // it('should set counter value',()=>{
  //  component.subscribeTimer = 1;
  //  fixture.detectChanges();
  //  expect(component.counter).toEqual(1);
  // })

  // it('should trigger showOverLay click', () => {
  //   spyOn(component.model, 'nativeElement');
  //   expect(component.model.nativeElement.show).toHaveBeenCalled();
  // });

  // it('should trigger hide click', () => {
  //   spyOn(component.model, 'nativeElement');
  //   expect(component.model.nativeElement.hide).toHaveBeenCalledTimes;
  // });

  it('should trigger resendOtp',()=>{
    let service = TestBed.inject(SharedService);
    spyOn(service, 'updateResendApi').and.callFake;
    spyOn(component, 'closeModal').and.callFake;
    component.resendOtp('resendOOBPopUp');
    expect(service.updateResendApi).toHaveBeenCalled;
  });


  it('should trigger stayIn',()=>{
    let service = TestBed.inject(SharedService);
    spyOn(service, 'updateIdleRef').and.callFake;
    spyOn(component, 'closeModal').and.callFake;
    component.stayIn('idleTimeoutDialog');
    expect(service.updateIdleRef).toHaveBeenCalled;
  });

  it('should trigger signout',()=>{
    let service = TestBed.inject(SharedService);
    spyOn(service, 'updateIdleRef').and.callFake;
    spyOn(component, 'closeModal').and.callFake;
    component.signOut('idleTimeoutDialog');
    expect(service.updateIdleRef).toHaveBeenCalled;
  });

});
