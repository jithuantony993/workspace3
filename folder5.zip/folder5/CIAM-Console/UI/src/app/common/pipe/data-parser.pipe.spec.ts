import { DataParserPipe } from './data-parser.pipe';

describe('DataParserPipe', () => {
  let pipe: DataParserPipe;

  beforeEach(() => {
    pipe = new DataParserPipe();
  });

  it('should return the corresponding value from TAG_DATA if it exists', () => {
    const input = 'Tag-1';
    const expectedOutput = 'tag 1';

    const result = pipe.transform(input,'');

    expect(result).toEqual(expectedOutput);
  });

  it('should replace hyphens and underscores with spaces and convert to lowercase if the value does not exist in TAG_DATA', () => {
    const input = 'tag_2';
    const expectedOutput = 'tag 2';

    const result = pipe.transform(input,'');

    expect(result).toEqual(expectedOutput);
  });

  it('should return the input value as is if it is not present in TAG_DATA and does not contain hyphens or underscores', () => {
    const input = 'tag3';
    const expectedOutput = 'tag3';

    const result = pipe.transform(input,'');

    expect(result).toEqual(expectedOutput);
  });

  it('should return the input value as by removiong API', () => {
    const input = 'tag3api';
    const expectedOutput = 'tag3';

    const result = pipe.transform(input,'screened');

    expect(result).toEqual(expectedOutput);
  });
});