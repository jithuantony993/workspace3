import * as moment from 'moment';
import { TimeFormatPipe } from './time-format.pipe';

describe('TimeFormatPipe', () => {
  let pipe: TimeFormatPipe;

  beforeEach(() => {
    pipe = new TimeFormatPipe();
  });

  it('should return an empty string if the value is falsy', () => {
    expect(pipe.transform(null)).toEqual('');
    expect(pipe.transform(undefined)).toEqual('');
    expect(pipe.transform('')).toEqual('');
    expect(pipe.transform(0)).toEqual('');
    expect(pipe.transform(false)).toEqual('');
  });

  it('should format the value as expected if it is a moment object', () => {
    const value = moment('2021-07-01T10:30:00');
    const formattedValue = pipe.transform(value);
    expect(formattedValue).toEqual('Jul - 01 - 21 10:30:00.000');
  });

  // it('should format the value as expected if it is a valid date string', () => {
  //   const value = '2021-07-01T10:30:00';
  //   const formattedValue = pipe.transform(value);
  //   expect(formattedValue).toEqual('Jul - 01 - 21 10:30');
  // });

  // it('should return the original value if it is not a moment object or a valid date string', () => {
  //   const value = 'invalid date';
  //   const formattedValue = pipe.transform(value);
  //   expect(formattedValue).toEqual(value);
  // });
});