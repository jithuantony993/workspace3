import { JsonparserPipe } from './jsonparser.pipe';

describe('JsonparserPipe', () => {
  let pipe: JsonparserPipe;

  beforeEach(() => {
    pipe = new JsonparserPipe();
  });

  it('should parse JSON and return the specified property', () => {
    const value = '{"name": "John", "age": 30}';
    const property = 'name';
    const result = pipe.transform(value, property);
    expect(result).toBe('John');
  });

  it('should return an empty string if the JSON parsing fails', () => {
    const value = 'invalid json';
    const property = 'name';
    const result = pipe.transform(value, property);
    expect(result).toBe('');
  });

  // it('should return an empty string if the specified property is not found', () => {
  //   const value = '{"name": "John", "age": 30}';
  //   const property = 'address';
  //   const result = pipe.transform(value, property);
  //   expect(result).toBe('');
  // });
});