import { Pipe, PipeTransform } from '@angular/core';
import { TAG_DATA } from 'src/app/resources/tagdata';

@Pipe({
  name: 'dataParser'
})
export class DataParserPipe implements PipeTransform {

  transform(value: string, type: string): string {
    if (TAG_DATA[value]) {
      return TAG_DATA[value];
    }
    if(type=='screened'){
      value= value.replace(/(api|API)/g, '')
    }
    return value.replace(/^(?!(signin|SIGN-IN|SIGN_IN))(si)|[-_]/ig, ' ').toLowerCase();
  }

}
