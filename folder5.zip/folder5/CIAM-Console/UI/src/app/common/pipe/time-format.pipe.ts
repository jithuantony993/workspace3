import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'timeFormat'
})
export class TimeFormatPipe implements PipeTransform {

  transform(value: any, ...args: unknown[]): unknown {
    if (!value) {
      return '';
    }

    value=moment.utc(value).local()
    if (moment.isMoment(value)) {
      return value.format('MMM - DD - YY hh:mm:ss.SSS');
    }

    const momentValue = moment(value);
    if (momentValue.isValid()) {
      return momentValue.format('MMM - DD - YY hh:mm:ss.SSS');
    }

    return value;
  }

}
