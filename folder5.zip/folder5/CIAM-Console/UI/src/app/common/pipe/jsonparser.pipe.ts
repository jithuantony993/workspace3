import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'parseJson'
})
export class JsonparserPipe implements PipeTransform {

  transform(value: string, property: string): any {
    try {
      const parsedValue = JSON.parse(value);
      let dataParsed=parsedValue[property]
      return (dataParsed !="{}" && dataParsed!="undefined")?dataParsed:'';
    } catch (e) {
      console.error('Error parsing JSON:', e);
      return '';
    }
  }
}



