import { Component, Input} from '@angular/core';
import { LDService } from '../../shared-services/ld/ld.service';
import {Toggles} from '../../resources/flags';
import { CIAM} from '../../resources/messages';
import { SharedService } from '../../shared-services/shared/shared.service';
import { AppConfigService } from '../../shared-services/ciam-appconfig/app.config.service';

@Component({
  selector: 'app-app-layout',
  templateUrl: './app-layout.component.html',
  styleUrls: ['./app-layout.component.scss']
})
export class AppLayoutComponent {
  
  @Input() testVar:string;
  _flagSubscription: any;
  _ciamReference: boolean;
  _signinSeqNavFeature: boolean;
  _messages:  any  = CIAM;
  _refID: string= null;

  constructor(
    private ldService: LDService,
    private sharedService: SharedService
  )
  {
    this.sharedService.refID.subscribe((data)=>{
      this._refID = data;
    })
    this._flagSubscription = ldService.flagChange.subscribe(() => this.initFlags(ldService));
    this.initFlags(ldService)
  }
  
  initFlags(ldService: LDService) {
    this._ciamReference = (ldService.getSwitch(Toggles._ciam_reference) && AppConfigService.settings?.env.name!=="production");
    this.sharedService._signinSeqNavFeature = ldService.getSwitch(Toggles._signin_seq_nav_feature);
  }
}
