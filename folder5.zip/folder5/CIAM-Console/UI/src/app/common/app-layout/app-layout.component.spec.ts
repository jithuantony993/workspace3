import { ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppLayoutComponent } from './app-layout.component';

import { Router } from '@angular/router';
import {LDService } from '../../shared-services/ld/ld.service'
import { Subject } from 'rxjs';
import { AppConfigService } from 'src/app/shared-services/ciam-appconfig/app.config.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HTTP } from '@ionic-native/http/ngx';

describe('AppLayoutComponent', () => {
  let component: AppLayoutComponent;
  let fixture: ComponentFixture<AppLayoutComponent>;
  let router: Router;

  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }
  let ldService = {
    flagChange: new Subject<any>(), //{ subscribe: () => {}},
    getSwitch: () => true
  };
  // let appConfigService:AppConfigService;
  beforeEach(() => {

    // appConfigService = TestBed.inject(AppConfigService);
    AppConfigService.settings = {
      env: {
        name: "test"
      },
    } as any;

    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ AppLayoutComponent ],
           imports: [IonicModule.forRoot(),HttpClientTestingModule],
      providers:[ HTTP, { provide: LDService, useValue: ldService } , { provide: Router, useValue: mockRouter }]
    }).compileComponents();
    fixture = TestBed.createComponent(AppLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    
    
  });

  it('should create', () => {
    ldService.flagChange.next("Test");
    expect(component).toBeTruthy();   
  });

});
