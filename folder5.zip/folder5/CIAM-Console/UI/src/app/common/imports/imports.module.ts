import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import {AppLayoutComponent} from '../app-layout/app-layout.component';
import {ErrorBannerComponent} from '../../common/error-banner/error-banner.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxIntlTelInputModule } from 'ngx-intl-tel-input';
import { IonicModule } from '@ionic/angular';
import { NavigationsComponent } from 'src/app/navigations/navigations.component';
import { TimeFormatPipe } from '../pipe/time-format.pipe';
import { JsonparserPipe } from '../pipe/jsonparser.pipe';
import { DataParserPipe } from '../pipe/data-parser.pipe';


@NgModule({
  declarations: [
    AppLayoutComponent,
    ErrorBannerComponent, 
    NavigationsComponent,
    TimeFormatPipe,
    JsonparserPipe,
    DataParserPipe,

  ],
  imports: [
    CommonModule,
    NgxIntlTelInputModule,
    IonicModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports:    [ 
    TimeFormatPipe,
    AppLayoutComponent, 
    ErrorBannerComponent,
    ReactiveFormsModule,
    NgxIntlTelInputModule,
    NavigationsComponent,
    JsonparserPipe,
    DataParserPipe,

  ]
})
export class ImportsModule { }
