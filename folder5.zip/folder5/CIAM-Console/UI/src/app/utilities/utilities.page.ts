import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { apiResponseError } from '../ma-interface/api-response-interface';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';

@Component({
  selector: 'app-utilities',
  templateUrl: './utilities.page.html',
  styleUrls: ['./utilities.page.scss'],
})
export class UtilitiesPage implements OnInit {
  apiEndPoints = AppConfigService?.settings?.endpoints?.console;
  success_response=null;
  hash_data=null;
  identifier_data=null;
  access_token = null;
  public errMsgContent: string;
  public isFormSubmit: boolean;
  constructor( private formBuilder: FormBuilder, private sharedService: SharedService,
    private http: HttpClient) { }
  public accessTokenForm: FormGroup = this.formBuilder.group({
    email: ['', ([Validators.required])],
    entryuuid: ['',([Validators.required])]
  });
  public guidForm: FormGroup = this.formBuilder.group({});
  public hashForm: FormGroup = this.formBuilder.group({
    ssn: ['', ([Validators.required])],
    dob: ['', ([Validators.required])]
  });
  public identifierForm: FormGroup = this.formBuilder.group({
    identifier: ['', ([Validators.required])]
  });

  async ngOnInit() {
    this.generateGUID();
  }

  getHash(){
    this.isFormSubmit = true;
    if (this.hashForm?.valid) {

      let request={
        ssn: this.hashForm?.value?.ssn,
        dob: this.hashForm?.value?.dob.replaceAll('-',''),
      }
      this.http.post(this.apiEndPoints?.generateHash, request, {responseType: 'text'}).subscribe((result) => {

          this.hash_data = result;
         
      }, (error:apiResponseError) => {
        //this.userNotFound=true;
        this.sharedService?.updateLoaderStatus(false);
        this.errorHandler(error);
      })
    } 
  }

  getAccessToken() {
    this.isFormSubmit = true;
    if(this.accessTokenForm.valid){
      let request = {
        email : this.accessTokenForm?.value?.email,
        entryuuid : this.accessTokenForm?.value?.entryuuid
      }
      this.http.post(this.apiEndPoints?.accesstoken,request).subscribe((result : any) => {
        this.access_token = result?.access_token;
      }, (error: apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.accessTokenForm.reset();
        this.isFormSubmit = false;
      })
    }
  }

  generateGUID() {
    this.isFormSubmit = true;
    if(this.guidForm.valid){
      this.http.post(this.apiEndPoints?.guid,null, {responseType: 'text'}).subscribe((result : string) => {
        this.success_response = result;
      }, (error:apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.guidForm.reset();
        this.isFormSubmit = false;
        console.log(error);
      })
    }
  }

  getIdentifierHash() {
    this.isFormSubmit = true;
    if (this.identifierForm?.valid) {
      let endpoit = this.apiEndPoints?.getIdentifierHash + "?identifier="+ this.identifierForm?.value?.identifier;
      this.http.post(endpoit, null, {responseType: 'text'}).subscribe((result) => {

          this.identifier_data = result;
         
      }, (error:apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.identifierForm.reset();
        this.isFormSubmit = false;
        console.log(error);
      })
    } 
  }
  errorHandler(error:apiResponseError){
      if(error.status === 400){
        this.errMsgContent = error?.error?.errorMessage
      }else{
        this.hashForm.reset();
        this.isFormSubmit = false;
        console.log('error')
      }
    }
  }


