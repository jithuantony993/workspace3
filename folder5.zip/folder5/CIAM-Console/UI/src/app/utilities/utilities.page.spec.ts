import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of, throwError } from 'rxjs';

import { UtilitiesPage } from './utilities.page';

describe('UtilitiesPage', () => {
  let component: UtilitiesPage;
  let fixture: ComponentFixture<UtilitiesPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ UtilitiesPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP, FormBuilder]
    }).compileComponents();

    fixture = TestBed.createComponent(UtilitiesPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call generateGUID', () => {
    let result = "3004a361-818c-42af-8c4c-4f069c2df8d6";
    spyOn(component['http'],"post").and.returnValue(of(result));
    component.generateGUID();
    expect(component.success_response).not.toBeNull();
  });

  it('should call getHash', () => {
    component.hashForm.controls['ssn'].setValue('223334444');
    component.hashForm.controls['dob'].setValue('19690410');
    let result = "0278a743a8e4e32caca3dc48fd1445c2163296f75eb49d1a838a68b06d5fea57";
    spyOn(component['http'],"post").and.returnValue(of(result));
    component.getHash();
    expect(component.hash_data).not.toBeNull();
  });

  it('should trigger getHash with error', () => {
    component.hashForm.controls['ssn'].setValue('223334444');
    component.hashForm.controls['dob'].setValue('19690410');
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      errorMessage: "Error Message",
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    };
    spyOn(component['http'], "post").and.callFake(() => {
      return throwError({error});
    });
    spyOn(component,"errorHandler");
    component.getHash();
    expect(component.errorHandler).toHaveBeenCalled();
  });

  it('should call getAccessToken', () => {
    component.accessTokenForm.controls['email'].setValue('testing@example.com');
    component.accessTokenForm.controls['entryuuid'].setValue('1234-4321-12344321-1234-4321');
    let result = {
      access_token: "TEST"
    };
    spyOn(component['http'],"post").and.returnValue(of(result));
    component.getAccessToken();
    expect(component.access_token).toEqual("TEST");
  });

  it('should trigger getAccessToken with error', () => {
    component.accessTokenForm.controls['email'].setValue('testing@example.com');
    component.accessTokenForm.controls['entryuuid'].setValue('1234-4321-12344321-1234-4321');
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      errorMessage: "Error Message",
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    };
    spyOn(component['http'], "post").and.callFake(() => {
      return throwError({error});
    });
    component.getAccessToken();
    expect(component.isFormSubmit).toBeFalse();
  });

  it('should call getIdentifierHash', () => {
    component.identifierForm.controls['identifier'].setValue('test');
    let result = "3004a361-818c-42af-8c4c-4f069c2df8d6";
    spyOn(component['http'],"post").and.returnValue(of(result));
    component.getIdentifierHash();
    expect(component.identifier_data).not.toBeNull();
  });

  it('should trigger getIdentifierHash with error', () => {
    component.identifierForm.controls['identifier'].setValue('test');
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "post").and.callFake(() => {
      return throwError({error});
    });
    component.getIdentifierHash();
    expect(component.isFormSubmit).toEqual(false);
  });

  it('should trigger errorHandler with 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.errMsgContent).toEqual(error.error.errorMessage);
  });

  it('should trigger errorHandler without 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 500,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.isFormSubmit).toEqual(false);
  });
  
});
