import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { UtilitiesPageRoutingModule } from './utilities-routing.module';

import { UtilitiesPage } from './utilities.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    UtilitiesPageRoutingModule,
    ImportsModule
  ],
  declarations: [UtilitiesPage]
})
export class UtilitiesPageModule {}
