import { Component, Input,Output, EventEmitter, ViewChild, ElementRef, ViewEncapsulation, HostListener } from '@angular/core';
import {CIAM} from './resources/messages';
import {Router,Event, NavigationEnd} from '@angular/router'
import { AppTrailers } from './shared-services/app-trailers/app-trailers.service';
import { SharedService , modalobj} from './shared-services/shared/shared.service';
import { CIAM_TAGS } from './resources/constants'
import { AppIncludesComponent } from './common/app-includes/app-includes.component';
import { interval, Subscription, timer } from 'rxjs';
import { AppConfigService } from './shared-services/ciam-appconfig/app.config.service';
import { HttpService } from './shared-services/http/http.service';
@Component({
  selector: 'ciam-console-app',
  templateUrl: 'app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation:ViewEncapsulation.None
})
export class AppComponent {
  time:any; 
@ViewChild('paginator') paginator: AppIncludesComponent;  
@Input() item :string;
message:  any  = CIAM ;
modelRefVar:string;
closeModelRefVar:string;
modalSub:Subscription;
limit = AppConfigService?.settings?.limit;
modalContent:any={};
modalOpen:boolean=false;
/**
 * main idle timeout 
 */
source:any;
sourceSub=new Subscription();
/**
 * 1 min timer for idle popup display
 */
initiateSource:any;
initiateSourceSub=new Subscription();
/**
 * 4min timer
 */
initiateAuthSource:any;
initiateAuthSourceSub=new Subscription();
initiateAuthSourceApi=new Subscription();

base_url = AppConfigService.settings?.pingConfig;
ciam_url = AppConfigService.settings?.endpoints;
base_apiUrl = AppConfigService.settings?.env?.appURL;
SPRedirectURI = AppConfigService.settings?.SPRedirectURI;
constructor(  public router: Router, 
              private _http: HttpService,
              private appTrailers : AppTrailers,
              public sharedService:SharedService, private elementRef: ElementRef) {

  this.appTrailers.add(CIAM_TAGS.CIAM_APP_INIT);
 
  // this.sharedService.update_code.subscribe((data)=>{
  //   this.serviceData.emit(data);
  // });

/**
 * This will subscribe modelRef observable
   */
  this.modalSub=this.sharedService.modelRef.subscribe((data)=>{
        if(data.name){
          this.invokeModels(data);
        }
  });
   
    let nativeElement = elementRef.nativeElement;
    this.sharedService.authData = JSON.parse(nativeElement.getAttribute('authData'));
    if(this.sharedService?.authData != null && this.sharedService?.authData?.IsNative=="true"){
      this.sharedService._isMYBNative = true;
    }

   
    
     /** for idle timeout reset timer whever a route change occured */
     this.router.events.subscribe((event: Event) => {
      // see also 
      if (event instanceof NavigationEnd) {
        console.log('navigation end')
        // subscribing to NavigationEnd which is about to happen
       
      }
      
    }); 
  
  }

  invokeModels(modelRef: modalobj) {
    this.modelRefVar = modelRef.name;
    this.modalContent = modelRef.content;
    this.paginator[ modelRef.name].nativeElement.show();
  }

 

  ngOnInit() {
    this.router.initialNavigation();
  }
  // @HostListener('document:mousemove')
  // @HostListener('document:keypress')
  //  @HostListener('click')
  // @HostListener('document:wheel')
  // @HostListener('document:touchstart')
  // @HostListener('document:touchend')
  // @HostListener('document:touchcancel')



  

  
  ngAfterViewInit(){
   

  }

  ngOnDestroy(){
    this.initiateSourceSub.unsubscribe();
    this.sourceSub?.unsubscribe();
    this.modalSub?.unsubscribe();
    this.initiateAuthSourceSub?.unsubscribe();
    this.initiateAuthSourceApi.unsubscribe();
  }

 
}
