import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CiamReportFourPage } from './ciam-report-four.page';

const routes: Routes = [
  {
    path: '',
    component: CiamReportFourPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CiamReportFourPageRoutingModule {}
