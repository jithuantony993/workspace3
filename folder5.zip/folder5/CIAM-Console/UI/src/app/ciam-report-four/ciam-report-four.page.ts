import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { round } from 'lodash';
import { ScaleType } from '@swimlane/ngx-charts';
import * as moment from 'moment';
import * as $ from 'jquery';
import 'daterangepicker';

@Component({
  selector: 'app-ciam-report-four',
  templateUrl: './ciam-report-four.page.html',
  styleUrls: ['./ciam-report-four.page.scss'],
})
export class CiamReportFourPage implements OnInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser") ? AppConfigService?.settings?.endpoints?.console?.appinsights : AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  loginsuccessRate: any;
  rounded_num: any;
  GArounded_num: number = 0;
  Passwordrounded_num: number = 0;
  SMSrounded_num: number = 0;
  Emailrounded_num: number = 0;
  Passwordresetrounded_num: number = 0;
  SuccessRate: number = 0;
  GAsuccessRate: any;
  PasswordReset: any;
  TotalSuccessfulAttempts: any;
  TotalAttempts: any;
  val:any;
  ffAttempts:any;
  // glanceHours: any = 1;
  startDate: any;
  endDate: any;
  endDateFormated: string;
  startDateFormated: string;
  counts: {
    total: number;
  }[] = [];
  single: any[] = [{
    "name": "EmailID",
    "value": 89400
  },
  {
    "name": "Mobile",
    "value": 72000
  }
 ];
  view: [number, number] = [400, 250,];
  gradient: boolean = true;
  showLegend: boolean = true;
  showLabels: boolean = true;
  isDoughnut: boolean = false;

  colorScheme = {
    name: '',
    selectable: false,
    group: ScaleType.Ordinal,
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA']
  };

  constructor(private http: HttpService, private sharedService: SharedService) { }


  async ngOnInit() {
   // this.getallCounts();
  }

  // async UpdateHours(event) {
  //   this.sharedService.glanceHours = event.target.value;
  //   this.glanceHours = this.sharedService.glanceHours;
  //   this.getallCounts();
  // }

  ngAfterViewInit() {
    this.loadScript();
  }

  async getCount(event: string, pos) {
    return new Promise<void>((resolve, reject) => {
      this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name in ('" + event + "') | where timestamp between(datetime("+this.startDateFormated+")..datetime("+this.endDateFormated+")) | summarize Unique = dcount(session_Id),Total = count()").subscribe((result: any) => {
        this.counts[pos] = {
          total: result?.body?.tables[0]?.rows[0][1]
        };
        resolve();
      })
    });
  }
  async getLoginsuccessRate() {
    this.TotalSuccessfulAttempts = this.counts[0].total;
    this.TotalAttempts = this.counts[1].total;
    this.loginsuccessRate = (this.TotalSuccessfulAttempts / this.TotalAttempts) * 100;
    this.rounded_num = round(this.loginsuccessRate, 2);
  }
  async getGAsuccessRate() {
    this.TotalSuccessfulAttempts = this.counts[14].total;
    this.TotalAttempts = this.counts[15].total;
    this.GAsuccessRate = (this.TotalSuccessfulAttempts / this.TotalAttempts) * 100;
    this.GArounded_num = round(this.GAsuccessRate, 2);
  }
  async getPasswordSuccessRate() {
    this.TotalSuccessfulAttempts = this.counts[2].total + this.counts[4].total;
    this.TotalAttempts =this.counts[3].total + this.counts[5].total; ;
    this.SuccessRate = (this.TotalSuccessfulAttempts /this.TotalAttempts) * 100;
    this.Passwordrounded_num = round(this.SuccessRate, 2);
  }
  async getSMSSuccessRate() {
    this.TotalSuccessfulAttempts = this.counts[6].total + this.counts[8].total;
    this.TotalAttempts = this.counts[7].total + this.counts[9].total;
    this.SuccessRate = (this.TotalSuccessfulAttempts / this.TotalAttempts) * 100;
    this.SMSrounded_num = round(this.SuccessRate, 2);
  }
  async getEmailSuccessRate() {
    this.TotalSuccessfulAttempts = this.counts[10].total + this.counts[12].total;
    this.TotalAttempts = this.counts[11].total + this.counts[13].total;
    this.SuccessRate = (this.TotalSuccessfulAttempts / this.TotalAttempts) * 100;
    this.Emailrounded_num = round(this.SuccessRate, 2);
  }
async getallCounts(){
  const promises = [
    this.getCount('SI-LOOKUP-SUBMIT-IDENTIFIER-SUCCESS', 0),
    this.getCount('SI-LOOKUP-SUBMIT-IDENTIFIER-API', 1),
    this.getCount('SI-FFA-PWD-API-SUCCESS', 2),
    this.getCount('SI-FFA-PWD-API', 3),
    this.getCount('SI-SFA-PWD-VALIDATE-SUCCESS', 4),
    this.getCount('SI_SFA_PWD_VALIDATE_API', 5),
    this.getCount('SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS', 6),
    this.getCount('SI-FFA-MOBILE-OOB-VALIDATE', 7),
    this.getCount('SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS', 8),
    this.getCount('SI-SFA-MOBILE-OOB-VALIDATE', 9),
    this.getCount('SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS', 10),
    this.getCount('SI-FFA-EMAIL-OOB-VALIDATE', 11),
    this.getCount('SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS', 12),
    this.getCount('SI-SFA-EMAIL-OOB-VALIDATE', 13),
    this.getCount('SI-SFA-GA-VALIDATE-SUCCESS', 14),
    this.getCount('SI-SFA-GA-VALIDATE-SUCCESS', 15),
    this.getCount('UI-POSTAUTH-RESET-PASSWORD-API-SUCCESS', 16),
    this.getCount('UI-POSTAUTH-RESET-PASSWORD-ONLOAD', 17),
  ];
  await Promise.all(promises);
  this.getLoginsuccessRate();
  this.getPasswordSuccessRate();
  this.getSMSSuccessRate();
  this.getEmailSuccessRate();
  this.getGAsuccessRate();
  this.getPasswordResetRate()
}

async getPasswordResetRate() {
  this.TotalSuccessfulAttempts = this.counts[16].total ;
  this.TotalAttempts = this.counts[17].total ;
  this.SuccessRate = (this.TotalSuccessfulAttempts / this.TotalAttempts) * 100;
  this.Passwordresetrounded_num = round(this.SuccessRate, 2);
}

onSelect(event){}

onActivate(event){}

onDeactivate(event){}

loadScript() {
  this.startDate = moment().startOf('hour');
  this.endDate = moment().startOf('hour').add(1, 'hour');

  let startDate = moment(this.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
  this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
  console.log(this.startDateFormated, 'startDate');
  const endDate = moment(this.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
  this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
  console.log(this.endDateFormated, 'endDate');

  $('input[name="datetimes"]').daterangepicker({
    timePicker: true,
    startDate: this.startDate,
    endDate: this.endDate,
    locale: {
      format: 'MM/DD/YYYY hh:mm A'
    }
  });
  $('input[name="datetimes"]').on('apply.daterangepicker', ((ev, picker) => {
    this.selectedDate(picker)
  }));
  this.getDataByDate(this.startDateFormated, this.endDateFormated);
}

selectedDate(event) {
  const startDate = moment(event.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
  this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
  console.log(this.startDateFormated, 'startDate');
  const endDate = moment(event.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
  this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
  console.log(this.endDateFormated, 'endDate');
  this.getDataByDate(this.startDateFormated, this.endDateFormated);
}

async getDataByDate(startDate, endDate){
  this.getallCounts();
}

}