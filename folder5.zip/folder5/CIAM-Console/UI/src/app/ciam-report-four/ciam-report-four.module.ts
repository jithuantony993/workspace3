import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportFourPageRoutingModule } from './ciam-report-four-routing.module';

import { CiamReportFourPage } from './ciam-report-four.page';
import { ImportsModule } from '../common/imports/imports.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamReportFourPageRoutingModule,
    NgxChartsModule

  ],
  declarations: [CiamReportFourPage]
})
export class CiamReportFourPageModule {}
