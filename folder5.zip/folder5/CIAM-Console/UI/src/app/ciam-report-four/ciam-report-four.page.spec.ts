import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import * as moment from 'moment';
import { of } from 'rxjs';
import { CiamReportFourPage } from './ciam-report-four.page';

describe('CiamReportFourPage', () => {
  let component: CiamReportFourPage;
  let fixture: ComponentFixture<CiamReportFourPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CiamReportFourPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(CiamReportFourPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger loadScript', () => {
    component.loadScript();
    expect(component.startDate).not.toBeNull();
    expect(component.endDate).not.toBeNull();
  });

  it('should trigger selectedDate', () => {
    const event = {
      startDate: moment("2023-08-01 00:00:00"),
      endDate: moment("2023-08-08 00:00:00")
    }
    component.selectedDate(event);
    expect(component.startDateFormated).toEqual("2023-07-31T18:30:00");
    expect(component.endDateFormated).toEqual("2023-08-07T18:30:00");
  });

  it('should trigger getDataByDate', () => {
    const startDateFormated = "2023-07-31T18:30:00";
    const endDateFormated = "2023-08-07T18:30:00";
    spyOn(component,'getallCounts');
    component.getDataByDate(startDateFormated,endDateFormated);
    expect(component.getallCounts).toHaveBeenCalled();
  });

  it('should trigger getallCounts', async() => {
    spyOn(component,'getCount');
    spyOn(component,"getLoginsuccessRate");
     await component.getallCounts();
    expect(component.getLoginsuccessRate).toHaveBeenCalled();
  });

  it('should trigger getCount', async() => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 0 , 1 ]
          ]
        }]
      }
    }
    spyOn(component['http'], "_httpDataGet").and.returnValues(of(result));
    component.getCount('TEST',0)
    expect(component.counts[0].total).toEqual(1);
  });

  it('should trigger getLoginsuccessRate', async() => {
    component.counts[0] = { total : 50 };
    component.counts[1] = { total : 100 };
    component.getLoginsuccessRate();
    expect(component.rounded_num).toEqual(50);
  });

  it('should trigger getGAsuccessRate', async() => {
    component.counts[14] = { total : 50 };
    component.counts[15] = { total : 100 };
    component.getGAsuccessRate();
    expect(component.GArounded_num).toEqual(50);
  });

  it('should trigger getPasswordSuccessRate', async() => {
    component.counts[2] = { total : 25 };
    component.counts[4] = { total : 25 };
    component.counts[3] = { total : 50 };
    component.counts[5] = { total : 50 };
    component.getPasswordSuccessRate();
    expect(component.Passwordrounded_num).toEqual(50);
  });

  it('should trigger getSMSSuccessRate', async() => {
    component.counts[6] = { total : 25 };
    component.counts[8] = { total : 25 };
    component.counts[7] = { total : 50 };
    component.counts[9] = { total : 50 };
    component.getSMSSuccessRate();
    expect(component.SMSrounded_num).toEqual(50);
  });

  it('should trigger getEmailSuccessRate', async() => {
    component.counts[10] = { total : 25 };
    component.counts[12] = { total : 25 };
    component.counts[11] = { total : 50 };
    component.counts[13] = { total : 50 };
    component.getEmailSuccessRate();
    expect(component.Emailrounded_num).toEqual(50);
  });

  it('should trigger getPasswordResetRate', async() => {
    component.counts[16] = { total : 50 };
    component.counts[17] = { total : 100 };
    component.getPasswordResetRate();
    expect(component.Passwordresetrounded_num).toEqual(50);
  });

  it('should log the clicked item', () => {
    spyOn(component,"onSelect");
    component.onSelect("data");
    expect(component.onSelect).toHaveBeenCalledWith("data");
  });

  it('should log the Activate item', () => {
    spyOn(component,"onActivate");
    component.onActivate("data");
    expect(component.onActivate).toHaveBeenCalledWith("data");
  });

  it('should log the Deactivate item', () => {
    spyOn(component,"onDeactivate");
    component.onDeactivate("data");
    expect(component.onDeactivate).toHaveBeenCalledWith("data");
  });

});
