import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GetDetailsEmailPageRoutingModule } from './get-details-email-routing.module';

import { GetDetailsEmailPage } from './get-details-email.page';
import { ImportsModule } from 'src/app/common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    GetDetailsEmailPageRoutingModule
  ],
  declarations: [GetDetailsEmailPage]
})
export class GetDetailsEmailPageModule {}
