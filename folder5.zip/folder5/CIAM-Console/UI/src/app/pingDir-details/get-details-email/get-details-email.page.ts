import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { apiResponseError, UserInfoResponseResult } from 'src/app/ma-interface/api-response-interface';
import { AppConfigService } from 'src/app/shared-services/ciam-appconfig/app.config.service';
import { SharedService } from 'src/app/shared-services/shared/shared.service';

@Component({
  selector: 'app-get-details-email',
  templateUrl: './get-details-email.page.html',
  styleUrls: ['./get-details-email.page.scss'],
})
export class GetDetailsEmailPage implements OnInit {
  apiEndPoints = AppConfigService?.settings?.endpoints?.console;
  public isFormSubmit: boolean;
  response_details: UserInfoResponseResult;
  
  constructor(private formBuilder: FormBuilder, private sharedService: SharedService,
    private http: HttpClient) { }
    public getDetailsForm: FormGroup = this.formBuilder.group({
      email: ['', ([Validators.required])]
    });

  ngOnInit() {
  }

  checkNull(guid : string) { 
    return (guid == "00000000-0000-0000-0000-000000000000")? false :true;
  }

  getDetails() {
    this.isFormSubmit = true;
    if (this.getDetailsForm?.valid) {
      let endpoint = this.apiEndPoints?.getDetailsEmail + "?email="+ this.getDetailsForm?.value?.email;
      this.http.get(endpoint).subscribe((result : any) => {
        this.response_details=result;
      }, (error:apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.getDetailsForm.reset();
        this.isFormSubmit = false;
        console.log(error);
      })
    } 
  }

}
