import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GetDetailsEmailPage } from './get-details-email.page';

const routes: Routes = [
  {
    path: '',
    component: GetDetailsEmailPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GetDetailsEmailPageRoutingModule {}
