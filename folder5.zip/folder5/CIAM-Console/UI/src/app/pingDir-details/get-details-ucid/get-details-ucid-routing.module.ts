import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { GetDetailsUcidPage } from './get-details-ucid.page';

const routes: Routes = [
  {
    path: '',
    component: GetDetailsUcidPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class GetDetailsUcidPageRoutingModule {}
