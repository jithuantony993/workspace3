import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { apiResponseError, UserInfoResponseResult } from 'src/app/ma-interface/api-response-interface';
import { AppConfigService } from 'src/app/shared-services/ciam-appconfig/app.config.service';
import { SharedService } from 'src/app/shared-services/shared/shared.service';

@Component({
  selector: 'app-get-details-ucid',
  templateUrl: './get-details-ucid.page.html',
  styleUrls: ['./get-details-ucid.page.scss'],
})
export class GetDetailsUcidPage implements OnInit {
  apiEndPoints = AppConfigService?.settings?.endpoints?.console;
  public isFormSubmit: boolean;
  response_details: UserInfoResponseResult;
  
  constructor(private formBuilder: FormBuilder, private sharedService: SharedService,
    private http: HttpClient) { }
    public getDetailsForm: FormGroup = this.formBuilder.group({
      ucid: ['', ([Validators.required])]
    });

  ngOnInit() {
  }

  checkNull(guid : string) { 
    return (guid == "00000000-0000-0000-0000-000000000000")? false :true;
  }

  getDetails() {
    this.isFormSubmit = true;
    if (this.getDetailsForm?.valid) {
      let endpoint = this.apiEndPoints?.getDetailsUcid + "?ucid="+ this.getDetailsForm?.value?.ucid;
      this.http.get(endpoint).subscribe((result  :any) => {
        this.response_details=result;
      }, (error:apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.getDetailsForm.reset();
        this.isFormSubmit = false;
        console.log(error);
      })
    } 
  }

}
