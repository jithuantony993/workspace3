import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of, throwError } from 'rxjs';

import { GetDetailsPhonePage } from './get-details-phone.page';

describe('GetDetailsPhonePage', () => {
  let component: GetDetailsPhonePage;
  let fixture: ComponentFixture<GetDetailsPhonePage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ GetDetailsPhonePage ],
      imports: [IonicModule.forRoot(),
        FormsModule, HttpClientModule, HttpClientTestingModule,
      ReactiveFormsModule],
      providers: [FormBuilder, HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(GetDetailsPhonePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getDetails', () => {
    component.getDetailsForm.controls['mobile'].setValue("9876543210");
    let result = 'test';
    spyOn(component['http'],"get").and.returnValue(of(result));
    component.getDetails();
    expect(component.response_details).not.toBeNull();
  });

  it('should call getDetails with error', () => {
    component.getDetailsForm.controls['mobile'].setValue("987654321");
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'],"get").and.callFake(() => {
      return throwError({error});
    });
    component.getDetails();
    expect(component.isFormSubmit).toEqual(false);
  });

  it('should call checkNull with not a null', () => {
    var nullOrNot = component.checkNull("12345678-1234-1234-1234-123456781234");
    expect(nullOrNot).toEqual(true);
  })

  it('should call checkNull with a null', () => {
    var nullOrNot = component.checkNull("00000000-0000-0000-0000-000000000000");
    expect(nullOrNot).toEqual(false);
  })
});
