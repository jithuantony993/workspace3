import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GetDetailsPhonePageRoutingModule } from './get-details-phone-routing.module';

import { GetDetailsPhonePage } from './get-details-phone.page';
import { ImportsModule } from 'src/app/common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    GetDetailsPhonePageRoutingModule
  ],
  declarations: [GetDetailsPhonePage]
})
export class GetDetailsPhonePageModule {}
