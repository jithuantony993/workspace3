
import { Component, OnInit } from '@angular/core';
import * as FingerprintJS from 'fingerprintjs2';
import { Color, NgxChartsModule, ScaleType } from '@swimlane/ngx-charts';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { apiResponse, apiResponseLog } from '../ma-interface/api-response-interface';
import { SERVICES_DASHBOARD_EVENTS } from './services-dashboard-data-structure';
import { SharedService } from '../shared-services/shared/shared.service';


export interface DashboardEvent{
  count: number;
  alternateKey: string;
}
@Component({
  selector: 'app-services-dashboard',
  templateUrl: './services-dashboard.page.html',
  styleUrls: ['./services-dashboard.page.scss'],
})

export class ServicesDashboardPage implements OnInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  dashboardEvents: any;

  servCardOps: any = [];
  servAPIM: any = [];
  servIDMnEDS: any = [];
  servIDM: any = [];

  servCardOpsCount: any;
  servAPIMCount: any;
  servIDMnEDSCount: any;
  servIDMCount: any;

    constructor(private http: HttpService, private sharedService: SharedService,) { 

    this.dashboardEvents = Object.assign({}, SERVICES_DASHBOARD_EVENTS);

   }
   
  ngOnInit() {

    this.getServCardOps();
    this.getServAPIM();
    this.getServIDMnEDS();
    this.getServIDM();
  }

  getServCardOps(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies | where name contains \"/efp/cardops\" and toint(resultCode) > 399 and timestamp > ago(24hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.servCardOps = result?.body?.tables[0]?.rows;
          this.servCardOpsCount = result?.body?.tables[0]?.rows?.length;
          console.log("CardOps Services");
          
    })
  }
   getServAPIM(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies| where name contains \"/eap/\"and toint(resultCode) > 399 and timestamp > ago(24hrs) | order by timestamp desc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.servAPIM = result?.body?.tables[0]?.rows;
          this.servAPIMCount = result?.body?.tables[0]?.rows?.length;
          console.log("Services via APIM");
   })
  }
  getServIDMnEDS(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies| where name contains \"/edp/\"and toint(resultCode) > 399 and timestamp > ago(24hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.servIDMnEDS = result?.body?.tables[0]?.rows;
          this.servIDMnEDSCount = result?.body?.tables[0]?.rows?.length;
          console.log("IDM and EDS transaction services");
    })
  }
  getServIDM(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies| where name contains \"/edp/\"and toint(resultCode) > 399 and timestamp > ago(24hrs) | order by timestamp desc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.servIDM = result?.body?.tables[0]?.rows;
          this.servIDMCount = result?.body?.tables[0]?.rows?.length;
          console.log("IDM Services");
    })
  }

}
