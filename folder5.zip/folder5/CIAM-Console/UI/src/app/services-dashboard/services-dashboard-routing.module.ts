import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ServicesDashboardPage } from './services-dashboard.page';

const routes: Routes = [
  {
    path: '',
    component: ServicesDashboardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ServicesDashboardPageRoutingModule {}
