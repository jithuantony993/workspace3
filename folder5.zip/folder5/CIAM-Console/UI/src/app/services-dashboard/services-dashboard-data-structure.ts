export const SERVICES_DASHBOARD_EVENTS: any = {
    "CARD-PROOF-SERVICE": {
        "metaData": {
            "keys": ["CARD-PROOF-SERVICE-DOWN", "CARD-PROOF-SERVICE-EXCEPTION"]
        },
        "CARD-PROOF-SERVICE-DOWN": {  count: 0 },
        "CARD-PROOF-SERVICE-EXCEPTION": {  name: "CARD-PROOF-SERVICE-FAILURE", count: 0 },
       
    },
    "IDM-SERVICE": {
        "metaData": {
            "keys": ["IDM-SERVICE-DOWN", "IDM-SERVICE-AUTHENTICATION-ERROR", "IDM-UCID-PING-UPDATE-FAILURE", "IDM-SSNDOB-SEARCH-FAILURE", "IDM-EMAIL-SEARCH-FAILURE", "IDM-WEAK-UCID-FAILURE", "IDM-STRONG-UCID-FAILURE"]
        },
        "IDM-WEAK-UCID-FAILURE": { count: 0 },
        "IDM-WEAK-UCID-EXCEPTION": { addCountTo: "IDM-WEAK-UCID-FAILURE",count: 0 },
        "IDM-STRONG-UCID-FAILURE": { count: 0 },
        "IDM-STRONG-UCID-EXCEPTION": { addCountTo: "IDM-STRONG-UCID-FAILURE", count: 0 },
        "IDM-EMAIL-SEARCH-FAILURE": { count: 0 },
        "IDM-EMAIL-SEARCH-EXCEPTION": { count: 0 },
        "IDM-SSNDOB-SEARCH-FAILURE": { count: 0 },
        "IDM-SSNDOB-SEARCH-EXCEPTION": { addCountTo: "IIDM-SSNDOB-SEARCH-FAILURE" ,count: 0 },
        "IDM-SERVICE-DOWN": { count: 0 },
        "IDM-SERVICE-AUTHENTICATION-ERROR": { count: 0 },
        "IDM-UCID-PING-UPDATE-FAILURE": { count: 0 },
        "IDM-UCID-PING-UPDATE-EXCEPTION": {addCountTo: "IDM-UCID-PING-UPDATE-FAILURE", count: 0 },
    },
   
};