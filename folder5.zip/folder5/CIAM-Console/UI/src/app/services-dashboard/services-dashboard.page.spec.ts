import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of } from 'rxjs';

import { ServicesDashboardPage } from './services-dashboard.page';

describe('ServicesDashboardPage', () => {
  let component: ServicesDashboardPage;
  let fixture: ComponentFixture<ServicesDashboardPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ ServicesDashboardPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(ServicesDashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getServCardOps', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getServCardOps();
    expect(component.servCardOps).toEqual([1,2,3]);
    expect(component.servCardOpsCount).toEqual(3);
  });

  it('should trigger getServCardOps branch cover',() => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getServCardOps();
    expect(component.servCardOps).not.toBeNull();
    expect(component.servCardOpsCount).not.toBeNull();
  });

  it('should call getServAPIM', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getServAPIM();
    expect(component.servAPIM).toEqual([1,2,3]);
    expect(component.servAPIMCount).toEqual(3);
  });

  it('should trigger getServAPIM branch cover',() => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getServAPIM();
    expect(component.servAPIM).not.toBeNull();
    expect(component.servAPIMCount).not.toBeNull();
  });

  it('should call getServIDMnEDS', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getServIDMnEDS();
    expect(component.servIDMnEDS).toEqual([1,2,3]);
    expect(component.servIDMnEDSCount).toEqual(3);
  });

  it('should trigger getServIDMnEDS branch cover',() => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getServIDMnEDS();
    expect(component.servIDMnEDS).not.toBeNull();
    expect(component.servIDMnEDSCount).not.toBeNull();
  });

  it('should call getServIDM', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getServIDM();
    expect(component.servIDM).toEqual([1,2,3]);
    expect(component.servIDMCount).toEqual(3);
  });

  it('should trigger getServIDM branch cover',() => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getServIDM();
    expect(component.servIDM).not.toBeNull();
    expect(component.servIDMCount).not.toBeNull();
  });
});
