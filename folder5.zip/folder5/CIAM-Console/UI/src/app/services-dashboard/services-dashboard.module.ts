import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ServicesDashboardPageRoutingModule } from './services-dashboard-routing.module';

import { ServicesDashboardPage } from './services-dashboard.page';
import { ImportsModule } from './../common/imports/imports.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ServicesDashboardPageRoutingModule,
    ImportsModule,
    NgxChartsModule
  ],
  declarations: [ServicesDashboardPage]
})
export class ServicesDashboardPageModule {}
