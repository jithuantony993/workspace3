import { FormatTimePipe } from './format-time.pipe';

describe('FormatTimePipe', () => {

  it('create an instance', () => {
    const pipe = new FormatTimePipe();
    expect(pipe).toBeTruthy();
  });

  it('should transform timeout in MM:SS format', () => {
    const pipe = new FormatTimePipe();
    const result = pipe.transform(60);
    expect(result).toBe('01:00');
  });
  
});
