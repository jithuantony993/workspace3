import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciam-report-six',
  templateUrl: './ciam-report-six.page.html',
  styleUrls: ['./ciam-report-six.page.scss'],
})
export class CiamReportSixPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
