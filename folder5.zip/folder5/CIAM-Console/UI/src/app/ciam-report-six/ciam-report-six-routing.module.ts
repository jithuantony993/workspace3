import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CiamReportSixPage } from './ciam-report-six.page';

const routes: Routes = [
  {
    path: '',
    component: CiamReportSixPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CiamReportSixPageRoutingModule {}
