import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportSixPageRoutingModule } from './ciam-report-six-routing.module';

import { CiamReportSixPage } from './ciam-report-six.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamReportSixPageRoutingModule
  ],
  declarations: [CiamReportSixPage]
})
export class CiamReportSixPageModule {}
