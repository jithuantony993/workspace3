import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AppConfigService } from 'src/app/shared-services/ciam-appconfig/app.config.service';
import { apiResponse, apiResponseError, user_login_response } from '../ma-interface/api-response-interface';
import { ApiRequestInterface } from '../ma-interface/api-request-interface';
import { Subscription } from 'rxjs';
import { HttpService } from 'src/app/shared-services/http/http.service';
import { Location } from '@angular/common'
import { SharedService } from 'src/app/shared-services/shared/shared.service';
import { AppTrailers } from '../shared-services/app-trailers/app-trailers.service';
import { ActivatedRoute, Router } from '@angular/router';
//import { nameValidator } from '../validators/nameValidator';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  apiEndPoints = AppConfigService?.settings?.endpoints?.console?.login;
  userLoginRequest: ApiRequestInterface['user_login'];
  public isFormSubmit: boolean;
  public showHelp: boolean;
  public errMsgContent: string;
  clienError: string = '';
  loginUser = new Subscription();


  constructor(
    private sharedService: SharedService,
    private location: Location,
    private router: Router,
    private formBuilder: FormBuilder,
    private appTrailers: AppTrailers,
    private http: HttpService,
    private route: ActivatedRoute) { }


  public loginForm: FormGroup = this.formBuilder.group({
    secret_key: ['', ([Validators.required])]
  }
  );

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
     if(JSON.stringify(params).includes('guid')){
      this.sharedService.loginUser.authStatus='PublicUser';
      this.sharedService.guidParam=params?.guid; 
      console.log('guid from query param :', this.sharedService?.guidParam)
      this.goToLocation('/ut', false);
     }
    }
   );
  }


  userLogin() {
    this.isFormSubmit = true;
    if (this.loginForm?.valid) {
      this.sharedService.updateLoaderStatus(true);
      this.userLoginRequest = {
        credential: this.loginForm?.value?.secret_key
        }
      console.log(this.userLoginRequest);

      this.loginUser =this.http._post(this.apiEndPoints, this.userLoginRequest).subscribe((result: apiResponse) => {
        this.sharedService?.updateLoaderStatus(false);
        if (result?.body?.statusCode === 200) {
          let success_response : user_login_response = result.body;
          /**Data store in shared service to access accross application */
          this.sharedService.id = success_response?.id;
          this.sharedService.loginUser.authStatus = success_response?.authStatus;
          this.sharedService.loginUser.refId = success_response?.referenceId;
          /** Ends */
          if(this.sharedService.loginUser.authStatus ==  "AdminUser" || this.sharedService.loginUser.authStatus ==  "MasterUser" || this.sharedService.loginUser.authStatus ==  "NewUser")
          this.goToLocation('/ciam-report-two', false);
        } 
        else{
          this.errMsgContent ='Incorrect Secret Key';
          this.isFormSubmit = false;
          this.loginForm.reset();
        }
      }, (error:apiResponseError) => {
        this.sharedService?.updateLoaderStatus(false);
        this.errorHandler(error);
      })

    } 
    else {
      this.errMsgContent = "Please enter the Secret Key"
      this.clienError = "Something went wrong!";
    }
  }


  ngOnDestroy() {
    this.sharedService.unsubscribeTimer();
  }
  /**
   * 
   * @param error : API response error 
   */
  errorHandler(error:apiResponseError){
    if(error.status === 400){
      this.errMsgContent = error?.error?.errorMessage
    }else{
      this.loginForm.reset();
      this.isFormSubmit = false;
      this.sharedService.invokeModel({name:'errorDialog',content:{msg:error?.error?.errorMessage}});
    }
  }

   /**
   * 
   * @param url routing path
   */
    goToLocation(url: string, status:boolean = true) {
      this.sharedService.landingUrl = url;
      this.location.go(this.location.path());
      this.router.navigate([url], { skipLocationChange: true });
    }

}
