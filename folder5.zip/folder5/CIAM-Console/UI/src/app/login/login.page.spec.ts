import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of, throwError } from 'rxjs';

import { LoginPage } from './login.page';

describe('LoginPage', () => {
  let component: LoginPage;
  let fixture: ComponentFixture<LoginPage>;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }
  let route = {
    queryParams: of({})
  }

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ LoginPage ],
      imports: [IonicModule.forRoot(),
        RouterTestingModule,
        HttpClientModule,
        FormsModule,
        ReactiveFormsModule],
      providers: [
        FormBuilder,HTTP,
        { provide:Router, useValue: mockRouter },
        { provide: ActivatedRoute, useValue: route }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(LoginPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call userLogin', () => {
    component.loginForm.controls['secret_key'].setValue('test');
    const result = {
      status : 200
    }
    spyOn(component['http'],"_post").and.returnValue(of(result));
    component.userLogin();
    expect(result.status).toEqual(200);
  });
  
  it('userLogin functio should call goToLocation()', () => {
    component.loginForm.controls['secret_key'].setValue('test');
    const result = {
      status : 200,
      body : {
        statusCode:200,
        authStatus : "MasterUser"
      }
    }
    let url = '/ciam-report-two';
    spyOn(component['http'],"_post").and.returnValue(of(result));
    component.userLogin();
    expect(component['sharedService'].loginUser.authStatus).toEqual('MasterUser');
    //expect(component.goToLocation).toHaveBeenCalledWith(url, false);
  });

  it('goTolocation function should navigate to Dashboard', () => {
    let url = '/dashboard';
    component.goToLocation(url,false);
    expect(mockRouter.navigate).toHaveBeenCalledWith([url], { skipLocationChange: true });
  });

  it('should trigger errorHandler with 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "_post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.errMsgContent).toEqual(error.error.errorMessage);
  });

  it('should trigger errorHandler without 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 500,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "_post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.isFormSubmit).toEqual(false);
  });

});
