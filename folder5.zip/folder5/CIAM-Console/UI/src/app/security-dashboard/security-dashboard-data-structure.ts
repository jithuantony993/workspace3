export const SECURITY_DASHBOARD_EVENTS: any = {
    "NUDATA_STATUS": {
        "metaData": {
            "keys": ["NUDATA-INITIATE", "NUDATA-SUCCESS", "NUDATA-FAILURE", "NUDATA-DB-LOG-INITIATE", "NUDATA-DB-LOG-SUCCESS", "NUDATA-DB-LOG-FAILURE"]
        },
        "NUDATA-INITIATE": { count: 0 },
        "NUDATA-SUCCESS": { count: 0 },
        "NUDATA-FAILURE": { count: 0 },
        "NUDATA-EXCEPTION": { addCountTo: "NUDATA-FAILURE", count: 0 },
        "NUDATA-DB-LOG-INITIATE": { count: 0 },
        "NUDATA-DB-LOG-SUCCESS": { count: 0 },
        "NUDATA-DB-LOG-FAILURE": { count: 0 },
        "NUDATA-DB-LOG-EXCEPTION": { addCountTo: "NUDATA-DB-LOG-FAILURE", count: 0 }
    },
    "TOKEN_VALIDATION_STATUS": {
        "metaData": {
            "keys": ["SECURITY-TOKEN-VALIDATE", "SECURITY-TOKEN-VALIDATE-SUCCESS", "SECURITY-TOKEN-VALIDATE-FAILURE", "SECURITY-TOKEN-VALIDATE-SKIPPED", "SECURITY-TOKEN-READ-INITIATE", "SECURITY-TOKEN-READ-SUCCESS", "SECURITY-TOKEN-READ-FAILURE",]
        },
        "SECURITY-TOKEN-VALIDATE": { count: 0 },
        "SECURITY-TOKEN-VALIDATE-SUCCESS": { count: 0 },
        "SECURITY-TOKEN-VALIDATE-FAILURE": { count: 0 },
        "SECURITY-TOKEN-VALIDATE-EXCEPTION": { addCountTo: "SECURITY-TOKEN-VALIDATE-FAILURE", count: 0 },
        "SECURITY-TOKEN-VALIDATE-SKIPPED": { count: 0 },
        "SECURITY-TOKEN-READ-INITIATE": { count: 0 },
        "SECURITY-TOKEN-READ-SUCCESS": { count: 0 },
        "SECURITY-TOKEN-READ-FAILURE": { count: 0 },
    },
    "XSS_VALIDATION_STATUS": {
        "metaData": {
            "keys": ["XSS-CHECK-INITIATE", "XSS-CHECK-SUCCESS", "XSS-CHECK-FAILURE", "XSS-CHECK-SKIPPED-ONLOGIC", "XSS-CHECK-ENDPOINT-EXCLUDED"]
        },
        "XSS-CHECK-INITIATE": { count: 0 },
        "XSS-CHECK-SUCCESS": { count: 0 },
        "XSS-CHECK-FAILURE": { count: 0 },
        "XSS-CHECK-EXCEPTION": { addCountTo: "XSS-CHECK-FAILURE", count: 0 },
        "XSS-CHECK-SKIPPED-ONLOGIC": { count: 0 },
        "XSS-CHECK-ENDPOINT-EXCLUDED": { count: 0 },
    },
    "ENCRIPTION_DECRYPTION_STATUS": {
        "metaData": {
            "keys": ["ENCRYPT-INITIATE", "ENCRYPT-SUCCESS", "ENCRYPT-EXCEPTION","ENCRYPT-INTIATE", "DECRYPT-SUCCESS", "DECRYPT-EXCEPTION"]
        },
        "ENCRYPT-INITIATE": { count: 0 },
        "ENCRYPT-SUCCESS": { count: 0 },
        "ENCRYPT-EXCEPTION": { name: "ENCRYPT-FAILURE", count: 0 },
        "ENCRYPT-INTIATE": { count: 0 },
        "DECRYPT-SUCCESS": { count: 0 },
        "DECRYPT-EXCEPTION": { name: "DECRYPT-FAILURE", count: 0 },
       
    },
    "SIGN_VERIFY_STATUS": {
        "metaData": {
            "keys": ["SIGNED-DATA-INITIATE", "SIGNED-DATA-SUCCESS", "SIGNED-DATA-EXCEPTION", "VERIFY-SIGNATURE-INITIATE", "VERIFY-SIGNATURE-SUCCESS",  "VERIFY-SIGNATURE-EXCEPTION"]
        },

        "SIGNED-DATA-INITIATE": { count: 0 },
        "SIGNED-DATA-SUCCESS": { count: 0 },
        "SIGNED-DATA-EXCEPTION": { name: "SIGNED-DATA-FAILURE", count: 0 },
        "VERIFY-SIGNATURE-INITIATE": { count: 0 },
        "VERIFY-SIGNATURE-SUCCESS": { count: 0 },
        "VERIFY-SIGNATURE-EXCEPTION": { name: "VERIFY-SIGNATURE-FAILURE", count: 0 },
     
    },
    "GOOGLE_AUTH_STATUS": {
        "metaData": {
            "keys": ["GA-VALIDATE-INITIATE", "GA-VALIDATE-SUCCESS", "GA-VALIDATE-INVALID","GA-VALIDATE-EXCEPION" ]
        },

        "GA-VALIDATE-INITIATE": { count: 0 },
        "GA-VALIDATE-SUCCESS": { count: 0 },
        "GA-VALIDATE-INVALID": { count: 0 },
        "GA-VALIDATE-EXCEPION": { name: "GA-VALIDATE-FAILURE", count: 0 },
        
    },
};