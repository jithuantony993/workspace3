import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SecurityDashboardPage } from './security-dashboard.page';

const routes: Routes = [
  {
    path: '',
    component: SecurityDashboardPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SecurityDashboardPageRoutingModule {}
