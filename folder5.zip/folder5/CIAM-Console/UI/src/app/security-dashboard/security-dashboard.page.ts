import { Component, OnInit } from '@angular/core';
import * as FingerprintJS from 'fingerprintjs2';
import { Color, NgxChartsModule, ScaleType } from '@swimlane/ngx-charts';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { apiResponse, apiResponseLog } from '../ma-interface/api-response-interface';
import { SECURITY_DASHBOARD_EVENTS } from './security-dashboard-data-structure';
import { SharedService } from '../shared-services/shared/shared.service';

export interface DashboardEvent{
  count: number;
  alternateKey: string;
}

@Component({
  selector: 'app-security-dashboard',
  templateUrl: './security-dashboard.page.html',
  styleUrls: ['./security-dashboard.page.scss'],
})
export class SecurityDashboardPage implements OnInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  dashboardEvents: any;

    constructor(private http: HttpService, private sharedService: SharedService) { 

    this.dashboardEvents = Object.assign({}, SECURITY_DASHBOARD_EVENTS);

   }

  ngOnInit() {

    let dashboardEventKeys = Object.keys(this.dashboardEvents);
    if(dashboardEventKeys) {
      dashboardEventKeys.forEach(eventKey => {
        let dashboardSubEventKeys = Object.keys(this.dashboardEvents[eventKey]);
        dashboardSubEventKeys.forEach(subEventKey => {
          if(subEventKey != "metaData") {
          this.getDahsboardEventCount(eventKey, subEventKey);
          }
        });
      });
    }
  }


  getDahsboardEventCount(eventName: string, subEventName: string){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+subEventName+"\"| where timestamp > ago(24h)| count").subscribe((result: apiResponse) => {
         
          let resultCount = result?.body?.tables[0]?.rows[0]?.[0];
          if(this.dashboardEvents[eventName][subEventName]['addCountTo']) {
            let alterSubEventName = this.dashboardEvents[eventName][subEventName]['addCountTo'];
            this.dashboardEvents[eventName][alterSubEventName].count = this.dashboardEvents[eventName][alterSubEventName].count + resultCount;
          } else {
            this.dashboardEvents[eventName][subEventName].count = this.dashboardEvents[eventName][subEventName].count + resultCount;
          }
    })
  }
  
  

}



  



