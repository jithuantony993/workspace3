import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of } from 'rxjs';

import { SecurityDashboardPage } from './security-dashboard.page';

describe('SecurityDashboardPage', () => {
  let component: SecurityDashboardPage;
  let fixture: ComponentFixture<SecurityDashboardPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ SecurityDashboardPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(SecurityDashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger getDahsboardEventCount case 1', () => {
    let eventName = 'NUDATA_STATUS';
    let subEventName = 'NUDATA-INITIATE';
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getDahsboardEventCount(eventName,subEventName);
    expect(component.dashboardEvents[eventName][subEventName].count).toBe(123);
  });

  it('should trigger getDahsboardEventCount case 2', () => {
    let eventName = 'NUDATA_STATUS';
    let subEventName = 'NUDATA-EXCEPTION';
    let alterSubEventName = 'NUDATA-FAILURE';
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getDahsboardEventCount(eventName,subEventName);
    expect(component.dashboardEvents[eventName][alterSubEventName].count).toBe(123);
  });

  it('should trigger getDahsboardEventCount branch cover', () => {
    let eventName = 'NUDATA_STATUS';
    let subEventName = 'NUDATA-INITIATE';
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getDahsboardEventCount(eventName,subEventName);
    expect(component.dashboardEvents[eventName][subEventName].count).not.toBeNull();
  });

});
