
export interface NuDetect {
  nuDetect: { [x: string]: string | number };
}

export interface NuDetectRequest extends NuDetect {
  username: string;
  password: string;
  
}

