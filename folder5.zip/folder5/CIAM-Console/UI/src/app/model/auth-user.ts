export interface AuthUser {
    previouSOPtionUsed: string,
    flowId: string,
    identifier: string,
    identifierType: string,
    uuid: string,
    username: string,
    status: string,
    clientId: string,
    email: Email,
    phone: Mobile,
    ffaStatus: string,
    ffaUsed: string,
    sfaUsed: string,
    sfaStatus: string,
    ffaPasswordAttempt: number,
    ffaPasswordLocked: boolean,
    sfaPasswordAttempt: number,
    sfaPasswordLocked: boolean,
    kbaLocked: boolean,
    accessToken: string,
    device_list: Array<any>,
    selected_device: string,
    sel_email: Selected_Email,
    sel_phone: Selected_Mobile,
    accountList: Array<device_list>,
    name: Name,
    alternativeOption: Array<altName>,
    user_multiple_account: boolean,
    tryOtherOption: tryOtherOptions,
    ga:GA,
    isTransacted: boolean
}

export interface tryOtherOptions {
    firstFactor: boolean,
    secondFactor: boolean,
    ffa_OptionSelectedScreen: string,
    sfa_OptionSelectedScreen: string,
}

export interface Email {
    id: string,
    ffaEmailAttempt: number,
    sfaEmailAttempt: number,
    usable: boolean,
    isLocked: boolean,
    isSfaLocked: boolean,
    ffa_multiaccount_email_Attempt: number
}

export interface Mobile {
    id: string,
    ffaMobileAttempt: number,
    sfaMobileAttempt: number,
    usable: boolean,
    isLocked: boolean,
    isSfaLocked: boolean,
    ffa_multiaccount_phone_Attempt: number
}

export interface Selected_Email {
    id: string,
    target: string,
    type: string,
    usable: string
}

export interface Selected_Mobile {
    id: string,
    target: string,
    type: string,
    usable: string
}

export interface device_list {
    entryUUID: string,
    givenName: string,
    hrbUserName: string,
    mail: string,
    sn: string
}
export interface Name {
    firstName: string,
    lastName: string
}
export interface altName {
    name: string
}

export interface loginHistory {
    entryUUID: string,
    status: number,
    remoteIPAddress: string,
    browserVersion: string | "",
    createdOn: Date,
    signInChannel: number,
    sessionID: string,
    user2FAMethod: string,
    user2FAStatus: number,
    userAgent: string,
    browserName: string | "",
    os: string | "",
    osVersion: string | "",
    device: string | "",
    deviceType: number | "",
    deviceOrientation: string | "",
    sourceURL: string
}


export interface CreateAccUser {
    flowId: string,
    id: string,
    uuid: string,
    status: string,
    email: CaEmail,
    mobile: CaMobile,
    name: Name,
    googleAuth: GoogleAuth,
    nuCaptcha: nuCaptcha,
    refId: string,
    flow: 'Create Account'
}

export interface CaEmail {
    value: string,
    caEmailAttempt: number,
    status: string
}

export interface CaMobile {
    value: string,
    caMobileAttempt: number,
    status: string,
    isLocked: boolean
}

export interface GoogleAuth {
    attempt: number,
    isLocked: boolean
}

export interface nuCaptcha {
    attempt: number,
    token: string,
    response:any

}

export interface GA {
    sfaGAAttempt:number,
    sfaGALocked:boolean
}


export interface LoginUser {
    id: string,
    status: string,
    authStatus: string,
    refId: string

}