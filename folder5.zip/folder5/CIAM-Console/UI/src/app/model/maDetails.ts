export interface MaDetails {
    'device-0':device,
    'device-1':device
}


export interface device {
    email:string,
    phone:string,
    type:string
}