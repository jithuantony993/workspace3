import { Component, OnInit, AfterViewInit} from '@angular/core';
import { ScaleType } from '@swimlane/ngx-charts';
import { interval, Subscription } from 'rxjs';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import * as moment from 'moment';
import * as $ from 'jquery';
import 'daterangepicker';
@Component({
  selector: 'app-ciam-report-one',
  templateUrl: './ciam-report-one.page.html',
  styleUrls: ['./ciam-report-one.page.scss'],
})
export class CiamReportOnePage implements OnInit, AfterViewInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  idProofCounts : any [] = [];
  successRate : any [] = [];
  glanceHours: any = 1;
  single: any [] = [];

  time  = interval(1000);
  refresh = new Subscription();

  startDate: any;
  endDate: any;
  endDateFormated: string;
  startDateFormated: string;

  //showSection: any = false;
  block: any = false;

  showXAxis: boolean = true;
  showYAxis: boolean = true;
  gradient: boolean = false;
  showLegend: boolean = true;
  showXAxisLabel: boolean = true;
  yAxisLabel: string = 'ID Proof';
  showYAxisLabel: boolean = true;
  xAxisLabel: string = 'Success Rate (%)';

  colorScheme = {
    name: '',
    selectable: false,
    group: ScaleType.Ordinal,
    domain: ['LightSeaGreen','MediumTurquoise', 'Olive', 'ForestGreen', 'Teal', 'MediumAquamarine']
  };


  constructor(private http: HttpService, private sharedService: SharedService) { }

  ngOnInit() {
    //this.setSectionVisible();
    
    // this.UpdateHours(this.glanceHours);
    // this.refresh = this.time.subscribe(x => {
    //   if((x+1)%300 == 0)
    //     this.UpdateHours(this.sharedService.glanceHours);
    // })
  }

  // UpdateHours(event) {
  //   this.idProofCounts.splice(0);
  //   this.successRate.splice(0);
  //   this.sharedService.glanceHours = event;
  //   this.glanceHours = this.sharedService.glanceHours;
  //   this.calcData('UI-SIDP-INTIATE-API-INVOKE','UI-SIDP-SUCCESS-ONLOAD',0,0); //SIDP
  //   this.calcData('MA-APP-CARD-PROOF-INIT','CP-CARD-PIN-MATCHING-SUBMIT-SUCCESS',2,1); //CardProof
  //   this.calcData('BP-LANDING-INIT','BP-SUCCESS-INIT',4,2); //BankProof
  //   this.calcData('AOL_INIT_SUBMIT', 'AOL-SUCCESS-PAGE-INIT',6,3); //AOL
  //   this.calcData('VAOL_INIT','VAOL-SUCCESS-PAGE-INIT',8,4); //VAOL  

  //   this.calc('UI-SIDP-KBA-ANSWER','UI-SIDP-KBA-ANSWER-SUCCESS","UI-SIDP-KBA-CHALLENGE-ANSWER-SUCCESS',10,5); //SIDP - KBA
  //   this.calc('API-API-SIDP-TAXOOB-API', 'API-API-SIDP-TAXOOB-BOTHOOB-IDPROOFED-USER","API-API-SIDP-TAXOOB-SINGLEOOB-IDPROOFED-USER',12,6); //SIDP - TAXOOB
  // }

  async calc(event1,event2_1,event2_2,pos1,pos2){
    await this.getIdproofCount(event1,event2_1,event2_2,pos1);
    this.calculateRate(this.idProofCounts[pos1],this.idProofCounts[pos1+1],pos2);
    this.setGraph();
  }

  async calcData(event1,event2,pos1,pos2){
    await this.getIdproofCountData(event1,event2,pos1);
    this.calculateRate(this.idProofCounts[pos1],this.idProofCounts[pos1+1],pos2);
    this.setGraph();
  }

  async calcDataUserID(event1,event2,pos1,pos2){
    await this.getIdproofCountDataUserId(event1,event2,pos1);
    this.calculateRate(this.idProofCounts[pos1],this.idProofCounts[pos1+1],pos2);
    this.setGraph();
  }

  async calcSIDP(pos1,pos2){
    await this.getSIDPTotalAndSuccess(pos1);
    this.calculateRate(this.idProofCounts[pos1],this.idProofCounts[pos1+1],pos2);
    this.setGraph();
  }

  calculateRate(attempt, success,pos) {
    var temp :any;
    if(attempt !== undefined && success !== undefined && success !== 0 && attempt !== 0) {
      temp = parseFloat(((success/attempt) * 100)?.toFixed(2));
      this.successRate[pos] = (temp>100)? NaN : temp;
    }
    else {
      this.successRate[pos] = 0;
    }
  }

  isSuccessRateNaN(val): boolean {
    return isNaN(val);
  }

  setGraph() {
    this.single = [
      {
        "name" : "SIDP",
        "value" : (this.isSuccessRateNaN(this.successRate[0])? 0 : this.successRate[0])
      },
      {
        "name" : "CardProof",
        "value" : (this.isSuccessRateNaN(this.successRate[1])? 0 : this.successRate[1])
      },
      {
        "name" : "BankProof",
        "value" : (this.isSuccessRateNaN(this.successRate[2])? 0 : this.successRate[2])
      },
      {
        "name" : "AOL",
        "value" : (this.isSuccessRateNaN(this.successRate[3])? 0 : this.successRate[3])
      },
      {
        "name" : "VAOL",
        "value" : (this.isSuccessRateNaN(this.successRate[4])? 0 : this.successRate[4])
      }
    ]
    let idProofCount = this.single
    Object.assign(this, { idProofCount });
  }

  onSelect($event){}

  onActivate($event){}

  onDeactivate($event){}

  async getIdproofCount(event1:string,event2_1:string,event2_2:string,pos) : Promise<boolean> {
    return new Promise<boolean> ((resolve) => {
      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == '"+event1+"' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result1: any) => {
        this.idProofCounts[pos] = result1?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos+1] !== undefined) {
          resolve(true);
        }
      });

      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where (name == '"+event2_1+"' or name == '"+event2_2+"') |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result2: any) => {
        this.idProofCounts[pos+1] = result2?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos] !== undefined) {
          resolve(true);
        }
      });

      setTimeout(() => {
        resolve(false);
      },5000);
    });
  }

  async getSIDPTotalAndSuccess(pos) : Promise<boolean> {
    return new Promise<boolean> ((resolve) => {
      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == 'UI-SIDP-CLIENTMATCH-API' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result1: any) => {
        this.idProofCounts[pos] = result1?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos+1] !== undefined) {
          resolve(true);
        }
      });

      this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'API-API-SIDP-TAXOOB-BOTHOOB-IDPROOFED-USER' or name =='API-API-SIDP-TAXOOB-SINGLEOOB-IDPROOFED-USER' or name == 'UI-SIDP-KBA-ANSWER-SUCCESS' or name =='UI-SIDP_KBA_CHALLENGE_ANSWER_SUCCESS'  ) and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize Total = count() ").subscribe((result: any) => {
        this.idProofCounts[pos+1] = result?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos] !== undefined) {
          resolve(true);
        }
      });

      setTimeout(() => {
        resolve(false);
      },5000);
    });
  }

  async getIdproofCountData(event1:string,event2:string,pos) : Promise<boolean> {
    return new Promise<boolean> ((resolve) => {
      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == '"+event1+"' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result1: any) => {
        this.idProofCounts[pos] = result1?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos+1] !== undefined) {
          resolve(true);
        }
      });

      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == '"+event2+"' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result2: any) => {
        this.idProofCounts[pos+1] = result2?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos] !== undefined) {
          resolve(true);
        }
      });

      setTimeout(() => {
        resolve(false);
      },5000);
    });
  }

  async getIdproofCountDataUserId(event1:string,event2:string,pos) : Promise<boolean> {
    return new Promise<boolean> ((resolve) => {
      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == '"+event1+"' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result1: any) => {
        this.idProofCounts[pos] = result1?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos+1] !== undefined) {
          resolve(true);
        }
      });

      this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == '"+event2+"' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result2: any) => {
        this.idProofCounts[pos+1] = result2?.body?.tables[0]?.rows[0][0];

        if(this.idProofCounts[pos] !== undefined) {
          resolve(true);
        }
      });

      setTimeout(() => {
        resolve(false);
      },5000);
    });
  }

  ngAfterViewInit() {
    this.loadScript();
  }

  loadScript() {
    this.startDate = moment().subtract(1, 'day').startOf('day');
    this.endDate = moment().startOf('day');

    let startDate = moment(this.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(this.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');

    $('input[name="datetimes"]').daterangepicker({
      timePicker: true,
      startDate: this.startDate,
      endDate: this.endDate,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    });
    $('input[name="datetimes"]').on('apply.daterangepicker', ((ev, picker) => {
      this.selectedDate(picker)
    }));
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }
  selectedDate(event) {
    const startDate = moment(event.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(event.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }

  getDataByDate(startDate, endDate) {
    this.idProofCounts.splice(0);
    this.successRate.splice(0);

    this.calcSIDP(0,0); //SIDP
    this.calcDataUserID('CP-CLIENT-MATCHING-SUBMIT-INIT','CP-CARD-PIN-MATCHING-SUBMIT-SUCCESS',2,1); //CardProof
    this.calcData('BP-LANDING-INIT','BP-SUCCESS-INIT',4,2); //BankProof
    this.calcData('AOL_INIT_SUBMIT', 'AOL-SUCCESS-PAGE-INIT',6,3); //AOL
    this.calcData('VAOL_INIT-SUBMIT','VAOL-SUCCESS-PAGE-INIT',8,4); //VAOL  

    this.calc('UI-SIDP-KBA-ANSWER','UI-SIDP-KBA-ANSWER-SUCCESS','UI-SIDP_KBA_CHALLENGE_ANSWER_SUCCESS',10,5); //SIDP - KBA
    this.calc('API-API-SIDP-TAXOOB-API', 'API-API-SIDP-TAXOOB-BOTHOOB-IDPROOFED-USER','API-API-SIDP-TAXOOB-SINGLEOOB-IDPROOFED-USER',12,6); //SIDP - TAXOOB
  }

  // setSectionVisible(){
  //   if(this.sharedService.loginUser.authStatus == "AdminUser") {
  //     this.showSection = false;
  //   } else {
  //     this.showSection = true;
  //   }
  // }

  ngOnDestroy() {
    this.refresh?.unsubscribe();
  }
}
