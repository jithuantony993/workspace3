import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CiamReportOnePage } from './ciam-report-one.page';

const routes: Routes = [
  {
    path: '',
    component: CiamReportOnePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CiamReportOnePageRoutingModule {}
