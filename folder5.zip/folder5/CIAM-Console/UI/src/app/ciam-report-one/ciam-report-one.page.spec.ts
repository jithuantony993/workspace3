import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import * as moment from 'moment';
import { of } from 'rxjs';

import { CiamReportOnePage } from './ciam-report-one.page';

describe('CiamReportOnePage', () => {
  let component: CiamReportOnePage;
  let fixture: ComponentFixture<CiamReportOnePage>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ CiamReportOnePage ],
      imports: [IonicModule.forRoot(),
      HttpClientModule,
      HttpClientTestingModule,
      RouterTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(CiamReportOnePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // it('should trigger UpdateHours', () => {
  //   const event =  24;
  //   component.UpdateHours(event);
  //   expect(component.glanceHours).toBe(24);
  // });

  it('should trigger loadScript', () => {
    component.loadScript();
    expect(component.startDate).not.toBeNull();
    expect(component.endDate).not.toBeNull();
  });

  it('should trigger selectedDate', () => {
    const event = {
      startDate: moment("2023-08-01 00:00:00"),
      endDate: moment("2023-08-08 00:00:00")
    }
    component.selectedDate(event);
    expect(component.startDateFormated).toEqual("2023-07-31T18:30:00");
    expect(component.endDateFormated).toEqual("2023-08-07T18:30:00");
  });

  it('should trigger getDataByDate', () => {
    const startDateFormated = "2023-07-31T18:30:00";
    const endDateFormated = "2023-08-07T18:30:00";
    component.getDataByDate(startDateFormated,endDateFormated);
    expect(component.idProofCounts).toEqual([ ]);
    expect(component.successRate).toEqual([ ]);
  });

  it('should trigger getIdproofCount', async() => {
    let e1 = "Event1";
    let e2 = "Event2";
    let e3 = "Event3";
    const result1 = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const result2 = {
      body : {
        tables : [{
          rows : [
            [ '222' ]
          ]
        }]
      }
    }
    spyOn(component['http'], "_httpDataGet").and.returnValues(of(result1), of(result2));
    const promise = component.getIdproofCount(e1,e2,e3,0);
      await expectAsync(promise).toBeResolvedTo(true);
    spyOn(component,"getIdproofCount").and.returnValue(Promise.resolve(true));
    component.getIdproofCount(e1,e2,e3,0)
    expect(component.idProofCounts[0]).toEqual('111');
    expect(component.idProofCounts[1]).toEqual('222');
  });

  it('should trigger getIdproofCountData', async() => {
    let e1 = "Event1";
    let e2 = "Event2";
    const result1 = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const result2 = {
      body : {
        tables : [{
          rows : [
            [ '222' ]
          ]
        }]
      }
    }
    spyOn(component['http'], "_httpDataGet").and.returnValues(of(result1), of(result2));
    const promise = component.getIdproofCountData(e1,e2,0);
      await expectAsync(promise).toBeResolvedTo(true);
    spyOn(component,"getIdproofCountData").and.returnValue(Promise.resolve(true));
    component.getIdproofCountData(e1,e2,0)
    expect(component.idProofCounts[0]).toEqual('111');
  });

  it('should trigger getIdproofCountDataUserId', async() => {
    let e1 = "Event1";
    let e2 = "Event2";
    const result1 = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const result2 = {
      body : {
        tables : [{
          rows : [
            [ '222' ]
          ]
        }]
      }
    }
    spyOn(component['http'], "_httpDataGet").and.returnValues(of(result1), of(result2));
    const promise = component.getIdproofCountDataUserId(e1,e2,0);
      await expectAsync(promise).toBeResolvedTo(true);
    spyOn(component,"getIdproofCountDataUserId").and.returnValue(Promise.resolve(true));
    component.getIdproofCountDataUserId(e1,e2,0)
    expect(component.idProofCounts[0]).toEqual('111');
  });

  it('should trigger getSIDPTotalAndSuccess', async() => {
    const result1 = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const result2 = {
      body : {
        tables : [{
          rows : [
            [ '222' ]
          ]
        }]
      }
    }
    spyOn(component['http'], "_httpDataGet").and.returnValues(of(result1), of(result2));
    const promise = component.getSIDPTotalAndSuccess(0);
      await expectAsync(promise).toBeResolvedTo(true);
    spyOn(component,"getSIDPTotalAndSuccess").and.returnValue(Promise.resolve(true));
    component.getSIDPTotalAndSuccess(0);
    expect(component.idProofCounts[0]).toEqual('111');
  });

  it('should trigger calculateRate case:1', () => {
    component.calculateRate(0,1,0); //attempt = 0, Success = 1
    expect(component.successRate[0]).toBe(0);
  });

  it('should trigger calculateRate case:2', () => {
    component.calculateRate(0,0,0); //attempt = 0, Success = 0
    expect(component.successRate[0]).toBe(0);
  });

  it('should trigger calculateRate case:3', () => {
    component.calculateRate(1,0,0); //attempt = 1, Success = 0
    expect(component.successRate[0]).toBe(0);
  });

  it('should trigger calculateRate case:4', () => {
    component.calculateRate(2,1,0); //attempt = 2, Success = 1
    expect(component.successRate[0]).toBe(50);
  });

  it('should trigger isSuccessRateNaN with NaN', () => {
    expect(component.isSuccessRateNaN(NaN)).toBe(true);
  });

  it('should trigger isSuccessRateNaN with not NaN', () => {
    expect(component.isSuccessRateNaN(1)).toBe(false);
  });

});
