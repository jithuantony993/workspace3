import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportOnePageRoutingModule } from './ciam-report-one-routing.module';

import { CiamReportOnePage } from './ciam-report-one.page';
import { ImportsModule } from '../common/imports/imports.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    NgxChartsModule,
    CiamReportOnePageRoutingModule
  ],
  declarations: [CiamReportOnePage]
})
export class CiamReportOnePageModule {}
