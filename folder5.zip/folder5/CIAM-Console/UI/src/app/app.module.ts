import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injector, APP_INITIALIZER, ApplicationRef } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Router, RouteReuseStrategy } from '@angular/router';
import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { createCustomElement } from '@angular/elements';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppConfigService } from './shared-services/ciam-appconfig/app.config.service';
import { AppIncludesComponent } from './common/app-includes/app-includes.component';
import { FormatTimePipe } from './pipes/timer/format-time.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'src/environments/environment';
import { CookieService } from 'ngx-cookie-service';

import { APP_BASE_HREF} from '@angular/common';
export function initializeApp(appConfig: AppConfigService) {
  return () => appConfig.load();
}
import { CiamInterceptorService } from './shared-services/interceptors/ciam-interceptor.service';

import { HTTP } from '@ionic-native/http/ngx';
import { ImportsModule } from './common/imports/imports.module';
import { TimeFormatPipe } from './common/pipe/time-format.pipe';
import { JsonparserPipe } from './common/pipe/jsonparser.pipe';
import { DataParserPipe } from './common/pipe/data-parser.pipe';

@NgModule({
  declarations: [
    AppComponent,
    AppIncludesComponent,
    FormatTimePipe,
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
  entryComponents: [],
  imports: [BrowserModule, IonicModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ImportsModule
  ],
  providers: [AppConfigService,
              HTTP,
            CookieService,
              { provide: RouteReuseStrategy, useClass: IonicRouteStrategy },{
                provide: APP_INITIALIZER,
                useFactory: initializeApp,
                deps: [AppConfigService],
                multi: true
             },{
              provide: HTTP_INTERCEPTORS,
              useClass: CiamInterceptorService,
              multi: true
             },{
              provide: APP_BASE_HREF,
              useValue: '/'
            }],
  bootstrap: [],
})
export class AppModule {
  env = environment;
  constructor(private injector: Injector,public router: Router) {
  }

  ngDoBootstrap(appRef:ApplicationRef) {
    
    if (this.env?.name != 'release') {
      appRef.bootstrap(AppComponent);
    } else {
      const app = createCustomElement(AppComponent, { injector: this.injector });
      customElements.define('ciam-console-app', app);
    }
      
  }


}
