import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AccesstokenPageRoutingModule } from './accesstoken-routing.module';

import { AccesstokenPage } from './accesstoken.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    IonicModule,
    AccesstokenPageRoutingModule,
    ImportsModule
  ],
  declarations: [AccesstokenPage]
})
export class AccesstokenPageModule {}
