import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiRequestInterface } from '../ma-interface/api-request-interface';
import { apiResponseError } from '../ma-interface/api-response-interface';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';

@Component({
  selector: 'app-accesstoken',
  templateUrl: './accesstoken.page.html',
  styleUrls: ['./accesstoken.page.scss'],
})
export class AccesstokenPage implements OnInit {

  public isFormSubmit: boolean;
  public errMsgContent: string;
  apiEndPoints = AppConfigService?.settings?.endpoints?.console?.accesstoken;
  tokenRequest: ApiRequestInterface['tokenRequest'];
  success_response=null;
  userNotFound: boolean=false;
  constructor(private formBuilder: FormBuilder, private sharedService: SharedService,
    private http: HttpService) { }

  public tokenForm: FormGroup = this.formBuilder.group({
    email: ['', ([Validators.required])]
  }
  );
  ngOnInit() {
  }

 
  
  getAccessToken(){
    this.isFormSubmit = true;
    if (this.tokenForm.valid) {
      this.sharedService.updateLoaderStatus(true);
      this.errMsgContent = "";
      this.tokenRequest = {
        email: this.tokenForm?.value?.email
        }
      console.log(this.tokenRequest);

     this.http._post(this.apiEndPoints, this.tokenRequest).subscribe((result) => {
        this.sharedService?.updateLoaderStatus(false);
        if (result.status === 200) {
          this.success_response = result.body;
          /**Data store in shared service to access accross application */
          this.sharedService.accessToken = this.success_response?.access_token;
          this.sharedService.refreshToken = this.success_response?.refresh_token;
          this.sharedService.idToken = this.success_response?.id_token;
          /** Ends */
        
        } 
      }, (error:apiResponseError) => {
        this.userNotFound=true;
        this.sharedService?.updateLoaderStatus(false);
        this.errorHandler(error);
      })

    } 
    else {
      this.userNotFound=true;
    }
  }

  errorHandler(error:apiResponseError){
    if(error.status === 400){
      this.errMsgContent = error?.error?.errorMessage
    }else{
      
      this.tokenForm.reset();
      this.isFormSubmit = false;
      this.sharedService.invokeModel({name:'errorDialog',content:{msg:error?.error?.errorMessage}});
    }
  }

}
