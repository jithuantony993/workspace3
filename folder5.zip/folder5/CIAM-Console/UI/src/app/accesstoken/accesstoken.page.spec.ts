import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of, throwError } from 'rxjs';

import { AccesstokenPage } from './accesstoken.page';

describe('AccesstokenPage', () => {
  let component: AccesstokenPage;
  let fixture: ComponentFixture<AccesstokenPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ AccesstokenPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP, FormBuilder]
    }).compileComponents();

    fixture = TestBed.createComponent(AccesstokenPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getAccessToken', () => {
    component.tokenForm.controls['email'].setValue('test@example.com');
    let result = {
      status : 200,
      body : 'test'
    }
    spyOn(component['http'],"_post").and.returnValue(of(result));
    component.getAccessToken();
    expect(component.success_response).not.toBeNull();
  });

  it('should call getAccessToken with invalid form', () => {
    component.tokenForm.invalid;
    component.getAccessToken();
    expect(component.userNotFound).toBe(true);
  });

  it('should trigger errorHandler with 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "_post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.errMsgContent).toEqual(error.error.errorMessage);
  });

  it('should trigger errorHandler without 400', () => {
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 500,
      statusText: 'Error',
      ok: true,
      url: 'test',
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    }
    spyOn(component['http'], "_post").and.callFake(() => {
      return throwError({error});
    });
    component.errorHandler(error);
    expect(component.isFormSubmit).toEqual(false);
  });
  
  it('should trigger getAccessToken with error', () => {
    component.tokenForm.controls['email'].setValue('test@example.com');
    let error = {
      headers: 'any',
      message: 'msg',
      name: 'name',
      status: 400,
      statusText: 'Error',
      ok: true,
      url: 'test',
      errorMessage: "Error Message",
      error : {
        errorMessage: "Error Message",
        referenceId: "1"
      }
    };
    spyOn(component['http'], "_post").and.callFake(() => {
      return throwError({error});
    });
    spyOn(component,"errorHandler");
    component.getAccessToken();
    expect(component.errorHandler).toHaveBeenCalled();
    expect(component.userNotFound).toBe(true);
  });

});
