import { HttpClient, HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of } from 'rxjs';

import { PerformanceDashboardPage } from './performance-dashboard.page';

describe('PerformanceDashboardPage', () => {
  let component: PerformanceDashboardPage;
  let fixture: ComponentFixture<PerformanceDashboardPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ PerformanceDashboardPage ],
      imports: [IonicModule.forRoot(),
      FormsModule, HttpClientModule, HttpClientTestingModule,
      ReactiveFormsModule],
      providers: [FormBuilder, HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(PerformanceDashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getPingDIR', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingDIR();
    expect(component.pingDir).toEqual(123);
  });

  it('should call getPingDIR branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingDIR();
    expect(component.pingDir).not.toBeNull();
  });

  it('should call getPingDIR with AdminUser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser"
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingDIR();
    expect(component.pingDir).toEqual(123);
  });

  it('should call getPingFED', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingFED();
    expect(component.pingFed).toEqual(123);
  });

  it('should call getPingFED branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingFED();
    expect(component.pingFed).not.toBeNull();
  });

  it('should call getPingFED with Adminuser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser"
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingFED();
    expect(component.pingFed).toEqual(123);
  });

  it('should call getPingONE', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingONE();
    expect(component.pingOne).toEqual(123);
  });

  it('should call getPingONE branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingONE();
    expect(component.pingOne).not.toBeNull();
  });

  it('should call getPingOneToken', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingOneToken();
    expect(component.pingOneToken).toEqual(123);
  });

  it('should call getPingOneToken branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingOneToken();
    expect(component.pingOneToken).not.toBeNull();
  });

  it('should call getCiamServices', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [123]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getCiamServices();
    expect(component.ciamServices).toEqual(123);
  });

  it('should call getCiamServices branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getCiamServices();
    expect(component.ciamServices).not.toBeNull();
  });

  it('should call getCardOps', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getCardOps();
    expect(component.cardOps).toEqual(123);
  });

  it('should call getCardOps branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getCardOps();
    expect(component.cardOps).not.toBeNull();
  });

  it('should call getIdmServ', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getIdmServ();
    expect(component.idmServ).toEqual(123);
  });

  it('should call getIdmServ branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getIdmServ();
    expect(component.idmServ).not.toBeNull();
  });

  it('should call getApimServ', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getApimServ();
    expect(component.apimServ).toEqual(123);
  });

  it('should call getApimServ branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getApimServ();
    expect(component.apimServ).not.toBeNull();
  });

  it('should call getEmailServ', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getEmailServ();
    expect(component.emailServ).toEqual(123);
  });

  it('should call getEmailServ branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getEmailServ();
    expect(component.emailServ).not.toBeNull();
  });

  it('should call getAllLogout', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAllLogout();
    expect(component.allLogout).toEqual(123);
  });

  it('should call getAllLogout branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getAllLogout();
    expect(component.allLogout).not.toBeNull();
  });

  it('should call getNudata', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getNudata();
    expect(component.nudata).toEqual(123);
  });

  it('should call getNudata branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getNudata();
    expect(component.nudata).not.toBeNull();
  });

  it('should call getWave', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getWave();
    expect(component.wave).toEqual(123);
  });

  it('should call getWave branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getWave();
    expect(component.wave).not.toBeNull();
  });

  it('should call getWaveGraph', () => {
    const result = {
      body : {
        tables : [{
          rows : 123
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getWaveGraph();
    expect(component.waveGraph).toEqual(123);
  });

  it('should call getWaveGraph branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getWaveGraph();
    expect(component.waveGraph).not.toBeNull();
  });

  it('should call getPerformanceUrl for AdminUser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser"
    component.getPerformanceUrl();
    expect(component.performanceDataUrl).toEqual(component.performanceDataProdUrl);
  });

  it('should trigger getPerformanceBucket with all If conditions true', () => {
    component.SearchForm.controls['statusCode'].setValue(200);
    component.SearchForm.controls['url'].setValue("url");
    component.SearchForm.controls['lastHour'].setValue(24);
    const result1 = {
      body : {
        tables : [{
          rows : 111
        }]
      }
    }
    const result2 = {
      body : {
        tables : [{
          rows : 222
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValues(of(result1),of(result2));
    component.getPerformanceBucket();
    expect(component.performanceBucketAll).toEqual(111);
    expect(component.performanceBucketConsolidate).toEqual(222);
  });

  it('should trigger getPerformanceBucket branch cover', () => {
    component.SearchForm = null;
    spyOn(component['http'],"_httpDataGet").and.returnValues(of(null),of(null));
    component.getPerformanceBucket();
    expect(component.performanceBucketAll).not.toBeNull();
    expect(component.performanceBucketConsolidate).not.toBeNull();
  });

});
