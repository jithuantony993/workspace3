import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PerformanceDashboardPageRoutingModule } from './performance-dashboard-routing.module';

import { PerformanceDashboardPage } from './performance-dashboard.page';
import { ImportsModule } from '../common/imports/imports.module';
import { RouterModule } from '@angular/router';
import { ScrollingModule } from '@angular/cdk/scrolling'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    RouterModule,
    ScrollingModule,
    PerformanceDashboardPageRoutingModule
  ],
  exports: [RouterModule],
  declarations: [PerformanceDashboardPage]
})
export class PerformanceDashboardPageModule {}
