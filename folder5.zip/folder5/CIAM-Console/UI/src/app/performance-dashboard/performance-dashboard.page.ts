import { Component, OnInit } from '@angular/core';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { apiResponse } from '../ma-interface/api-response-interface';
import { FormBuilder, FormGroup } from '@angular/forms';
import { SharedService } from '../shared-services/shared/shared.service';

@Component({
  selector: 'app-performance-dashboard',
  templateUrl: './performance-dashboard.page.html',
  styleUrls: ['./performance-dashboard.page.scss'],
})
export class PerformanceDashboardPage implements OnInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  
  pingDir: any = [];
  pingFed: any = [];
  pingOne: any = [];
  pingOneToken: any = [];
  ciamServices: any = [];
  cardOps: any = [];
  idmServ: any = [];
  apimServ: any = [];
  emailServ: any = [];
  allLogout: any = [];
  nudata: any = [];
  wave: any = [];
  waveGraph: any = [];
  performanceBucketAll: any = [];
  performanceBucketConsolidate: any = [];
  performanceDataUrl: any = [];
  performanceQaDataUrl: string[] = ['dir.ent.qa.hrbe.proofidcloud.com', 'auth.ent.qa.hrbe.proofidcloud.com', 'auth.qa.hrbe.proofidcloud.com',
  'dir-qa.hrblock.com','api.pingone.com','auth.pingone.com','ciam'];
  performanceDataProdUrl: string[] = ['dir.hrbe.proofidcloud.com', 'auth.hrbe.proofidcloud.com',
  'dir.hrblock.com','api.pingone.com','auth.pingone.com','ciam'];

  constructor(private formBuilder: FormBuilder,private http: HttpService, private sharedService: SharedService,) { }
  public SearchForm: FormGroup = this.formBuilder.group({
    statusCode: ['', ([])],
    url: ['', ([])],
    lastHour: ['', ([])]
  }
  );
  ngOnInit() {
    this.getPerformanceBucket();
    this.getPingDIR();
    this.getPingFED();
    this.getPingONE();
    this.getPingOneToken();
    this.getCiamServices();
    this.getCardOps();
    this.getIdmServ();
    this.getApimServ();
    this.getEmailServ();
    this.getAllLogout();
    this.getNudata();
    this.getWave();
    this.getWaveGraph();
    this.getPerformanceUrl();
    
  }
  scrollToElement($el): void {
    console.log($el);
    $el.scrollIntoView({behavior: "smooth", block: "start", inline: "nearest"});
  }
  getPingDIR(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"dir.hrblock.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc";
    } else {
      var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"dir-qa.hrblock.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc";
    }
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingDir = result?.body?.tables[0]?.rows;
          console.log("Ping Dir");
          
    })
  }
   getPingFED(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"login.hrblock.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc";
    } else {
      var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"login-qa.hrblock.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc";
    }
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingFed = result?.body?.tables[0]?.rows;
          console.log("Ping Fed");
   })
  }
  getPingONE(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"api.pingone.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingOne = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getPingOneToken(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"auth.pingone.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingOneToken = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getCiamServices(){
    var query = "AzureDiagnostics| where ResourceType == \"APPLICATIONGATEWAYS\" and OperationName == \"ApplicationGatewayAccess\" and httpStatus_d > 199 and requestUri_s contains \"/ciam/\" and TimeGenerated > ago(1hrs) | order by TimeGenerated desc | take 100";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.ciamServices = result?.body?.tables[0]?.rows[0]?.[0];
          console.log("CIAM Services");
    })
  }
  getCardOps(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies | where name contains \"/efp/cardops\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.cardOps = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getIdmServ(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies| where name contains \"/edp/\"and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.idmServ = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getApimServ(){
    var query = "union isfuzzy=true availabilityResults,requests,exceptions,pageViews,traces,customEvents,dependencies| where name contains \"/eap/\"and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.apimServ = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getEmailServ(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"/publishemail/\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.emailServ = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getAllLogout(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"/idp/startSLO.ping\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.allLogout = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getNudata(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"api-nd.hrblock.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.nudata = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getWave(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"api.waveapps.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.wave = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getWaveGraph(){
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"gql.waveapps.com\" and toint(resultCode) > 199 and timestamp > ago(1hrs) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.waveGraph = result?.body?.tables[0]?.rows;
          console.log("Ping One");
    })
  }
  getPerformanceUrl(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      this.performanceDataUrl = this.performanceDataProdUrl;
    } else {
      this.performanceDataUrl = this.performanceQaDataUrl;
    }              
          console.log("Performance Data Url");
      
  }
  getPerformanceBucket(){
    var filterQuery= "| where ";
    if(this.SearchForm?.value?.statusCode!='' && this.SearchForm?.value?.statusCode!=undefined)
    {
      filterQuery+=" toint(resultCode) >= "+this.SearchForm?.value?.statusCode;
    }else{
      filterQuery+=" toint(resultCode) >0 ";
    }
    if(this.SearchForm?.value?.url!='' && this.SearchForm?.value?.url!=undefined)
    {
      filterQuery+=" and target contains \""+this.SearchForm?.value?.url+"\"";
    }
    if(this.SearchForm?.value?.lastHour!='' && this.SearchForm?.value?.lastHour!=undefined)
    {
      filterQuery+=" and timestamp > ago("+this.SearchForm?.value?.lastHour+"hrs) ";
    }else{
      filterQuery+=" and timestamp > ago(1hrs) ";
    }
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies "+filterQuery+" | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.performanceBucketAll = result?.body?.tables[0]?.rows;
    })
    query+=" |summarize Count=count() by performanceBucket";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
      this.performanceBucketConsolidate = result?.body?.tables[0]?.rows;
})
  }
}
