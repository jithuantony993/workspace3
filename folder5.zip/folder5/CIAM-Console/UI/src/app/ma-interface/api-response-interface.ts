export interface SuccessData {
    statusCode: number,
    statusMessage: string,
    referenceId: string,
    errorMessage: string,
    response: string
}

export interface apiResponse {
    body: any,
    headers: any,
    status: number,
    statusText: string,
    type: number,
    url: string
}

export interface apiResponseError {
    error: erroeResponseObject,
    headers: any,
    message: string,
    name: string,
    status: number,
    statusText: string,
    ok: boolean,
    url: string,
    errorMessage?:string
}

export interface erroeResponseObject {
    errorMessage: string
    referenceId: string
}

export interface verifyEmailResponse extends common_response {
    isEmailAvailable: boolean
}

export interface MAAPPConfig extends UpdatePassword {
    env: {
        name: string;
        appURL : string;
        imgPath : string;
        iconPath : string;
    };
    server: {
        consoleBaseApiUrl: string;
    };
    endpoints: {
       
        console: {
            login,
            appinsights,
            appinsightsProd,
            accesstoken,
            guid,
            generateHash,
            getIdentifierHash,
            fetchCodeFromMalinator,
            getDetailsEmail,
            getDetailsPhone,
            getDetailsUcid
        },tools:{
            getByLogin,
            getByEmail,
            userLoginHistory,
          }
        signin : {
            initiateAuth
        }
        logout:{
            logout_base,
            target_resource
        }    
    };
    ldClient: {
        key: string,
        ldUser: string;
    };
     dtm:{
         url:string
     }
    launch: {
        url: string
    };
    limit: {
        interval: number,
        idleTimeOut:number,
        idlePopTimer:number,
        initiateAuthTimer:number
    };
    pingConfig : {
        host:{
            pingdirHostname,
            pingfedHostname
        }
    },  appInsightKey:string,
    SPRedirectURI:{
        LoginRouterApp,
        MyBlockApp,
        TXOApp,
        ChrysalisApp
    }
}

export interface UpdatePassword {
    updatepassword: string
}

export interface create_account_success_response extends common_response {
    entryUUID: "string"
}
export interface create_account_sec_screen_success_response extends common_response {
    entryUUID: "string"
}


export interface verify_obb_success extends common_response {
    entryUUID: string,
}

/**Update mobile success */
export interface update_mobile_success extends common_response {
    entryUUID: string,
}

/**Update email success */
export interface update_email_success extends common_response {
    entryUUID: string,
}

/**Resend device obb success response  */
export interface verify_device_resend_obb_success extends common_response {

}

/**Create profile post request response */
export interface create_profile_post_response extends common_response {  
    entryUUID: string,
}

export interface user_login_response extends common_response {  
    authStatus: string,
}

export interface skip_for_now_response extends common_response{
    entryUUID: string
}
export interface common_response {
    statusMessage: string,
    referenceId: string,
    errorMessage: string,
    statusCode: number,
    id: string,
    type: string,
    status: string,
}


export interface apiResponseLog {
    tables: Table[]
  }
  
  export interface Table {
    name: string
    columns: Column[]
    rows: number[][]
  }
  
  export interface Column {
    name: string
    type: string
  }
  
  export interface UserInfoResponseResult {
    userAttributes : {
       uid : string
       uname : string
       lastlogindate : string
       isactive : boolean
       currentLoginDate : string
       waveAccessToken : string
       passwordResetMobile : string
       mail : string
       ucid : string
       useridtoken : string
       hashedciamId : string
       signature : string
       mobile : string
       idHash : string
    }
    identityAttributes : {
        idproofing : {
            signature : string
            IDPChannel : number
        }
        cardproofing : {
            cardProofingSignature : string 
        }
        bankingProofing : {
            bankIDPStatus : string
            bankIDPSoftFail : string
            bankIDPHardFail : string
        }
        vaolProofing : {
            vaolWorkspaceID : any
            vaolTaxYear : number
        }
        aolProofing : {
            userGuid : any
        }
        paperlessProofing : {
            taxWorkSpaceID : any
            taxReturnGuid : any
        }
        irsDetails : {
            emailIDOOB : string
            mobilePhoneOOB : string
            machineAuthentication : number
            passwordResetCurrent : number
            passwordResetLast : number
            emailIDResetCurrent : number
            emailIDResetLast : number
            mobilePhoneResetCurrent : number
            mobilePhoneResetLast : number
            identityProofingLevel : number
            tokenAuthenticationLevel : string
            identityAssuranceLevel : string
            authenticationReviewCode : number
        }
    }
}