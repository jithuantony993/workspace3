export interface ApiRequestInterface extends nuDetect {

    user_login : {
        credential: string,
        email?: string
    }

    tokenRequest:{
        email: string
    }
    
}

export interface nuDetect {
    placement: string | number,
    placementPage: string | number,
    sessionId: string | number,
    widgetData: any,
    nudata:nuData
}
export interface nuData {
    remoteAddress: string,
    schema: string,
    serverName: string,
    userName: string,
    requestURI: string,
    userAgent: string,
    xForwardedFor: string,
    validationStatus: true
  }
