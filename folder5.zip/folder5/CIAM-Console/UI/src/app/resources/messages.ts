
export const CIAM = {
    next_btn_lbl: "Next",
    cancel_btn_lbl: "Cancel",
    back_btn_lbl: "Back",
    reference_Id: " ID :"
}

export const CREATE_ACCOUNT = {
    heading: "Create your account.",
    sub_heading: "Have an account?",
    sub_heading_link: " Sign in",
    privacy_policy: "Privacy policy.",
    license_agreement: "License agreement.",
    primary_button: "Next",
    email: "Email",
    password: "Password",
    cnf_Password: "Confirm Password",
    remember_device: "Remember this device.",
    agree_content_one: "I agree to the terms and conditions of the",
    agree_content_two: "Electronic Communications Consent",
    agree_content_three: " and the ",
    agree_content_four: "Online Service Agreement",
    agree_content_five: ", which includes the requirement that any dispute be resolved through binding arbitration. I also acknowledge that the H&R Block ",
    agree_content_six: "Privacy Notice",
    agree_content_seven: " was made available to me.",
    agreementPolicy: "I agree to H&R Block's Online Services Agreement which includes the requirement that any dispute be resolved through binding arbitration. I have also received H&R Block's Privacy Notice.",
    email_not_available: "Account already exists for this email.",
    invalid_email: "Enter a valid e-mail address"
};

export const CIAM_VALIDATE_OOB = {
    heading: "Enter the code we emailed you.",
    body: "We sent the code to your email ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    resend_code_link_label: "Resend security code",
    //resend_heading_one: "Haven't recieved my code.",
    edit_email_verification_screen: "Edit email from account creation email verification screen.",
    invalid_code: "Sorry, we don't recognize this security code. Please try again.",
    resend_heading_one: "Uh oh! I haven't received my code.",
    resend_msg: "Still not receiving it? Click the button below to generate a new code.",
    check_junk: "Check your junk mail folder or wait a few minutes.",
    go_back: "Go Back",
    resend: "Resend Code"
}

export const CIAM_BROWSER_BACK_BUTTON = {
    browserBack_heading_one: "Browser Controls Inactive",
    browserBack_heading_two: "Sorry - you can't use your browser's Back button to return to a previous screen.",
    back_btn_lbl: "OK"
};

export const CIAM_ERROR_BANNER = {
    error_btn_lbl: "Close error message",
    error_msg: "Please review the following information."
}

export const CIAM_FOOTER = {
    helpPassword: "password ",
    copyright: "Copyright © 2020-2021 HRB Digital LLC. All rights reserved "
}

export const CIAM_PASSWORD_HELP = {
    helpPassword: "Valid password criteria",
    password_length: "8-30 characters",
    password_upCase: "One uppercase letter",
    password_lwCase: "One lowercase letter",
    password_specialChar: "One special character (Ex: $,#,% or !)",
    password_num: "One number"
}

export const CIAM_IDLE_TIME_POPUP = {
    idle_timeout_heading_one: "Anybody there?",
    idle_timeout_heading_two: "You'll be signed out of your account in one minute due to inactivity.",
    idle_timeout_signOut_button: "SIGN OUT",
    idle_timeout_stayIn_button: "STAY SIGNED IN"
};

export const CIAM_SINGIN = {
    heading: "Sign in to your account.",
    dont_have_account: "Don’t have an account?",
    create_account: "Create account",
    email: "Email",
    password: "Password",
    remember_device: "Remember this device",
    ff_link_label: "Forgot your username or password?",
    signin_btn_label: "Sign in",
    osa_link_label: "Terms & Condition"
};

export const CIAM_HEADER = {
    hrblogo: "Hrb logo.",
    lending_tree_logo: "Lending Tree logo",
    stride_logo: "Stride logo",
    mos_logo: "Mos logo"
};
export const EULA_OSA_PAGE = {
    heading: "ONLINE SERVICES AGREEMENT",
    table_of_contents: "TABLE OF CONTENTS",
    introduction: "1. Introduction",
    your_use_of_the_products_and_services: "2. Your Use of The Products and Services",
    intellectual_property_rights: "3. Intellectual Property Rights",
    your_privacy: "4. Your Privacy",
    your_access_to_products_and_Services: "5. Your Access to Products and Services",
    the_products_and_services: "6. The Products and Services",
    limited_guarantees: "7. Limited Guarantees",
    disclaimer_of_Warranties: "8. Disclaimer of Warranties",
    limitations_on_liability_and_damages: "9. Limitations on Liability and Damages",
    indemnification: "10. Indemnification",
    arbitration_if_a_dispute_arises: "11. ARBITRATION IF A DISPUTE ARISES (" + '"Arbitration Agreement"' + ")",
    consent_to_electronic_communication: "12. SMS Text Messages",

    termination_of_this_agreement: "13. Termination of this Agreement",
    other: "14. Other",
    definitions: "15. Definitions",
    copy_rights: "Copyright © 2021-2022 HRB Digital LLC. All rights reserved."

}
export const CIAM_SUCCESS = {
    success_msg: "Congrats! Your account is all set.",
    success_msg_sub: "Don't forget, you can always update your account information later.",
    success_button: "Done"
}

export const CIAM_PROFILE = {
    heading: "Add info to help secure your account.",
    first_name: "First name",
    last_name: "Last name",
    back_btn_label: "Cancel",
    create_accnt_btn_label: "Create account",
    sign_in_account: "Sign in",
    have_account: "Have an account?",
    client_error: "Please Provide valid details"
}

export const CIAM_MOBILE_VALIDATE_OOB = {
    heading: "Enter the code we sent you.",
    body: "We sent the code to your number ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    skip_for_now: "Skip for now",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    edit_mobile_verification_screen: "Edit mobile number from account creation mobile verification screen.",
    invalid_code: "Sorry, we don't recognize this security code. Please try again.",
    try_another_way: "Try another way"
}
export const ECC_EULA = {
    heading_main: "Electronic Communications Consent",
    heading_sub: "Tax Year 2021",
    introduction: "1. Consent to electronic communication.",
    para_1: "This Electronic Communications Consent (" + '"' + "Consent" + '"' + ") provides important information required by the Electronic Signatures in Global and National Commerce Act (E-SIGN Act) and your consent to electronic delivery of any Communications relating to your use of any Products and Services (defined below) or your relationship with us. You are not required to consent to receiving disclosures electronically, but if you do not consent, you may not be able to proceed with using the Products and Services electronically. References to " + '"' + "you" + '"' + " or " + '"' + "your" + '"' + " herein refers to the individual(s) applying for or receiving any Products and Services. References to " + '"' + "we" + '"' + " or " + '"' + "us" + '"' + " herein refers to HRB Tax Group, Inc., HRB Digital LLC, and MetaBank®, National Association, as well their respective affiliates, or the franchisees of any of them, as applicable. " + '"' + "Products and Services" + '"' + " means any products or services you apply for or receive while in an H&R Block office or through an H&R Block website, whether offered by HRB Tax Group, Inc., MetaBank, or one of their respective affiliates or franchisees.",
    software_content_li_1: "(A) a Current Version (defined below) of Internet Explorer, Chrome, Safari, or Firefox;",
    software_content_li_2: "(B) an internet connection;",
    software_content_li_3: "(C) an email account and related software for accessing the email account;",
    software_content_li_4: "(D) a Current Version of a program that accurately receives, accesses, and displays PDF files; and",
    software_content_li_5: "(E) a device with an operating system capable of supporting all of the above. You will need a printer if you wish to print and retain paper records or sufficient electronic storage capacity if you wish to retain records in",
    software_content_li_6: "electronic form.",
    software_content_li_7: '"' + "Current Version" + '"' + " means a version of the software that is currently being supported by its publisher.",
    heading_sub_5: " Withdrawing consent and updating information.",
    sub_para_head_2: "Scope of consent.",
    para_2: "You agree that any Communication (defined below) we provide may be in electronic form, and that all Communications in electronic format from us to you will be considered " + '"' + "in writing." + '"' + " Your consent to receive Communications electronically applies to all Communications relating to your use of the Products and Services or your relationship with us. You also agree that we do not need to provide you with an additional paper (non-electronic) copy of the Communications unless specifically requested as described below. You should print or download for your records a copy of any Communication that is important to you. This Consent does not require us to deliver Communications electronically, and we may provide paper copies of Communications at our discretion. " + '"' + "Communications" + '"' + " means all notices, disclosures (including those required by law), agreements, fee schedules, tax returns, records, documents, account statements or other information we provide to you or that you sign or agree to relating to your use of Products and Services.",
    sub_para_head_3: "Method of delivery.",
    para_3: "We may provide electronic Communications to you in at least one of the following methods:",
    para_3_content_li_1: "(A) via email at the email address you provided to us;",
    para_3_content_li_2: "(B) by access to a designated area of one of our websites (e.g., MyBlock℠ or within a" +
        "mobile app); or",
    para_3_content_li_3: "(C) during your use of our systems including, without limitation, via a screen or page" +
        "within the Products and Services, one of H&R Block's websites or your MyBlock account, or via a link to a web" +
        "page containing the Communications.",
    sub_para_head_4: "Hardware and software requirements.",
    para_4: "To access Communications, you must have the following:",
    sub_para_head_6: "Obtaining paper copies.",
    para_6: "You have the right to receive a paper copy of Communications. You may request paper copies of" +
        " Communications by calling 1-800-HRBLOCK. We must receive your request within a reasonable time after we first" +
        " provided the Communication to you.",
    sub_para_head_7: "Withdraw consent or update information.",
    para_7_content_li_1: "If you want to withdraw your consent to" +
        " receive Communications electronically or update your information, including a change to your email address," +
        " you must notify us in writing at the following address: HRB Digital LLC, Attn: Client Services 6th Floor, P.O." +
        " Box 10435, Kansas City, Missouri 64171-0435. Please provide your physical address, email address, and phone" +
        " number to request the change. If you fail to notify us of a change in email address, you understand and agree" +
        " that any communications sent via email will be deemed to have been provided or made available to you in" +
        " electronic form.",
    sub_para_head_8: "Result of withdrawing consent. ",
    para_8_content_li_1: "If you choose to withdraw your consent to receive" +
        " Communications electronically, then you may be unable to access certain features or functionality of Products" +
        " and Services. In some cases, your decision to withdraw your consent to receive Communications electronically" +
        " may impede the functionality and features of the Products and Services to an extent that your ability to use" +
        " the Products and Services is terminated. You acknowledge that some notices may be " + '"' + "one-time" + '"' + " notices for which" +
        " your consent may not practically be withdrawn after receiving the initial electronic notice.",
    sub_para_head_9: "Confidentiality/Limitation of Liability.",
    para_9_content_li_1: "You have the right to receive a paper copy of Communications. You may request paper copies of" +
        " You understand that the Communications may be confidential in nature. We are not responsible for unauthorized" +
        " access by third parties to information and/or communications provided electronically or for any damages," +
        " including direct, indirect, special, incidental or consequential damages, caused by unauthorized access. If you" +
        " have any questions about these disclosures, you may contact us by telephone at 1-800-472-5625 (1-800-HRBLOCK).",
    copy_right: "Copyright © 2021-2022 HRB Digital LLC. All rights reserved."

}
export const CA_MOBILE_UPDATE = {
    heading_main: "Add two-step verification.",
    sub_head_1: "We'll use this number to help you sign in on",
    sub_head_2: "unrecognized devices and to speed up your taxes.",
    footer_head: "We'll text you a security verification code.",
    button_caption: "Send code",
    see_other_options: "See other options"
}
export const CA_EMAIL_UPDATE = {
    heading_main: "Update your email address.",
    sub_head_1: "We'll use this email to help you sign in on",
    sub_head_2: "unrecognized devices and to speed up your taxes.",
    button_caption: "Send code"
}
export const SIGN_SUCCESS = {
    success_head: "Welcome back",
    success_head2: "!",
    success_msg: "Two-factor authentication is enabled for",
    success_msg2: "your account so we'll ask you to verify",
    success_msg3: "one more time to keep your account",
    success_msg4: "secure.",
    button_text: "Continue"
}
export const CIAM_FFA_PASSWORD = {
    heading_main: "Enter your password.",
    dtm_tracker: "FFA Password Screen",
    password: "Password",
    signin_btn_label: "Sign In",
    second_heading: "Or skip the password and login with a one-time security code.",
    second_heading_lock: "Login with a one-time security code.",
    third_heading: "Where would you like us to send your one-time code?",
    txt_number: "Text my primary phone number",
    txt_mail: "Email my primary address",
    primary_phone: "Primary phone for OBB verification",
    primary_email: "Primary Email-Id for OBB verification",
    invalid_password: "The password you entered is incorrect."
}
export const FFA_MOBILE_VALIDATE_OOB = {
    heading: "Enter the code we sent you.",
    body: "We sent the code to your number ending in ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    skip_for_now: "Skip for now",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    edit_mobile_verification_screen: "Edit mobile number from account creation mobile verification screen.",
    invalid_code: "The code you entered is incorrect.",
    continue_button: "Continue",
    try_another_way_link: "Try another way",
}

export const CIAM_FFA_EMAIL_VALIDATE_OOB = {
    heading: "Enter the code we sent you.",
    body: "We sent the code to your email ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    edit_email_verification_screen: "Edit email from account creation email verification screen.",
    invalid_code: "The code you entered is incorrect.",
    try_another_way_link: "Try another way",
}
export const SFA_MOBILE_VALIDATE_OOB = {
    heading: "Enter the code we sent to ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    skip_for_now: "Skip for now",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    edit_mobile_verification_screen: "Edit mobile number from account creation mobile verification screen.",
    invalid_code: "The code you entered is incorrect.",
    continue_button: "Continue",
    try_another_way_link: "Try another way",
}
export const CIAM_SFA_OPTIONS = {
    heading: "Almost done! Only one step left.",
    sub_heading: "We don't recognize your device. Choose a way to confirm you're really you.",
    enter_password_label: "Enter password",
    confirm_id_label: "Confirm ID via questions",
    confirm_id_sub_label: "Includes past addresses and other personal info.",
    answer_security_label: "Answer security questions",
    answer_security_sub_label: "These are questions you set up when you made your account",
    emeralid_card_label: "Use my EmeralId Card info",
    show_additional_label: "Show additional options",
    hide_additional_label: "Hide additional options",
    email_text: "Get an email at",
    mobile_text: "Text me at",
    next_btn: "Next",
    onetime_passcode: "One Time Passcode",
    google_authenticator: "Google Authenticator"
}


export const CIAM_SFA_EMAIL_VALIDATE_OOB = {
    heading: "Enter the code we sent to",
    //body: "We sent the code to your email ",
    try_another_way_link: "Try another way",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    edit_email_verification_screen: "Edit email from account creation email verification screen.",
    invalid_code: "The code you entered is incorrect."
}

export const CIAM_USER_LOOKUP = {
    heading: "Sign in to your account.",
    sub_heading: "Enter your username, email, or mobile number to get started.",
    dont_have_account: "Don’t have an account?",
    create_account: "Create Account",
    mobileemail: "Username, email, mobile",
    continue_btn_label: "Continue",
    or: "OR",
    not_found: "Account not found."
};

export const CIAM_PASSWORD_RESET_SUCCESS = {
    success_msg: "Success! Your new password is all set.",
    success_msg_sub: "Let's get you into your account.",
    success_button: "Done"
};
export const RESET_PASSWORD = {
    heading_main: "Reset your password",
    btn_caption: 'Next',
    password: 'Password',
    cnf_password: 'Confirm password'

};

export const CA_SFA_PASSWORD = {
    heading_main: "Enter your password",
    dtm_tracker: "SFA Password Screen",
    password: "Password",
    next_btn_label: "Next",
    try_btn_label: "Try another way",
    invalid_password: "The password you entered is incorrect."
};

export const CIAM_COMMON_CONSTANTS = {
    period: ".",
    question_mark: "?",
    ambersand: "&",
    equal_to: "="
}

export const CIAM_SI_USER_LISTING = {
    heading: "Good news! We found your account.",
    username: "Username",
    search_link: "Search for a different account",
    last_signin_label: "Last Sign in",
    continue_btn: "Continue"
}
export const FFA_MULTIACC_MOBILE_VALIDATE_OOB = {
    heading: "Enter the code we sent you.",
    body: "We sent the code to your number ending in ",
    security_code_lbl: "Verification code",
    resend_code_link: "I still haven't received my code.",
    cancel_btn: "Cancel",
    resend_code_link_label: "Resend security code",
    resend_heading_one: "Haven't recieved my code.",
    invalid_code: "The code you entered is incorrect."
}

export const KBA_QUESTIONS = {
    heading_one: "Answer a few questions for verification.",
    heading_two: "To make sure your documents are secure, you have five minutes to answer these questions.",
    next_btn: "Continue",
}

export const KBA_CHQNS_QUESTIONS = {
    heading: "Answer for the primary taxpayer.",
    next_btn: "Next",
}

export const KBA_PII = {
    heading: "Let's make sure you're you.",
    sub_heading: "Enter your details exactly as they appeared on your last tax return.",
    first_name: "First name",
    last_name: "Last name",
    ssn: "Social Security Number (SSN)",
    dob: "Date of birth",
    zip_code: "Zip code",
    continue_btn: "Continue",
    back_link: "back to SFA Options",
    back_btn: "Back",
    try_another_way_link: "Try another way",
}

export const KBA_PII_SUCCESS = {
    heading: "Got it. Thanks!",
    success_msg1: "Now we just need you to answer a few",
    success_msg2: "questions about yourself to verify your",
    success_msg3: "identity.",
    next_btn: "Next"
}

export const INTL_MOBILE = {
    invalid_mobile: "Enter a valid mobile number.",
    required: " Enter a mobile number.",
    intl_phone_legend: "We'll text you a security verification code."
}
export const SIGN_IN_FAILURE = {
    heading: "Uh oh! We couldn't sign you in",
    button_txt: "Try again"

}

export const ACCOUNT_LOCK = {
    heading: "Your account is temporarily locked.",
    body_txt: "For your security, we’ve locked this account due to too many attempts to sign in. You can try to sign in again in 20 minutes.",
    button_txt: "Got it"

}
export const two_step_verification = {
    heading: "Two-step verification.",
    text: "These are secure ways to ensure you're you when you sign in from a device we don't recognize.",
    heading_two: "Recommended",
    Text_heading: "Text Message",
    Setup_link: "Set up",
    Google_Authenticator: "Google Authenticator",
    heading_three: "Other options",
    Email_text: "Email",
    Skip_link: "Skip for now"

}

export const SILA = {
    next_btn: "Next",
    heading: "We've updated our terms & policies.",
    privacy_policy: "Privacy policy.",
    primary_button: "Next",
    agree_content_one: "I agree to the terms and conditions of the",
    agree_content_two: "Electronic Communications Consent",
    agree_content_three: " and the ",
    agree_content_four: "Online Service Agreement",
    agree_content_five: ", which includes the requirement that any dispute be resolved through binding arbitration. I also acknowledge that the H&R Block ",
    agree_content_six: "Privacy Notice",
    agree_content_seven: " was made available to me.",
    agreementPolicy: "I agree to H&R Block's Online Services Agreement which includes the requirement that any dispute be resolved through binding arbitration. I have also received H&R Block's Privacy Notice.",
    bank_agree_content_one: "I agree to",
    bank_agree_content_two: "Online Banking Agreement."
};
export const OMBA = {
    heading_main: "ONLINE AND MOBILE BANKING AGREEMENT",
    table_of_contents: "TABLE OF CONTENTS",

    table_of_contents_1: "1.Introduction",
    table_of_contents_2: "2.Definitions",
    table_of_contents_3: "3.The Services",
    table_of_contents_4: "4.Available Services",
    table_of_contents_5: "5.ELECTRONIC FUND TRANSFER ACT DISCLOSURES",
    table_of_contents_6: "6.ARBITRATION IF A DISPUTE ARISES (\"Arbitration Agreement\")",
    table_of_contents_7: "7.General Provisions Relating to this Agreement",

    introduction: "1. Introduction",
    Definitions: "2.Definitions.",
    Access_Credentials: "2.1 \"Access Credentials\"",
    Account: "2.2 \"Account\"",
    Account_Alerts: "2.3 \"Account Alerts\"",
    Agreement: "2.4 \"Agreement\"",
    Bill_Pay_Service: "2.5 \"Bill Pay Service\"",
    Business_Day: "2.6 \"Business Day\"",
    CardAccount: "2.7 \"Card Account\" or \"Emerald Card Account\"",


};

export const SILA_ERROR_BANNER = {
    terms_condition_error: "Error: You must agree to the Electronic Communications Consent, Online Services Agreement, and Privacy Notice.",
    bank_terms_condition_error: "Error: You must agree to the Online Banking Agreement."
};

export const GOOGLE_AUTH_SUCCESS = {
    heading1: "Google",
    heading2: "Authenticator",
    heading3: "is activated.",
    body_txt: "You can manage this in your account settings.",
    button_txt: "Got it"
};

export const GOOGLE_AUTH = {
    heading_one: "Connect Google Authenticator.",
    heading_link: "What's Google Authenticator?",
    sub_heading_one: "1. Get the app",
    sub_heading_two: " 2. Connect it.",
    sub_heading_three: "3. Confirm it.",
    content_one: "Download the Google Authenticator app to your iOS or Android device.",
    content_two: "Copy this code and enter it in the app.",
    content_three: "Enter the six- digit code it generates.",
    ga_input_label: "Google Authenticator code",
    copy_code: "COPY CODE",
    ga_next_btn: "Next",
    ga_cancel_btn: "Cancel",
    ga_help_page_heading_one: "What's Google Authenticator?",
    ga_help_page_paragraph_one: "Google Authenticator is an app that generates one- time use verification codes.",
    ga_help_page_paragraph_two: " If you set up Google Authenticator, we'll ask you to enter the code it generates. This proves it's your account when you sign in from a device we don't recognize.",
    ga_help_page_paragraph_three: " If you don't use Google Authenticator, you can verify your account another way."
};

export const NUCAPTCHA_FAILURE = {
    heading1: "Sorry,but we can't",
    heading2: "sign you in.",
    body_txt1: "Please try again with a different browser or come",
    body_txt2: "back later.",
    button_txt: "Got it"
};
export const NUCAPTCHA_HELPER = {
    heading1: "Having trouble with the code?",
    body_txt1: "If you are having troubleseeing or entering your code,try any of these fixes:",
    nucaptcha_para_one: "Switch to a different internet browser.",
    nucaptcha_para_two: "Try switching to a new device.For Ex:If you are on your smartphone, use a desktop computer or laptop instead.",
    nucaptcha_para_three: "Leave this page and wait for a few minutes before trying to sign in again.",
    button_txt: "Got it"
};


export const SIGN_IN_GOOGLE_AUTH = {
    heading_one: "Enter the code from Google Authenticator.",
    ga_next_btn: "Next",
    ga_cancel_btn: "Cancel",
    ga_input_label: "Google Authenticator code",
    try_another_way_link: "Try another way",
    invalid_code: "Sorry, We don't recognize this code. Please try again.",
}

export const VERIFY_CAPTCHA = {
    heading: "Let's make sure you are human",
    heading_1: "Enter the code you see so we know you are not a bot",
    heading_2: "Uh-oh! That was'nt quite right.",
    heading_3: "Enter the new code or choose new code to get new letters.",
    trouble_link: "Having trouble?",
    submit_btn: "Submit"
}

