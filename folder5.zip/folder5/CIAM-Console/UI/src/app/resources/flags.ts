export const Toggles = {
    _ciam_reference: "ciam-reference",
    _ma_enable_2fa_options: "ma-enable-2fa-options",
    _signin_seq_nav_feature: "signin-seq-nav-feature"
    
};

export const Contents = {
    _ciam_reference: "ciam-reference",
    _ma_enable_2fa_options: "ma-enable-2fa-options",
    _intl_country_codes: "intl-country-codes"
   
};

export const TempFlags = {
    _temp_flag_eula_prompt: "temp-flag-eula-prompt"
};

export const FeatureFlags = {
    _temp_flag_eula_prompt: "temp-flag-eula-prompt"
};

export const BiometricFlag = {
  _temp_flag_enable_biometric_methods: "temp-flag-enable-biometric-methods"
};
