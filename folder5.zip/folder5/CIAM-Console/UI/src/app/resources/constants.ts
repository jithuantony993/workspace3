export const rensed_delay = {
    delay : 10
}
export const CIAM_TAGS = {
    CIAM_APP_INIT : "CIAM-APP-INIT"
}
export const CIAM_GAURD_TAGS = {
    MA_GUARD_BACK : "MA-GUARD-BACK"
}


