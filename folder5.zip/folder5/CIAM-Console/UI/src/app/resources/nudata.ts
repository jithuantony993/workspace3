export enum NUDATA_PLACEMENTS {
    HRB_Login = 'HRBLogin',
    HRB_Create_Account = 'HRBCreateAccount',
    HRB_ID_Proof = 'HRBIDProof', 
    HRB_Account_Lookup = 'HRBAccountLookup', 
  }
  export enum NUDATA_PLACEMENT_PAGES {
    HRB_Login = 1,
    HRB_Create_Account = 2,
    HRB_ID_Proof = 3,
    HRB_Account_Lookup = 4,
  }