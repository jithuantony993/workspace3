export const TAG_DATA = {
    "SI-APP-ONLOAD": "Loading SIGNIN APP",
    "SI-LOOKUP-INITIATE-CALL": "User Lookup initiate call",
    "SI-EVENT-BACK-TO-PARENT":"Control back to parent APP"
}