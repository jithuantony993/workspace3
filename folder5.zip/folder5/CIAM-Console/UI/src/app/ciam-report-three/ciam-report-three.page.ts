import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciam-report-three',
  templateUrl: './ciam-report-three.page.html',
  styleUrls: ['./ciam-report-three.page.scss'],
})
export class CiamReportThreePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
