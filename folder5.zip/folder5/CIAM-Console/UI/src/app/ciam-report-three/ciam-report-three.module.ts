import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportThreePageRoutingModule } from './ciam-report-three-routing.module';

import { CiamReportThreePage } from './ciam-report-three.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamReportThreePageRoutingModule
  ],
  declarations: [CiamReportThreePage]
})
export class CiamReportThreePageModule {}
