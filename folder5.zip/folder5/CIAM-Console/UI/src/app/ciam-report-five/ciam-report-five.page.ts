import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ciam-report-five',
  templateUrl: './ciam-report-five.page.html',
  styleUrls: ['./ciam-report-five.page.scss'],
})
export class CiamReportFivePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
