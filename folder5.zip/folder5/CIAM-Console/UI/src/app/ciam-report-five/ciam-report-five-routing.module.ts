import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CiamReportFivePage } from './ciam-report-five.page';

const routes: Routes = [
  {
    path: '',
    component: CiamReportFivePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CiamReportFivePageRoutingModule {}
