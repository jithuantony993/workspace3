import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportFivePageRoutingModule } from './ciam-report-five-routing.module';

import { CiamReportFivePage } from './ciam-report-five.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamReportFivePageRoutingModule
  ],
  declarations: [CiamReportFivePage]
})
export class CiamReportFivePageModule {}
