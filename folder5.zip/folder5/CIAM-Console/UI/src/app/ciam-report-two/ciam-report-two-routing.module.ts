import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CiamReportTwoPage } from './ciam-report-two.page';

const routes: Routes = [
  {
    path: '',
    component: CiamReportTwoPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CiamReportTwoPageRoutingModule {}
