import { Component, OnInit } from '@angular/core';
import { ScaleType } from '@swimlane/ngx-charts';
import * as moment from 'moment';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import * as $ from 'jquery';
import 'daterangepicker';

@Component({
  selector: 'app-ciam-report-two',
  templateUrl: './ciam-report-two.page.html',
  styleUrls: ['./ciam-report-two.page.scss'],
})
export class CiamReportTwoPage implements OnInit {

  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  public login_loginSuccessRate:number=0;
  public login_distinctLoggedIn:number=0;
  public login_newAccountCreated:number=0;
  public login_totalUniqueCount:number=0;
  public from_Date:string;
  public to_Date:string;

  public showSection:boolean=false;
  public showPIIFail:boolean=true;
  //Account creation and Login
  public CA_Attempt:number=0;
  public CA_Created:number=0;
  public CA_PII_Failed:number=0;
  public CA_Email_Failed:number=0;
  public CA_Email_Success:number=0;
  public Login_Attempt:number=0;
  public Login_Success:number=0;

  public Login_Success_Rate:number=0;
  public CA_Success_Rate:number=0;

  //Date picker
  startDate: any;
  endDate: any;

  //FFA - SMS OOB
  public FFA_SMS_loginSuccessRate:number=0;
  public FFA_SMS_loginSuccessCount:number=0;
  public FFA_SMS_totalUniqueCount:number=0;

    //FFA - Email OOB
    public FFA_Email_loginSuccessRate:number=0;
    public FFA_Email_loginSuccessCount:number=0;
    public FFA_Email_totalUniqueCount:number=0;

    //SFA - SMS OOB
    public SFA_SMS_loginSuccessRate:number=0;
    public SFA_SMS_loginSuccessCount:number=0;
    public SFA_SMS_totalUniqueCount:number=0;
  
      //FFA - Email OOB
      public SFA_Email_loginSuccessRate:number=0;
      public SFA_Email_loginSuccessCount:number=0;
      public SFA_Email_totalUniqueCount:number=0;

   //Google Auth
   public Google_Auth_loginSuccessRate:number=0;
   public Google_Auth_loginSuccessCount:number=0;
   public Google_Auth_totalUniqueCount:number=0;

   //KBA
   public KBA_loginSuccessRate:number=0;
   public KBA_loginSuccessCount:number=0;
   public KBA_totalUniqueCount:number=0;

   //FFA PWD
   public FFA_PWD_loginSuccessRate:number=0;
   public FFA_PWD_loginSuccessCount:number=0;
   public FFA_PWD_totalUniqueCount:number=0;

      //SFA PWD
      public SFA_PWD_loginSuccessRate:number=0;
      public SFA_PWD_loginSuccessCount:number=0;
      public SFA_PWD_totalUniqueCount:number=0;
 
  successRateData: any[]= [];
  ffaSMSOOBSuccessRateData: any[]= [];
  ffaEmailOOBSuccessRateData: any[]= [];
  sfaSMSOOBSuccessRateData: any[]= [];
  sfaEmailOOBSuccessRateData: any[]= [];
  GoogleAuthSuccessRateData: any[]= [];
  KBASuccessRateData: any[]= [];
  FFAPWDSuccessRateData: any[]= [];
  SFAPWDSuccessRateData: any[]= [];
  view: [number, number] = [700, 300];

  // Login options
  legend: boolean = false;
  legendTitle: string = 'Year';
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showLegend : boolean = false;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  showGridLines: boolean = false;
  xAxisLabel: string = 'Month';
  yAxisLabel: string = 'Success Rate';
  public tooltipTemplate = (data: any) => `<span>${data.value}%</span>`;
  public yAxisTickFormatting = (value: number) => `${value}%`;
  timeline: boolean = true;
  colorScheme = {
    name: '',
    selectable: false,
    group: ScaleType.Ordinal,
    domain: ['#5AA454']
  };

  constructor( private http: HttpService, private sharedService: SharedService) { }

  ngOnInit() {    
    this.showPIIFail = moment().isAfter('2023-08-04T01:00:00Z');    
    this.setSectionVisible();
    this.loadDatePicker();    
  }
initiate(){
  this.getAccoountCreationAttemptReport();
  this.getAccoountCreatedReport();
  this.getAccoountCreationPIIFailedReport();
  this.getAccoountCreatioEmailFailedReport();
  this.getAccoountCreationEmailSuccessReport();
  this.getLoginAttemptReport();
  this.getLoginSuccessReport();
  this.getDistinctLoginSuccessReport();


    this.getSuccessDetails();
    this.getFFASMSOOBSuccessDetails();
    this.getFFAEmailOOBSuccessDetails();
    this.getSFASMSOOBSuccessDetails();
    this.getSFAEmailOOBSuccessDetails();
    this.getGoogleAuthSuccessDetails();
    this.getKBASuccessDetails();
    this.getFFAPWDSuccessDetails();
    this.getSFAPWDSuccessDetails();
}

  getAccoountCreationAttemptReport(){
   this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == ('CA-EMAIL-OOB-PAGE-INIT') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) |summarize Total=count()").subscribe((result: any) => {
      
      this.CA_Attempt =  result?.body?.tables[0]?.rows[0][0];  
      this.calculateCARate();
    })
  }
  getAccoountCreatedReport(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where (name == 'CIAM-CA-SUCCESS-INIT' or name == 'GOOGLE_AUTH_SUCCESS_INIT' or name == 'CA-TWO-FA-INIT') and timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | project distinctIdentifier = coalesce(tostring(customDimensions.Email), tostring(customDimensions.Identifier)) |summarize Total=dcount(distinctIdentifier)").subscribe((result: any) => {
       
       this.CA_Created =  result?.body?.tables[0]?.rows[0][0];  
       this.calculateCARate();
     })
   }

   getAccoountCreationPIIFailedReport(){


    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let q1=customEvents | where (name == 'CIAM-PROFILE-PAGE-INIT') and timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize totalPIIAttempt = countif(name == 'CIAM-PROFILE-PAGE-INIT'); let q2=customEvents | where (name == 'MOBILE-OBB-PAGE-INIT' or name == 'CA-TWO-FA-INIT') and timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize total=dcount(tostring(customDimensions.Email)); union q1, q2 | summarize totalPIIFailed = "+encodeURIComponent("sum(totalPIIAttempt)-sum(total)")).subscribe((result: any) => {

       this.CA_PII_Failed =  result?.body?.tables[0]?.rows[0][0];  
       this.CA_PII_Failed =(this.CA_PII_Failed <0)?NaN:this.CA_PII_Failed ;
     })
   }

   getAccoountCreatioEmailFailedReport(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where (name == 'CA-EMAIL-OOB-PAGE-INIT' or name == 'CIAM-PROFILE-PAGE-INIT') and timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize totalAttempt = countif(name == 'CA-EMAIL-OOB-PAGE-INIT'), successLoginAttempt = countif(name == 'CIAM-PROFILE-PAGE-INIT') | extend totalEmailOOBFailed = totalAttempt - successLoginAttempt | project totalEmailOOBFailed").subscribe((result: any) => {
     
     this.CA_Email_Failed =  result?.body?.tables[0]?.rows[0][0];  
     this.CA_Email_Failed =(this.CA_Email_Failed <0)?NaN:this.CA_Email_Failed ;
   })
 }

 getAccoountCreationEmailSuccessReport(){
  this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == ('CA-EMAIL-VALIDATE-OOB-REQUEST-SUCCESS') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) |summarize Total=count()").subscribe((result: any) => {
   
   this.CA_Email_Success =  result?.body?.tables[0]?.rows[0][0];  
 })
}

getLoginAttemptReport(){
  this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == ('SI-LOOKUP-SUBMIT-IDENTIFIER-SUCCESS') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) |summarize Total=count()").subscribe((result: any) => {
   
   this.Login_Attempt =  result?.body?.tables[0]?.rows[0][0];  
   this.calculateLoginRate();
 })
}

getLoginSuccessReport(){
  this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == ('SI-SFA-COMPLETED') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) |summarize Total=count()").subscribe((result: any) => {
   
   this.Login_Success =  result?.body?.tables[0]?.rows[0][0];  
   this.calculateLoginRate();
 })
}


getDistinctLoginSuccessReport(){
  this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where name == ('SI-SFA-COMPLETED') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize successLoginUnique = dcount(tostring(customDimensions.Identifier))").subscribe((result: any) => {
   
   this.login_distinctLoggedIn =  result?.body?.tables[0]?.rows[0][0];  
 })
}

  getSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == ('SI-LOOKUP-SUBMIT-IDENTIFIER-SUCCESS') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize totalAttemptUnique= count() by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == ('SI-SFA-COMPLETED') | where timestamp between (datetime("+this.from_Date+") .. datetime("+this.to_Date+")) | summarize successLoginUnique = count() by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.successRateData = data;
       }
    })
  }

  getFFASMSOOBSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-FFA-MOBILE-OOB-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.ffaSMSOOBSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.FFA_SMS_loginSuccessCount=successLoginSum;
        this.FFA_SMS_totalUniqueCount=totalLoginSum;
        this.FFA_SMS_loginSuccessRate= parseFloat(((this.FFA_SMS_loginSuccessCount/this.FFA_SMS_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getFFAEmailOOBSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-FFA-EMAIL-OOB-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.ffaEmailOOBSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.FFA_Email_loginSuccessCount=successLoginSum;
        this.FFA_Email_totalUniqueCount=totalLoginSum;
        this.FFA_Email_loginSuccessRate= parseFloat(((this.FFA_Email_loginSuccessCount/this.FFA_Email_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getSFASMSOOBSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-SFA-MOBILE-OOB-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.sfaSMSOOBSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.SFA_SMS_loginSuccessCount=successLoginSum;
        this.SFA_SMS_totalUniqueCount=totalLoginSum;
        this.SFA_SMS_loginSuccessRate= parseFloat(((this.SFA_SMS_loginSuccessCount/this.SFA_SMS_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getSFAEmailOOBSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-SFA-EMAIL-OOB-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.sfaEmailOOBSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.SFA_Email_loginSuccessCount=successLoginSum;
        this.SFA_Email_totalUniqueCount=totalLoginSum;
        this.SFA_Email_loginSuccessRate= parseFloat(((this.SFA_Email_loginSuccessCount/this.SFA_Email_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getGoogleAuthSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-SFA-GA-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-SFA-GA-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.GoogleAuthSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.Google_Auth_loginSuccessCount=successLoginSum;
        this.Google_Auth_totalUniqueCount=totalLoginSum;
        this.Google_Auth_loginSuccessRate= parseFloat(((this.Google_Auth_loginSuccessCount/this.Google_Auth_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getKBASuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-SFA-KBA-PII-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name in ('PROOF-ID-SFA-KBA-QUESTIONS-SUCCESS','PROOF-ID-SFA-KBA-CHALLENGE-QUESTION-SUCCESS')| where customDimensions.AuthStatus contains 'ACKNOWLEDGMENT_REQUIRED' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.KBASuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.KBA_loginSuccessCount=successLoginSum;
        this.KBA_totalUniqueCount=totalLoginSum;
        this.KBA_loginSuccessRate= parseFloat(((this.KBA_loginSuccessCount/this.KBA_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  getFFAPWDSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-FFA-PWD-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-FFA-PWD-API-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.FFAPWDSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.FFA_PWD_loginSuccessCount=successLoginSum;
        this.FFA_PWD_totalUniqueCount=totalLoginSum;
        this.FFA_PWD_loginSuccessRate= parseFloat(((this.FFA_PWD_loginSuccessCount/this.FFA_PWD_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }
  getSFAPWDSuccessDetails(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "let totalAttempt = customEvents | where name == 'SI-SFA-PWD-ONLOAD' and timestamp >= ago(90d) | summarize totalAttemptUnique= dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); let successLogin = customEvents | where name == 'SI-SFA-PWD-VALIDATE-SUCCESS' and timestamp >= ago(90d) | summarize successLoginUnique = dcount(user_Id) by Month = format_datetime(timestamp, 'yyyy-MM'); totalAttempt | join kind=inner successLogin on Month | project Month, SuccessRate = round((todouble(successLoginUnique) / todouble(totalAttemptUnique))*100,2),successLoginUnique,totalAttemptUnique | order by Month asc").subscribe((result: any) => {
      let arryaData=result?.body?.tables[0]?.rows;
      if(arryaData?.length>0){
        const data = [
          {
            name: '',
            series: arryaData.map(item => ({
              name: item[0],
              value: item[1]
            }))
          }
        ];    
        this.SFAPWDSuccessRateData = data;
        let successLoginSum=0;
        let totalLoginSum=0;
        arryaData.forEach(element => {
          successLoginSum+=element[2];
          totalLoginSum+=element[3];
        });
        this.SFA_PWD_loginSuccessCount=successLoginSum;
        this.SFA_PWD_totalUniqueCount=totalLoginSum;
        this.SFA_PWD_loginSuccessRate= parseFloat(((this.SFA_PWD_loginSuccessCount/this.SFA_PWD_totalUniqueCount)*100)?.toFixed(2));
      }
    })
  }

  // Date picker 
  

  loadDatePicker() {
    this.startDate = moment().subtract(1, 'day').startOf('day');
    this.endDate = moment().startOf('day');

    let startDate = moment(this.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.from_Date = startDate.format('YYYY-MM-DDTHH:mm:ss')
    const endDate = moment(this.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.to_Date = endDate.format('YYYY-MM-DDTHH:mm:ss')

    $('input[name="datetimes"]').daterangepicker({
      timePicker: true,
      startDate: this.startDate,
      endDate: this.endDate,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    });
    this.initiate();
    $('input[name="datetimes"]').on('apply.daterangepicker', ((ev, picker) => {
      this.selectedDate(picker)
    }));
  }
  selectedDate(event) {
    const startDate = moment(event.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.from_Date = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.from_Date, 'startDate');
    const endDate = moment(event.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.to_Date = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.to_Date, 'endDate');
    this.initiate();
  }

  setSectionVisible(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      this.showSection = false;
    } else {
      this.showSection = true;
    }
  }

  private calculateCARate(): void {
    if (this.CA_Attempt !== undefined && this.CA_Created !== undefined && this.CA_Created !== 0
      && this.CA_Attempt !== 0) {
      this.CA_Success_Rate = parseFloat(((this.CA_Created / this.CA_Attempt) * 100)?.toFixed(2));
      this.CA_Success_Rate = (this.CA_Success_Rate >100)? NaN: this.CA_Success_Rate;
    } else {
       this.CA_Success_Rate = 0;
    }
  }

  private calculateLoginRate(): void {
    if (this.Login_Attempt !== undefined && this.Login_Success !== undefined && this.Login_Success !== 0
      && this.Login_Attempt !== 0) {
      this.Login_Success_Rate = parseFloat(((this.Login_Success / this.Login_Attempt) * 100)?.toFixed(2));
      this.Login_Success_Rate = (this.Login_Success_Rate >100)? NaN: this.Login_Success_Rate;
    } else {
       this.Login_Success_Rate = 0;
    }
  }

  isSuccessRateNaN(val): boolean {
    return isNaN(val);
  }
}
