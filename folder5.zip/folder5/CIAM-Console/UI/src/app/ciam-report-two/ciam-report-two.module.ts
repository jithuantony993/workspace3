import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamReportTwoPageRoutingModule } from './ciam-report-two-routing.module';

import { CiamReportTwoPage } from './ciam-report-two.page';
import { ImportsModule } from '../common/imports/imports.module';
import { NgxChartsModule } from '@swimlane/ngx-charts';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamReportTwoPageRoutingModule,
    NgxChartsModule
  ],
  declarations: [CiamReportTwoPage],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ],
})
export class CiamReportTwoPageModule {}
