import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import * as moment from 'moment';
import { of } from 'rxjs';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';

import { CiamReportTwoPage } from './ciam-report-two.page';

describe('CiamReportTwoPage', () => {
  let component: CiamReportTwoPage;
  let fixture: ComponentFixture<CiamReportTwoPage>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ CiamReportTwoPage ],
      imports: [IonicModule.forRoot(),
      HttpClientModule,
      HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(CiamReportTwoPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger setSectionVisible with AdminUser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser";
    component.setSectionVisible();
    expect(component.showSection).toEqual(false);
  });

  it('should trigger setSectionVisible with MasterUser', () => {
    component["sharedService"].loginUser.authStatus = "MasterUser";
    component.setSectionVisible();
    expect(component.showSection).toEqual(true);
  });

  it('should trigger loadDatePicker', () => {
    component.loadDatePicker();
    expect(component.startDate).not.toBeNull();
    expect(component.endDate).not.toBeNull();
  });

  it('should trigger selectedDate', () => {
    const event = {
      startDate: moment("2023-08-01 00:00:00"),
      endDate: moment("2023-08-08 00:00:00")
    }
    component.selectedDate(event);
    expect(component.from_Date).toEqual("2023-07-31T18:30:00");
    expect(component.to_Date).toEqual("2023-08-07T18:30:00");
  });

  it('should trigger getAccoountCreationAttemptReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAccoountCreationAttemptReport();
    expect(component.CA_Attempt).toEqual(123);
  });

  it('should trigger getAccoountCreatedReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAccoountCreatedReport();
    expect(component.CA_Created).toEqual(123);
  });

  it('should trigger getAccoountCreationPIIFailedReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAccoountCreationPIIFailedReport();
    expect(component.CA_PII_Failed).toEqual(123);
  });

  it('should trigger getAccoountCreatioEmailFailedReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAccoountCreatioEmailFailedReport();
    expect(component.CA_Email_Failed).toEqual(123);
  });

  it('should trigger getAccoountCreationEmailSuccessReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAccoountCreationEmailSuccessReport();
    expect(component.CA_Email_Success).toEqual(123);
  });

  it('should trigger getLoginAttemptReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getLoginAttemptReport();
    expect(component.Login_Attempt).toEqual(123);
  });

  it('should trigger getLoginSuccessReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getLoginSuccessReport();
    expect(component.Login_Success).toEqual(123);
  });

  it('should trigger getDistinctLoginSuccessReport', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ 123 ]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getDistinctLoginSuccessReport();
    expect(component.login_distinctLoggedIn).toEqual(123);
  });
  
  it('should trigger getSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [ {
            name : '',
            series : [
              {
                name : undefined,
                value : undefined
              }
            ]
          }
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSuccessDetails();
    expect(component.successRateData).toEqual(result.body.tables[0].rows);
  });

  it('should trigger getFFASMSOOBSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getFFASMSOOBSuccessDetails();
    expect(component.FFA_SMS_loginSuccessCount).toEqual(525);
    expect(component.FFA_SMS_totalUniqueCount).toEqual(774);
    expect(component.FFA_SMS_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getFFAEmailOOBSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getFFAEmailOOBSuccessDetails();
    expect(component.FFA_Email_loginSuccessCount).toEqual(525);
    expect(component.FFA_Email_totalUniqueCount).toEqual(774);
    expect(component.FFA_Email_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getSFASMSOOBSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSFASMSOOBSuccessDetails();
    expect(component.SFA_SMS_loginSuccessCount).toEqual(525);
    expect(component.SFA_SMS_totalUniqueCount).toEqual(774);
    expect(component.SFA_SMS_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getSFAEmailOOBSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSFAEmailOOBSuccessDetails();
    expect(component.SFA_Email_loginSuccessCount).toEqual(525);
    expect(component.SFA_Email_totalUniqueCount).toEqual(774);
    expect(component.SFA_Email_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getGoogleAuthSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getGoogleAuthSuccessDetails();
    expect(component.Google_Auth_loginSuccessCount).toEqual(525);
    expect(component.Google_Auth_totalUniqueCount).toEqual(774);
    expect(component.Google_Auth_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getKBASuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getKBASuccessDetails();
    expect(component.KBA_loginSuccessCount).toEqual(525);
    expect(component.KBA_totalUniqueCount).toEqual(774);
    expect(component.KBA_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getFFAPWDSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getFFAPWDSuccessDetails();
    expect(component.FFA_PWD_loginSuccessCount).toEqual(525);
    expect(component.FFA_PWD_totalUniqueCount).toEqual(774);
    expect(component.FFA_PWD_loginSuccessRate).toEqual(67.83);
  });

  it('should trigger getSFAPWDSuccessDetails', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [
              "2023-04",
              62.72,
              106,
              169
            ],
            [
              "2023-05",
              69.26,
              419,
              605
            ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSFAPWDSuccessDetails();
    expect(component.SFA_PWD_loginSuccessCount).toEqual(525);
    expect(component.SFA_PWD_totalUniqueCount).toEqual(774);
    expect(component.SFA_PWD_loginSuccessRate).toEqual(67.83);
  });

});
