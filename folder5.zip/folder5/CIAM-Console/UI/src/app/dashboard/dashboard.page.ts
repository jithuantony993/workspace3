import { Component, OnInit } from '@angular/core';
import * as FingerprintJS from 'fingerprintjs2';
import { Color, ScaleType } from '@swimlane/ngx-charts';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { apiResponse } from '../ma-interface/api-response-interface';
import { SharedService } from '../shared-services/shared/shared.service';
import * as moment from 'moment';
import * as $ from 'jquery';
import 'daterangepicker';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.page.html',
  styleUrls: ['./dashboard.page.scss'],
})

export class DashboardPage implements OnInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser")?AppConfigService?.settings?.endpoints?.console?.appinsights:AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  successLogin: string;
  successCreateAccount: string;
  aolCount : string;
  vaolCount : string;
  paperlessCount : string;
  sfaEmailSuccess : string;
  sfaMobileSuccess : string;
  sfaPasswordSuccess : string;
  sfaDeviceSuccess : string;
  sfaGASuccess : string;
  sfaKBASuccess : string;
  sfaKBACHSuccess : string;
  ffaPasswordSuccess : string;
  ffaEmailSuccess : string;
  ffaMobileSuccess : string;
  totalFFA : string;

  single: any[] = [];

  pingDir: any = [];
  pingFed: any = [];
  pingOne: any = [];
  ciamServices: any = [];

  pingDirCount: any;
  pingFedCount: any;
  pingOneCount: any;
  ciamServicesCount: any;
  glanceHours: any = 1;  
  startDate: any;
  endDate: any;
  endDateFormated: string;
  startDateFormated: string;
  showSection: any = false;
  constructor(private http: HttpService, private sharedService: SharedService) {  }

  ngOnInit() {

    // this.sharedService.glanceHours = 1;
    // this.glanceHours = this.sharedService.glanceHours;

    FingerprintJS.get((result) => {
      console.log("FingerPrint",result);
    });
  
    this.loadScript();
  }

  loadScript() {
    this.startDate = moment().subtract(1, 'day').startOf('day');
    this.endDate = moment().startOf('day');

    let startDate = moment(this.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(this.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');

    $('input[name="datetimes"]').daterangepicker({
      timePicker: true,
      startDate: this.startDate,
      endDate: this.endDate,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    });
    $('input[name="datetimes"]').on('apply.daterangepicker', ((ev, picker) => {
      this.selectedDate(picker)
    }));
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }

  selectedDate(event) {
    const startDate = moment(event.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(event.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }
  // UpdateHours(event) {
  //   this.sharedService.glanceHours = event.target.value;
  //   this.glanceHours = this.sharedService.glanceHours;
  //   this.getSuccessLogin();
  //   this.getSuccessCreateAccount();
  //   this.getAOLMagicLinkCount();
  //   this.getVAOLMagicLinkCount();
  //   this.getPaperlessMagicLinkCount();
  //   this.getStatCount(); 
    
  //   this.getFFAPasswordSuccess("SI-FFA-PWD-API-SUCCESS");
  //   this.getFFAEmailSuccess("SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS");
  //   this.getFFAMobileSuccess("SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS");
    
  //   this.getPingDIR();
  //   this.getPingFED();
  //   this.getPingONE();
  // }

  
  async getStatCount(){
    this.getTotalCountSFAEmail("SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS");
    this.getTotalCountSFAMobile("SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS");
    this.getTotalCountSFAPassword("SI-SFA-PWD-VALIDATE-SUCCESS");
    this.getTotalCountSFAGA("SI-SFA-GA-VALIDATE-SUCCESS");
    this.getTotalCountSFAKBA("PROOF-ID-SFA-KBA-QUESTIONS-SUCCESS");
    this.getTotalCountSFAKBACH("SI-SFA-KBA-CHALLENGE-QNS-API-SUCCESS");
    this.getTotalCountSFADevice("'PROOF-ID-FFA-PASSWORD-SUBMIT-PAYLOAD-DEVICE-RECOGNISED', 'PROOF-ID-FFA-EMAIL-DEVICE-DEVICERECOGNITION', 'PROOF-ID-FFA-MOBILE-DEVICE-DEVICERECOGNITION'");
    var totFFA = parseInt(this.ffaPasswordSuccess) + parseInt(this.ffaEmailSuccess) + parseInt(this.ffaMobileSuccess);  
    this.totalFFA =  ""+totFFA;
    setTimeout(()=> {
      this.setGraph()
    },7000)
  }

  setGraph(){      
    
    var kba = parseInt(this.sfaKBASuccess) + parseInt(this.sfaKBACHSuccess);     
    this.single= [
    {
      "name": "Email",
      "value": this.sfaEmailSuccess
    },
    {
      "name": "Mobile",
      "value": parseInt(this.sfaMobileSuccess)
    },
    {
      "name": "Password",
      "value": parseInt(this.sfaPasswordSuccess)
    },
    {
      "name": "GA",
      "value": parseInt(this.sfaGASuccess)
    },
    {
      "name": "Device",
      "value": parseInt(this.sfaDeviceSuccess)
    },
    {
      "name": "KBA",
      "value": kba
    }];

   let data = this.single;
    Object.assign(this, { data });
   }

  

  // options
  gradient: boolean = true;
  showLegend: boolean = true;
  showLabels: boolean = true;
  isDoughnut: boolean = false;

  colorScheme:Color = {
    domain: ['maroon','Olive','orange', 'ForestGreen', 'Teal', 'yellow'],
    name: '',
    selectable: false,
    group: ScaleType.Ordinal
  };



  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));
  }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }

  getSuccessLogin(){
    
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name == ('SI-SFA-COMPLETED') | where timestamp between (datetime("+this.startDateFormated+") .. datetime("+this.endDateFormated+")) |summarize Total=count()").subscribe((result: apiResponse) => {
          this.successLogin =result?.body?.tables[0]?.rows[0]?.[0]    
    })
  }

  getSuccessCreateAccount(){
    
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where (name == 'CIAM-CA-SUCCESS-INIT' or name == 'GOOGLE_AUTH_SUCCESS_INIT' or name == 'CA-TWO-FA-INIT') and timestamp between (datetime("+this.startDateFormated+") .. datetime("+this.endDateFormated+")) | project distinctIdentifier = coalesce(tostring(customDimensions.Email), tostring(customDimensions.Identifier)) |summarize Total=dcount(distinctIdentifier)").subscribe((result: apiResponse) => {
          this.successCreateAccount =result?.body?.tables[0]?.rows[0]?.[0]          
    })
  }

  getAOLMagicLinkCount(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \"AOL-MAGIC-LINK-EMAIL-SEND-SUCCESS\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
          this.aolCount =result?.body?.tables[0]?.rows[0]?.[0]
    })
  }
  getVAOLMagicLinkCount(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \"VAOL-MAGIC-LINK-EMAIL-SEND-SUCCESS\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
          this.vaolCount =result?.body?.tables[0]?.rows[0]?.[0]
    })
  }
  getPaperlessMagicLinkCount(){
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \"PAPERLESS-MAGIC-LINK-SUCCESS\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
          this.paperlessCount =result?.body?.tables[0]?.rows[0]?.[0]
    })
  }

  getTotalCountSFAEmail(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaEmailSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
 
  }

  getTotalCountSFAMobile(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaMobileSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
 
  }

  getTotalCountSFAPassword(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaPasswordSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
 
  }


  getTotalCountSFAKBACH(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"| where customDimensions.AuthStatus contains 'ACKNOWLEDGMENT_REQUIRED' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaKBACHSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
 
  }

  getTotalCountSFAKBA(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"| where customDimensions.AuthStatus contains 'ACKNOWLEDGMENT_REQUIRED' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaKBASuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }
  
  getTotalCountSFAGA(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaGASuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }

  getTotalCountSFADevice(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name in ("+eventName+")|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.sfaDeviceSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }

  getFFAPasswordSuccess(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.ffaPasswordSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }

  getFFAEmailSuccess(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.ffaEmailSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }

  getFFAMobileSuccess(eventName:string):any{
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents| where name contains \""+eventName+"\"|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| count").subscribe((result: apiResponse) => {
         
          console.log("Event Name", eventName);
          console.log("Total Count", result?.body?.tables[0]?.rows[0]?.[0]);
          this.ffaMobileSuccess = result?.body?.tables[0]?.rows[0]?.[0];
    })
  }

  getPingDIR(){
    this.setSectionVisible();
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"dir-qa.hrblock.com\" and toint(resultCode) > 399 and timestamp between(datetime(" + this.startDateFormated + ")..datetime(" + this.endDateFormated + ")) | order by timestamp desc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingDir = result?.body?.tables[0]?.rows;
          this.pingDirCount = result?.body?.tables[0]?.rows?.length;
          console.log("Ping Dir");
          
    })
  }
   getPingFED(){   
    this.setSectionVisible(); 
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"login-qa.hrblock.com\" and toint(resultCode) > 399 and timestamp between(datetime(" + this.startDateFormated + ")..datetime(" + this.endDateFormated + ")) | order by timestamp desc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingFed = result?.body?.tables[0]?.rows;
          this.pingFedCount = result?.body?.tables[0]?.rows?.length;
          console.log("Ping Fed");
   })
  }

  getDataByDate(startDate, endDate) {
    this.getSuccessLogin();
    this.getSuccessCreateAccount();
    this.getAOLMagicLinkCount();
    this.getVAOLMagicLinkCount();
    this.getPaperlessMagicLinkCount();
    this.getStatCount(); 
    
    this.getFFAPasswordSuccess("SI-FFA-PWD-API-SUCCESS");
    this.getFFAEmailSuccess("SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS");
    this.getFFAMobileSuccess("SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS");
    
    this.getPingDIR();
    this.getPingFED();
    this.getPingONE();
  }
  getPingONE(){
    this.setSectionVisible();    
    var query = "union isfuzzy=true availabilityResults, requests, exceptions, pageViews, traces, customEvents, dependencies | where target == \"api.pingone.com\" and toint(resultCode) > 399 and timestamp between(datetime(" + this.startDateFormated + ")..datetime(" + this.endDateFormated + ")) | order by timestamp desc"
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.pingOne = result?.body?.tables[0]?.rows;
          this.pingOneCount = result?.body?.tables[0]?.rows?.length;
          console.log("Ping One");
    })
  }
  setSectionVisible(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      this.showSection = false;
    } else {
      this.showSection = true;
    }
  }
}
