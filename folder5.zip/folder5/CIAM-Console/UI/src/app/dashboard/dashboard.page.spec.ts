import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import * as moment from 'moment';
import { of } from 'rxjs';

import { DashboardPage } from './dashboard.page';

describe('DashboardPage', () => {
  let component: DashboardPage;
  let fixture: ComponentFixture<DashboardPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(DashboardPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger setGraph from getStatCount',fakeAsync(() => {
    spyOn(component,"setGraph");
    component.getStatCount();
    tick(7000);
    expect(component.setGraph).toHaveBeenCalled();
  }));

  it('should trigger setGraph', () => {
    component.sfaEmailSuccess = "10";
    component.sfaMobileSuccess = "20"
    component.sfaPasswordSuccess = "30"
    component.sfaGASuccess = "40"
    component.sfaDeviceSuccess = "50"
    component.sfaKBASuccess = "30"
    component.sfaKBACHSuccess = "30"
    let single= [
      {
        "name": "Email",
        "value": "10"
      },
      {
        "name": "Mobile",
        "value": 20
      },
      {
        "name": "Password",
        "value": 30
      },
      {
        "name": "GA",
        "value": 40
      },
      {
        "name": "Device",
        "value": 50
      },
      {
        "name": "KBA",
        "value": 60
      }];

      component.setGraph();
      expect(component.single).toEqual(single);
  });

  it('should trigger loadScript', () => {
    component.loadScript();
    expect(component.startDate).not.toBeNull();
    expect(component.endDate).not.toBeNull();
  });

  it('should trigger selectedDate', () => {
    const event = {
      startDate: moment("2023-08-01 00:00:00"),
      endDate: moment("2023-08-08 00:00:00")
    }
    component.selectedDate(event);
    expect(component.startDateFormated).toEqual("2023-07-31T18:30:00");
    expect(component.endDateFormated).toEqual("2023-08-07T18:30:00");
  });

  it('should call getSuccessLogin', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getSuccessLogin();
    expect(component.successLogin).toEqual("123");
  });

  it('should trigger getSuccessLogin branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getSuccessLogin();
    expect(component.successLogin).not.toBeNull();
  });

  it('should call getSuccessCreateAccount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getSuccessCreateAccount();
    expect(component.successCreateAccount).toEqual("123");
  });

  it('should trigger getSuccessCreateAccount branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getSuccessCreateAccount();
    expect(component.successCreateAccount).not.toBeNull();
  });

  it('should call getAOLMagicLinkCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getAOLMagicLinkCount();
    expect(component.aolCount).toEqual("123");
  });

  it('should trigger getAOLMagicLinkCount branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getAOLMagicLinkCount();
    expect(component.aolCount).not.toBeNull();
  });

  it('should call getVAOLMagicLinkCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getVAOLMagicLinkCount();
    expect(component.vaolCount).toEqual("123");
  });

  it('should trigger getVAOLMagicLinkCount branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getVAOLMagicLinkCount();
    expect(component.vaolCount).not.toBeNull();
  });

  it('should call getPaperlessMagicLinkCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPaperlessMagicLinkCount();
    expect(component.paperlessCount).toEqual("123");
  });

  it('should trigger getPaperlessMagicLinkCount branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPaperlessMagicLinkCount();
    expect(component.paperlessCount).not.toBeNull();
  });

  it('should call getTotalCountSFAEmail', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAEmail("SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS");
    expect(component.sfaEmailSuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAEmail branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAEmail("SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS");
    expect(component.sfaEmailSuccess).not.toBeNull();
  });

  it('should call getTotalCountSFAMobile', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAMobile("SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS");
    expect(component.sfaMobileSuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAMobile branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAMobile("SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS");
    expect(component.sfaMobileSuccess).not.toBeNull();
  });

  it('should call getTotalCountSFAPassword', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAPassword("SI-SFA-PWD-VALIDATE-SUCCESS");
    expect(component.sfaPasswordSuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAPassword branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAPassword("SI-SFA-PWD-VALIDATE-SUCCESS");
    expect(component.sfaPasswordSuccess).not.toBeNull();
  });

  it('should call getTotalCountSFAGA', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAGA("SI-SFA-GA-VALIDATE-SUCCESS");
    expect(component.sfaGASuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAGA branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAGA("SI-SFA-GA-VALIDATE-SUCCESS");
    expect(component.sfaGASuccess).not.toBeNull();
  });

  it('should call getTotalCountSFAKBA', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAKBA("SI-SFA-KBA-QNS-API-SUCCESS");
    expect(component.sfaKBASuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAKBA branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAKBA("SI-SFA-KBA-QNS-API-SUCCESS");
    expect(component.sfaKBASuccess).not.toBeNull();
  });

  it('should call getTotalCountSFAKBACH', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFAKBACH("SI-SFA-KBA-CHALLENGE-QNS-API-SUCCESS");
    expect(component.sfaKBACHSuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFAKBACH branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFAKBACH("SI-SFA-KBA-CHALLENGE-QNS-API-SUCCESS");
    expect(component.sfaKBACHSuccess).not.toBeNull();
  });

  it('should call getTotalCountSFADevice', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getTotalCountSFADevice("SI-FFA-PWD-API-DEVICE-RECOGNISED");
    expect(component.sfaDeviceSuccess).toEqual("123");
  });

  it('should trigger getTotalCountSFADevice branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getTotalCountSFADevice("SI-FFA-PWD-API-DEVICE-RECOGNISED");
    expect(component.sfaDeviceSuccess).not.toBeNull();
  });

  it('should call getFFAPasswordSuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getFFAPasswordSuccess("SI-FFA-PWD-API-SUCCESS");
    expect(component.ffaPasswordSuccess).toEqual("123");
  });

  it('should trigger getFFAPasswordSuccess branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getFFAPasswordSuccess("SI-FFA-PWD-API-SUCCESS");
    expect(component.ffaPasswordSuccess).not.toBeNull();
  });

  it('should call getFFAEmailSuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getFFAEmailSuccess("SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS");
    expect(component.ffaEmailSuccess).toEqual("123");
  });

  it('should trigger getFFAEmailSuccess branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getFFAEmailSuccess("SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS");
    expect(component.ffaEmailSuccess).not.toBeNull();
  });

  it('should call getFFAMobileSuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ["123"]
          ]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getFFAMobileSuccess("SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS");
    expect(component.ffaMobileSuccess).toEqual("123");
  });

  it('should trigger getFFAMobileSuccess branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getFFAMobileSuccess("SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS");
    expect(component.ffaMobileSuccess).not.toBeNull();
  });

  it('should call getPingDIR', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingDIR();
    expect(component.pingDir).toEqual([1,2,3]);
    expect(component.pingDirCount).toEqual(3);
  });

  it('should trigger getPingDIR branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingDIR();
    expect(component.pingDir).not.toBeNull();
    expect(component.pingDirCount).not.toBeNull();
  });

  it('should call getPingFED', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingFED();
    expect(component.pingFed).toEqual([1,2,3]);
    expect(component.pingFedCount).toEqual(3);
  });

  it('should trigger getPingFED branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingFED();
    expect(component.pingFed).not.toBeNull();
    expect(component.pingFedCount).not.toBeNull();
  });

  it('should call getPingONE', () => {
    const result = {
      body : {
        tables : [{
          rows : [1,2,3]
        }]
      }
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getPingONE();
    expect(component.pingOne).toEqual([1,2,3]);
    expect(component.pingOneCount).toEqual(3);
  });

  it('should trigger getPingONE branch cover', () => {
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(null));
    component.getPingONE();
    expect(component.pingOne).not.toBeNull();
    expect(component.pingOneCount).not.toBeNull();
  });

  it('should log the clicked item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onSelect(data);
    expect(console.log).toHaveBeenCalledWith('Item clicked', data);
  });

  it('should log the Activate item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onActivate(data);
    expect(console.log).toHaveBeenCalledWith('Activate', data);
  });

  it('should log the Deactivate item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onDeactivate(data);
    expect(console.log).toHaveBeenCalledWith('Deactivate', data);
  });

  it('should trigger setSectionVisible with AdminUser', () => {
    component["sharedService"].loginUser.authStatus = "AdminUser";
    component.setSectionVisible();
    expect(component.showSection).toEqual(false);
  });
});
