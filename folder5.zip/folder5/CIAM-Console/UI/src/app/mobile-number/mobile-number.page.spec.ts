import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import { of } from 'rxjs';

import { MobileNumberPage } from './mobile-number.page';

describe('MobileNumberPage', () => {
  let component: MobileNumberPage;
  let fixture: ComponentFixture<MobileNumberPage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ MobileNumberPage ],
      imports: [IonicModule.forRoot(),
        HttpClientModule,
        HttpClientTestingModule],
      providers: [HTTP]
    }).compileComponents();

    fixture = TestBed.createComponent(MobileNumberPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger getLoginwithMobileCount', () => {
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            16,
            16
          ],
          [
            "2023-06-01T00:00:00Z",
            470,
            538
          ],
          [
            "2023-07-01T00:00:00Z",
            401,
            416
          ],
          [
            "2023-08-01T00:00:00Z",
            84,
            118
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getLoginwithMobileCount();
    expect(component.mobileloginSuccessCount).toBe(971);
  });

  it('should trigger getLoginAttemptCount', () => {
    let successData = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getLoginAttemptCount(successData);
    expect(component.ciamLoginAttempts).toBe(1988);
  });

  it('should trigger getAddMobileTotalCount', () => {
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            64,
            88
          ],
          [
            "2023-06-01T00:00:00Z",
            511,
            640
          ],
          [
            "2023-07-01T00:00:00Z",
            394,
            442
          ],
          [
            "2023-08-01T00:00:00Z",
            286,
            340
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    spyOn(component,'getSuccessCount');
    component.getAddMobileTotalCount();
    expect(component.getSuccessCount).toHaveBeenCalledWith(result?.body?.tables[0].rows);
  });

  it('should trigger getSuccessCount', () => {
    let value = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getSuccessCount(value);
    expect(component.oobSuccessCount).toBe(1988);
  });

  it('should trigger getSkippedCount', () => {
    let val1 = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    let val2 = [
      [
        "2023-05-01T00:00:00Z",
        37,
        40
      ],
      [
        "2023-06-01T00:00:00Z",
        883,
        1128
      ],
      [
        "2023-07-01T00:00:00Z",
        860,
        980
      ],
      [
        "2023-08-01T00:00:00Z",
        208,
        349
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getSkippedCount(val1,val2);
    expect(component.skipMobileCount).toBe(1988);
  });

  it('should trigger getConfirmMobileTotalCount', () => {
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    spyOn(component,'getConfirmMobileSkippedCount');
    component.getConfirmMobileTotalCount();
    expect(component.getConfirmMobileSkippedCount).toHaveBeenCalledWith(result?.body?.tables[0]?.rows);
  });

  it('should trigger getConfirmMobileSkippedCount', () => {
    let value = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getConfirmMobileSkippedCount(value);
    expect(component.confirmMobileSkipCount).toBe(1988);
  });

  it('should trigger getConfirmMobileUpdatedCount', () => {
    let val1 = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    let val2 = [
      [
        "2023-05-01T00:00:00Z",
        37,
        40
      ],
      [
        "2023-06-01T00:00:00Z",
        883,
        1128
      ],
      [
        "2023-07-01T00:00:00Z",
        860,
        980
      ],
      [
        "2023-08-01T00:00:00Z",
        208,
        349
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getConfirmMobileUpdatedCount(val1,val2);
    expect(component.confirmMobileUpdateCount).toBe(1988);
  });

  it('should trigger getConfirmMobileSuccessCount', () => {
    let val1 = [
      [
        "2023-05-01T00:00:00Z",
        16,
        16
      ],
      [
        "2023-06-01T00:00:00Z",
        470,
        538
      ],
      [
        "2023-07-01T00:00:00Z",
        401,
        416
      ],
      [
        "2023-08-01T00:00:00Z",
        84,
        118
      ]
    ];
    let val2 = [
      [
        "2023-05-01T00:00:00Z",
        37,
        40
      ],
      [
        "2023-06-01T00:00:00Z",
        883,
        1128
      ],
      [
        "2023-07-01T00:00:00Z",
        860,
        980
      ],
      [
        "2023-08-01T00:00:00Z",
        208,
        349
      ]
    ];
    let val3 = [
      [
        "2023-05-01T00:00:00Z",
        37,
        40
      ],
      [
        "2023-06-01T00:00:00Z",
        883,
        1128
      ],
      [
        "2023-07-01T00:00:00Z",
        860,
        980
      ],
      [
        "2023-08-01T00:00:00Z",
        208,
        349
      ]
    ];
    const result = {
      body: {tables : [{
        rows : [
          [
            "2023-05-01T00:00:00Z",
            37,
            40
          ],
          [
            "2023-06-01T00:00:00Z",
            883,
            1128
          ],
          [
            "2023-07-01T00:00:00Z",
            860,
            980
          ],
          [
            "2023-08-01T00:00:00Z",
            208,
            349
          ]
        ]
      }]},
      headers: "",
      status: 200,
      statusText: "Success",
      type: 0,
      url: ""
    }
    spyOn(component['http'],"_httpDataGet").and.returnValue(of(result));
    component.getConfirmMobileSuccessCount(val1,val2,val3);
    expect(component.confirmMobileSuccessCount).toBe(1988);
  });

  it('should trigger formatPercent case 1', () => {
    let date = "2023-05-01T00:00:00Z";
    let result = component.formatPercent(date);
    expect(result).toBe('Apr-2023');
  });

  it('should trigger totalCount', () => {
    let rows = [
      [
        "2023-05-01T00:00:00Z",
        37,
        40
      ],
      [
        "2023-06-01T00:00:00Z",
        883,
        1128
      ],
      [
        "2023-07-01T00:00:00Z",
        860,
        980
      ],
      [
        "2023-08-01T00:00:00Z",
        208,
        349
      ]
    ]
    let total = component.totalCount(rows);
    expect(total).toBe(1988);
  });

  it('should log the clicked item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onSelect(data);
    expect(console.log).toHaveBeenCalledWith('Item clicked', data);
  });

  it('should log the Activate item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onActivate(data);
    expect(console.log).toHaveBeenCalledWith('Activate', data);
  });

  it('should log the Deactivate item', () => {
    const data = { id: 1, name: 'Item 1' };
    spyOn(console,'log');
    component.onDeactivate(data);
    expect(console.log).toHaveBeenCalledWith('Deactivate', data);
  });
});
