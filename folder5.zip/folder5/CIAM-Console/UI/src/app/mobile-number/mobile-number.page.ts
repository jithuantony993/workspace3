import { Component, OnInit } from '@angular/core';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { apiResponse } from '../ma-interface/api-response-interface';
import { Color, ScaleType } from '@swimlane/ngx-charts';

export interface DashboardEvent{
  count: number;
  alternateKey: string;
}

@Component({
  selector: 'app-mobile-number',
  templateUrl: './mobile-number.page.html',
  styleUrls: ['./mobile-number.page.scss'],
})
export class MobileNumberPage implements OnInit {
  appInsightsApiEndPoints = AppConfigService?.settings?.endpoints?.console?.appinsights;
  addMobilePromptCount=0;
  oobSuccessCount=0;
  mobileloginSuccessCount=0;
  skipMobileCount=0;
  skippedCountPercent;
  oobSuccessCountPercent: string;
  mobileLoginAttempts :any;
  ciamLoginAttempts =0;
  confirmMobileMobilePromptCount=0;
  confirmMobileSuccessCount=0;
  confirmMobileSkipCount=0;
  confirmMobileUpdateCount=0;
  confirmMobileSkippedCountPercent;
  confirmMobileUpdateCountPercent;
  mobileLoginSuccessCountPercent;
  confirmMobileSuccessCountPercent: string;
  loginswithMobile:any;
  loginAttemptwithMobile:any;
  loginwithMobilePercent:any;
  addMobilePrompt:any;
  confirmMobilePrompt:any;
  gradient: boolean = true;
  showLegend: boolean = true;
  showLabels: boolean = true;
  isDoughnut: boolean = false;
  explodeSlices:boolean=false;
  view: [number, number] = [400, 150];
  showXAxis = true;
  showYAxis = true;
  showXAxisLabel = true;
  xAxisLabel = '';
  showYAxisLabel = true;
  yAxisLabel = '';
  autoScale = true;
  below: any;
  colorScheme:Color = {
    domain: ['#5AA454', '#A10A28', '#C7B42C', '#AAAAAA'],
    name: '',
    selectable: false,
    group: ScaleType.Ordinal
  };
  legendTitle = '';
  single: { name: string; value: number; }[];
  confirmMobileNumber:{name:string; value;number;}[];
  multi = [
    {
      "name": "Germany",
      "series": [
        {
          "name": "01-01-2010",
          "value": 7300000
        },
        {
          "name": "01-01-2011",
          "value": 8940000
        }
      ]
    },
  
    {
      "name": "USA",
      "series": [
        {
          "name": "01-01-2010",
          "value": 7870000
        },
        {
          "name": "01-01-2011",
          "value": 8270000
        }
      ]
    }
  ];
  confirmMobileData: { name: string; value: number; }[];
    constructor(private http: HttpService) { 
   }

  ngOnInit() {
    this.getLoginwithMobileCount();
    this.getAddMobileTotalCount();
    this.getConfirmMobileTotalCount();
  }

  getLoginwithMobileCount(){
    var query = "customEvents | where name in ('SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id), Count=count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.mobileloginSuccessCount = this.totalCount(result?.body?.tables[0]?.rows);
          var successData =result?.body?.tables[0].rows;
          
          var seriesArrayObj =[];
          successData.forEach(function (value) {
          var elementJObj = {"value": value[2],"name": value[0]};
            seriesArrayObj .push(elementJObj );            
          }); 

          
         this.loginswithMobile = [{"name":"Logins with mobile number", "series": seriesArrayObj }];
          
          this.getLoginAttemptCount(successData);
    })
  }

  getLoginAttemptCount(successData:any){
    var query = "customEvents | where name in ('SI-LOOKUP-MULTIPLE-ACCOUNT-MOBILE','SI-FFA-MOBILE-OOB-ONLOAD') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id),  Count=count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.ciamLoginAttempts = this.totalCount(result?.body?.tables[0]?.rows);
          this.mobileLoginSuccessCountPercent = ((this.mobileloginSuccessCount/this.ciamLoginAttempts) *100).toFixed(1) ;
          var attemptedData =result?.body?.tables[0].rows;
          var outerArrayObj = [];
          var outerPercentageArrayObj = [];
          
          console.log("attempteddata", attemptedData);
          var outerPercentageArrayObj = [];
          var seriesPercentageArrayObj = [];
          successData.forEach(function(successItem) {
              var elementJObj = {
                  "value": successItem[2],
                  "name": 'Logins with Mobile Number'
              };
              var seriesArrayObj = [];
              seriesArrayObj.push(elementJObj);          
              attemptedData.forEach(function(attemptedItem) {
                  if (attemptedItem[0] == successItem[0]) {
                      var elementJObj = {
                          "value": attemptedItem[2],
                          "name": 'Total Distinct CIAM Login Attempts YTD'
                      };
                      seriesArrayObj.push(elementJObj);
                      var percentage = attemptedItem[2] > 0 ? ((successItem[2] / attemptedItem[2]) *100 ).toFixed(1) : 0;
                      elementJObj = {
                          "value": percentage,
                          "name": successItem[0]
                      };
                      seriesPercentageArrayObj.push(elementJObj);
                      return;
                  }
              });
              var outerJObj = {
                  "name": successItem[0],
                  "series": seriesArrayObj
              };
              outerArrayObj.push(outerJObj);
          
          });
          var outerPercentageJObj = {
              "name": "% Active Accounts w mobile nbr",
              "series": seriesPercentageArrayObj
          };
          outerPercentageArrayObj.push(outerPercentageJObj);
          this.loginAttemptwithMobile = outerArrayObj;
          this.loginwithMobilePercent = outerPercentageArrayObj;
});
}
  getAddMobileTotalCount(){
    var query = "customEvents | where name in ('UI-POSTAUTH-ADD-MOBILE-ONLOAD') | where timestamp >= startofyear(now())| summarize Unique = dcount(session_Id),Total = count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
        //  this.addMobilePromptCount = this.totalCount(result?.body?.tables[0]?.rows);
          var addMobilePrompt = result?.body?.tables[0].rows;
      this.getSuccessCount(addMobilePrompt);
    })
  }
  getSuccessCount(addMobilePrompt:any){
    var query = "customEvents | where name in ('UI-POSTAUTH-VALIDATE-ADD-MOBILE-OOB-SUCCESS') | where timestamp >= startofyear(now())| summarize Unique = dcount(session_Id),Total = count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.oobSuccessCount = this.totalCount(result?.body?.tables[0]?.rows);          
          var addedData = result?.body?.tables[0]?.rows;          
          this.getSkippedCount(addMobilePrompt, addedData);
    })    
  }
  
  getSkippedCount(addMobilePrompt:any, addedData:any){
    var query = "customEvents | where name in ('POSTAUTH-ADD-MOBILE-SKIP-API') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id),Total = count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {      
          this.skipMobileCount = this.totalCount(result?.body?.tables[0]?.rows);        
          var skippedData = result?.body?.tables[0]?.rows;
          this.addMobilePromptCount = this.skipMobileCount + this.oobSuccessCount;
          this.oobSuccessCountPercent =((this.oobSuccessCount/this.addMobilePromptCount) *100).toFixed(1);
          this.skippedCountPercent = ((this.skipMobileCount/this.addMobilePromptCount) *100).toFixed(1) ;
          setTimeout(()=>{      
            this.single = [

              {
                "name": "Added",
                "value": this.oobSuccessCount
              },
              {
                "name": "Skipped",
                "value": this.skipMobileCount
              }
            ]
          }, 500);         
          this.getAddMobileNumberPromptGraph(addMobilePrompt, addedData, skippedData);
    })
  }  
 
  getAddMobileNumberPromptGraph(promptData:any, added:any, skipped:any){
    var outerArrayObj = [];
    var seriesAddObj = [];         
    var seriesSkipObj = []; 
    console.log('pr',promptData);
    console.log('ad',added);
    promptData.forEach(function(prompt) { 
        added.forEach(function(addedItem) {
            if (addedItem[0] == prompt[0]) {
              //var percentage = prompt[2] > 0 ? ((addedItem[2] / prompt[2]) *100 ).toFixed(1) : 0;
              //console.log("pr1",percentage);
                var elementJObj = {
                    "value": addedItem[2],
                    "name": addedItem[0].toString()
                };
                seriesAddObj.push(elementJObj)
                return;
            }      
          });
        
        skipped.forEach(function(skippedItem) {
            if (skippedItem[0] == prompt[0]) {   
              //var percentage = prompt[2] > 0 ? ((skippedItem[2] / prompt[2]) *100 ).toFixed(1) : 0;
              //console.log("pr",percentage);           
                var elementJObj = {
                    "value": skippedItem[2],
                    "name": skippedItem[0].toString()
                };
                seriesSkipObj.push(elementJObj)
                return;
            }
        });   
    });
    var addedObj = {
      "name": 'Mobile Number Added',
      "series": seriesAddObj
    };
    
    outerArrayObj.push(addedObj);
    var skippedObj = {
    "name": 'Mobile Number Skipped',
    "series": seriesSkipObj
    };
   
    outerArrayObj.push(skippedObj);
    console.log("addmob",outerArrayObj);
    this.addMobilePrompt = outerArrayObj;
  }
  getConfirmMobileTotalCount(){
    var query = "customEvents | where name in ('UI-POSTAUTH-CONFIRM-MOBILE-FLOW-INITIATE') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id), Count=count() by month =startofmonth(timestamp) | order by month asc";  
      this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
     // this.confirmMobileMobilePromptCount = this.totalCount(result?.body?.tables[0]?.rows);
     var promptData = result?.body?.tables[0]?.rows;
      this.getConfirmMobileSkippedCount(promptData);
    })
  }
  getConfirmMobileSkippedCount(promptData : any){
    var query = "customEvents | where name in ('UI-POSTAUTH-CONFIRM-MOBILE-SKIP-SUCCESS') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id), Count=count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.confirmMobileSkipCount = this.totalCount(result?.body?.tables[0]?.rows);          
          var skippedMobile = result?.body?.tables[0]?.rows;
          this.getConfirmMobileUpdatedCount(skippedMobile, promptData);
        })
  }
  getConfirmMobileUpdatedCount(skippedData : any, promptData : any){
    var query = "customEvents | where name in ('UI-POSTAUTH-CONFIRM-MOBILE-API-SUCCESS') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id), Count=count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.confirmMobileUpdateCount = this.totalCount(result?.body?.tables[0]?.rows);          
          var updatedMobile = result?.body?.tables[0]?.rows;
          this.getConfirmMobileSuccessCount(updatedMobile, skippedData, promptData)
        })
  }
  getConfirmMobileSuccessCount(updatedData : any, skippedData : any, promptData : any){
    var query = "customEvents | where name in ('UI-POSTAUTH-CONFIRM-MOBILE-API') | where timestamp >= startofyear(now()) | summarize Unique = dcount(session_Id), Count=count() by month =startofmonth(timestamp) | order by month asc";
    this.http._httpDataGet(this.appInsightsApiEndPoints+ query).subscribe((result: apiResponse) => {
          this.confirmMobileSuccessCount = this.totalCount(result?.body?.tables[0]?.rows);         
          this.confirmMobileMobilePromptCount = this.confirmMobileUpdateCount  + this.confirmMobileSuccessCount + this.confirmMobileSkipCount;
          this.confirmMobileSuccessCountPercent =((this.confirmMobileSuccessCount/this.confirmMobileMobilePromptCount) *100).toFixed(1);
          this.confirmMobileSkippedCountPercent = ((this.confirmMobileSkipCount/this.confirmMobileMobilePromptCount) *100).toFixed(1) ;
          this.confirmMobileUpdateCountPercent = ((this.confirmMobileUpdateCount/this.confirmMobileMobilePromptCount) *100).toFixed(1) ;
          var confirmedMobile = result?.body?.tables[0]?.rows;
          setTimeout(()=>{      
            this.confirmMobileData = [
              {
                "name": "Confirmed",
                "value": this.confirmMobileSuccessCount
              },
              {
                "name": "Updated",
                "value": this.confirmMobileUpdateCount
              },
              {
                "name": "Skipped",
                "value": this.confirmMobileSkipCount
              }
            ]
          }, 500);
          this.getConfirmMobileNumberPromptGraph(promptData,confirmedMobile, updatedData, skippedData);
    })
    
  }
  getConfirmMobileNumberPromptGraph(promptData:any, confirmed:any, updated:any, skipped:any){
    var outerArrayObj = [];
    var seriesConfirmedObj = [];         
    var seriesSkippedObj = []; 
    var seriesUpdatedObj = []; 
    promptData.forEach(function(prompt) { 
        confirmed.forEach(function(confirmedItem) {
            if (confirmedItem[0] == prompt[0]) {                
                var elementJObj = {
                    "value": confirmedItem[2],
                    "name": confirmedItem[0]
                };
                seriesConfirmedObj.push(elementJObj)
                return;
            }      
          });
        
        skipped.forEach(function(skippedItem) {
            if (skippedItem[0] == prompt[0]) {               
                var elementJObj = {
                    "value": skippedItem[2],
                    "name": skippedItem[0]
                };
                seriesSkippedObj.push(elementJObj)
                return;
            }
        });  
        
        updated.forEach(function(updatedItem) {
          if (updatedItem[0] == prompt[0]) {              
              var elementJObj = {
                  "value": updatedItem[2],
                  "name": updatedItem[0]
              };
              seriesUpdatedObj.push(elementJObj)
              return;
          }
      }); 
    });
    var confirmedObj = {
      "name": 'Mobile Number Confirmed',
      "series": seriesConfirmedObj
    };    
    outerArrayObj.push(confirmedObj);

    var skippedObj = {
    "name": 'Mobile Number Skipped',
    "series": seriesSkippedObj
    };   
    outerArrayObj.push(skippedObj);

    var updatedObj = {
      "name": 'Mobile Number Updated',
      "series": seriesUpdatedObj
      };   
      outerArrayObj.push(updatedObj);

    console.log("confrmmob",outerArrayObj);
    this.confirmMobilePrompt = outerArrayObj;
  }
  onSelect(data): void {
    console.log('Item clicked', JSON.parse(JSON.stringify(data)));
  }

  onActivate(data): void {
    console.log('Activate', JSON.parse(JSON.stringify(data)));
  }

  onDeactivate(data): void {
    console.log('Deactivate', JSON.parse(JSON.stringify(data)));
  }
  totalCount(rows : any) {
    let total = 0;
    for(let data of rows){
      total += data[1];
    }
    return total;
  }
  formatPercent(axisDate) {
  try{
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];
    var localDate =new Date(axisDate);
    var month =months [ localDate.getMonth()-1];
    var year = localDate.getFullYear();
    return  month + '-' + year;
  }
  catch{
    return axisDate;
  }
  }
}



  



