import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AssetLoaderService {
  private renderer: Renderer2;

  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  /**
   * @param url Location of the script source
   * @returns Either the DOM node generated for the script if it does not exist or `true` if it already exists or has been loaded
   */
  public createExternalScript(url: string): HTMLScriptElement | boolean {
    const existingScripts: HTMLScriptElement[] = Array.from(
      document.getElementsByTagName('script')
    );
    if (
      existingScripts.filter((existingScript) =>
        existingScript?.src?.includes(url)
      ).length > 0
    ) {
      return true;
    }
    const newScript: HTMLScriptElement = this.renderer.createElement('script');
    this.renderer.setAttribute(newScript, 'type', 'text/javascript');
    this.renderer.setAttribute(newScript, 'src', url);
    return newScript;
  }

  /**
   * @param url Location of the link source
   * @returns Either the DOM node generated for the link if it does not exist or `true` if it already exists or has been loaded
   */
  public createExternalLink(url: string): HTMLLinkElement | boolean {
    const existingLinks: HTMLLinkElement[] = Array.from(
      document.getElementsByTagName('link')
    );
    if (
      existingLinks.filter((existingLink) => existingLink?.href?.includes(url))
        .length > 0
    ) {
      return true;
    }
    const newLink: HTMLLinkElement = this.renderer.createElement('link');
    this.renderer.setAttribute(newLink, 'rel', 'stylesheet');
    this.renderer.setAttribute(newLink, 'type', 'text/css');
    this.renderer.setAttribute(newLink, 'href', url);
    return newLink;
  }

  /**
   * @param text Location of the script source
   * @returns Either the DOM node generated for the script if it does not exist or `true` if it already exists or has been loaded
   */
   public createScripts(script: string, idValue: string): HTMLScriptElement | boolean {
    const newScript: HTMLScriptElement = this.renderer.createElement('script');
    this.renderer.setAttribute(newScript, 'type', 'text/javascript');
    this.renderer.setAttribute(newScript, 'text', script);
    this.renderer.setAttribute(newScript, 'id', idValue);
    return newScript;
  }

  public appendExternalAsset(parent: HTMLElement, child: HTMLElement): void {
    this.renderer.appendChild(parent, child);
  }

  public removeExternalAsset(parent: HTMLElement, child: HTMLElement): void {
    this.renderer.removeChild(parent, child);
  }
}
