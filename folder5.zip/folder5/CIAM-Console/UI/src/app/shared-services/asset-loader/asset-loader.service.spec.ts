import { TestBed } from '@angular/core/testing';

import { AssetLoaderService } from './asset-loader.service';

describe('AssetLoaderService', () => {
  let service: AssetLoaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AssetLoaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create a link', () => {
    service.createExternalLink('test');
    expect(true).toBe(true);
  });

  it('should create a script tag', () => {
    service.createExternalScript('test');
    expect(true).toBe(true);
  });

  it('should appendChild ', () => {
    let parentElem = document.createElement('div');
    let childElem = document.createElement('p');
    service.appendExternalAsset(parentElem,childElem);
    expect(true).toBe(true);
  });
  it('should removeChild ', () => {
    let parentElem = document.createElement('div');
    let childElem = document.createElement('p');
    service.appendExternalAsset(parentElem,childElem);
    service.removeExternalAsset(parentElem,childElem);
    expect(true).toBe(true);
  });
});
