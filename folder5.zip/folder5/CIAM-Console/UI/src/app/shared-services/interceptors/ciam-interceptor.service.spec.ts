import { HttpHandler, HttpHeaderResponse, HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';

import { CiamInterceptorService } from './ciam-interceptor.service';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { Observable, of } from 'rxjs';

describe('CiamInterceptorService', () => {
  let service: CiamInterceptorService;
  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      providers:[{ provide: Router, useValue: mockRouter }]
    });
    service = TestBed.inject(CiamInterceptorService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call interceptor', () => {

    let response = {body: { status: 'FAILED', code: 'access_denied' },
      headers: new HttpHeaders(),
      status: 400,
      statusText: 'FAILED',
      url: null};

      const resp = new HttpResponse(response);
      // resp.body = '';


    const next: any = {
      handle: () => {
        return of(resp)
      }
    };
    
    const requestMock = new HttpRequest('GET', '/test');
    service.intercept(requestMock, next).subscribe((res) => {
        expect(1).toBe(1);
    });
   
});

// it('should call interceptor with success', () => {

//   let response = {body: { status: 'SUCCESS', code: 'access_denied' },
//     headers: new HttpHeaders(),
//     status: 400,
//     statusText: 'SUCCESS',
//     url: null};

//     const resp = new HttpResponse(response);
//     // resp.body = '';


//   const next: any = {
//     handle: () => {
//       return of(resp)
//     }
//   };
  
//   const requestMock = new HttpRequest('GET', '/test');
//   service.intercept(requestMock, next).subscribe((res) => {
//       expect(1).toBe(1);
//   });
 
// });
});
