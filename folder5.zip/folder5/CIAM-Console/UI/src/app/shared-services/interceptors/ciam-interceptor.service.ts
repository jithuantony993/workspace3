import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SharedService } from '../../shared-services/shared/shared.service';
import { map, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';



@Injectable({ providedIn: 'root' })

export class CiamInterceptorService implements HttpInterceptor {

  constructor(private router: Router, private sharedService: SharedService) { }
 
  intercept(httpRequest: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    return next.handle(httpRequest).pipe(

      map((event: HttpEvent<any>) => {

        console.log(event);
        if (event instanceof HttpResponse) {
          this.sharedService.updateRefID(event?.body?.referenceId);
          if (event?.body?.status=='FAILED' && (event?.body?.code=='access_denied' || event?.body?.code=='server_error')) {
            this.router.navigate(['/sign-in-failure'], { skipLocationChange: true }); 
            return;
          }if(event?.body?.status == 'RESUME'){
            window.location.href = event?.body?.resumeUrl;
          }else{
             return event;
          }
        }else {
          return event;
        }

    })

    );

  }
  
}
