import { HttpClientTestingModule , HttpTestingController} from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AppConfigService } from './app.config.service';
import { environment } from 'src/environments/environment';


describe('AppConfigService', () => {
  let service:AppConfigService;
  let httpMock: HttpTestingController;
  beforeEach(async() => {
    TestBed.configureTestingModule({
    
      imports: [HttpClientTestingModule],
      providers:[{
        provide:AppConfigService
      }]
      
    }).compileComponents();
    service = TestBed.inject(AppConfigService);
    httpMock = TestBed.inject(HttpTestingController);
  });
  it('should be created', () => {
   // const service: AppConfigService = TestBed.inject(AppConfigService);
    expect(service).toBeTruthy();
  });

  it('should call fetch json file', (done) => {

    service.load().then((res)=>{
      expect(res).toEqual();
      done();
    })

    let  settingsRequest = httpMock.expectOne(`${environment.configPath}.${environment.name}.json`);
    settingsRequest.flush({});

    httpMock.verify();

  });

  it('should thrown ', (done) => {
    let file  = environment.configPath+'.'+environment.name+'.json'
    let error = 'File loading error '+file+' <=> {"headers":{"normalizedNames":{},"lazyUpdate":null,"headers":{}},"status":0,"statusText":"Unknown Error","url":"./assets/config/config.local.json","ok":false,"name":"HttpErrorResponse","message":"Http failure response for ./assets/config/config.local.json: 0 ","error":{"isTrusted":false}}'
    service.load().then((res)=>{
      // expect(res).toEqual();
      // done();
    }).catch((error)=>{
      expect(error).toBe(error);
      done();
    })

    let  settingsRequest = httpMock.expectOne(`${environment.configPath}.${environment.name}.json`);
    settingsRequest.error(new ErrorEvent(error));

    httpMock.verify();

  });

})
