import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { MAAPPConfig as CIAMAPPConfig } from '../../ma-interface/api-response-interface';
@Injectable({
  providedIn: 'root'
})
export class AppConfigService {
  static settings: CIAMAPPConfig;
  constructor(private http: HttpClient) {}
  load() {
    const configFile = `${environment.configPath}.${environment.name}.json`;
    return new Promise<void>((resolve, reject) => {
        this.http.get(configFile).toPromise().then((response: CIAMAPPConfig) => {
          AppConfigService.settings = response;
          resolve();
        }).catch((response: any) => {
            reject(`File loading error '${configFile}'<=> ${JSON.stringify(response)}`);
        });
    });
  }
}
