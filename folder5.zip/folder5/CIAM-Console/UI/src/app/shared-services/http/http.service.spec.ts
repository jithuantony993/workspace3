import { TestBed } from '@angular/core/testing';
import { HttpService } from './http.service';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP } from '@ionic-native/http/ngx';

describe('HttpService', () => {
    let service: HttpService;
    let httpTestingController: HttpTestingController;
    let httpClient: HttpClient;

    beforeEach(async() => {
        TestBed.configureTestingModule({
            imports: [HttpClientTestingModule],
            providers: [HTTP]
        });

        httpClient = TestBed.inject(HttpClient);
        httpTestingController = TestBed.inject(HttpTestingController);
        service = TestBed.inject(HttpService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('should check for the base url', () => {
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        const url = "/testurl2";
        const options = {
            external: true
        }
        expect(service.generateUrl(url, options)).toEqual(service.base_url.consoleBaseApiUrl + url);
    })

    /* post Method:Start */

    it('should return expected data on POST 200', () => {
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }

        const expectedResult = { TestResponse: 1 };
        service._post("testApi/sample", {}).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );

        // service should have made to check the post url
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('POST');

        const headers = new HttpHeaders()
        // Expect server to return the data after POST
        const expectedResponse = new HttpResponse({
            status: 200,
            statusText: 'OK',
            body: expectedResult
        });
        req.event(expectedResponse);
    });

    it('should return error response for POST 404 error', () => {
        const postErrorMsg = 'Deliberate 404 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._post("testApi/sample", {}).subscribe(
            data => fail('should have failed with the 404 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(postErrorMsg, 'message');
            }
        );
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(postErrorMsg, { status: 404, statusText: 'Deliberate 404 error' });
    });

    /* post Method:End */


    /* get Method:start */

    it('should return expected data on GET 200', () => {
        const expectedResult = { TestResponse: 1 };
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }

        service._get("testApi/sample/get", {}, null).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );

        // service should have made to check the get url
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/get";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('GET');

        // Respond with mock data, causing Observable to resolve.
        // Subscribe callback asserts that correct data was returned.
        req.flush(expectedResult);

        // Finally, assert that there are no outstanding requests.
        httpTestingController.verify();
    });

    it('should return error response for GET 403 error', () => {
        const getErrorMsg = 'Deliberate 403 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._get("testApi/sample/get", {}, null).subscribe(
            data => fail('should have failed with the 404 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(getErrorMsg, 'message');
            }
        );
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/get";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(getErrorMsg, { status: 403, statusText: 'Deliberate 403 error' });
    });

    /* get Method:End */


    /* PUT Method start */

    it('should return expected data on PUT 200', () => {
        const expectedResult = { TestResponse: 1 };
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }

        service._put("testApi/sample/put", {}).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );

        // service should have made to check the put url
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/put";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('PUT');

        // Expect server to return the data after POST
        const expectedResponse = new HttpResponse({
            status: 200,
            statusText: 'OK',
            body: expectedResult
        });
        req.event(expectedResponse);
    });


    it('should return error response for PUT 500 error', () => {
        const putErrorMsg = 'deliberate 500 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._put("testApi/sample/put", {}).subscribe(
            data => fail('should have failed with the 500 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(putErrorMsg, 'message');
            }
        );
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/put";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(putErrorMsg, { status: 500, statusText: 'deliberate 500 error' });
    });

    /* PUT Method end */

    /* Delete Method start */

    xit('should return expected data on Delete', () => {
        const expectedResult = { TestResponse: 1 };
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._delete("testApi/sample/delete", {}).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );
        // service should have made to check the post url
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/delete";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('DELETE');

        // Respond with mock data, causing Observable to resolve.
        // Subscribe callback asserts that correct data was returned.
        req.flush(expectedResult);

        // Finally, assert that there are no outstanding requests.
        httpTestingController.verify();
    });

    xit('can test for 400 invalid input error', () => {
        const deleteErrorMsg = 'Deliberate 400 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._delete("testApi/sample/delete", {}).subscribe(
            data => fail('should have failed with the 400 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(deleteErrorMsg, 'message');
            }
        );
        const envUrl = service.base_url.consoleBaseApiUrl + "testApi/sample/delete";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(deleteErrorMsg, { status: 400, statusText: 'Deliberate 400 error' });
    });

    /* Delete method: End */


     /* call external Method get with response tex/html */

     it('should return expected data on get external', () => {
        const expectedResult = '{ "TestResponse": 1 }';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._getExternal("baseURL/sample/get", {}).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );
        // service should have made to check the post url
        const envUrl = service.base_url.consoleBaseApiUrl + "/sample/get";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('GET');

        // Respond with mock data, causing Observable to resolve.
        // Subscribe callback asserts that correct data was returned.
        req.flush(expectedResult);

        // Finally, assert that there are no outstanding requests.
        httpTestingController.verify();
    });

    it('can test for 400 get external', () => {
        const getErrorMsg = 'Deliberate 400 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._getExternal("baseURL/testApi/sample/get", {}).subscribe(
            data => fail('should have failed with the 400 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(getErrorMsg, 'message');
            }
        );
        const envUrl = service.base_url.consoleBaseApiUrl + "/testApi/sample/get";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(getErrorMsg, { status: 400, statusText: 'Deliberate 400 error' });
    });

    /* Delete method: End */


    /* call external Method get with response tex/html */

    it('should return expected data on postexternal', () => {
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }

        const expectedResult = { TestResponse: 1 };
        service._postExternal("testApi/sample", {}).subscribe(
            resp => {
                expect(resp.body).toEqual(expectedResult, 'should return expected data')
            },
            fail
        );

        // service should have made to check the post url
        const envUrl =  "testApi/sample";
        const req = httpTestingController.expectOne(envUrl);
        expect(req.request.method).toEqual('POST');

        const headers = new HttpHeaders()
        req.flush(expectedResult);

        // Finally, assert that there are no outstanding requests.
        httpTestingController.verify();
    });

    it('can test for 400  postexternal', () => {
        const postErrorMsg = 'Deliberate 404 error';
        service.base_url = {
            consoleBaseApiUrl: "baseURL"
        }
        service._postExternal("testApi/sample", {}).subscribe(
            data => fail('should have failed with the 404 error'),
            (error: HttpErrorResponse) => {
                expect(error.error).toEqual(postErrorMsg, 'message');
            }
        );
        const envUrl ="testApi/sample";
        const req = httpTestingController.expectOne(envUrl);

        // Respond with mock error
        req.flush(postErrorMsg, { status: 404, statusText: 'Deliberate 404 error' });
    });

    /* Delete method: End */

});
