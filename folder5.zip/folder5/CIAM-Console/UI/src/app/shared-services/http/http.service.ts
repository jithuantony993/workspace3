import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { Observable, Observer, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { AppTrailers } from '../app-trailers/app-trailers.service';
import { apiResponse, apiResponseLog } from '../../ma-interface/api-response-interface';
import { AppConfigService } from '../ciam-appconfig/app.config.service';
import { SharedService } from '../shared/shared.service';
import { HTTP } from '@ionic-native/http/ngx';
@Injectable({
  providedIn: 'root'
})
export class HttpService {
  base_url = AppConfigService.settings?.server;
  constructor(
    private httpClient: HttpClient,
    private appTrailers: AppTrailers,
    private ionicHttp: HTTP,
    private sharedService: SharedService) { }
  /**
   * 
   * @returns headers for the api call
   */
  getHttpOption() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    }
  }

  getHttpDataOption() {
    return {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'x-api-key': this.sharedService.loginUser.authStatus == "MasterUser" ?'n5567cy3ccfxnov0lweq4e1am4klww3hresbq273':'lpm2u1fkt405cxmm71zilm6fdnavv4a183c7zcha'
      })
    }
  }
  /**
   * 
   * @param url => stable url
   * @returns => url append with current enviornment url
   */
  generateUrl(url: string, options: any) {
    return this.sharedService._isMYBNative? localStorage.getItem('CIAMBaseAppUrl')+url: this.base_url?.consoleBaseApiUrl + url;
  }

  /**
      * 
      * @param url - api path
      * @param options - data to be passed to backend
      * @returns response from the backend
      */

  public _get(path: string, options?: any, requestParams?: any, direct_url: boolean = false): Observable<any> {
    let api_url = direct_url ? path : this.generateUrl(path, {});
    return this.sharedService._isMYBNative ? this._ionicget(api_url, options, requestParams) : this._httpget(api_url, options, requestParams);
  }


  /**
      * httpclient call
      * @param url - api path
      * @param options - data to be passed to backend
      * @returns response from the backend
      */
  public _httpget(api_url: string, options?: any, requestParams?: any): Observable<any> {
    return this.httpClient
      .get(api_url,
        {
          headers: this.getHttpOption().headers,
          observe: 'response',
          params: requestParams
        })
      .pipe(map((response: apiResponse) => {
        this.appTrailers.dependencyData(api_url, response.status, "GET", "1000");
        return response;
      }
      ),
        catchError((error: HttpErrorResponse) => {
          this.appTrailers.dependencyData(error.url, error.status, "GET", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return throwError(error);
        }));
  }

  public _httpDataGet(api_url: string, options?: any): Observable<any> {
    return this.httpClient
      .get(api_url,
        {
          headers: this.getHttpDataOption().headers,
          observe: 'response'
         
        })
      .pipe(map((response: apiResponse) => {
        this.appTrailers.dependencyData(api_url, response.status, "GET", "1000");
        return response;
      }
      ),
        catchError((error: HttpErrorResponse) => {
          this.appTrailers.dependencyData(error.url, error.status, "GET", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return throwError(error);
        }));
  }

  /**
      * native ionic client
      * @param url - api path
      * @param options - data to be passed to backend
      * @returns response from the backend
      */
  public _ionicget(api_url: string, options?: any, requestParams?: any): Observable<any> {

    return new Observable((observer: Observer<object>) => {

      this.ionicHttp.get(api_url, requestParams, this.getHttpOption().headers)
        .then(res => {
          this.appTrailers.dependencyData(api_url, res.status, "GET", "1000");
          return observer.next(res);
        })
        .catch((error) => {
          this.appTrailers.dependencyData(error.url, error.status, "GET", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return observer.next(error);
        })

    });
  }

  /**
   * 
   * @path url - api path
   * @requestParams data -  passed to the db
   * @returns  response from the backend
   */
  public _post(path: string, requestParams: any, direct_url: boolean = false): Observable<any> {

    let api_url = direct_url ? path : this.generateUrl(path, {});
    return this.sharedService._isMYBNative ? this._ionicpost(api_url, requestParams) : this._httppost(api_url, requestParams);

  }


  /**
   * http client call
   * @path url - api path
   * @requestParams data -  passed to the db
   * @returns  response from the backend
   */
  public _httppost(api_url: string, requestParams: any): Observable<any> {
    return this.httpClient
      .post(api_url,
        JSON.stringify(requestParams), {
        headers: this.getHttpOption().headers,
        observe: 'response',
      })
      .pipe(map(
        (response: apiResponse) => {
          this.sharedService.updateRefID(response?.body['referenceId']);
          this.appTrailers.dependencyData(api_url, response.status, "POST", "1001");
          return response;
        }
      ),
        catchError((err: HttpErrorResponse) => {
          this.appTrailers.dependencyData(err.url, err.status, "POST", "1000");
          this.appTrailers.exceptionTrack(err.statusText);
          return throwError(err);
        }));
  }
  /**
  * ionic client call
  * @path url - api path
  * @requestParams data -  passed to the db
  * @returns  response from the backend
  */
  public _ionicpost(api_url: string, requestParams: any): Observable<any> {

    return new Observable((observer: Observer<object>) => {

      this.ionicHttp.post(api_url, requestParams, this.getHttpOption().headers)
        .then((response: apiResponse) => {
          this.sharedService.updateRefID(response?.body['referenceId']);
          this.appTrailers.dependencyData(api_url, response.status, "POST", "1001");
          return observer.next(response);
        })
        .catch((error: HttpErrorResponse) => {
          this.appTrailers.dependencyData(error.url, error.status, "POST", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return observer.next(error);
        })

    });
  }


  /**
   * 
   * @path url - api path
   * @requestParams data -  passed to the db
   * @returns  response from the backend
   */
  public _postExternal(path: string, requestParams: any): Observable<any> {
    let api_url = path;
    return this.sharedService._isMYBNative ? this._ionicPostExternal(api_url, requestParams) : this._httpPostExternal(api_url, requestParams);
  }


  /**
   * 
   * @path url - api path
   * @requestParams data -  passed to the db
   * @returns  response from the backend
   */
  public _ionicPostExternal(api_url: string, requestParams: any): Observable<any> {

    return new Observable((observer: Observer<object>) => {

      this.ionicHttp.post(api_url, requestParams, this.getHttpOption().headers)
        .then((response: apiResponse) => {
          return observer.next(response);
        })
        .catch((error: HttpErrorResponse) => {
          return observer.next(error);
        })

    });
  }


  /**
   * 
   * @path url - api path
   * @requestParams data -  passed to the db
   * @returns  response from the backend
   */
  public _httpPostExternal(api_url: string, requestParams: any): Observable<any> {
    return this.httpClient
      .post(api_url,
        JSON.stringify(requestParams), {
        headers: this.getHttpOption().headers,
        observe: 'response',
      })
      .pipe(map(
        (response) => {
          return response;
        }
      ),
        catchError((err: HttpErrorResponse) => {
          return throwError(err);
        }));
  }



  /**
        * 
        * @param url - api path
        * @param options - data to be passed to backend
        * @returns response from the backend
        */
  public _getExternal(url: string, options?: any, requestParams?: any): Observable<any> {
    let api_url = url

    return this.httpClient
      .get(api_url,
        {
          headers: new HttpHeaders({
            'Accept': 'text/html'
          }),
          responseType: 'text',
          observe: 'response',
          params: requestParams
        })
      .pipe(map((response) => {
        // this.appTrailers.dependencyData(api_url, response.status, "GET", "1000");
        return response;
      }
      ),
        catchError((error: HttpErrorResponse) => {
          // this.appTrailers.dependencyData(error.url, error.status, "GET", "1000");
          // this.appTrailers.exceptionTrack(error.statusText);
          return throwError(error);
        }));
  }

  /**
   * common call
   * @param url - api path
   * @param requestParams - which passed to the db
   * @returns response from the api
   */
  public _put(url: string, requestParams: any): Observable<any> {

    let api_url = this.generateUrl(url, {});
    //let httpOptions = this.getHttpOption()
    //return this.httpClient.put(api_url, requestParams, httpOptions)
    return this.sharedService._isMYBNative ? this._ionicPut(api_url, requestParams) : this._httpPut(api_url, requestParams);
  }


  /**
   * ionic client call
   * @param url - api path
   * @param requestParams - which passed to the db
   * @returns response from the api
   */
  public _ionicPut(api_url: string, requestParams: any): Observable<any> {
    //let httpOptions = this.getHttpOption()
    //return this.httpClient.put(api_url, requestParams, httpOptions)

    return new Observable((observer: Observer<object>) => {

      this.ionicHttp.put(api_url, requestParams, this.getHttpOption().headers)
        .then((response: apiResponse) => {
          this.sharedService.updateRefID(response?.body['referenceId']);
          this.appTrailers.dependencyData(api_url, response.status, "PUT", "1000");
          return observer.next(response);
        })
        .catch((error: HttpErrorResponse) => {
          this.appTrailers.dependencyData(error.url, error.status, "PUT", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return observer.next(error);
        })

    });
  }

  /**
   * http client call
   * @param url - api path
   * @param requestParams - which passed to the db
   * @returns response from the api
   */
  public _httpPut(api_url: string, requestParams: any): Observable<any> {
    //let httpOptions = this.getHttpOption()
    //return this.httpClient.put(api_url, requestParams, httpOptions)
    return this.httpClient.put(api_url,
      JSON.stringify(requestParams), {
      headers: this.getHttpOption().headers,
      observe: 'response',
    }).pipe(map((response: apiResponse) => {
      this.sharedService.updateRefID(response?.body['referenceId']);
      this.appTrailers.dependencyData(api_url, response.status, "PUT", "1000");
      return response;
    }
    ),
      catchError((err: HttpErrorResponse) => {
        this.appTrailers.dependencyData(err.url, err.status, "PUT", "1000");
        this.appTrailers.exceptionTrack(err.statusText);
        return throwError(err);
      })
    )
  }

  /**
   * 
   * @param url - api path 
   * @param requestParams - data such as id which is to be deleted 
   * @returns response from the api
   */

  public _delete(url: string, requestParams?: any): Observable<any> {
    let api_url = this.generateUrl(url, {});
    //return this.httpClient.delete(api_url, httpOptions)
    return this.sharedService._isMYBNative ? this._ionicDelete(api_url, requestParams) : this._httpDelete(api_url, requestParams);
  }


  /**
  * ionic client call
  * @param url - api path 
  * @param requestParams - data such as id which is to be deleted 
  * @returns response from the api
  */

  public _ionicDelete(api_url: string, requestParams?: any): Observable<any> {
    return new Observable((observer: Observer<object>) => {
      this.ionicHttp.delete(api_url, requestParams, this.getHttpOption())
        .then((response: any) => {
          this.appTrailers.dependencyData(api_url, response.statusCode, "DELETE", "1000");
          return observer.next(response);
        })
        .catch((error: HttpErrorResponse) => {
          this.appTrailers.dependencyData(error.url, error.status, "DELETE", "1000");
          this.appTrailers.exceptionTrack(error.statusText);
          return observer.next(error);
        })
    });
  }

  /**
* http client call
* @param url - api path 
* @param requestParams - data such as id which is to be deleted 
* @returns response from the api
*/

  public _httpDelete(url: string, requestParams?: any): Observable<any> {
    let api_url = this.generateUrl(url, {});
    let httpOptions = this.getHttpOption()
    //return this.httpClient.delete(api_url, httpOptions)
    return this.httpClient.delete(api_url, {
      headers: this.getHttpOption().headers,
      observe: 'response',
    }).pipe(map((response: any) => {
      this.appTrailers.dependencyData(api_url, response.statusCode, "DELETE", "1000");
      return response;
    }
    ),
      catchError((err: HttpErrorResponse) => {
        this.appTrailers.dependencyData(err.url, err.status, "DELETE", "1000");
        this.appTrailers.exceptionTrack(err.statusText);
        return throwError(err);
      })
    )
  }

}

