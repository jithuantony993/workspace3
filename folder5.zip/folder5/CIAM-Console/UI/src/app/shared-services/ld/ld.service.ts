import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { initialize } from "launchdarkly-js-client-sdk";
import { AppConfigService } from '../ciam-appconfig/app.config.service';

@Injectable({
    providedIn: 'root'
})

export class LDService {
    private _ldClient: any;
    _ld_config = AppConfigService.settings?.ldClient;
    private _flags: any;
    flagChange: Subject<any> = new Subject<any>();

    constructor() {
        this.initialize();
    }

    initialize(){
        this._flags = {};    
        this._ldClient = initialize(this._ld_config.key,
            { key: "PrabhashVS", anonymous: true });
      
        this._ldClient.on('change', (flags: any) => {     
            for (let flag in flags) {
                this._flags[flag] = flags[flag].current;
            }
            this.flagChange.next(this._flags);
        });

        this._ldClient.on('ready', () => {
            this.setFlags();
        })
    }

    getSwitch(toggleName: string): boolean {
        let flag = this._flags[toggleName];
        if (flag == undefined) {
            this._flags[toggleName] = false;
            flag = false;
        }
        return flag;
    }

    getCountries(flagName: string): string {
        let data = this._flags[flagName];
        if (data == undefined || data== "") {
            this._flags[flagName] = ['us', 'ca', 'au', 'in'];
            data = ['us', 'ca', 'au', 'in'];
        }
        return JSON.stringify(data);
    }

    setFlags() {
        this._flags = this._ldClient?.allFlags();
        this.flagChange.next(this._flags);
    }

    setLDClient(ldClient: any) {
        this._ldClient = ldClient;
    }
}