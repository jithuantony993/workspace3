import { TestBed } from '@angular/core/testing';
import { NavigationEnd, Router } from '@angular/router';
import { of } from 'rxjs';
import { LDService } from './ld.service';
import { AppConfigService } from '../ciam-appconfig/app.config.service';


describe('LDService', function (){

    let service: LDService;
  
    beforeEach(() => {
      AppConfigService.settings = {
        ldClient: {
          key: 'test'
        }
      } as any;
      TestBed.configureTestingModule({});
      service = TestBed.inject(LDService);
      //service = new LDService();
     
      // TestBed.configureTestingModule({
        
      //   providers: [
      //     {
      //       provide: Router,
      //       useValue: {
      //         events: of(new NavigationEnd(1, '', '')),
      //       },
      //     },
      //   ],
      // });
      // service = TestBed.inject(LDService);
     
    });
  
    
    it('should be created', () => {
      service.setLDClient({
        allFlags: () => {
          return {'us': "us", 'ca': 'ca', 'au':'au', 'in': ''};
        }
      });
      service.setFlags();
      service.getCountries('in');
      expect(service).toBeTruthy();
    });

	it('should match the countries',  () =>{
        let data:  string[] = ['us', 'ca', 'au', 'in'];
        var dataRes = service.getCountries("coumtryFlag");
        expect(dataRes).toContain("us");
    });

  it('should return true or false', () =>{
    var dataRes = service.getSwitch("coumtryFlag");
    expect(dataRes).toBe(false)
  });
});