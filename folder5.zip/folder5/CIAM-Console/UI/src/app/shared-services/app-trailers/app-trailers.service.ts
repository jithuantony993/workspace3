import { Injectable } from '@angular/core';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import { DeviceDetectorService, DeviceInfo } from 'ngx-device-detector';
import { SharedService } from '../../shared-services/shared/shared.service';
import { AppConfigService } from '../ciam-appconfig/app.config.service';


@Injectable({
  providedIn: 'root'
  })

export class AppTrailers {

  deviceInfo:DeviceInfo;
  device: any;

  appInsights: ApplicationInsights;

  constructor(
    private deviceDetectorService: DeviceDetectorService,
    private sharedService: SharedService
  ) {
    const appInsightsKey = AppConfigService.settings?.appInsightKey;
    if (!appInsightsKey) {
      // add custom behavior to handle this scenario
      //console.error('Application Insights key not found.');
      return;
    }
    this.appInsights = new ApplicationInsights({
      config: {
        instrumentationKey: appInsightsKey //'b60b6e3f-4737-489f-b84e-7df8014edfd7'    
      }
    });

    this.appInsights.loadAppInsights();
    this.appInsights.trackPageView();
  }
  add(tagName: string) {
      this.deviceInfo = this.deviceDetectorService.getDeviceInfo();
      var hostname:string = window.location.hostname;
         
      this.appInsights?.trackEvent({
          name: tagName,
          properties: { 
            AppName : "CIAM",
            ModuleName: "Authentication",
            HostName: hostname,
            TagName : 'AR_'+tagName,
            UserAgent: this.deviceInfo?.userAgent,
            BrowserName: this.deviceInfo?.browser,
            BrowserVersion: this.deviceInfo?.browser_version,
            OS: this.deviceInfo?.os,
            OSVersion: this.deviceInfo?.os_version,
            Device: this.deviceInfo?.device,
            DeviceType: this.deviceInfo?.deviceType,
            DeviceOrientation: this.deviceInfo?.orientation,
            TrackingId: (this.sharedService?.refID) ? this.sharedService?.refID : ''
          }
        });
  }
    processTime(name : string, time: any){
      this.appInsights?.trackMetric({name: name, average: time});
    }

    dependencyData(url: string, responseCode: any, type: string, id: string){
      this.appInsights?.trackDependencyData({name: url, responseCode: responseCode, type: type, id: id});
    }
    
    exceptionTrack(error: string){
      this.appInsights?.trackException({exception: new Error(error)});
    }

    pageView(pageName: string){
      this.appInsights?.trackPageView({name: pageName});
    }

    pageViewPerformance(pageName: string, url: string){
      this.appInsights?.trackPageViewPerformance({name: pageName, uri: url})
    }
    
    addLog(tagName : string){
      this.deviceInfo = this.deviceDetectorService.getDeviceInfo();
      var hostname:string = window.location.hostname;
      this.appInsights?.trackEvent({
          name: tagName,
          properties: { 
            AppName : "CIAM-Login",
            ModuleName: "Authentication",
            HostName: hostname,
            TagName: 'AR_'+tagName,
            TrackingId: (this.sharedService?.refID) ? this.sharedService?.refID: '',
            UserAgent: this.deviceInfo?.userAgent,
            BrowserName: this.deviceInfo?.browser,
            BrowserVersion: this.deviceInfo?.browser_version,
            OS: this.deviceInfo?.os,
            OSVersion: this.deviceInfo?.os_version,
            Device: this.deviceInfo?.device,
            DeviceType: this.deviceInfo?.deviceType,
            DeviceOrientation: this.deviceInfo?.orientation
          }
        });
    }
}

