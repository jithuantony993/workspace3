import { TestBed } from '@angular/core/testing';
import { AppTrailers } from './app-trailers.service';
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
describe('AppTrailers', () => {
  let service: AppTrailers;
  const appInsights = new ApplicationInsights({ config: {
    instrumentationKey: 'sdfkdfksfks'
} });
  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppTrailers);
  });

  it('should be created', (done) => {
    spyOn(appInsights,'loadAppInsights').and.callThrough()
    spyOn(appInsights,'trackPageView').and.callThrough();
    done();
    expect(service).toBeTruthy();
  });

  it('should call app insight track event', () => {
    service.deviceInfo = {
      userAgent:'testua',
      browser:'chrome',
      browser_version:'v8',
      os:'windows',
      os_version:'10',
      device:'test',
      deviceType:'android',
      orientation:'portrait'
    }
    spyOn(appInsights,'trackEvent').and.callThrough();
    spyOn(service,'add').and.callThrough();
    service.add('test');
    expect(service.add).toHaveBeenCalledWith('test');
  });

  it('should call app insight trackMetric event', () => {
    spyOn(appInsights,'trackMetric').and.callThrough();
    spyOn(service,'processTime').and.callThrough();
    service.processTime('test','07:40 am');
    expect(service.processTime).toHaveBeenCalledWith('test','07:40 am');
  });

  it('should call app insight trackDependencyData event', () => {
    spyOn(appInsights,'trackDependencyData').and.callThrough();
    spyOn(service,'dependencyData').and.callThrough();
    service.dependencyData('google.com','200','testdependency','123');
    expect(service.dependencyData).toHaveBeenCalledWith('google.com','200','testdependency','123');
  });

  it('should call app insight trackException event', () => {
    spyOn(appInsights,'trackException').and.callThrough();
    spyOn(service,'exceptionTrack').and.callThrough()
    service.exceptionTrack('oops something went wrong');
    expect(service.exceptionTrack).toHaveBeenCalledWith('oops something went wrong');
  });
  it('should call app insight trackPageView event', () => {
    spyOn(appInsights,'trackPageView').and.callThrough();
    spyOn(service,'pageView').and.callThrough();
    service.pageView('signin');
    expect(service.pageView).toHaveBeenCalledWith('signin');
  });
  it('should call app insight trackPageViewPerformance event', () => {
    spyOn(appInsights,'trackPageViewPerformance').and.callThrough();
    spyOn(service,'pageViewPerformance').and.callThrough();
    // let trackobj = {'name': 'ciam', 'uri': '/dashboard'};
    service.pageViewPerformance('ciam','/dashboard');
    expect(service.pageViewPerformance).toHaveBeenCalledWith('ciam','/dashboard');
  });

});
