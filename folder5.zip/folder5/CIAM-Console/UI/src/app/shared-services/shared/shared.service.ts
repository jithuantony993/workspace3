import { Injectable } from '@angular/core';
import { BehaviorSubject, timer } from 'rxjs';
import ReverseGeocode, { ILocation, IGeocode } from "bigdatacloud-reverse-geocoding";
import { AppConfigService } from '../ciam-appconfig/app.config.service';
import { LoginUser } from 'src/app/model/auth-user';
export interface modalobj {
  name: string,
  content: object
}
export interface mobileObj {
  phone: string | null,
  dialCode: string | null,
  countryCode: string | null
}

export interface profileObj {
  first_name: string | '',
  last_name: string | '',
  phone?: {}
}

export interface ServiceData {
  status: string | 'AUTHENTICATION FAILED',
  code: string | null,
  // postAuth:{} | null
}
export interface userData {
  sessionIdFromEmail:any|[],
  userFlowList: any|[],
  dataFromTrackingId:any|[],
  userInfoData:any|[],
  emailLinks: any|[] ,
  selectedUF:String|null,
  selectedSession:String|null,
  selectedImprint:String|null,
  identifier:String|null
}



@Injectable({
  providedIn: 'root'
})
export class SharedService {
  
  private serviceData = new BehaviorSubject<ServiceData>({} as any);
  update_code = this.serviceData.asObservable();
  private userDetails = new BehaviorSubject<userData>({} as any);
  update_userDetails = this.userDetails.asObservable();
  authData=null;
  deviceRecognicedInPassword:any ='';
  landingUrl = '/'; //This key hold current active url - This is used in auth guard service for restricting direct url access
  email = ""; // This key hold the current value of email
  mobile = {
    phone: '',
    dialCode: '',
    countryCode: '',
    number: ''
  };
  oob = ""; // This key hold the current value of oob
  id = "";
  uuid = "f702cbce-7f7d-487d-a66d-ca3a9583ebb9";
  guid: string=null;
  partner_id = "";
  nudataDomVal = "";
  /** for showing counter on resent otp */
  public counter = new BehaviorSubject(false);
  counter_value = this.counter.asObservable();
  timeLeft: number;
  referenceId: string;
  isTaxesApp: boolean = false;
  isMYBApp: boolean = false;
  isAndroid: boolean = false;
  isIOS: boolean = false;
  hasBiometricEnabled: boolean = false;
  isFaceid: boolean = false;
  isTouchId: boolean = false;
  accessToken: string;
  refreshToken:string;
  idToken:string;
  randomGUID: string;
  guidParam:string;
  createAccountInfo = {
    email: '',
    userPassword: ''
  };
  signInUser = "Adrian"
  caEmail = "";
  caMobile = "";
  caEmailOOBAttempt = 0;
  caMobileOOBAttempt = 0;
  isCreateAccountMobileVerifiedSuccess: boolean = false;
  _signinSeqNavFeature: boolean;

  glanceHours : number;

  locationInfo: string= "";

  latitude: any = 0; 
  longitude: any = 0;

  _isMYBNative: boolean;
  _initialDirEmail = '';
  silookupAttempt = 0;
  /**
   *profile form
   */
  profile: profileObj;
  /**
   * profile form
   */
  /** resend otp call */
  private call_resend_otp = new BehaviorSubject({
    identifier: false,
    key: ''
  });
  resend_api_call = this.call_resend_otp.asObservable();

  /**This section used to observe reference id from API response */
  private refIDSub = new BehaviorSubject('');
  refID = this.refIDSub.asObservable();
  private closeRefModelSub = new BehaviorSubject('');
  closeModelRef = this.closeRefModelSub.asObservable();


  /**This section used to observe reference model info from each api function */
  private refModelSub = new BehaviorSubject<modalobj>({} as any);
  modelRef = this.refModelSub.asObservable();

  loginUser:  LoginUser = {
    id:'',
    status: '',
    authStatus: '',
    refId: ''
  }
 

  /**
   * idle timeout variable
   */

   private idle_time = new BehaviorSubject({key:null,val:false});
   idle_ref = this.idle_time.asObservable();
  

  transferAuthCode(serviceData: ServiceData) {
    console.log("Integration Process 5");
    this.updateLoaderStatus(true);
    this.serviceData.next(serviceData);
    console.log("Integration Process 6");
  }

  /**This section used to observe loader status */
  private showLoaderSubject = new BehaviorSubject(false);
  showLoader = this.showLoaderSubject.asObservable();

  /**
   * This function used for updating referenceId from each api response
   * @param refid : Response from API execution - referenceId
   */
  updateRefID(refid: string) {
    this.refIDSub.next(refid);
  }

  /**
 * This function used for updating ref model name from each api function response
 * @param identifier : reference model name
 */
  invokeModel(identifier: modalobj) {
    this.refModelSub.next(identifier);
  }

  /**
* This function used for updating closeRefModelSub model name from each api function response
* @param identifier : reference model name
*/
  closeModel(identifier: string) {
    this.closeRefModelSub.next(identifier);
  }


  /**
   * This function used for updating Loader status
   * @param showLoader : Boolean value from screen events
   */
  updateLoaderStatus(showLoader: boolean) {
    this.showLoaderSubject.next(showLoader);
  }

  /**
  * This function used for updating ref model name from each api function response
  * @param identifier : reference model name
  */
  updateResendApi(identifier: boolean, type: string) {
    let idfObj = {
      identifier: identifier,
      key: type
    }
    this.call_resend_otp.next(idfObj);
  }

  /**
   * start timer for resend otp 
   */
  oberserableTimer() {
    this.counter.next(true);
  }

  /**
 * unsubscribe timer for resend otp 
 */
  unsubscribeTimer(){
    //this.timeLeft = 0;
    this.counter.next(false);
  }

  /**
  * This function is used to handle error api response (Error with status code 200).
  * @param response : api response 
  */

  handleError(response: any) {
    var returnMsg = null;
    switch (response?.status) {
      case 400:
        returnMsg = response?.statusText;
        break;
      case 401:
        break;
      case 500:
        this.invokeModel({ name: 'error500', content: { msg: 'hhiii' } });
        break;
      default:
        returnMsg = response?.statusMessage;
        break;
    }
    return returnMsg;
  }

  restartCreateAccount() {
    this.caEmailOOBAttempt = 0;
    this.caMobileOOBAttempt = 0;
    this.mobile = {
      phone: '',
      dialCode: '',
      countryCode: '',
      number: ''
    };
  }

  async getReverseCoding() {
    const geocode = new ReverseGeocode();
    const location: ILocation = { lat: this.latitude, long: this.longitude };
    const place: IGeocode = await geocode.locate(location);
    const appendString = place.principalSubdivision && place.countryName ? ',': ' ';
    this.locationInfo  = place.principalSubdivision + appendString +place.countryName;
  }

  getCurrentCoordinates() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        if (position) {
          this.latitude = position.coords.latitude;
          this.longitude = position.coords.longitude;
          this.getReverseCoding();
        }
      });
    }else {
      this.locationInfo = "";
    }
  }
  getAppURL(){
    return this._isMYBNative? localStorage.getItem('CIAMBaseAppUrl'): AppConfigService?.settings?.env?.appURL;
  }

  setPhone(phone:string, code:string) {
    return ((code && code !='') ? code.replace('+',''):'') + ((phone && phone !='') ? phone:'');
  }

  generateGUID(){
    this.guid='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      var r = Math.random() * 16 | 0,
        v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
/**
 * This is for updating idle time value when clicking stay signin button on popup
 * @param val => this is a boolean value always will be true
 */
  updateIdleRef(val: boolean,key:string){
    let obj = {key:key,val:val}
    this.idle_time.next(obj);
  }

  showIdleModal(){
    this.invokeModel({ name: 'idleTimeoutDialog', content: { } });
  }
  closeIdleModel(){
    this.updateIdleRef(false,'signout');
  }

  /**
 * unsubscribe timer for resend otp 
 */
  updateUserDetails(data:userData){
    //this.timeLeft = 0;
    this.userDetails.next(data)
  }
}
