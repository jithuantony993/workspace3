import { TestBed } from '@angular/core/testing';
import { BehaviorSubject } from 'rxjs';
import { filter } from 'rxjs/operators';

import { SharedService } from './shared.service';

describe('SharedService', () => {
  let service: SharedService;
  const subjectMock = new BehaviorSubject('TestMessage');
  const mockchangeMessage = {      
    selectedDate: subjectMock.asObservable()
  };

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SharedService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should trigger getReverseCoding ', () => {
    service.getReverseCoding();
    expect(1).toBe(1);
  });
  it('should trigger restartCreateAccount ', () => {
    service.restartCreateAccount();
    expect(1).toBe(1);
  });
  it('should trigger handleError response status 400 ', () => {
    let response = {
      status: 400,
      statusText:'text',
      statusMessage:'message'

   } as any;
    service.handleError(response);
    expect(1).toBe(1);
  });
  it('should trigger handleError response status 401 ', () => {
    let response = {
      status: 401,  statusText:'text',
      statusMessage:'message'
   } as any;
    service.handleError(response);
    expect(1).toBe(1);
  });
  it('should trigger handleError response status 500 ', () => {
    let response = {
      status: 500,  statusText:'text',
      statusMessage:'message'
   } as any;
    service.handleError(response);
    expect(1).toBe(1);
  });
  it('should trigger handleError response status default ', () => {
    let response = {
      status: 'default',  statusText:'text',
      statusMessage:'message'
   } as any;
    service.handleError(response);
    expect(1).toBe(1);
  });
  
  it('should trigger updateRefID ', () => {
    //spyOn(service, 'getReverseCoding').and.returnValue()
    service.updateRefID('refID');
    expect(1).toBe(1);
  });
  it('should trigger updateLoaderStatus true ', () => {
    service.updateLoaderStatus(true);
    expect(1).toBe(1);
  });
  it('should trigger closeModel true ', () => {
    service.closeModel('');
    expect(1).toBe(1);
  });
  it('should trigger oberserableTimer', () => {
    service.oberserableTimer();
    expect(1).toBe(1);
  });
  it('should trigger updateResendApi', () => {
      service.updateResendApi(true,'text');
    expect(1).toBe(1);
  });
  it('should trigger unsubscribeTimer', () => {
    service.unsubscribeTimer();
  expect(1).toBe(1);
});

it('should trigger transferAuthCode', () => {
  let serviceData : {
    status: 'AUTHENTICATION FAILED',
    code: null,
  };
  spyOn(service, 'updateLoaderStatus');
  service.transferAuthCode(serviceData);
  expect(service.updateLoaderStatus).toHaveBeenCalledWith(true);
});

it('should return only the phone number if code is empty', () => {
  const phone = '1234567890';
  const code = '';

  const result = service.setPhone(phone, code);

  expect(result).toEqual('1234567890');
});

it('should return only the code if phone number is empty', () => {
  const phone = '';
  const code = '+1';

  const result = service.setPhone(phone, code);

  expect(result).toEqual('1');
});

it('should return an empty string if both phone number and code are empty', () => {
  const phone = '';
  const code = '';

  const result = service.setPhone(phone, code);

  expect(result).toEqual('');
});

it('should trigger generateGUID', () => {
  let result : any = service.generateGUID();
  expect(result).not.toBeNull();
});

it('should trigger showIdleModal', () => {
  spyOn(service,"invokeModel");
  service.showIdleModal();
  expect(service.invokeModel).toHaveBeenCalled();
});

it('should trigger closeIdleModel', () => {
  spyOn(service,"updateIdleRef");
  service.closeIdleModel();
  expect(service.updateIdleRef).toHaveBeenCalled();
});


  // it('get message updateCode',() =>{
  //   let data = {
  //     status: '',
  //     code: ''
  //   }
  //   service.transferAuthCode(data);
  //   const value = 'TestMessage';
  //   subjectMock.pipe(filter(res => !!res))
  //   .subscribe(res => expect(res).toEqual(value));
  //   subjectMock.next(value);
  // });

});
