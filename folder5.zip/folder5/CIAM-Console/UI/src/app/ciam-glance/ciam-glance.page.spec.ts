import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HTTP } from '@ionic-native/http/ngx';
import { IonicModule } from '@ionic/angular';
import * as moment from 'moment';
import { of } from 'rxjs';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';

import { CiamGlancePage } from './ciam-glance.page';

describe('CiamGlancePage', () => {
  let component: CiamGlancePage;
  let fixture: ComponentFixture<CiamGlancePage>;

  beforeEach(async() => {
    TestBed.configureTestingModule({
      declarations: [ CiamGlancePage ],
      imports: [IonicModule.forRoot(),
      HttpClientModule,
      HttpClientTestingModule],
      providers: [HTTP, SharedService]
    }).compileComponents();

    fixture = TestBed.createComponent(CiamGlancePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.glanceHours).toBe(1);
  });

  // it('should trigger UpdateHours', () => {
  //   const event = 24;
  //   component.UpdateHours(event);
  //   expect(component.glanceHours).toBe(24);
  // });

  it('should trigger getCount', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getCount(event,0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getIdproofCount', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, null);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = CpSucc', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcSuccessRate").withArgs(19,4,1);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'CpSucc');
    expect(component.calcSuccessRate).toHaveBeenCalledWith(19,4,1);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = BpSucc', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcSuccessRate").withArgs(11,12,2);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'BpSucc');
    expect(component.calcSuccessRate).toHaveBeenCalledWith(11,12,2);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = AolSucc', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcSuccessRate").withArgs(5,6,3);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'AolSucc');
    expect(component.calcSuccessRate).toHaveBeenCalledWith(5,6,3);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = VaolSucc', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcSuccessRate").withArgs(8,23,4);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'VaolSucc');
    expect(component.calcSuccessRate).toHaveBeenCalledWith(8,23,4);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = SidpFail', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcFailureRate").withArgs(18,2,0);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'SidpFail');
    expect(component.calcFailureRate).toHaveBeenCalledWith(18,2,0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = AolFail', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcFailureRate").withArgs(5,7,3);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'AolFail');
    expect(component.calcFailureRate).toHaveBeenCalledWith(5,7,3);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCount with RateCalu = VaolFail', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(component,"calcFailureRate").withArgs(8,10,4);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCount(event,0, 'VaolFail');
    expect(component.calcFailureRate).toHaveBeenCalledWith(8,10,4);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getIdproofCountUnique', () => {
    const event = 'TEST';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getIdproofCountUnique(event,0);
    expect(component.idProofCounts[0]).toEqual('111');
  });

  it('should trigger getBPFailure', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getBPFailure(0);
    expect(component.idProofCounts[0]).toEqual('111');
  });

  it('should trigger getSfaSuccessCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSfaSuccessCount();
    expect(component.SfaSuccessCount.unique).toEqual('111');
    expect(component.SfaSuccessCount.total).toEqual('222');
  });

  it('should trigger getSfaFailureCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSfaFailureCount();
    expect(component.SfaFailureCount.unique).toEqual('111');
    expect(component.SfaFailureCount.total).toEqual('222');
  });

  it('should trigger accessByClientCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            ['111', '222','333','444']
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.accessByClientCount();
    expect(component.accessClientCount.DEFAULT_CLIENT).toEqual('111');
    expect(component.accessClientCount.MYBLOCK_CLIENT).toEqual('222');
    expect(component.accessClientCount.TXO_CLIENT).toEqual('333');
    expect(component.accessClientCount.DOTCOM_CLIENT).toEqual('444');
  });

  it('should trigger getSFAKBACount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSFAKBACount(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getCASuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111' , '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getCASuccess(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getCountByIdentifier', () => {
    const event = 'Test';
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111' , '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getCountByIdentifier(event,0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getLookUpFailure', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getLookUpFailure(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getFFASuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getFFASuccess(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getFFAFailure', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getFFAFailure(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getDeviceRecognised', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '111', '222' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getDeviceRecognised(0);
    expect(component.counts[0].unique).toEqual('111');
    expect(component.counts[0].total).toEqual('222');
  });

  it('should trigger getSIDPKBASuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSIDPKBASuccess(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getSIDPTaxOOBSuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSIDPTaxOOBSuccess(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });
  
  it('should trigger getSIDPTotalSuccess', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSIDPTotalSuccess(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getBPTypeCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getBPTypeCount("TEST",0,null);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getSpruceCount', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getSpruceCount(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getBpHardFail', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getBpHardFail(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger getBpSoftFail', () => {
    const result = {
      body : {
        tables : [{
          rows : [
            [ '123' ]
          ]
        }]
      }
    }
    const http = TestBed.inject(HttpService);
    spyOn(http,'_httpDataGet').and.returnValue(of(result));
    component.getBpSoftFail(0);
    expect(component.idProofCounts[0]).toEqual('123');
  });

  it('should trigger ngAfterViewInit', () => {
    spyOn(component,"loadScript");
    component.ngAfterViewInit();
    expect(component.loadScript).toHaveBeenCalled();
  });

  it('should trigger loadScript', () => {
    component.loadScript();
    expect(component.startDate).not.toBeNull();
    expect(component.endDate).not.toBeNull();
  });

  it('should trigger selectedDate', () => {
    const event = {
      startDate: moment("2023-08-01 00:00:00"),
      endDate: moment("2023-08-08 00:00:00")
    }
    component.selectedDate(event);
    expect(component.startDateFormated).toEqual("2023-07-31T18:30:00");
    expect(component.endDateFormated).toEqual("2023-08-07T18:30:00");
  });

  it('should trigger calcSuccessRate', () => {
    component.idProofCounts = [100,50];
    component.calcSuccessRate(0,1,0);
    expect(component.successRate[0]).toBe(50);
  });

  it('should trigger calcFailureRate', () => {
    component.idProofCounts = [100,50];
    component.calcFailureRate(0,1,0);
    expect(component.failureRate[0]).toBe(50);
  });
});
