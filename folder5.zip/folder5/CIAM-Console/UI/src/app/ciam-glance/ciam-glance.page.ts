import { AfterViewInit, Component, OnInit } from '@angular/core';
import { interval, Subscription } from 'rxjs';
import { AppConfigService } from '../shared-services/ciam-appconfig/app.config.service';
import { HttpService } from '../shared-services/http/http.service';
import { SharedService } from '../shared-services/shared/shared.service';
import * as moment from 'moment';
import * as $ from 'jquery';
import 'daterangepicker';
@Component({
  selector: 'app-ciam-glance',
  templateUrl: './ciam-glance.page.html',
  styleUrls: ['./ciam-glance.page.scss'],
})
export class CiamGlancePage implements OnInit, AfterViewInit {
  appInsightsApiEndPoints = (this.sharedService.loginUser.authStatus == "MasterUser") ? AppConfigService?.settings?.endpoints?.console?.appinsights : AppConfigService?.settings?.endpoints?.console?.appinsightsProd;
  postion1: number = 0;
  postion2: number = 0;
  counts: {
    unique: string;
    total: string;
  }[] = [];

  idProofCounts: any [] = [];

  successRate : any [] = [];
  failureRate : any [] = [];

  time = interval(1000);
  refresh = new Subscription();

  SfaSuccessCount: any;
  SfaFailureCount: any;
  accessClientCount: any;
  glanceHours: any = 1;
  startDate: any;
  endDate: any;
  endDateFormated: string;
  startDateFormated: string;
  showSection: any = false;
  constructor(private http: HttpService, private sharedService: SharedService) { }

  ngOnInit() {

    this.setSectionVisible();
    console.log("Inside ngOnInit");
    // this.UpdateHours(this.glanceHours);
    // this.refresh = this.time.subscribe(x => {
    //   if ((x + 1) % 300 == 0)
    //     this.UpdateHours(this.sharedService.glanceHours);
    // })

  }

  // UpdateHours(event) {
  //   this.sharedService.glanceHours = event;
  //   this.glanceHours = this.sharedService.glanceHours;

  // }

  getCount(event: string, pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name == '" + event + "' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(user_Id),Total = count()").subscribe((result: any) => {
      this.counts[pos] = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  }

  getIdproofCount(event: string, pos,RateCalu :string) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name == '" + event + "' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result: any) => {
      this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
      if(RateCalu !== null) {
        switch(RateCalu){
          case 'CpSucc' :
            this.calcSuccessRate(19,4,1);
            break;
          case 'BpSucc' : 
            this.calcSuccessRate(11,12,2);
            break;
          case 'AolSucc' :
            this.calcSuccessRate(5,6,3);
            break;
          case 'VaolSucc' :
            this.calcSuccessRate(8,23,4);
            break;
          case 'SidpFail' :
            this.calcFailureRate(18,2,0);
            break;
          case 'AolFail' :
            this.calcFailureRate(5,7,3);
            break;
          case 'VaolFail' :
            this.calcFailureRate(8,10,4);
        }
      }
    })
  }

  getIdproofCountUnique(event: string, pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name == '" + event + "' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result: any) => {
      this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
    })
  }

  getBPFailure(pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'BP-FAILURE-INIT' or name=='BP-HARD-FAILURE-INIT')  |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = count()").subscribe((result: any) => {
      this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
      this.calcFailureRate(11,pos,2);
    })
  }

  getSfaSuccessCount() {
    let query1 = "let q1= customEvents | where (name=='SI-SFA-PWD-VALIDATE-SUCCESS' or name=='SI-SFA-GA-VALIDATE-SUCCESS' or name=='SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS' or name=='SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS' or name == 'PROOF-ID-FFA-PASSWORD-SUBMIT-PAYLOAD-DEVICE-RECOGNISED' or name == 'PROOF-ID-FFA-EMAIL-DEVICE-DEVICERECOGNITION' or name == 'PROOF-ID-FFA-MOBILE-DEVICE-DEVICERECOGNITION') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)),Total = count();";
    let query2 = "let q2= customEvents | where name == 'PROOF-ID-SFA-KBA-QUESTIONS-SUCCESS' | where customDimensions.AuthStatus == 'ACKNOWLEDGMENT_REQUIRED' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize  Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    let query3 = "let q3= customEvents | where name == 'PROOF-ID-SFA-KBA-CHALLENGE-QUESTION-SUCCESS' | where customDimensions.AuthStatus == 'ACKNOWLEDGMENT_REQUIRED' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize  Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    this.http._httpDataGet(this.appInsightsApiEndPoints + query1 + query2 + query3 + " union q1,q2,q3 | summarize Unique = sum(Unique), Total = sum(Total)").subscribe((result: any) => {
      this.SfaSuccessCount = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  }

  getSfaFailureCount() {
    let query1 = "let q1= customEvents | where (name=='SI-SFA-PWD-FAILURE' or name=='SI-SFA-PWD-EXCEPTION' or name=='SI-SFA-GA-FAILURE' or name=='SI-SFA-GA-EXCEPTION' or name=='SI-SFA-EMAIL-OOB-VALIDATE-FAILURE' or name=='SI-SFA-EMAIL-OOB-VALIDATE-EXCEPTION' or name=='SI-SFA-MOBILE-OOB-VALIDATE-FAILURE' or name=='SI-SFA-MOBILE-OOB-VALIDATE-EXCEPTION' or name=='SI-SFA-KBA-CHALLENGE-QNS-API-FAILURE' or name=='SI-SFA-KBA-CHALLENGE-QNS-API-EXCEPTION' or name=='SI-SFA-KBA-QNS-API-EXCEPTION' or name=='SI-SFA-KBA-IDV-API-EXCEPTION') and  timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    let query2 = "let q2= customEvents | where name == 'PROOF-ID-SFA-KBA-CHALLENGE-QUESTION-SUCCESS' | where customDimensions.AuthStatus in ('IDENTIFIER_REQUIRED','ALTERNATIVE_AUTH_FACTOR_REQUIRED') |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    let query3 = "let q3= customEvents | where name == 'SI-SFA-KBA-QNS-API-SUCCESS' | where customDimensions.AuthStatus in ('IDENTIFIER_REQUIRED','ALTERNATIVE_AUTH_FACTOR_REQUIRED') |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    let query4 = "let q4= customEvents | where name == 'SI-SFA-KBA-IDV-API-SUCCESS' | where customDimensions.AuthStatus == 'ALTERNATIVE_AUTH_FACTOR_REQUIRED'|where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize Unique = dcount(tostring(customDimensions.Identifier)), Total = count();";
    this.http._httpDataGet(this.appInsightsApiEndPoints + query1 + query2 + query3 + query4 + " union q1,q2,q3,q4 | summarize ConsolidatedUnique = sum(Unique), ConsolidatedTotal = sum(Total)").subscribe((result: any) => {
      this.SfaFailureCount = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  }

  accessByClientCount() {
    this.http._httpDataGet(this.appInsightsApiEndPoints+ "customEvents | where (name == 'SI-DEFAULT-CLIENT' or name == 'SI-MYBLOCK-CLIENT' or name == 'SI-TXO-CLIENT' or name == 'SI-DOT-COM-CLIENT') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize totalDefaultClient = countif(name == 'SI-DEFAULT-CLIENT'), totalMyblockClient = countif(name == 'SI-MYBLOCK-CLIENT'), totalTXOClient = countif(name == 'SI-TXO-CLIENT'), totalDotcomClient = countif(name == 'SI-DOT-COM-CLIENT') ").subscribe((result: any) => {
      this.accessClientCount = {
        DEFAULT_CLIENT:(result?.body?.tables[0]?.rows[0])?result?.body?.tables[0]?.rows[0][0]:0,
        MYBLOCK_CLIENT:(result?.body?.tables[0]?.rows[0])?result?.body?.tables[0]?.rows[0][1]:0,
        TXO_CLIENT:(result?.body?.tables[0]?.rows[0])?result?.body?.tables[0]?.rows[0][2]:0,
        DOTCOM_CLIENT:(result?.body?.tables[0]?.rows[0])?result?.body?.tables[0]?.rows[0][3]:0,
      };    
    })
  }

  getSFAKBACount(pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name=='PROOF-ID-SFA-KBA-QUESTIONS-SUCCESS' or name=='PROOF-ID-SFA-KBA-CHALLENGE-QUESTION-SUCCESS') | where customDimensions.AuthStatus=='ACKNOWLEDGMENT_REQUIRED' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)),Total = count()").subscribe((result: any) => {
      this.counts[pos] = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  }

  getCASuccess(pos){
      this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'CIAM-CA-SUCCESS-INIT' or name == 'GOOGLE_AUTH_SUCCESS_INIT' or name == 'CA-TWO-FA-INIT')  and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | project distinctIdentifier = coalesce(tostring(customDimensions.Email), tostring(customDimensions.Identifier)) | summarize DistinctCount = dcount(distinctIdentifier),TotalCount = count()").subscribe((result: any) => {
        this.counts[pos] = {
          unique: result?.body?.tables[0]?.rows[0][0],
          total: result?.body?.tables[0]?.rows[0][1]
        };
      })
    
  }

  getCountByIdentifier(event: string, pos) {
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name == '" + event + "' |where timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Unique = dcount(tostring(customDimensions.Identifier)),Total = count()").subscribe((result: any) => {
      this.counts[pos] = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  }

  getLookUpFailure(pos){
    this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'SI-LOOKUP-SUBMIT-IDENTIFIER-FAILURE' or name == 'SI-LOOKUP-EXCEPTION') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize DistinctCount = dcount(tostring(customDimensions.Identifier)),TotalCount = count() ").subscribe((result: any) => {
      this.counts[pos] = {
        unique: result?.body?.tables[0]?.rows[0][0],
        total: result?.body?.tables[0]?.rows[0][1]
      };
    })
  
}

getFFASuccess(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'SI-FFA-PWD-API-SUCCESS' or name == 'SI-FFA-EMAIL-OOB-VALIDATE-SUCCESS' or name == 'SI-FFA-MOBILE-OOB-VALIDATE-SUCCESS') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize DistinctCount = dcount(tostring(customDimensions.Identifier)),TotalCount = count() ").subscribe((result: any) => {
    this.counts[pos] = {
      unique: result?.body?.tables[0]?.rows[0][0],
      total: result?.body?.tables[0]?.rows[0][1]
    };
  })

}

getFFAFailure(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'SI-FFA-PWD-API-EXCEPTION' or name == 'SI-FFA-EMAIL-OOB-VALIDATE-FAILURE' or name == 'SI-FFA-EMAIL-OOB-VALIDATE-EXCEPTION'or name == 'SI-FFA-MOBILE-OOB-VALIDATE-FAILURE'or name =='SI-FFA-MOBILE-OOB-VALIDATE-EXCEPTION'or name =='SI-FFA-PASSWORD-LIMIT-EXCEED') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize DistinctCount = dcount(tostring(customDimensions.Identifier)),TotalCount = count() ").subscribe((result: any) => {
    this.counts[pos] = {
      unique: result?.body?.tables[0]?.rows[0][0],
      total: result?.body?.tables[0]?.rows[0][1]
    };
  })

}

getDeviceRecognised(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'PROOF-ID-FFA-PASSWORD-SUBMIT-PAYLOAD-DEVICE-RECOGNISED' or name == 'PROOF-ID-FFA-EMAIL-DEVICE-DEVICERECOGNITION' or name == 'PROOF-ID-FFA-MOBILE-DEVICE-DEVICERECOGNITION') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize DistinctCount = dcount(tostring(customDimensions.Identifier)),TotalCount = count() ").subscribe((result: any) => {
    this.counts[pos] = {
      unique: result?.body?.tables[0]?.rows[0][0],
      total: result?.body?.tables[0]?.rows[0][1]
    };
  })

}

getSIDPKBASuccess(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'UI-SIDP-KBA-ANSWER-SUCCESS' or name =='UI-SIDP_KBA_CHALLENGE_ANSWER_SUCCESS' ) and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize Total = count() ").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
  })

}

getSIDPTaxOOBSuccess(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'API-API-SIDP-TAXOOB-BOTHOOB-IDPROOFED-USER' or name =='API-API-SIDP-TAXOOB-SINGLEOOB-IDPROOFED-USER' ) and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize Total = count() ").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
  })

}

getSIDPTotalSuccess(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where (name == 'API-API-SIDP-TAXOOB-BOTHOOB-IDPROOFED-USER' or name =='API-API-SIDP-TAXOOB-SINGLEOOB-IDPROOFED-USER' or name == 'UI-SIDP-KBA-ANSWER-SUCCESS' or name =='UI-SIDP_KBA_CHALLENGE_ANSWER_SUCCESS'  ) and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "')) | summarize Total = count() ").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
    this.calcSuccessRate(18,pos,0);
  })

}

getBPTypeCount(event: string, pos,ratePos) {
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where customDimensions.ElementParams contains ('\"productType\": "+event+"') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
    this.calcSuccessRate(11,pos,ratePos);
  })
}
getSpruceCount(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where customDimensions.ElementParams contains ('\"isSpruce\": true') and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0] 
    this.calcSuccessRate(11,pos,8);
  })
}

getBpHardFail(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name=='BP-HARD-FAILURE-INIT' and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
  })
}

getBpSoftFail(pos){
  this.http._httpDataGet(this.appInsightsApiEndPoints + "customEvents | where name=='BP-FAILURE-INIT' and timestamp between(datetime('" + this.startDateFormated + "')..datetime('" + this.endDateFormated + "'))| summarize Total = dcount(user_Id)").subscribe((result: any) => {
    this.idProofCounts[pos] = result?.body?.tables[0]?.rows[0][0]
  })
}


  ngAfterViewInit() {
    console.log("Inside ngAfterViewInit");
    this.loadScript();
  }

  loadScript() {
    this.startDate = moment().subtract(1, 'day').startOf('day');
    this.endDate = moment().startOf('day');


    let startDate = moment(this.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(this.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');

    $('input[name="datetimes"]').daterangepicker({
      timePicker: true,
      startDate: this.startDate,
      endDate: this.endDate,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    });
    $('input[name="datetimes"]').on('apply.daterangepicker', ((ev, picker) => {
      this.selectedDate(picker)
    }));
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }
  selectedDate(event) {
    const startDate = moment(event.startDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.startDateFormated = startDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.startDateFormated, 'startDate');
    const endDate = moment(event.endDate.format('YYYY-MM-DD HH:mm:ss')).utc();
    this.endDateFormated = endDate.format('YYYY-MM-DDTHH:mm:ss')
    console.log(this.endDateFormated, 'endDate');
    this.getDataByDate(this.startDateFormated, this.endDateFormated);
  }

  getDataByDate(startDate, endDate) {
    console.log("Inside getDataByDate");

    this.getCount('SI-APP-ONLOAD', 0); //counts[0] 
    this.getCountByIdentifier('SI-LOOKUP-SUBMIT-IDENTIFIER-API', 1); //counts[1]
    this.getCountByIdentifier('SI-LOOKUP-SUBMIT-IDENTIFIER-SUCCESS', 2); //counts[2]
    this.getLookUpFailure(3); //counts[3]
    this.getCount('SI-LOOKUP-CREATE-ACCOUNT-BUTTON', 4); //counts[4]
    this.getCountByIdentifier('SI-LOOKUP-SINGLE-ACCOUNT', 5); //counts[5]
    this.getCountByIdentifier('SI-LOOKUP-MULTIPLE-ACCOUNT', 6); //counts[6]
    this.getFFASuccess(7); //counts[7]
    this.getFFAFailure(8); //counts[8]
    this.getDeviceRecognised(9); //counts[9]
    this.getCount('CIAM-CA-SUBMIT-VALID', 10); //counts[10]
    this.getCASuccess(11); //counts[11]
    this.getCount('SI-EVENT-BACK-TO-PARENT', 12); //counts[12]
    this.getCountByIdentifier('SI-SFA-PWD-VALIDATE-SUCCESS', 13); //counts[13]
    this.getCountByIdentifier('SI-SFA-EMAIL-OOB-VALIDATE-SUCCESS', 14); //counts[14]
    this.getCountByIdentifier('SI-SFA-MOBILE-OOB-VALIDATE-SUCCESS', 15); //counts[15]
    this.getCountByIdentifier('SI-SFA-GA-VALIDATE-SUCCESS', 16); //counts[16]
    this.getSFAKBACount(17); //counts[17]
    this.getCount('CA-EMAIL-OOB-PAGE-INIT', 18); //counts[10]
    this.getSfaSuccessCount();
    this.getSfaFailureCount();
    this.accessByClientCount();

    //SIDP
    this.getIdproofCount('UI-SIDP-INTIATE-API-INVOKE', 0,null); //idproofCounts[0]   Loaded
    this.getIdproofCountUnique('UI-SIDP-CLIENTMATCH-API',18);//idproofCounts[18] Initiate
    this.getSIDPTotalSuccess(17); //idproofCounts[17] Success
    this.getIdproofCount('UI-SIDP-SUCCESS-ONLOAD', 1,null); //idproofCounts[1] Nav success
    this.getSIDPKBASuccess(15); //idproofCounts[15] KBA success
    this.getSIDPTaxOOBSuccess(16); //idproofCounts[16] Tax OOB success
    this.getIdproofCount('UI-SIDP-FAILURE-EVENT-BACK', 2,'SidpFail'); //idproofCounts[2] Failure
    
    //Card proof
    this.getIdproofCount('MA-APP-CARD-PROOF-INIT', 3, null); //idproofCounts[3] Loaded
    this.getIdproofCountUnique('CP-CLIENT-MATCHING-SUBMIT-INIT',19);//idproofCounts[19] Initiated
    this.getIdproofCount('CP-CARD-PIN-MATCHING-SUBMIT-SUCCESS', 4,'CpSucc'); //idproofCounts[4] Success

    //BankProof
    this.getIdproofCount('BP-LANDING-INIT', 11, null); //idproofCounts[11] Initiated
    this.getIdproofCount('BP-SUCCESS-INIT', 12, 'BpSucc'); //idproofCounts[12] Success
    this.getBPTypeCount('ra', 25, 5 ); //idproofCounts[25]
    this.getBPTypeCount('rt', 24, 6 ); //idproofCounts[24]
    this.getBPTypeCount('ec', 26, 7 ); //idproofCounts[26]
    this.getSpruceCount(29); //idproofCounts[29]
    this.getBPFailure(13); //idproofCounts[13] Failure
    this.getBpHardFail(27); //idproofCounts[27]
    this.getBpSoftFail(28); //idproofCounts[28]
    this.getIdproofCount('MFJ-LINK-EXPIRED-INIT', 14,null); //idproofCounts[14] Failure

    //AOL
    this.getIdproofCount('AOL_INIT_SUBMIT', 5, null); //idproofCounts[5] Loaded
    this.getIdproofCountUnique('AOL-PII-CLIENT-MATCHING-SERVICE',21)//idproofCounts[21] Initiaied
    this.getIdproofCount('AOL-SUCCESS-PAGE-INIT', 6, 'AolSucc'); //idproofCounts[6] Success
    this.getIdproofCount('AOL-ERROR-SCREEN-INIT', 7, 'AolFail'); //idproofCounts[7] Failure

    //VAOL
    this.getIdproofCount('VAOL_INIT-SUBMIT', 8, null); //idproofCounts[8] Loaded
    this.getIdproofCount('VAOL-CLIENT-MATCHING-PII-PAGE-INIT',22, null)//idproofCounts[22] Initiated
    this.getIdproofCount('API-VAOL-IDPROOF-PERFORM-PII-SUCCESS', 9, null); //idproofCounts[9] Success
    this.getIdproofCount('VAOL-SUCCESS-PAGE-INIT', 23, 'VaolSucc'); //idproofCounts[23] Nav Success
    this.getIdproofCount('VAOL-ERROR-PAGE-INIT', 10, 'VaolFail'); //idproofCounts[10] Failure


   //MNGACCUNT
   this.getIdproofCount('MA-LANDING-DELETE-CLICK', 30,null);
   this.getIdproofCount('MA-DELETE-SUCCESS', 31,null);
  }


  calcSuccessRate(pos1,pos2,pos){
    var temp :any;
    let attempt = this.idProofCounts[pos1];
    let success = this.idProofCounts[pos2];
    if(attempt !== undefined && success !== undefined && success !== 0 && attempt !== 0) {
      temp = parseFloat(((success/attempt) * 100)?.toFixed(2));
      this.successRate[pos] = (temp>100)? NaN : temp;
    }
    else {
      this.successRate[pos] = 0;
    }
  }

  calcFailureRate(pos1,pos2,pos){
    var temp :any;
    let attempt = this.idProofCounts[pos1];
    let failure = this.idProofCounts[pos2];
    if(attempt !== undefined && failure !== undefined && failure !== 0 && attempt !== 0) {
      temp = parseFloat(((failure/attempt) * 100)?.toFixed(2));
      this.failureRate[pos] = (temp>100)? NaN : temp;
    }
    else {
      this.failureRate[pos] = 0;
    }
  }

  isRateNaN(val): boolean {
    return isNaN(val);
  }

  setSectionVisible(){
    if(this.sharedService.loginUser.authStatus == "AdminUser") {
      this.showSection = false;
    } else {
      this.showSection = true;
    }
  }


  ngOnDestroy() {
    this.refresh?.unsubscribe();
  }
}
