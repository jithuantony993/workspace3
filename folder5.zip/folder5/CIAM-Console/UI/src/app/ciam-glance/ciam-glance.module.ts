import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CiamGlancePageRoutingModule } from './ciam-glance-routing.module';

import { CiamGlancePage } from './ciam-glance.page';
import { ImportsModule } from '../common/imports/imports.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ImportsModule,
    CiamGlancePageRoutingModule
  ],
  declarations: [CiamGlancePage]
})
export class CiamGlancePageModule {}
