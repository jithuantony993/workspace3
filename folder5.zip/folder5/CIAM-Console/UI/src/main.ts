import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';
declare var __webpack_public_path__;
import 'zone.js/dist/zone';
import('./environments/environment').then(value => {
  __webpack_public_path__ = value.environment.baseUrl+"/";

});

if (environment.name === "production") {
  enableProdMode();
}


platformBrowserDynamic().bootstrapModule(AppModule)

  .catch(err => console.log(err));


  