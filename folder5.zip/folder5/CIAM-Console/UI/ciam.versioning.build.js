/**
 * Package version collected from package.json
 * Configured now only in environment.ts/ciam.replace.build
 * Prebuild is run always
 * deploy-url is configured 'ciam-data'
 */

var fs = require('fs');
var path = require('path');
var replaceFile = require('replace-in-file');
var packageJSON = require("./package.json");
var angular = require("./angular.json");
var version = require("./src/assets/version.profile.json"); // Mobile Live Update - Independence
var buildVersion = packageJSON.version;
var buildPath = '/';
var defaultProject = angular.defaultProject;
var appendUrl = '?v=' + buildVersion;

const getNestedObject = (nestedObj, pathArr) => {
  return pathArr.reduce((obj, key) =>
    (obj && obj[key] !== 'undefined') ? obj[key] : undefined, nestedObj);
}
const relativePath = getNestedObject(angular, ['projects', defaultProject, 'architect', 'build', 'options', 'outputPath']); // To identify relative build path when angular build is made
buildPath += relativePath.replace(/[/]/g, '/');
const versionPath = '/' + relativePath.replace(/[/]/g, '/') + '/assets'; // Mobile Live Update - Independence
var indexPath = __dirname + buildPath + '/' + 'index.html';
var versionProfile = __dirname + buildPath + '/assets/' + 'version.profile.json'; // Mobile Live Update - Independence
console.log('Angular build path:', __dirname, buildPath);
console.log('Change by buildVersion:', buildVersion);

fs.readdir(__dirname + buildPath, (err, files) => {
  files.forEach(file => {
    if (file.match(/^(main|polyfills-es5|polyfills|runtime|vendor|scripts|styles)+([a-z0–9.\-])*(js|css)$/g)) { // REGEX is identified by build files generated and append
      console.log('Current Filename:', file);
      const currentPath = file;
      const changePath = file + appendUrl;
      changeIndex(currentPath, changePath);
    }
  });
});

function changeIndex(currentfilename, changedfilename) {
  const options = {
    files: indexPath,
    // from: '"' + currentfilename + '"',
    // to: '"' + changedfilename + '"',
    from: '"' + '/ciam-console/' + currentfilename + '"', // Current filepath after --deploy-url in package.json
    to: '"' + '/ciam-console/' + changedfilename + '"', // Modified filepath after versioning
    allowEmptyPaths: false,
  };

  try {
    let changedFiles = replaceFile.sync(options);
    if (changedFiles == 0) {
      console.log("File updated failed");
    } else if (changedFiles[0].hasChanged === false) {
      console.log("File already updated");
    }
    console.log('Changed Filename:', changedfilename);
  } catch (error) {
    console.error('Error occurred:', error);
    throw error
  }
}

// Mobile Live Update - Independence
fs.readdir(__dirname + versionPath, (err, files) => {
  console.log("dir", __dirname + versionPath, versionProfile);
  console.log("files", files);
  files.forEach(file => {
    if (file == 'version.profile.json') {
      const currentVn = version.version;
      updateVersion(currentVn, buildVersion);
    }
  })
});

function updateVersion(currentVn, newVn) {
  const options = {
    files: versionProfile,
    from: ['"' + currentVn + '"', 'v' + currentVn ],
    to: ['"' + newVn + '"', 'v' + newVn ],
    allowEmptyPaths: false,
  };

  try {
    let changedFiles = replaceFile.sync(options);
    if (changedFiles == 0) {
      console.log("File update failed ");
    } else if (changedFiles[0].hasChanged === false) {
      console.log("File already updated")
    }
    console.log('Changed Filename V:', buildVersion);
  } catch (error) {
    console.error('Error occurred', error);
    throw error
  }
}
